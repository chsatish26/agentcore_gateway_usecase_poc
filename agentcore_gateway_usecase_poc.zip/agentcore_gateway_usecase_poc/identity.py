"""Identity resources this POC owns, and the vault round trip that proves them.

Why this file exists at all is worth recording, because its absence was a real
hole in the POC. The refunds backend performs a genuine token-vault round trip,
but against a workload identity and credential provider that predate this work
(`wid-nb-c5438d5f`, `demo-apikey-37d2ae24` - the Lambda reads both from env
vars). That demonstrated the *capability* and left **nothing attributable to
the POC on the console's credential-provider list**, which is the same gap as
having no gateway to open.

So `setup` now creates two resources under POC names and `destroy` removes
them.

One thing that was not obvious and is worth not rediscovering: `CreateGateway`
auto-creates a workload identity named after the gateway ID, so
`novacart-price-match-poc-qdnpxdyr1x` exists in the identity directory
regardless of this file. `destroy_identity()` does not touch it - deleting a
resource the gateway created implicitly is the gateway's business, and whether
`DeleteGateway` cleans it up is untested.

## The distinction that matters

There are two different things you can do with a credential provider, and
conflating them would undermine the whole security argument:

* **Provisioning and verifying** - an operator creates the provider, stores a
  secret in the vault, and confirms it can be retrieved. This is an admin
  action. It happens once, at `setup`, from a terminal, under a human's IAM
  identity. That is what `verify_round_trip()` below is.

* **Consuming at request time** - the *backend behind the gateway* fetches the
  credential at the moment it needs it, having been reached through an
  authorised tool call. The agent never sees it. That is what `RefundToolEcho`
  does, and it is the architecture the POC is arguing for.

`verify_round_trip()` is deliberately **not** called from the agent path. An
agent that fetches its own credentials is exactly the design this architecture
exists to avoid, and a demo that blurred the two would be arguing against
itself. It runs at provisioning time, prints a masked preview, and stops.

The API key stored here is synthetic and generated locally. No real credential
is involved, and the plaintext is never printed or written to disk - only a
masked preview ever leaves this module.
"""

import secrets
from typing import Any, Dict, Optional

import boto3
import botocore.exceptions

import config


def _control():
    return boto3.client('bedrock-agentcore-control', region_name=config.REGION)


def _data():
    return boto3.client('bedrock-agentcore', region_name=config.REGION)


def mask(secret: Optional[str]) -> str:
    """Masked preview, in the same shape the refunds backend returns.

    Three leading characters and three trailing, which is enough to confirm two
    sides are talking about the same credential and not enough to use it.
    """
    if not secret:
        return '(none)'
    if len(secret) <= 8:
        return '***'
    return f'{secret[:3]}***{secret[-3:]}'


def synthetic_api_key() -> str:
    """A locally generated stand-in for a payment provider key.

    Prefixed so that anybody who finds it in the vault can tell at a glance
    that it is not a real credential and nothing is protected by it.
    """
    return f'novacart-poc-synthetic-{secrets.token_hex(16)}'


# ------------------------------------------------------------------ provision

def ensure_workload_identity(control, say) -> Dict[str, str]:
    """Create or adopt the POC's workload identity.

    This is the agent's own name in the identity directory - the thing a
    workload access token is issued *for*. It is not a credential.
    """
    name = config.WORKLOAD_IDENTITY_NAME
    try:
        existing = control.get_workload_identity(name=name)
        say(f'  workload identity  {name} (existing)')
        return {'name': name, 'arn': existing['workloadIdentityArn']}
    except botocore.exceptions.ClientError as exc:
        if exc.response['Error']['Code'] != 'ResourceNotFoundException':
            raise

    created = control.create_workload_identity(name=name)
    say(f'  workload identity  {name} (created)')
    return {'name': name, 'arn': created['workloadIdentityArn']}


def ensure_credential_provider(control, say) -> Dict[str, Any]:
    """Create or adopt the POC's API key credential provider.

    An existing provider is adopted rather than rotated. `UpdateApiKey...`
    would replace the stored secret, and silently changing a credential that
    something else might be mid-flight on is not a thing a demo should do.
    """
    name = config.CREDENTIAL_PROVIDER_NAME
    try:
        existing = control.get_api_key_credential_provider(name=name)
        say(f'  credential provider {name} (existing, secret left alone)')
        return {'name': name,
                'arn': existing['credentialProviderArn'],
                'created': False}
    except botocore.exceptions.ClientError as exc:
        if exc.response['Error']['Code'] != 'ResourceNotFoundException':
            raise

    created = control.create_api_key_credential_provider(
        name=name, apiKey=synthetic_api_key())
    say(f'  credential provider {name} (created, synthetic secret)')
    return {'name': name,
            'arn': created['credentialProviderArn'],
            'created': True}


def ensure_identity(say=print) -> Dict[str, Any]:
    """Provision both, so there is something named for the POC in the console."""
    control = _control()
    workload = ensure_workload_identity(control, say)
    provider = ensure_credential_provider(control, say)
    return {'workload_identity_name': workload['name'],
            'workload_identity_arn': workload['arn'],
            'credential_provider_name': provider['name'],
            'credential_provider_arn': provider['arn']}


# --------------------------------------------------------------------- verify

def verify_round_trip(workload_name: str = None, provider_name: str = None,
                      say=print) -> Dict[str, Any]:
    """Prove the vault actually returns the secret, at provisioning time.

    Two calls, both on the data plane:

        GetWorkloadAccessToken(workloadName)  -> a short-lived workload token
        GetResourceApiKey(token, providerName) -> the stored secret, plaintext

    The second call is the one worth understanding. The caller does not present
    the credential; it presents *proof of which workload it is* and the vault
    decides what that workload may retrieve. So rotating the secret never
    touches the workload, and revoking the workload never touches the secret.

    Returns a masked result. The plaintext is discarded inside this function
    and is never logged, printed or persisted.
    """
    workload_name = workload_name or config.WORKLOAD_IDENTITY_NAME
    provider_name = provider_name or config.CREDENTIAL_PROVIDER_NAME
    data = _data()

    result: Dict[str, Any] = {'workloadName': workload_name,
                              'providerName': provider_name}
    try:
        token_response = data.get_workload_access_token(
            workloadName=workload_name)
    except botocore.exceptions.ClientError as exc:
        result['ok'] = False
        result['error'] = (f"{exc.response['Error']['Code']}: "
                           f"{exc.response['Error']['Message'][:160]}")
        say(f'  vault round trip   FAILED at GetWorkloadAccessToken '
            f"- {result['error']}")
        return result

    token = token_response.get('workloadAccessToken')
    result['tokenIssued'] = bool(token)
    result['tokenPreview'] = mask(token)

    try:
        key_response = data.get_resource_api_key(
            workloadIdentityToken=token,
            resourceCredentialProviderName=provider_name)
    except botocore.exceptions.ClientError as exc:
        result['ok'] = False
        result['error'] = (f"{exc.response['Error']['Code']}: "
                           f"{exc.response['Error']['Message'][:160]}")
        say(f'  vault round trip   token issued, but GetResourceApiKey failed '
            f"- {result['error']}")
        return result

    # The plaintext exists only in this local for the length of one expression.
    result['ok'] = True
    result['apiKeyMasked'] = mask(key_response.get('apiKey'))
    say(f"  vault round trip   OK - workload token issued, secret retrieved "
        f"({result['apiKeyMasked']})")
    return result


# -------------------------------------------------------------------- teardown

def destroy_identity(say=print) -> list:
    """Delete only the two resources this POC created.

    The backend's own `wid-nb-c5438d5f` / `demo-apikey-37d2ae24` are not
    touched: they predate this POC, the Lambda reads them from its environment,
    and removing them would break a function other demos share.
    """
    control = _control()
    removed = []
    for label, call, kwargs in [
            ('credential provider', control.delete_api_key_credential_provider,
             {'name': config.CREDENTIAL_PROVIDER_NAME}),
            ('workload identity', control.delete_workload_identity,
             {'name': config.WORKLOAD_IDENTITY_NAME})]:
        try:
            call(**kwargs)
            removed.append(f"{label} {kwargs['name']}")
            say(f"  deleted {label} {kwargs['name']}")
        except botocore.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == 'ResourceNotFoundException':
                say(f"  {label} {kwargs['name']} already gone")
            else:
                say(f"  could not delete {label} {kwargs['name']}: "
                    f"{exc.response['Error']['Code']}")
    return removed
