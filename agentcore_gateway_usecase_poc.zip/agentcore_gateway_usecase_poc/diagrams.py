"""Graphviz diagrams for the POC walkthrough.

Each returns DOT source for `st.graphviz_chart`. Kept separate from the app so
they can be rendered to PNG for a slide pack without starting Streamlit:

    python -c "import diagrams; print(diagrams.decision_path())" | dot -Tpng -o path.png

Two conventions carried through all of them, because a management audience reads
colour before it reads labels:

* **blue** is the governed path - through the gateway, subject to policy.
* **amber** is ungoverned - the browser, which Cedar cannot see.

The amber is not decoration. It is the one structural gap in this POC and the
diagram should make somebody ask about it.
"""

GOVERNED = '#31527a'
UNGOVERNED = '#b8860b'
ALLOW = '#1e7f3f'
DENY = '#c5221f'
MUTED = '#80868b'

_HEAD = ('digraph G {\n'
         '  rankdir=%s; bgcolor="transparent";\n'
         '  node [fontname="Helvetica", fontsize=10, shape=box, '
         'style="rounded,filled", color="#cfd8e3", fillcolor="white"];\n'
         '  edge [fontname="Helvetica", fontsize=9, color="%s"];\n')


def use_case_flow() -> str:
    """The four steps of one claim, each on its own capability.

    The arrow labels carry the argument: the amount is *computed* between steps
    2 and 3, so policy adjudicates a number nobody chose.
    """
    return (_HEAD % ('TB', MUTED)) + f'''
  claim  [label="Customer claim\\n\\"a competitor is cheaper\\"", fillcolor="#f1f6fb", color="{GOVERNED}"];
  search [label="1. WEB SEARCH\\nwhich pages have the price?", color="{GOVERNED}", fillcolor="#f1f6fb"];
  browse [label="2. BROWSER\\nwhat does the page say now?", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
  amount [label="the gap is computed here\\nours − theirs = refund", shape=note, color="{MUTED}", fillcolor="#f8f9fa"];
  policy [label="3. POLICY\\nmay we refund THIS amount?", color="{GOVERNED}", fillcolor="#f1f6fb"];
  ident  [label="4. IDENTITY\\nwhich credential moves it?", color="{GOVERNED}", fillcolor="#f1f6fb"];
  done   [label="claim settled", color="{ALLOW}", fillcolor="#eaf5ec"];
  refuse [label="refused, and the rule\\nthat refused is named", color="{DENY}", fillcolor="#fdecea"];

  claim  -> search;
  search -> browse [label=" candidate URLs "];
  browse -> amount [label=" live price "];
  amount -> policy [label=" an amount nobody typed "];
  policy -> ident  [label=" allowed "];
  policy -> refuse [label=" denied ", color="{DENY}"];
  ident  -> done;
}}
'''


def gateway_stack() -> str:
    """What `setup` builds, and what deliberately sits outside it."""
    return (_HEAD % ('TB', MUTED)) + f'''
  agent [label="the agent\\nholds NO tool credentials\\nonly its own AWS identity", color="{GOVERNED}", fillcolor="#f1f6fb"];

  subgraph cluster_gw {{
    label="AgentCore Gateway  ·  novacart-price-match-poc";
    fontname="Helvetica"; fontsize=10; color="{GOVERNED}";
    style="rounded"; bgcolor="#fbfdff";
    inbound [label="inbound identity\\nAWS_IAM (SigV4)"];
    cedar   [label="policy engine\\nCedar · ENFORCE\\n3 policies", color="{GOVERNED}", fillcolor="#e8f0fa"];
    t1      [label="target \\"research\\"\\nconnector web-search 1.2.0"];
    t2      [label="target \\"novacart\\"\\nlambda RefundToolEcho"];
    inbound -> cedar;
    cedar -> t1; cedar -> t2;
  }}

  web   [label="the live web", shape=ellipse, color="{MUTED}"];
  vault [label="TOKEN VAULT\\ncredential fetched at call time", color="{GOVERNED}", fillcolor="#e8f0fa"];

  subgraph cluster_br {{
    label="Browser  ·  data plane  ·  NOT governed by Cedar";
    fontname="Helvetica"; fontsize=10; color="{UNGOVERNED}";
    style="rounded,dashed"; bgcolor="#fffdf5";
    chrome [label="managed Chrome\\nCDP over websocket", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
  }}

  agent -> inbound [label=" signed POST /mcp "];
  agent -> chrome  [label=" IAM only ", color="{UNGOVERNED}", style=dashed];
  t1 -> web;
  t2 -> vault;
  chrome -> web [color="{UNGOVERNED}", style=dashed];
}}
'''


def decision_path() -> str:
    """Where authorisation happens relative to the backend.

    The ordering is the entire security argument, so it gets its own diagram:
    policy runs at (2), the backend at (3). A refused call never reaches a
    credential.
    """
    return (_HEAD % ('LR', MUTED)) + f'''
  call [label="tool call\\nprocess_refund(amount)", color="{GOVERNED}", fillcolor="#f1f6fb"];
  one [label="① inbound identity\\nwho is calling?"];
  two [label="② POLICY\\nCedar sees the\\nARGUMENTS", color="{GOVERNED}", fillcolor="#e8f0fa"];
  three [label="③ outbound identity\\nwhich credential\\nfor this target?"];
  back [label="backend runs\\nmoney moves"];
  stop [label="DENIED here\\nno credential fetched\\nno backend call", color="{DENY}", fillcolor="#fdecea"];

  call -> one -> two;
  two -> three [label=" allowed "];
  three -> back;
  two -> stop [label=" denied ", color="{DENY}"];
}}
'''


def tool_visibility() -> str:
    """Why the rollout order is forced: ENFORCE with no policies hides everything."""
    return (_HEAD % ('LR', MUTED)) + f'''
  a [label="engine attached\\nENFORCE, 0 policies", color="{DENY}", fillcolor="#fdecea"];
  b [label="tools/list returns\\nNOTHING\\n(targets are READY)", color="{DENY}", fillcolor="#fdecea"];
  c [label="so: LOG_ONLY first", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
  d [label="discover the 3\\npublished tool names"];
  e [label="write policies\\nagainst real names"];
  f [label="flip to ENFORCE\\n2 of 3 tools visible", color="{ALLOW}", fillcolor="#eaf5ec"];

  a -> b [label=" nothing to\\n write policies about "];
  b -> c [style=dashed];
  c -> d -> e -> f;
}}
'''
