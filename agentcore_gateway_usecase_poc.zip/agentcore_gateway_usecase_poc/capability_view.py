"""The 'Six capabilities' page: one requirement per tab, evidence under each.

Split out of `streamlit_app.py` because it is a self-contained deliverable -
six rows of a requirements table, each needing its own evidence rendering - and
folding 400 more lines into an app that was already 800 would have made both
harder to read.

Everything here is read from `artifacts/capabilities_*.json`, written by
`python run_poc.py capabilities`. The page cannot assert anything the probe did
not observe, which is the same constraint the rest of the app works under and
the reason the statuses are trustworthy.

The per-capability **Re-probe** buttons are the demo. They call AWS when
pressed and never on load, so the page opens instantly, and a sceptic in the
room can watch the evidence regenerate rather than taking a JSON file on
faith. Policy is the one to press: it runs the $99/$100/$101 sweep live and
takes about five seconds.
"""

from typing import Any, Dict, List, Optional

import streamlit as st

import capabilities
import config

STATUS_STYLE = {
    capabilities.PROVEN: ('#1e7f3f', '#eaf5ec', '✅'),
    capabilities.PARTIAL: ('#b8860b', '#fdf6e3', '◐'),
    capabilities.BLOCKED: ('#c5221f', '#fdecea', '🛑'),
}

# Policy verdicts are shown with the same banner as capability statuses but
# are a different kind of thing, so they get their own entries rather than
# being folded into STATUS_STYLE. They match the main app's colours on
# purpose: a denial should look the same here as it does on 'Walk a claim'.
VERDICT_STYLE = {
    'ALLOWED': ('#1e7f3f', '#eaf5ec', '✅'),
    'DENIED': ('#c5221f', '#fdecea', '🛑'),
}

INTEGRATION_NOTE = {
    'Direct': 'The gateway itself calls this service, or is called by it.',
    'Indirect': 'The agent uses both; the two services never talk to each '
                'other.',
    'Optional/Indirect': 'Available through a custom tool, not built in.',
}


def _chip(status: str) -> str:
    colour, background, icon = STATUS_STYLE.get(
        status, ('#80868b', '#f8f9fa', 'ℹ️'))
    return (f"<span style='background:{background};color:{colour};"
            f"padding:2px 10px;border-radius:12px;font-weight:700;"
            f"font-size:0.85rem;white-space:nowrap'>{icon} {status}</span>")


def _banner(status: str, headline: str, detail: str = '') -> None:
    colour, background, icon = STATUS_STYLE.get(
        status, VERDICT_STYLE.get(status, ('#80868b', '#f8f9fa', 'ℹ️')))
    st.markdown(
        f"<div style='background:{background};border-left:6px solid {colour};"
        f"padding:12px 16px;border-radius:4px'>"
        f"<div style='color:{colour};font-weight:700'>{icon} {status} — "
        f"{headline}</div>"
        + (f"<div style='color:#3c4043;margin-top:6px'>{detail}</div>"
           if detail else '')
        + '</div>', unsafe_allow_html=True)


def _count(value: Any) -> str:
    """Format a CloudWatch Sum as a count.

    Every counter comes back as a float because GetMetricData returns doubles,
    and `24.0 denials` reads like a rounding artefact rather than a number of
    events.
    """
    if value is None:
        return '—'
    if isinstance(value, float) and value.is_integer():
        return f'{int(value):,}'
    return f'{value:,}' if isinstance(value, (int, float)) else str(value)


def _total(block: Optional[Dict[str, Any]], key: str) -> str:
    """Pull a metric total out of the observability shape, tolerating gaps."""
    if not isinstance(block, dict):
        return '—'
    entry = block.get(key)
    if not isinstance(entry, dict):
        return '—'
    return _count(entry.get('total'))


def _claims(evidence: Dict[str, Any]) -> None:
    """The proven / not-proven split, side by side.

    Both columns always render. A page that only showed the left one would be
    marketing, and the right-hand column is the reason anybody should believe
    the left.
    """
    left, right = st.columns(2, gap='large')
    with left:
        st.markdown('**What this establishes**')
        for item in evidence.get('proven') or []:
            st.markdown(f'- {item}')
    with right:
        st.markdown('**What it does not**')
        for item in evidence.get('not_proven') or []:
            st.markdown(f'- {item}')


def _reprobe(key: str, label: str, estimate: str) -> None:
    """A button that regenerates this capability's evidence against AWS."""
    if not st.button(f'Re-probe {label} now', key=f'probe_{key}',
                     help=f'Calls AWS and rewrites the evidence file. '
                          f'About {estimate}.'):
        return
    lines: List[str] = []
    with st.spinner(f'Probing {label} against account 196856463470…'):
        bundle = capabilities.probe_all(only=[key], say=lines.append)
        path = capabilities.write_evidence(bundle)
    st.success(f'Evidence rewritten — {path.split("/")[-1]}. '
               f'Status: {bundle["evidence"][key].get("status")}')
    st.code('\n'.join(line for line in lines if line.strip()), language='text')
    st.caption('Reload the page or re-pick the newest bundle in the sidebar to '
               'see the refreshed numbers below.')


# ------------------------------------------------------------------- runtime

def render_runtime(evidence: Dict[str, Any]) -> None:
    contract = evidence.get('contract') or {}
    hosted = evidence.get("hosted") or evidence.get("deploy") or {}
    target = evidence.get('as_target') or {}

    _banner(evidence.get('status', '—'),
            f"the agent is hosted on AWS, speaks Runtime's contract, and is "
            f"refused by Cedar from in there",
            f"Runtime `{hosted.get('runtime_id', 'not deployed')}` — "
            f"{hosted.get('status', 'unknown')}, "
            f"{hosted.get('network_mode', '—')} networking")

    st.markdown('#### ① The agent implements Runtime’s contract')
    st.caption('Runtime requires exactly two routes on port 8080 and is silent '
               'when you get them wrong. The harness boots the real server and '
               'checks each one.')

    rows = ['| Check | Expected | Result | Observed |', '|---|---|---|---|']
    for check in contract.get('checks') or []:
        observed = check.get('observed')
        rows.append(f"| `{check.get('check')}` | {check.get('expected')} | "
                    f"{'✅' if check.get('ok') else '❌'} | "
                    f"`{str(observed)[:90]}` |")
    st.markdown('\n'.join(rows))

    if contract.get('ok'):
        st.success(f"{contract.get('passed')}/{contract.get('total')} passed. "
                   'The last row is the one that matters: driven through '
                   '`/invocations`, the agent reached the live gateway and was '
                   '**refused by name**. The hosted copy hits the same '
                   'ceiling, because the ceiling is not in the agent.')

    st.markdown('---')
    st.markdown('#### ② AWS is hosting it')

    if not hosted.get('invoked'):
        st.warning(
            f"The hosted agent did not answer this probe, so this row is "
            f"scored on the local contract alone. Reported: "
            f"`{hosted.get('why_not') or hosted.get('invoke_error') or hosted.get('status')}`")
        st.code('\n'.join(hosted.get('deploy_commands') or []), language='bash')
    else:
        served = hosted.get('served_by') or {}
        st.caption('Not a capability check — an actual invocation of the '
                   'deployed agent, made while this evidence was written.')
        cols = st.columns(4)
        cols[0].metric('Status', hosted.get('status', '—'),
                       help=f"version {hosted.get('version')}")
        cols[1].metric('Services reached',
                       len(hosted.get('services_touched') or []))
        cols[2].metric('Round trip', f"{hosted.get('total_ms', 0):.0f} ms")
        cols[3].metric('Refund verdict',
                       'DENIED' if hosted.get('denied_by') else 'allowed')

        st.markdown(f'''
The agent runs as the identity below. It is a role session **AgentCore
created** when it started the process — nothing on a developer's machine can
produce one, which is what turns "it is hosted" from a claim into something
you can check.

```
{served.get('identity', '—')}
```

From inside that process it reached
**{', '.join(hosted.get('services_touched') or [])}**, and the refund it tried
was refused by **`{hosted.get('denied_by') or 'nothing this run'}`**. The
artifact is a {hosted.get('artifact_mode', 'zip')} — the container image this
row once waited on turned out not to be required at all.
''')
        with st.expander('What the hosted agent reported, step by step'):
            for step in hosted.get('trace') or []:
                st.markdown(
                    f"**{step.get('seq')}. {step.get('service')}** · "
                    f"`{step.get('api')}` · **{step.get('verdict')}** · "
                    f"{step.get('latency_ms') or 0:.0f} ms  \n"
                    f"{step.get('detail', '')}")
            st.caption(f"Session {hosted.get('session_id', '—')}, probed "
                       f"{hosted.get('probed_at')}. The ‘Ask the hosted agent’ "
                       f"page draws this same structure for a prompt you type.")

    build = hosted.get('build_blocked_by') or {}
    with st.expander('Why a zip and not a container image'):
        cols = st.columns(4)
        cols[0].metric('Docker daemon',
                       '✅' if build.get('docker_daemon') else '❌')
        cols[1].metric('buildx', '✅' if build.get('buildx') else '❌')
        cols[2].metric('Host arch', build.get('host_arch', '—'))
        cols[3].metric('A container would need',
                       build.get('runtime_requires', '—'))
        st.markdown(f'''
This host cannot build the image a container runtime needs — {build.get('why_not')
or 'it can, in fact'}. That used to be recorded here as the blocker on the
whole row.

It was a correct measurement and the wrong conclusion. `agentRuntimeArtifact`
also accepts `codeConfiguration`: a zip in S3 run by a managed interpreter,
which needs no Docker, no ECR and no cross-compilation. Three accurate
measurements composed into a false conclusion because they shared one
unexamined premise — that the artifact had to be an image.

Reproduce the runtime from nothing:
''')
        st.code('\n'.join(hosted.get('deploy_commands') or []), language='bash')

    st.markdown('---')
    st.markdown('#### ③ The other direction — a Runtime agent *as* a tool')
    left, right = st.columns([1, 1], gap='large')
    with left:
        st.markdown(f'''
A gateway target of type **`{target.get('target_type')}`** takes an endpoint, so
a Runtime agent that speaks MCP can be published as a tool other agents call
through the same gateway — inheriting the same Cedar policies.

The shape below is read from the live service model, not from documentation.
''')
        st.warning(f"**Not exercised.** {target.get('why_not')} "
                   f"{target.get('account_runtimes_ready')} runtimes are "
                   f"`READY` in this account and none of them are ours.")
    with right:
        st.json(target.get('example') or {}, expanded=True)
        with st.expander('Accepted target types, from the live API'):
            st.json(target.get('shapes') or {}, expanded=False)

    st.markdown('---')
    _claims(evidence)


# ------------------------------------------------------------------ identity

def render_identity(evidence: Dict[str, Any]) -> None:
    resources = evidence.get('resources') or {}
    round_trip = evidence.get('round_trip') or {}
    metrics = evidence.get('metrics') or {}

    _banner(evidence.get('status', '—'),
            'the POC owns identity resources and the vault returns the secret',
            'Corroborated by CloudWatch counters that this POC does not write.')

    left, middle, right = st.columns(3, gap='large')
    with left:
        st.markdown('**① Provisioned** — an admin action, once')
        for label, item in resources.items():
            icon = '✅' if item.get('exists') else '❌'
            st.markdown(f"{icon} `{item.get('name')}`  \n"
                        f"<span style='color:#80868b;font-size:0.8rem'>"
                        f"{label.replace('_', ' ')}</span>",
                        unsafe_allow_html=True)
        st.caption('Created by `setup`, deleted by `destroy`. These are what '
                   'you now see on the console’s Identity page.')
    with middle:
        st.markdown('**② The vault round trip**')
        if round_trip.get('ok'):
            st.success(f"Token issued, secret retrieved  \n"
                       f"`{round_trip.get('apiKeyMasked')}`")
            st.markdown(f'''
```
GetWorkloadAccessToken({round_trip.get('workloadName')})
  -> workload token
GetResourceApiKey(token, {round_trip.get('providerName')})
  -> the stored secret
```
''')
            st.caption('The caller never presents the credential. It presents '
                       'proof of *which workload it is*, and the vault decides '
                       'what that workload may retrieve.')
        else:
            st.error(f"Round trip failed: {round_trip.get('error')}")
    with right:
        st.markdown('**③ Consumed** — per request, by the backend')
        consumed = evidence.get('consumed_at_request_time') or {}
        st.code(str(consumed.get('backend', '—')).split(':function:')[-1],
                language='text')
        st.caption(consumed.get('note', ''))

    st.markdown('---')
    st.markdown('#### The independent check')
    st.caption('This is the part worth pointing at. The round trip above is '
               'this POC marking its own homework. The numbers below are the '
               '*service* counting vault activity, dimensioned by our '
               'provider name, in a namespace we do not write to.')
    cols = st.columns(2)
    for column, name in zip(cols, ('WorkloadAccessTokenFetchSuccess',
                                   'ApiKeyFetchSuccess')):
        entry = metrics.get(name) or {}
        column.metric(name, _count(entry.get('total')))
        column.caption(f"`{entry.get('dimension', '—')}` · "
                       f"{entry.get('means', '')}")

    st.markdown('---')
    _claims(evidence)


# -------------------------------------------------------------------- policy

def _reconcile(overall: Dict[str, Any], by_policy: Dict[str, Any]) -> None:
    """Check the per-policy counters add up to the totals, and say so.

    This is the check to do in front of an auditor, and it is computed here
    rather than asserted in the probe so that it visibly fails if the numbers
    ever stop agreeing. Two denial routes exist and the service keeps them in
    separate counters: a rule you wrote said no, versus nothing you wrote said
    yes. They are different governance stories.
    """
    def total(block, key):
        entry = (block or {}).get(key) or {}
        value = entry.get('total')
        return value if isinstance(value, (int, float)) else 0

    named_allows = sum(total(c, 'AllowDecisions') for c in by_policy.values())
    named_denies = sum(total(c, 'DenyDecisions') for c in by_policy.values())
    allows = total(overall, 'AllowDecisions')
    denies = total(overall, 'DenyDecisions')
    defaults = total(overall, 'NoDeterminingPolicies')

    allows_agree = named_allows == allows
    denies_agree = named_denies + defaults == denies

    body = (f"- allows: {' + '.join(str(int(total(c, 'AllowDecisions'))) for c in by_policy.values() if total(c, 'AllowDecisions'))} "
            f"= **{int(allows)}** {'✅' if allows_agree else '⚠️'}\n"
            f"- denies: {int(named_denies)} named by a rule + {int(defaults)} "
            f"denied by default = **{int(denies)}** "
            f"{'✅' if denies_agree else '⚠️'}")

    if allows_agree and denies_agree:
        st.success(f'**Every decision is accounted for.**\n\n{body}\n\n'
                   f'So the {int(defaults)} default-denials are visibly '
                   f'distinguishable from the {int(named_denies)} deliberate '
                   f'refusals — *nothing you wrote said yes* is not the same '
                   f'finding as *a rule you wrote said no*, and you can tell '
                   f'them apart without reading a log.')
    else:
        st.warning('**The per-policy counters do not add up to the totals.**\n\n'
                   + body + '\n\nMost likely a policy was deleted inside the '
                   'metric window, so its decisions are still counted overall '
                   'but it no longer appears in `ListPolicies`.')


def render_policy(evidence: Dict[str, Any]) -> None:
    boundary = evidence.get('boundary') or []
    metrics = (evidence.get('metrics') or {})
    overall = metrics.get('overall') or {}

    _banner(evidence.get('status', '—'),
            f"the ${config.AUTO_APPROVE_LIMIT} limit holds exactly, and "
            f"refusals name the rule",
            f"Policy engine `{evidence.get('policy_engine_id')}` in "
            f"`{evidence.get('mode')}`.")

    st.markdown('#### The boundary, probed live')
    columns = st.columns(len(boundary) or 1, gap='large')
    for column, row in zip(columns, boundary):
        with column:
            _banner(row.get('verdict'), f"${row.get('amount')}",
                    (f"by <code>{row.get('deciding_policy')}</code>"
                     if row.get('deciding_policy')
                     else 'within the limit')
                    + f" · {row.get('latency_ms')} ms")
    if evidence.get('boundary_holds'):
        st.success(f"**${config.AUTO_APPROVE_LIMIT} passes and "
                   f"${config.AUTO_APPROVE_LIMIT + 1} does not** — not "
                   f"approximately, exactly where the policy says. A limit you "
                   f"cannot locate precisely is a limit you cannot write a "
                   f"policy document about.")

    st.markdown('---')
    left, right = st.columns([1, 1], gap='large')
    with left:
        st.markdown('#### Default-deny, demonstrated')
        st.markdown(f"Tools the agent can see: "
                    + ', '.join(f'`{t}`' for t in
                                evidence.get('tools_visible') or []))
        if evidence.get('ungranted_tool_hidden'):
            st.success(f"`{evidence.get('ungranted_tool')}` is granted by no "
                       f"policy and is **absent from `tools/list`**. The agent "
                       f"is not resisting temptation — it was never told the "
                       f"option exists.")
        else:
            st.warning(f"`{evidence.get('ungranted_tool')}` is visible in the "
                       f"tool list. Expected it to be filtered.")
    with right:
        st.markdown('#### The rules in force')
        for policy in evidence.get('policies') or []:
            if policy.get('error'):
                st.error(policy['error'])
                continue
            st.markdown(f"- `{policy.get('name')}` — "
                        f"{policy.get('status', '').lower()}")
        st.caption('Three policies. Cedar reads `context.input`, which *is* '
                   'the tool’s arguments — the thing IAM cannot do. IAM can '
                   'say "may call process_refund"; it cannot say "…up to '
                   '$100".')

    st.markdown('---')
    st.markdown('#### What the service recorded, independently')
    cols = st.columns(4)
    labels = (('AllowDecisions', 'Allowed'), ('DenyDecisions', 'Denied'),
              ('DeterminingPolicies', 'A rule decided it'),
              ('NoDeterminingPolicies', 'Denied by default'))
    for column, (name, label) in zip(cols, labels):
        entry = overall.get(name) or {}
        column.metric(label, _count(entry.get('total')))
        column.caption(entry.get('means', ''))

    by_policy = metrics.get('by_policy') or {}
    if by_policy:
        st.markdown('**Per Cedar policy** — this is the governance answer')
        rows = ['| Policy | Allowed | Denied |', '|---|---|---|']
        for policy_id, counts in by_policy.items():
            rows.append(
                f"| `{policy_id}` | "
                f"{_total(counts, 'AllowDecisions')} | "
                f"{_total(counts, 'DenyDecisions')} |")
        st.markdown('\n'.join(rows))
        st.caption('An auditor can ask "how often did that specific rule fire '
                   'last month" and get a number out of CloudWatch — without '
                   'reading a log line or trusting this POC’s transcripts.')
        _reconcile(overall, by_policy)

    st.markdown('---')
    _claims(evidence)


# ------------------------------------------------------------- observability

def render_observability(evidence: Dict[str, Any]) -> None:
    discovered = evidence.get('discovered') or {}
    gateway = evidence.get('gateway') or {}
    traces = evidence.get('traces') or {}
    logs = evidence.get('logs') or {}

    _banner(evidence.get('status', '—'),
            f"{discovered.get('metric_count', 0)} metrics vended for this "
            f"gateway — and this POC instruments nothing",
            'Metrics, latency and errors are live. Traces are not: '
            'Transaction Search is off in this account.')

    st.info(f"**The finding worth leading with.** Nothing in this POC emits a "
            f"single metric, and every number on this page exists anyway. The "
            f"gateway vends them per request into "
            f"`{evidence.get('namespace')}` — "
            f"{discovered.get('stream_count', 0)} distinct dimension sets for "
            f"this one gateway. So this requirement is satisfied by work we "
            f"did not have to do.")

    st.markdown(f"#### Gateway health — last {evidence.get('window_days')} days")
    cols = st.columns(3)
    cols[0].metric('Invocations', _total(gateway, 'Invocations'))
    latency = (gateway.get('Latency') or {}).get('mean')
    cols[1].metric('Mean gateway latency',
                   f'{latency:.0f} ms' if latency else '—')
    backend = (gateway.get('TargetExecutionTime') or {}).get('mean')
    cols[2].metric('Mean backend execution',
                   f'{backend:.0f} ms' if backend else '—')

    if latency and backend and backend > latency:
        st.caption(
            f'**That second number is larger than the first, and it should '
            f'be.** `TargetExecutionTime` is only recorded for calls that '
            f'reached a target, so it averages over a different, smaller set '
            f'of requests than `Latency` does. The {_total(gateway, "UserErrors")} '
            f'policy denials below never touched the backend and were fast, '
            f'which pulls the overall mean down. Enforcement is not what makes '
            f'this gateway slow — refusing is the cheapest thing it does.')
    else:
        st.caption('`TargetExecutionTime` covers only calls that reached a '
                   'target, so it averages over a smaller set of requests '
                   'than `Latency`; the two are not a subset relationship.')

    cols = st.columns(3)
    cols[0].metric('User errors', _total(gateway, 'UserErrors'))
    cols[1].metric('System errors', _total(gateway, 'SystemErrors'))
    cols[2].metric('Throttles', _total(gateway, 'Throttles'))
    st.caption('`UserErrors` counts calls rejected for something the caller '
               'did — a policy denial lands here, which is why the number is '
               'not zero and should not be read as a fault.')

    per_tool = evidence.get('per_tool') or {}
    if per_tool and not per_tool.get('error'):
        st.markdown('#### Per tool')
        rows = ['| Tool | Invocations | Mean latency |', '|---|---|---|']
        for tool, metrics in per_tool.items():
            mean = (metrics.get('Latency') or {}).get('mean')
            rows.append(f"| `{tool}` | {_total(metrics, 'Invocations')} | "
                        f"{f'{mean:.0f} ms' if mean else '—'} |")
        st.markdown('\n'.join(rows))
        st.caption('The `Name` dimension carries the published '
                   '`<target>___<tool>` string, so this is the view that shows '
                   'which capability the agent actually leaned on.')

    st.markdown('---')
    st.markdown('#### Traces — the honest negative')
    left, right = st.columns([1.2, 1], gap='large')
    with left:
        st.warning(f'''
**Not available, and it is an account setting rather than a service gap.**

AgentCore ships gateway spans to CloudWatch through **Transaction Search**,
which flips the X-Ray segment destination to `CloudWatchLogs`. Here it reads
**`{traces.get('destination')}`**, sampling is at
**{(traces.get('sampling') or ['—'])[0]}%**, and there were
**{traces.get('traces_last_24h')} traces in the last 24 hours**.

Turning it on is an account-wide change with a billing impact. This is a shared
account with other teams' workloads in it, so it was not switched on
unilaterally — that is a decision with an owner, and the owner is not this POC.
''')
    with right:
        st.markdown('**Log groups**')
        for prefix, info in (logs.get('prefixes') or {}).items():
            st.markdown(f"- `{prefix}` — {info.get('count', info.get('error'))}")
        if not logs.get('gateway_has_log_group'):
            st.caption('There is **no** log group for a gateway. AgentCore '
                       'vends them for Runtime and Memory only, so gateway '
                       'observability is metrics-only until Transaction '
                       'Search is on. Said plainly because an empty log group '
                       'list otherwise looks like a misconfiguration.')
        if logs.get('ours'):
            st.markdown('**Ours**')
            for name in logs['ours']:
                st.markdown(f'- `{name}`')

    with st.expander(f"Every metric the service vends for this gateway "
                     f"({discovered.get('metric_count', 0)})"):
        for name, dimension_sets in (discovered.get('metrics') or {}).items():
            st.markdown(f'**{name}** — {len(dimension_sets)} dimension sets')
            st.caption(', '.join(
                sorted({','.join(sorted(d)) for d in dimension_sets})))
        st.caption('Note the trap: gateway-invocation metrics key on '
                   '`Resource` (the full ARN) while policy-decision metrics '
                   'key on `TargetResource` (the bare ID). Same gateway, same '
                   'namespace, two dimension names. Querying with the wrong '
                   'one returns an empty series rather than an error, which '
                   'reads exactly like a broken integration.')

    st.markdown('---')
    _claims(evidence)


# -------------------------------------------------------------------- memory

def render_memory(evidence: Dict[str, Any]) -> None:
    recalled = evidence.get('recalled') or {}
    first = evidence.get('first_request') or {}
    repeat = evidence.get('repeat_request') or {}

    _banner(evidence.get('status', '—'),
            'claims are remembered across processes, and recall confers no '
            'authority',
            f"Memory `{evidence.get('memory_id')}` · actor "
            f"`{evidence.get('actor_id')}` · "
            f"{evidence.get('expiry_days')}-day expiry.")

    st.markdown('#### Why this one is *indirect*')
    st.markdown('''
Memory and Gateway do not know about each other. There is no `memoryId` on a
gateway, no memory configuration on a target, and Cedar can neither read nor
write a memory record. What makes them one architecture is only that the same
agent uses both, for different things:

| | Service | Question it answers |
|---|---|---|
| **Authority** | Gateway + Policy | What is this agent allowed to *do*? |
| **Continuity** | Memory | What is this agent allowed to *recall*? |

So the demonstration is not "look, they are connected". It is the opposite, and
it is a security property.
''')

    st.markdown('---')
    st.markdown('#### The demo: remembering a refusal does not weaken it')

    left, middle, right = st.columns([1, 1, 1], gap='large')
    with left:
        st.markdown('**① Ask**')
        _banner(first.get('verdict', '—'),
                f"${(first.get('arguments') or {}).get('amount')}",
                f"by <code>{first.get('deciding_policy')}</code>"
                if first.get('deciding_policy') else '')
    with middle:
        st.markdown('**② Remember**')
        st.success(f"{(evidence.get('wrote') or {}).get('turns', 0)} turns "
                   f"written to session "
                   f"`{(evidence.get('wrote') or {}).get('session_id')}`")
        st.caption('Including the refusal and the Cedar policy that caused '
                   'it — the interesting case, not just the happy path.')
    with right:
        st.markdown('**③ Ask again, now remembering**')
        _banner(repeat.get('verdict', '—'),
                f"${(repeat.get('arguments') or {}).get('amount')}",
                f"by <code>{repeat.get('deciding_policy')}</code>"
                if repeat.get('deciding_policy') else '')

    if evidence.get('verdict_unchanged_by_memory'):
        st.success('**Same verdict.** The agent has perfect recall of having '
                   'been refused and is refused again identically, because '
                   'authority lives at the gateway and nothing in Memory can '
                   'vote on it. An agent whose memory *could* influence its '
                   'permissions would be an agent you could talk into a refund '
                   'by convincing it that it had been allowed one before — '
                   'prompt injection with a persistence layer.')

    st.markdown('---')
    st.markdown('#### What came back out of Memory')
    st.caption(f"Read with `ListEvents` in a separate process from the one "
               f"that wrote it. {recalled.get('count', 0)} turns, newest "
               f"first — the order the API returns, left alone deliberately.")
    for event in recalled.get('events') or []:
        with st.chat_message('user' if event.get('role') == 'USER'
                             else 'assistant'):
            st.markdown(event.get('text') or '')
            st.caption(f"`{event.get('event_id')}` · {event.get('at')}")

    sessions = evidence.get('sessions') or []
    long_term = evidence.get('long_term') or {}
    left, right = st.columns(2, gap='large')
    with left:
        st.markdown(f'**Sessions in this memory** ({len(sessions)})')
        for session in sessions:
            st.markdown(f'- `{session}`')
        st.caption('`ListEvents` needs both an actor and a session, and '
                   '`ListSessions` needs an actor. There is no way to sweep a '
                   'memory without knowing who you are looking for — a '
                   'sensible tenancy boundary, but it means the actor ID has '
                   'to stay stable across runs.')
    with right:
        st.markdown('**Long-term memory**')
        if not long_term.get('strategies_configured'):
            st.info(f"**Not configured, and the empty result is correct.** "
                    f"{long_term.get('note')}")
        else:
            st.json(long_term.get('records') or [])

    st.markdown('---')
    _claims(evidence)


# ------------------------------------------------------------------- browser

def render_browser(evidence: Dict[str, Any]) -> None:
    blocked = evidence.get('wrapper_blocked_by') or {}
    used = evidence.get('used_in_use_case') or {}

    _banner(evidence.get('status', '—'),
            'the browser works and is load-bearing — but it is reached off '
            'the gateway, not through it',
            f"Requirement as written: exposed through custom MCP tools "
            f"accessed via Gateway. That is the part that cannot be built "
            f"here.")

    st.markdown('#### What the browser actually does in this use case')
    left, right = st.columns([1, 1], gap='large')
    with left:
        cols = st.columns(2)
        cols[0].metric('Price read from the page',
                       f"${used.get('price_read')}" if used.get('price_read')
                       else '—')
        cols[1].metric('Refund then adjudicated',
                       f"${used.get('refund_adjudicated')}"
                       if used.get('refund_adjudicated') else '—')
        st.markdown(f'''
- **Browser** `{evidence.get('browser_id')}` — managed Chrome
  `{used.get('browser_version', '—')}`, running in AWS
- **Provenance** `{used.get('price_source', '—')}` — the retailer's own
  machine-readable offer price, not a number inferred from the words on the page
- **Rendered** {used.get('rendered_chars') or 0:,} characters
- **From run** `{used.get('from_run', '—')}`
''')
        st.success('**It is in the critical path.** The price the browser '
                   'reads is the number Cedar then adjudicates. Change the '
                   'competitor’s price and the authorisation outcome changes '
                   'with it — so this is not a side demo bolted onto a policy '
                   'story.')
    with right:
        st.markdown('**Reached via**')
        st.code(evidence.get('reached_via', '—'), language='text')
        st.warning('''
**This is the one gap in the fence, and it is worth volunteering.**

The browser is authorised by IAM alone. Cedar cannot see it, so an agent could
browse somewhere we would rather it did not. It only *reads*, which is why this
has not bitten us — it cannot move money.
''')

    st.markdown('---')
    st.markdown('#### Why it is not a gateway tool — asked of IAM, not remembered')
    st.caption('Exposing the browser through the gateway means publishing a '
               'custom MCP tool, which means a Lambda. A policy simulation '
               'answers whether we could create one. It changes nothing.')

    cols = st.columns(3)
    cols[0].metric('Action', blocked.get('action', '—'))
    cols[1].metric('IAM decision', blocked.get('decision', '—'))
    cols[2].metric('Allowed by the org?',
                   '✅' if blocked.get('allowed_by_organizations') else '❌')
    st.markdown(f"Denied by: "
                + ', '.join(f'`{p}`' for p in
                            blocked.get('matched_policies') or ['—']))
    st.info('**Read that carefully, because it is a useful distinction.** The '
            'organisation *permits* creating Lambdas — the account’s own '
            'policy is what denies it. So this is not an AgentCore limitation '
            'and not an org-level control; it is one line of this sandbox’s '
            'IAM policy, and the wrapper is about a day of work wherever that '
            'line is absent.')

    browsers = evidence.get('browsers') or []
    with st.expander(f'Custom browsers in this account ({len(browsers)}) — '
                     f'none of them ours'):
        st.caption(f"`ListBrowsers` returns *custom* browsers only. "
                   f"`{evidence.get('browser_id')}` is the service-managed one "
                   f"and never appears here — an empty list would not have "
                   f"meant 'no browser'.")
        for item in browsers:
            st.markdown(f"- `{item.get('name') or item.get('id')}` — "
                        f"{item.get('status', item.get('error'))}")

    st.markdown('---')
    _claims(evidence)


RENDERERS = {
    'runtime': render_runtime,
    'identity': render_identity,
    'policy': render_policy,
    'observability': render_observability,
    'memory': render_memory,
    'browser': render_browser,
}

PROBE_COST = {
    'runtime': ('Runtime', '90 seconds — it boots a server and probes '
                           'CreateAgentRuntime twice'),
    'identity': ('Identity', '10 seconds'),
    'policy': ('Policy', '5 seconds — it runs the $99/$100/$101 sweep live'),
    'observability': ('Observability', '15 seconds'),
    'memory': ('Memory', '20 seconds — it writes a claim and reads it back'),
    'browser': ('Browser', '5 seconds'),
}


# ---------------------------------------------------------------------- page

def render(bundle: Optional[Dict[str, Any]]) -> None:
    st.title('Six AgentCore services, one gateway')
    st.subheader('The requirement, and what each row is actually worth',
                 divider='blue')

    if not bundle:
        st.warning(
            'No capability evidence found in `artifacts/`. Everything on this '
            'page is read from a real probe, so there is nothing to show yet.'
            '\n\nProduce it with:\n\n'
            '```bash\npython run_poc.py setup         # once, if not already\n'
            'python run_poc.py capabilities\n```')
        return

    summary = bundle.get('summary') or {}
    counts = summary.get('counts') or {}

    cols = st.columns(4)
    cols[0].metric('Requirements', summary.get('total', 0))
    cols[1].metric('Proven', counts.get(capabilities.PROVEN, 0))
    cols[2].metric('Partial', counts.get(capabilities.PARTIAL, 0))
    cols[3].metric('Blocked', counts.get(capabilities.BLOCKED, 0))

    carried = bundle.get('carried') or {}
    st.caption(f"Probed {bundle.get('generated')} against account "
               f"{bundle.get('account')} / {bundle.get('region')}, gateway "
               f"`{bundle.get('gateway_id')}`."
               + (f"  ·  {len(bundle.get('probed') or [])} of "
                  f"{summary.get('total', 6)} rows were measured in this run; "
                  f"the rest are carried forward and labelled on their tabs."
                  if carried else ''))

    rows = ['| AgentCore service | Integration | How it uses Gateway | Status |',
            '|---|---|---|---|']
    for requirement in bundle.get('requirements') or []:
        evidence = (bundle.get('evidence') or {}).get(
            requirement['key']) or {}
        rows.append(
            f"| **{requirement['service']}** | {requirement['integration']} | "
            f"{requirement['claim']} | {_chip(evidence.get('status', '—'))} |")
    st.markdown('\n'.join(rows), unsafe_allow_html=True)

    st.caption(' · '.join(f'**{status}** — {meaning}'
                          for status, meaning
                          in capabilities.STATUS_MEANING.items()))

    st.info('**Why three of these are not green.** Two services cannot be '
            'fully exercised in this sandbox and one requirement cannot be '
            'built here at all. Each carries the measured reason and the date '
            'it was measured, on its own tab. A table of six greens would be '
            'a more comfortable deliverable and a worse one — the first person '
            'to try `CreateAgentRuntime` in this account would find out in '
            'about ten seconds that one of them was a lie.')

    st.markdown('---')

    labels = {}
    for requirement in bundle.get('requirements') or []:
        evidence = (bundle.get('evidence') or {}).get(
            requirement['key']) or {}
        _, _, icon = STATUS_STYLE.get(evidence.get('status'),
                                      ('', '', 'ℹ️'))
        labels[f"{icon} {requirement['service'].replace('AgentCore ', '')}"] = (
            requirement, evidence)

    tabs = st.tabs(list(labels))
    for tab, (requirement, evidence) in zip(tabs, labels.values()):
        with tab:
            key = requirement['key']
            st.markdown(f"### {requirement['service']}  "
                        f"{_chip(evidence.get('status', '—'))}",
                        unsafe_allow_html=True)
            st.markdown(f"> *{requirement['claim']}*")
            st.caption(f"**{requirement['integration']}** — "
                       f"{INTEGRATION_NOTE.get(requirement['integration'], '')}"
                       f"  ·  Demo path: *{requirement['demo']}*")

            if key in carried:
                st.caption(f"⏳ **Carried forward from the run of "
                           f"{carried[key]}** — this row was not re-measured "
                           f"in the selected bundle. Press the button at the "
                           f"bottom of this tab to refresh it.")

            if evidence.get('error'):
                st.error(f"This probe failed: `{evidence['error']}` — "
                         f"{evidence.get('message', '')}")

            with st.expander('What this POC built for it, and the API calls '
                             'behind the evidence'):
                for item in requirement.get('built') or []:
                    st.markdown(f'- {item}')
                st.caption('Evidence from: ' + ', '.join(
                    f'`{call}`' for call in
                    requirement.get('evidence_calls') or []))

            st.markdown('---')
            renderer = RENDERERS.get(key)
            if renderer:
                renderer(evidence)

            st.markdown('---')
            st.info(f"**The line to say.** {requirement.get('talking_point')}")

            label, estimate = PROBE_COST.get(key, (key, 'a moment'))
            _reprobe(key, label, estimate)
