"""Command line entry point for the NovaCart price-match POC.

    python run_poc.py setup         build the persistent gateway (idempotent)
    python run_poc.py status        what exists right now
    python run_poc.py run           run the scenario against it
    python run_poc.py capabilities  evidence for the six AgentCore services
    python run_poc.py destroy       delete what setup created

`setup` and `run` are separate on purpose. The gateway is meant to outlive any
one demo: you build it once, open it in the console, and run the scenario
against it as many times as you like. That is the opposite of the capability
evaluation next door, which tears its stack down in a `finally:` and therefore
leaves nothing to look at.
"""

import argparse
import json
import os
import sys
import time

import config
import gateway_stack


def _save_transcript(transcript: dict) -> str:
    os.makedirs(config.ARTIFACT_DIR, exist_ok=True)
    path = os.path.join(config.ARTIFACT_DIR,
                        f"run_{time.strftime('%Y%m%d_%H%M%S')}.json")
    with open(path, 'w') as handle:
        json.dump(transcript, handle, indent=2, default=str)
    return path


def main() -> int:
    parser = argparse.ArgumentParser(
        description='NovaCart price-match POC on AgentCore Gateway')
    parser.add_argument('command',
                        choices=['setup', 'status', 'run', 'capabilities',
                                 'destroy'])
    parser.add_argument('--case', choices=['small', 'large', 'evasion'],
                        help='run a single case instead of all of them')
    parser.add_argument('--only', nargs='+',
                        choices=['runtime', 'identity', 'policy',
                                 'observability', 'memory', 'browser'],
                        help='capabilities: probe a subset instead of all six')
    parser.add_argument('--log-only', action='store_true',
                        help='setup: leave the gateway in LOG_ONLY so nothing '
                             'is blocked yet (how a real rollout starts)')
    parser.add_argument('--yes', action='store_true',
                        help='destroy: skip the confirmation prompt')
    args = parser.parse_args()

    if args.command == 'setup':
        gateway_stack.setup(enforce=not args.log_only)
        print('\nNext: python run_poc.py run')
        return 0

    if args.command == 'status':
        report = gateway_stack.status()
        return 0 if report.get('exists') else 1

    if args.command == 'run':
        import scenario
        transcript = scenario.run_all(only=args.case)
        path = _save_transcript(transcript)
        print(f'\nTranscript: {path}')
        shots = sorted(f for f in os.listdir(config.ARTIFACT_DIR)
                       if f.endswith('.png'))
        if shots:
            print(f'Screenshots: {len(shots)} in {config.ARTIFACT_DIR}/ '
                  '(what the agent actually saw)')
        return 0

    if args.command == 'capabilities':
        import capabilities
        bundle = capabilities.probe_all(only=args.only)
        path = capabilities.write_evidence(bundle)
        counts = bundle['summary']['counts']
        print(f"\n{'Requirement':<26} {'Integration':<18} Status")
        for row in bundle['summary']['rows']:
            print(f"  {row['service']:<24} {row['integration']:<18} "
                  f"{row['status']}")
        print(f"\n{counts.get('PROVEN', 0)} proven, "
              f"{counts.get('PARTIAL', 0)} partial, "
              f"{counts.get('BLOCKED', 0)} blocked")
        print(f'Evidence: {path}')
        print('Open the Streamlit app and pick "Six capabilities" to walk it.')
        # A blocked requirement is a recorded finding, not a failed run. The
        # exit code reflects whether the probing worked, not whether every
        # service was available in this sandbox.
        return 0

    # destroy
    report = gateway_stack.status(verbose=False)
    if not report.get('exists'):
        print(f'Nothing to destroy: no gateway named {config.GATEWAY_NAME}.')
        return 0
    print(f"About to delete gateway {report['gateway_id']}, its "
          f"{len(report['targets'])} targets, the policy engine, "
          f"{len(report['policies'])} policies, the POC's own identity pair "
          f"and the POC's own memory ({config.MEMORY_NAME}).")
    print('The reused refunds Lambda and its credential provider are NOT '
          'touched, and neither are the other demos\' memories.')
    if not args.yes:
        if input('Type "destroy" to confirm: ').strip() != 'destroy':
            print('Cancelled.')
            return 1
    problems = gateway_stack.destroy()
    if problems:
        print('\nProblems during teardown:')
        for problem in problems:
            print(f'  {problem}')
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
