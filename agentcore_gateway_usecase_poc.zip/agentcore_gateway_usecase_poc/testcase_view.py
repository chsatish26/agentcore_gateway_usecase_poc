"""Three test cases, step by step, in language that needs no AWS background.

Every other page here is organised by *service*: which ones took part, what
each one returned. That is the right shape for an engineer and the wrong shape
for the question a management audience actually asks, which is:

    the agent said no three times - were those the same "no"?

They were not, and the difference is the entire governance story. So this page
is organised by *case* instead. One agent, one tool, three prompts that differ
only in a number or a verb, walked through the same six stages side by side, so
the exact stage where they diverge is visible rather than described.

The page has two halves and the order matters:

  1. the **storyboard** - what should happen at each stage of each case, with
     no AWS call at all. Readable on a plane, and it commits to a prediction.
  2. the **live run** - the same three prompts sent to the hosted agent, their
     real traces drawn next to the prediction.

Predicting first and measuring second is the point. A demo that only shows the
measurement asks the audience to accept that the result is the interesting one;
a prediction written down beforehand can be wrong in public, which is what
makes it worth anything when it is right.
"""

import time
import uuid
from typing import Any, Dict, List, Optional

import streamlit as st

import runtime_view
import trace_log

# The six stages every one of the three cases passes through, in order. Shared
# deliberately: three columns against the same six rows is what makes the fork
# legible. A per-case stage list would read as three unrelated stories, which
# is exactly the impression to avoid - they are the same story up to the point
# where the platform intervenes.
STAGES = [
    ('ask', '📥', 'The ask arrives',
     'Streamlit calls InvokeAgentRuntime. The agent is already running on AWS '
     'under its own IAM role; nothing of it runs in this app.'),
    ('remember', '🧠', 'The agent remembers',
     'It reads earlier claims for this customer out of AgentCore Memory, from '
     'sessions that ended before this one started.'),
    ('allowed', '🚪', 'It asks what it is allowed to use',
     'It calls tools/list on the gateway. The list that comes back is already '
     'filtered by policy, so it is a vocabulary, not a menu with locked items.'),
    ('decide', '🤖', 'The model decides',
     'Bedrock picks a tool and its arguments from that list. This is the only '
     'stage where the model has any say.'),
    ('act', '🛡️', 'The platform allows or refuses',
     'The call goes to the gateway, Cedar evaluates it, and the target runs '
     'only if the policy permits. The agent cannot skip this step.'),
    ('record', '📊', 'It is written down',
     'The outcome goes into Memory, and the whole run into CloudWatch. Both '
     'happen whether the answer was yes or no.'),
]

# status drives the colour, and the three values mean three different things:
# 'ok' happened normally, 'stop' is where the platform intervened, 'none' is a
# stage that had nothing to do. 'stop' is the row to point at in a demo.
CASES = [
    {
        'key': 'allowed',
        'label': '✅ Case 1 — inside the limit',
        'sub': 'A $15 refund. Everything works.',
        'preset': 0,
        'outcome': 'The refund is paid.',
        'enforced_by': 'Cedar, which **permitted** it — a decision, not an '
                       'absence of one.',
        'watch': 'Policy appears in the trace with verdict ALLOWED. If it were '
                 'missing, you could not tell a permitted call from an '
                 'unchecked one.',
        'stages': {
            'ask': ('ok', 'A verified price-match claim for $15.'),
            'remember': ('ok', 'Recalls earlier claims. They are context — the '
                               'system prompt says so explicitly — so they '
                               'cannot settle this one.'),
            'allowed': ('ok', 'Two tools: web search and process_refund.'),
            'decide': ('ok', 'Searches for the competitor price, then asks for '
                             'process_refund with amount 15.'),
            'act': ('ok', 'Cedar permits it. The Lambda target runs, fetches '
                          'the payment key from the Identity vault itself, and '
                          'pays. The agent never sees a credential.'),
            'record': ('ok', 'Three turns written to Memory, spans and stdout '
                             'to CloudWatch.'),
        },
    },
    {
        'key': 'denied',
        'label': '🛑 Case 2 — over the limit',
        'sub': 'A $101 refund. Same agent, same tool, bigger number.',
        'preset': 1,
        'outcome': 'The refund is refused, and the rule is named.',
        'enforced_by': 'A Cedar policy at the gateway — '
                       '`novacart_block_large_refunds`.',
        'watch': 'The refusal has a **measured latency** of its own (~150 ms), '
                 'because the gateway evaluated the policy, refused, and '
                 'returned without invoking the target. No money moved.',
        'stages': {
            'ask': ('ok', 'A verified price-match claim for $101.'),
            'remember': ('ok', 'Same recall. Nothing in it forbids this.'),
            'allowed': ('ok', 'The same two tools. process_refund is '
                              'permitted — it is the *argument* that is not.'),
            'decide': ('ok', 'The model asks for process_refund with amount '
                             '101. It is not being careless: the prompt is '
                             'specific and the claim is legitimate.'),
            'act': ('stop', 'Cedar refuses. The target is never invoked. The '
                            'error names the deciding policy, and the agent '
                            'reports the refusal rather than retrying or '
                            'working around it.'),
            'record': ('ok', 'The refusal is written to Memory too. A denial '
                             'is an outcome, not a gap.'),
        },
    },
    {
        'key': 'absent',
        'label': '👻 Case 3 — a tool nobody granted',
        'sub': '$40 of store credit. There is no store-credit tool.',
        'preset': 2,
        'outcome': 'The agent says it cannot, and names what it looked for.',
        'enforced_by': 'The policy-filtered tool list. Nothing refuses '
                       'anything, because nothing is ever attempted.',
        'watch': 'There is **no Policy step at all**, and that is correct. The '
                 'capability was absent from the vocabulary, so there was '
                 'nothing to decide.',
        'stages': {
            'ask': ('ok', 'Issue store credit — explicitly not a refund.'),
            'remember': ('ok', 'Recalls the refund from case 1, which is '
                               'relevant context and still not permission.'),
            'allowed': ('ok', 'Two tools come back. Neither issues store '
                              'credit. This is the stage that decides the '
                              'case, four steps before anyone notices.'),
            'decide': ('none', 'The model has nothing to call, so it answers '
                               'in words. The system prompt forbids '
                               'substituting an adjacent tool — issuing a '
                               'refund is not issuing store credit — because '
                               'early runs did exactly that and moved $40.'),
            'act': ('none', 'No tool call, so no gateway call and no Cedar '
                            'decision.'),
            'record': ('ok', 'Written down like any other turn.'),
        },
    },
]

STATUS_STYLE = {
    'ok': ('#1e7f3f', '#eaf5ec', 'happened'),
    'stop': ('#c5221f', '#fdecea', 'stopped here'),
    'none': ('#80868b', '#f1f3f4', 'nothing to do'),
}


def fork_diagram() -> str:
    """One agent, three prompts, three places the story can end.

    The shape is the argument: the three paths share everything up to the point
    where the platform acts, which is why "the agent refused" is the wrong
    description of two of the three endings.
    """
    return ('digraph T {\n'
            '  rankdir=LR; bgcolor="transparent"; nodesep=0.25; ranksep=0.45;\n'
            '  node [fontname="Helvetica", fontsize=9, shape=box, '
            'style="rounded,filled", fillcolor="white", color="#80868b"];\n'
            '  edge [fontname="Helvetica", fontsize=8, color="#80868b"];\n'
            '  app [label="📱 your prompt", shape=note, fillcolor="#f8f9fa"];\n'
            '  rt [label="🏗️ one hosted agent\\nsame code, same role"];\n'
            '  lst [label="🚪 tools/list\\npolicy-filtered"];\n'
            '  mdl [label="🤖 the model picks"];\n'
            '  ced [label="🛡️ Cedar decides", fillcolor="#fff8e1", '
            'color="#b06000"];\n'
            '  paid [label="✅ Case 1\\nrefund paid\\n$15 permitted", '
            'color="#1e7f3f", fillcolor="#eaf5ec", penwidth=2];\n'
            '  ref [label="🛑 Case 2\\nrefused by name\\n$101 blocked", '
            'color="#c5221f", fillcolor="#fdecea", penwidth=2];\n'
            '  abs [label="👻 Case 3\\nnever offered\\nstore credit absent", '
            'color="#80868b", fillcolor="#f1f3f4", penwidth=2, '
            'style="rounded,filled,dashed"];\n'
            '  app -> rt [label=" InvokeAgentRuntime "];\n'
            '  rt -> lst; lst -> mdl [label=" 2 tools "];\n'
            '  lst -> abs [label=" no such tool ", style=dashed];\n'
            '  mdl -> ced [label=" tools/call "];\n'
            '  ced -> paid [label=" permit "];\n'
            '  ced -> ref [label=" forbid "];\n'
            '}\n')


def _stage_cell(status: str, text: str) -> None:
    colour, background, _ = STATUS_STYLE.get(status, STATUS_STYLE['none'])
    st.markdown(
        f"<div style='border-left:4px solid {colour};background:{background};"
        f"padding:8px 10px;border-radius:5px;margin-bottom:6px;"
        f"min-height:92px'>"
        f"<div style='color:#3c4043;font-size:.82rem'>{text}</div>"
        f"</div>", unsafe_allow_html=True)


def _storyboard() -> None:
    """The six stages × three cases grid. No AWS calls."""
    header = st.columns([1.1, 1, 1, 1], gap='small')
    header[0].markdown('**Stage**')
    for index, case in enumerate(CASES):
        header[index + 1].markdown(f"**{case['label']}**")
        header[index + 1].caption(case['sub'])

    for key, icon, name, explain in STAGES:
        row = st.columns([1.1, 1, 1, 1], gap='small')
        with row[0]:
            st.markdown(f"{icon} **{name}**")
            st.caption(explain)
        for index, case in enumerate(CASES):
            status, text = case['stages'].get(key, ('none', '—'))
            with row[index + 1]:
                _stage_cell(status, text)

    row = st.columns([1.1, 1, 1, 1], gap='small')
    row[0].markdown('🏁 **How it ends**')
    row[0].caption('Three outcomes that all sound like “no” from outside.')
    for index, case in enumerate(CASES):
        with row[index + 1]:
            st.markdown(f"**{case['outcome']}**")
            st.caption(f"Enforced by {case['enforced_by']}")
            st.info(case['watch'])


def _live_run(state: Dict[str, Any]) -> None:
    """Send all three prompts to the hosted agent and draw what came back."""
    st.markdown('### Now run the three against the hosted agent')
    st.caption(
        f"Three real `InvokeAgentRuntime` calls to "
        f"`{state['agentRuntimeId']}`, in one session so the agent's own "
        f"history is in play, with a claim number generated now — a reused "
        f"claim number lets the agent recall an earlier demo run and answer "
        f"from memory without calling the tool, which looks like success and "
        f"proves nothing. Takes about 30 seconds.")

    if st.button('Run all three test cases', type='primary'):
        claim = runtime_view.fresh_claim()
        session = str(uuid.uuid4())
        results: List[Dict[str, Any]] = []
        progress = st.progress(0.0, text='starting…')
        for index, case in enumerate(CASES):
            label, prompt, _ = runtime_view.PRESETS[case['preset']]
            progress.progress(index / len(CASES), text=f'{label} …')
            started = time.time()
            sent = prompt.format(claim=f'{claim}-{index + 1}')
            try:
                result, elapsed = runtime_view.invoke(
                    state['agentRuntimeArn'],
                    {'prompt': sent, 'browser': False},
                    session)
                result['_round_trip_ms'] = elapsed
                if result.get('_session'):
                    session = result['_session']
                trace_log.record(sent, result, source='testcase',
                                 session=session)
            except Exception as exc:                    # noqa: BLE001
                result = {'error': f'{type(exc).__name__}: {exc}',
                          '_round_trip_ms': (time.time() - started) * 1000}
            results.append(result)
        progress.progress(1.0, text='done')
        st.session_state.tc_results = results
        st.session_state.tc_claim = claim

    results = st.session_state.get('tc_results')
    if not results:
        st.info('Nothing has been sent yet. This page makes no AWS calls until '
                'you press the button.')
        return

    st.caption(f"Claim number for this run: "
               f"`{st.session_state.get('tc_claim', '?')}`")

    # The comparison first: it is the whole point, and it is three numbers.
    rows = []
    for case, result in zip(CASES, results):
        trace = result.get('trace') or []
        policy = (result.get('services') or {}).get('Policy') or {}
        stop = next((s for s in trace if s['verdict'] == 'DENIED'), None)
        rows.append({
            'case': case['label'],
            'steps': len(trace),
            'services': len(result.get('services') or {}),
            'policy': (policy.get('verdict') or 'never consulted'),
            'stopped at': (f"step {stop['seq']} · {stop['api']}" if stop
                           else '—'),
            'agent ms': round(result.get('total_ms') or 0.0),
        })
    st.dataframe(rows, width='stretch', hide_index=True)
    st.caption(
        'Read the `policy` column across the three rows. ALLOWED, DENIED and '
        '*never consulted* are the three distinct states, and only the middle '
        'one is what people usually picture when they hear “the agent was '
        'blocked”.')

    columns = st.columns(3, gap='medium')
    for column, case, result in zip(columns, CASES, results):
        with column:
            st.markdown(f"**{case['label']}**")
            if result.get('error'):
                st.error(result['error'])
                continue
            trace = result.get('trace') or []
            st.graphviz_chart(runtime_view.step_flow(trace), width='stretch')
            st.markdown(f"> {(result.get('reply') or '—')[:420]}")
            where = (result.get('where') or {}).get('runtime') or {}
            if where.get('arn'):
                st.caption(f"ran at `{where['arn']}`")
            with st.expander('Raw trace'):
                st.json(trace, expanded=False)

    st.caption(
        'The three diagrams are the same data the table above is drawn from. '
        'Case 1 is longest because a permitted call does more work; case 3 is '
        'shortest because the capability was never in the agent’s vocabulary, '
        'so there was nothing to refuse.')


def render() -> None:
    st.title('Three test cases, step by step')
    st.subheader('One agent, three prompts, three different reasons it can '
                 'say no', divider='blue')

    st.markdown('''
The three cases below differ by one number and one verb. The agent, its code,
its IAM role and its tool list are identical in all three. Everything that
makes the outcomes different is **outside the agent**, which is the claim this
whole POC exists to support.

Read it twice: once as the storyboard — what should happen — and once as the
live run underneath, which is the same three prompts actually sent to the
hosted agent.
''')

    st.graphviz_chart(fork_diagram(), width='stretch')
    st.caption('The three paths share everything up to the point where the '
               'platform acts. That is why “the agent refused” is the wrong '
               'description of two of these three endings.')

    st.markdown('---')
    st.markdown('### The storyboard: six stages, three cases')
    st.caption('Green happened, red is where the platform intervened, grey had '
               'nothing to do. No AWS call is made to draw this — it is the '
               'prediction, and the live run below is the check on it.')
    _storyboard()

    st.markdown('---')
    state: Optional[Dict[str, Any]] = runtime_view.runtime_state()
    if not state or not state.get('agentRuntimeArn'):
        st.warning(
            'The storyboard above needs nothing. The live run needs a deployed '
            'runtime, and there is none recorded.\n\n'
            '```bash\ncd agentcore_runtime_deployment\n'
            'python deploy.py preflight\npython deploy.py deploy\n```')
        return
    _live_run(state)

    st.markdown('---')
    st.markdown('''
### Why the third case is the one to dwell on

Cases 1 and 2 are a permission check, and an audience accepts those readily
because every system they have ever used has them. Case 3 is different in kind:
there is no "you may not do that" anywhere in it. The capability is simply
absent from what the agent knows how to do, because no policy grants it.

Nothing in `agent.py` names a tool. It asks the gateway what it may use and
hands that answer to the model, so **revoking a policy removes a capability
with no code change and no redeploy** — and an agent cannot be talked into
using a tool it was never told about.
''')
