"""All traces — every prompt ever sent from this app, with its full trace.

*Ask the hosted agent* answers "what just happened". This answers "what has
ever happened", which is a different question and the one an auditor actually
asks. It reads `artifacts/traces/` rather than session state, so it survives a
restart of Streamlit, a closed browser, and the next press of the button.

It makes **no AWS call of its own** - everything on it was recorded at the time
each invocation ran. That is deliberate: a historical record that re-queries
live services is not a record, and the one thing this page must not do is
produce a different answer on Tuesday than it did on Monday.
"""

import json
from typing import Any, Dict, List

import streamlit as st

import runtime_view
import trace_log


def _where_else(state: Dict[str, Any]) -> None:
    """The other two places a trace exists, and what each one is good for.

    Worth stating plainly: this page is not the only record, and it is not the
    authoritative one. The agent's stdout is in CloudWatch whether this app
    ran or not, which makes it the record that survives deleting this folder.
    """
    runtime_id = state.get('agentRuntimeId') or '<runtime-id>'
    with st.expander('Where else every prompt is recorded — '
                     'CloudWatch, and the console'):
        st.markdown(
            'Three records exist, and they are not copies of each other.\n\n'
            '**1. This page** — the full structured trace per prompt, as the '
            'agent reported it: every service, every API, every verdict, every '
            'latency. Richest of the three, and the only one with the Cedar '
            'decision in it. It exists only for prompts sent from this app.\n\n'
            '**2. CloudWatch Logs** — the agent\'s own stdout, one log stream '
            'per session, for **every** invocation including ones sent from '
            '`invoke.py` or any other client. Less structured: it has the '
            'tools offered, the tool calls with their arguments, the model '
            'stop reasons and the turn counter, but not the assembled trace. '
            'It is the record that outlives this folder.\n\n'
            '**3. The AgentCore console** — *Observability* → *Sessions*, '
            'which needs **CloudWatch Transaction Search** enabled on the '
            'account. It is not enabled here, and turning it on is an '
            'account-wide change with a billing impact in a shared account, '
            'so it was deliberately left alone rather than switched on for a '
            'demo. Spans are being emitted regardless — the trace below is '
            'built from the same calls — so enabling it later makes the '
            'history visible there without changing a line of the agent.')
        st.code(f'# every prompt, newest stream first\n'
                f'aws logs describe-log-streams \\\n'
                f'  --log-group-name /aws/bedrock-agentcore/runtimes/'
                f'{runtime_id}-DEFAULT \\\n'
                f'  --order-by LastEventTime --descending --max-items 10\n\n'
                f'# one session\'s turns\n'
                f'cd agentcore_runtime_deployment && python deploy.py logs',
                language='bash')


def _flat_steps(rows: List[Dict[str, Any]], limit: int = 40
                ) -> List[Dict[str, Any]]:
    """Every step of every stored prompt in one table.

    The literal reading of "all the traces for every prompt": one flat, long
    table that can be searched and sorted across invocations, so a question
    like "has Cedar ever allowed over $100" is answered by filtering rather
    than by opening twelve expanders. Capped, because each invocation is 8-16
    steps and the grid stops being readable long before the data stops.
    """
    flat: List[Dict[str, Any]] = []
    for row in rows[:limit]:
        stored = trace_log.load(row.get('file') or '')
        result = stored.get('result') or {}
        for step in result.get('trace') or []:
            flat.append({
                'when': row.get('at'),
                'prompt': (row.get('prompt') or '')[:60],
                '#': step.get('seq'),
                'service': step.get('service'),
                'api': step.get('api'),
                'verdict': step.get('verdict'),
                'ms': round(step.get('latency_ms') or 0.0, 1),
                'at +ms': round(step.get('at_ms') or 0.0, 1),
                'detail': step.get('detail', ''),
            })
    return flat


def render() -> None:
    st.markdown('## All traces')
    st.markdown(
        'Every prompt sent from this app, with the trace the hosted agent '
        'returned for it. Recorded at the time it ran and read back off disk, '
        'so nothing here depends on a live call and nothing is lost when the '
        'next prompt overwrites the page you were looking at.')

    state = runtime_view.runtime_state() or {}
    rows = trace_log.history()
    stats = trace_log.stats()

    if not rows:
        st.info('No invocations recorded yet. Send a prompt on **Ask the '
                'hosted agent**, or press **Run all three test cases** on '
                '**Three test cases**, and every one of them will appear here '
                'with its full trace.')
        _where_else(state)
        return

    first, second, third, fourth = st.columns(4)
    first.metric('prompts recorded', stats['total'])
    second.metric('sessions', stats['sessions'])
    third.metric('refused by Cedar', stats['verdicts'].get('DENIED', 0))
    fourth.metric('allowed', stats['verdicts'].get('ALLOWED', 0))
    st.caption(f"Oldest `{stats['first']}` · newest `{stats['last']}` · stored "
               f"under `artifacts/traces/`. The counts are the three distinct "
               f"outcomes, not two: a prompt whose tool nobody granted is in "
               f"neither column, because Cedar was never consulted.")

    st.markdown('### Every prompt, newest first')
    table = [{'when': row.get('at'), 'from': row.get('source'),
              'prompt': (row.get('prompt') or '')[:90],
              'steps': row.get('steps'), 'services': row.get('services'),
              'policy': row.get('policy'),
              'tools': row.get('tools') or '—',
              'refused by': row.get('deciding_policy') or '—',
              'agent ms': row.get('agent_ms'),
              'session': str(row.get('session') or '')[:8],
              'error': row.get('error') or ''} for row in rows]
    st.dataframe(table, width='stretch', hide_index=True)

    st.download_button(
        f"Download all {len(rows)} invocations as one JSON",
        json.dumps(trace_log.bundle(), indent=2, default=str),
        file_name='agentcore_all_traces.json', mime='application/json',
        type='primary',
        help='Every stored response in full — ARNs, event ids, tool '
             'arguments, Cedar decisions, log groups. This is the artifact to '
             'hand to a reviewer who was not in the room.')

    st.markdown('---')
    st.markdown('### Open one prompt')

    def label_for(row: Dict[str, Any]) -> str:
        mark = {'DENIED': '🛑', 'ALLOWED': '✅'}.get(row.get('policy'), '👻')
        return (f"{mark} {row.get('at')} · {row.get('policy')} · "
                f"{(row.get('prompt') or '')[:70]}")

    chosen = st.selectbox('Which prompt', rows, format_func=label_for,
                          key='tv_pick')
    stored = trace_log.load((chosen or {}).get('file') or '')
    result = stored.get('result') or {}
    trace = result.get('trace') or []

    if not result:
        st.warning('That trace file could not be read. The index row survives, '
                   'which is why this says so instead of showing a blank page.')
        _where_else(state)
        return

    st.caption(f"Recorded `{stored.get('at')}` from **{stored.get('source')}** "
               f"· session `{str(stored.get('session') or '')[:8]}…` · file "
               f"`{stored.get('file')}`")
    st.markdown('**Prompt sent**')
    st.code(stored.get('prompt') or '—', language=None)

    if result.get('error'):
        st.error(f"The agent reported: {result['error']}")

    if result.get('reply'):
        st.markdown(f"**What the agent answered**\n\n> {result['reply']}")

    left, right = st.columns([1, 1.6], gap='medium')
    with left:
        st.markdown('**Every step, in order**')
        st.graphviz_chart(runtime_view.step_flow(trace), width='stretch')
    with right:
        st.markdown('**Which resources it used**')
        st.graphviz_chart(runtime_view.resource_graph(result), width='stretch')
        # The same cards as the live page, against a stored response: the
        # renderers take the response and nothing else, so a trace from last
        # week shows the identifiers it used rather than today's config.
        st.caption('Same diagram as the live page, drawn from the stored '
                   'response — so these are the ids *that* invocation used, '
                   'not whatever is configured now.')

    runtime_view._render_tool_calls(result)
    st.markdown('---')
    runtime_view._render_full_trace(result, trace)

    st.markdown('---')
    st.markdown('### Every step of every prompt, in one table')
    flat = _flat_steps(rows)
    st.caption(f'{len(flat)} steps across the {min(len(rows), 40)} most recent '
               f'invocations. Sort by `verdict` to find every refusal, or by '
               f'`ms` to find what the governance actually costs.')
    st.dataframe(flat, width='stretch', hide_index=True)

    _where_else(state)
