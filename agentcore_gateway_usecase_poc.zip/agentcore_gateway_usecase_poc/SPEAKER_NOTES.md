# Speaker notes — NovaCart price-match POC

**Audience:** senior management, non-technical. They are deciding whether to
fund this and whether to accept the risk.enen*Lgt**h:72* minutes of material, ~36 with questions.ec Stion211 adds 3
minutes and is for technical audiences only.
**What you need open:** the walkthrough app, and the AgentCore Gateway console
page for `novacart-price-match-poc` in a second tab.

```bash
python run_poc.py status          # confirm the gateway is READY
python run_poc.py run             # a fresh transcript for today
python run_poc.py capabilities    # fresh evidence, if presenngti section211

# Section 8 calls a hosted agent, so confirm it is up and warm it:
cd agentcore_runtime_deployment
python deploy.py status           # expect READY
python invoke.py "Competitor sells this for $80, refund the difference"
cd ..

streamlit run streamlit_app.py    # the thing you present from
```

**Warm the runtime before you walk in, and warm it twice.** A cold instance
takes up to thirty seconds to answer its first request and about six seconds
after that, so one throwaway invocation buys you the fast path. Run it twice
because of a measured platform flake: roughly one new session in three is
never routed to an instance at all and simply hangs. The app notices after
ninety seconds and retries on a fresh session by itself, saying so on screen -
but ninety seconds of silence on stage is still ninety seconds, and the fix is
to arrive with a warm runtime and an open session.

Prices are live. Do the run *before* you walk in, so you know what the numbers
will be and so a transient site failure surprises you in private rather than on
stage. The app reads the newest transcript automatically; the sidebar lets you
pick an older one if today's looks odd.

These notes follow e ape p's ehten sections. You can present entirely from it —
the only reason to touch a terminal in the room is if somebody asks to see the
run happen live, and `python run_poc.py run --case small` is about 40 seconds.

**The one sentence to land.** If they remember nothing else: *the rules live in
the platform, not in the agent's code or its prompt — so the agent cannot
exceed them even if it is tricked into trying.*

---

## Running order

| # | Section | Min | Starts | App section |
|---|---|---|---|---|
| 1 | The problem | 2 | 0:00 | The claim |
| 2 | The claim we are settling | 2 | 2:00 | The claim |
| 3 | What we built | 2 | 4:00 | The gateway |
| 4 | The easy claim | 3 | 6:00 | Walk a claim |
| 5 | The expensive claim | 3 | 9:00 | Same agent, different answer |
| 6 | The workaround | 2 | 12:00 | Same agent, different answer |
| 7 | **You pick the number** | 2 | 14:00 | Try it yourself |
| 8 | **The whole platform,  prompin one3 | | *00 t***Ask the hosted agent** |
| * t
**Three “no”s that are not the same 3 | 19:00 | 9 | |** ree | 9 | | agtest cases** |
| 10 | What the agent is *not* trusted with | 2 | 22:00 | The gateway |
| 11 | The honest gaps | 2 | 24:00 | The gateway |
| 12 | The rest of the platform | 3 | 26:00 | **Six capabilities** |
| 13 | What we want next | 1 | 29:00 | The gateway |

**Section 12 is for technical audiences only.** Drop it for management and the
deck is 27 minutes; keep it for architects and security reviewers, who ask
*"does this integrate with the rest of AgentCore"* within the first five
minutes.

For a 10-minute slot: sections 2, 5, 6, 7, 13. The refusals are the demo;
everything else is framing. **If you only have five minutes, do section 7** —
letting them choose the amount is worth more than any slide you could show
them.

**If the audience is non-technical, swap 4–6 for section 9.** Sections 4–6
walk one claim through the services, which is the right shape for an engineer;
section 9 walks three claims through six plain-language,
which is the r stages side by sideone else. Same evidencei and it reachee el for everyhes three different kind— the, a—  it reaches of "no" rein one screen ih0-minute slot with *architececte slot wntn *archi1e1ts*: sectio1s 5, 7, 10. Press a re-probe
button in front of them; a live call beats any amount of narration.

---

## 1. The problem — 2 min

> "We handle a lot of price-match claims. Each one is five minutes of somebody
> searching the web, opening a competitor's page, reading a price, checking our
> policy, and issuing a refund. It is entirely mechanical and we are paying
> people to do it."
>
> "An AI agent can do all five steps. The reason we have not shipped one is not
> the AI. It is the last step. To settle a claim, an agent needs to be able to
> move money — and nobody in this room wants to approve an agent with an open
> cheque book and a prompt that can be argued with."

Pause there. That is the real objection and you should say it before they do.

> "So the question we set out to answer was not *can the agent do the work*.
> It was: **can we put hard limits around it that the agent itself cannot
> move?** That is what I am going to show you working."

**If someone says "why not just hard-code the limit in the agent?"** — take it
now, it is the right question: *"Because then the limit is in the same place as
the thing being limited. Whoever changes the agent changes the rule, a prompt
that talks the model into a different number has already won, and there is no
audit trail. What I will show you instead puts the rule outside the agent
entirely."*

---

## 2. The claim we are settling — 2 min

> "Here is one real claim. A customer bought a power bank from us for $129.99.
> They tell us Anker's own site has it cheaper and they would like the
> difference."
>
> "To settle that, somebody has to find the page, read today's price, subtract,
> and decide whether they are allowed to refund that much. Four different
> things — and in our setup each one is handled by a different piece of AWS."

Walk the table in the README (step → capability). Do not name the AWS services
more than once; they do not care what they are called.

> "The important one is step three. The agent does not decide whether the
> refund is allowed. It asks, and something else decides."

---

## 3. What we built — 2 min

App → **The gateway**, top of the page. Switch to the console tab for a moment
so they see it is a real thing in a real account: `READY`, two targets, three
policies. The app's *three rules, in both languages* expanders give you the
plain English and the Cedar side by side — open one, briefly.

> "Everything the agent is allowed to touch goes through one front door. Two
> things are behind it: web search, and our refunds system."
>
> "Three rules are attached to that door. In plain English: refunds up to $100
> are automatic. Anything above $100 is refused. And web searches are capped at
> ten results."
>
> "Those rules are not in the agent's code. They are configuration on the door.
> I can change the $100 to $500 without a developer, without a deployment, and
> there is a record of who changed it."

**The credential point, briefly.** Worth 20 seconds because it is a standing
audit finding at most companies:

> "The agent holds no passwords or keys of any kind. When our refunds system
> needs the payment provider credential, it fetches it at the moment of use
> from a managed vault. Not a config file, not an environment variable, not
> anything a person could copy out — and every fetch shows up in a log."

If you are showing the console, the Identity page has two entries named for
this POC — a workload identity and a credential provider. One line on what
they are, then move on:

> "That is the agent's own name in the directory, and the vault entry holding
> the payment credential. Separate on purpose: rotating the secret never
> touches the agent, and removing the agent never touches the secret."

**Do not claim the agent fetches the credential.** It does not, and that is the
point rather than a shortcoming. If someone drills in, the precise version is
in the app under *The gateway → Identity*, and in `README.md` under
*Identity — two resources, deliberately not one*.

---

## 4. The easy claim — 3 min

App → **Walk a claim**, first claim. Walk the four numbered steps down the page.

> "It searched the web — through the same governed door. Ten results, just
> under six hundred milliseconds."

At step ②:

> "Now it has opened a real Chrome browser, running in AWS, and loaded Anker's
> actual product page. It is reading the page the way a customer sees it, not a
> cached copy."

**The screenshot is right there on the page.** oreticalmakpoint at it.

> "That is the page it looked a thcaptured at the time. Yobecause that0part went wrong the ent read the same number — and not by scanning the text, which we
> will come back to, because that part went wrong the first time."

Leave the amber *"18 plausible prices were on this page"me."d at the timem.eru can see $1he agthiss were on 11his page"* panel closed for now.
It is section 9's material and opening it here derails the story.

At step ④:

> "$129.99 minus $109.99 is $20. It asked the door: may I refund $20? Yes.
> Done. Five minutes of somebody's afternoon, in about three seconds."

Point at the identity lines:

> "And that last bit is the credential being fetched from the vault at the
> moment of use — masked, because the agent is never given the real value."

---

## 5. The expensive claim — 3 min

App → **Same agent, different answer**. The two cases are side by side.

**This is the slide the meeting is actually about.** Slow down. Say the heading
out loud before you say anything else:

> "Same agent. Same code. Same permissions. Same credentials. A different
> product — a MacBook."

Point at the right-hand column.

> "It found a $400 gap this time. And watch what happens."

Read the denial out loud, including the policy name.

> "Denied. By the rule called `novacart_block_large_refunds`. Not 'access
> denied' — it tells us exactly which rule stopped it, which is what you need
> when somebody asks in an audit why a decision went the way it did."
>
> "And the line underneath matters as much: our refunds system was never
> called. No credential was fetched. No money moved. The refusal happened at
> the door, before anything touched our payment path."

Then the sentence to land:

> "Nothing about the agent changed between these two cases. It did not choose
> to behave differently. The amount came from a live web page, and the rule
> applied itself to that amount. That is the control you are being asked to
> rely on, and it is doing the work."

**If someone asks "what if the customer tricks it into asking for more?"** —
this is the best question you can get: *"Then it gets refused in exactly the
same way. The decision is made outside the agent, by the door, after the
request is made and before anything runs. The agent being wrong, confused or
manipulated does not change the outcome. That is why the rule is not in the
agent."*

---

## 6. The workaround — 2 min

Same app page, scroll to **"And the obvious workaround?"**

> "Now the question a good auditor asks: fine, cash refunds are capped — can it
> go around them? Our system also supports store credit. Can it issue $400 of
> store credit instead?"

Point at `[a]`:

> "First, it cannot even see that option. The list of tools the agent is shown
> is filtered by the same rules. We did not grant store credit, so it is not on
> the menu. The agent is not resisting temptation; it has not been told the
> option exists."

Then `[b]`:

> "And if we call it directly, by name, bypassing the agent entirely —
> refused. Nothing grants it, so it is denied by default. You have to
> explicitly allow a capability for it to work, which is the right way round."

> "So the limit holds two ways: through the front door and around the side."

---

## 7. You pick the number — 2 min

App → **Try it yourself**. This is the strongest two minutes you have. Do not
narrate it — hand it over.

> "Everything so far is me showing you a recording of something I ran earlier.
> So let's take that out of it. Give me a number."

Type whatever they say into the amount box and press **Call the gateway**. It is
a signed request to the real gateway, in the real account, right now.

> "That went to AWS and back. Nothing here is mocked and nothing is cached."

Then press **Find the boundary**.

> "$99 — approved. $100 — approved. $101 — refused, by name. The limit is
> exactly where the policy says it is, and it is the policy saying it, not the
> code."

The point to land, while the three results are on screen:

> "I cannot talk it into a different answer from up here, and neither can a
> customer, and neither can the agent. If you want the limit to be $500, that
> is a configuration change — no developer, no deployment, and a logged record
> of who changed it."

**If someone asks to try the store credit option** — let them, it is the radio
button above. It comes back denied by default for any amount. That is a better
demonstration than anything you would have scripted.

Two honest caveats to have ready, because somebody sharp will ask:

- **"Did that actually move $99?"** No. The backend performs the real
  credential fetch and then stops; no payment provider is called. What is real
  is the authorisation decision.
- **"Is the limit hard-coded in the app?"** No — the app sends an amount and
  shows what came back. The $100 lives in the policy on the gateway. You can
  prove it by opening the expander below the verdict, which is the raw response.

---

## 8. The whole platform, in one prompt — 3 min

App → **Ask the hosted agent**. This is the section that answers the question
every technical reviewer is holding: *fine, but is this one gateway trick, or
is it the platform?*

The setup line matters, so say it before you press anything:

> "Everything up to now has been this laptop calling AWS. This page is
> different. The agent is not runnialk through what appears, in this order:

1. **The cards and the diagram.** Seven of the eight services  Then talk through what appears, in this order:

1. **The cards and the diagram.** Seven of the eight services lit up on this
   prompt - all eight on the allowed one - and grey for anything this request
   did not touch. lit entence."

Press **🛑 Over the limit**, then **Send it to the hosted agent**. It takes
about six seconds.Every box in the diagram carries the real id, not the service
   name.
   > "I did not draw that. The agent reported which services it called, which
   > resource each one was, and the page colouredkthem in. Grey mea   > "   > genuinely did not go ther is the whole argument."
3. **The timeline.** Point at the Policy row's latency.
   nfrastructure, under its own identity,
   > where nobody on this call can reach in and change its codeit
 e limit
   > followed it. That is the whole argument. b3. **The timeline.** Point at the Policy row's latency.
   > ds. That is the price."b
   If someone aonds. That is the price."

   If someone asks why the **allowed** run shows `permitted` there instead of
   a numsks why the **aliberate and a good question to get: a refusal can be
   timed on its own because the gateway refuses and returnsllwhile a permit is
   decided inside the same call that runs the tool. Prcosts a.out 170 millisecber, een a measurement nobody made.
4. **Every stephe **allowedan be
   timed on itb own inting `0 ms` would have
   bnd returnsmuwbole a permit is
   decided insid, in order.** The flow diagram a ove the cards is the same
   trace read top to olttom, with the gap in milliseconds on each arrow.
   > "Time runs downwards. The long arrow is the model thinking; the short one
   > in the middle is the policy decision."vehen scroll to **Check it yourself**. This is the screen to use when someone
wants addresses rather than bdjecti. s: eight cards, one per service, each
naming the resource that invocation actually used, not
> assem led ny this app. Thet anything:

> "Every value on these cards was> eported by the process that ranobnot
> assembled by this appds is runtime ARN comes out of the container's own
inenvironment — the caption sayt."
s so — so it ivethe agent telling you wve, in this order:

- **🏗️ if** — the runtime endpointingou where mesvnt vt."

You will not hage tuntime`, data plane), and the role session it ran as.ime,f"Th the runtime endpointime the API that inooked it
  (`InvokeAgentR
  >
  > data plane);
- 
 the role session it ran as this proat role session was created by AgentCore when it started the process.lves.Nothing on my machine can produce one — so you do not have to take 'it is
  > hosted' on my word."
- **🧠 Memory** — the memory id, the actor, the ids of the events written this
  turn, anns recalled from *earlier* conversations. Press **Read these
  events back from AgentCore Memory**.
  > "It remembered claimfused. Ths itfused. Th settled in a different session — and remembering an
  > approval does not grant it one; it still had to ask, and it still got
  > reose event ids were the agent's word for it. That button is a
  > separate call to the Memory service, after the request finished, and it
  > returns the turns themselves. The history is in a managed store, not in this
  > process."
- **🚪 Gateway** — the gateway id, its MCP endpoint, the tools it offered and
  which were called.
  > "Two tools offered, because two are granted. The  **🛡️ Policy** — one row per decision, with the rule that refused and the time
  it took. The engine and its rule list are below, flagged as read list is PO **🛡️ Policy** — one row per ded that rule, not me. The captioned low says which two linese engine ais card came off my disk instead of out of the call — if I had let
  > those sit unlabelled among the rest you would be right not to trust any of
  > it." **🔑 Identity**on this refusedd of out of the call — if I had let
  > those sit unlelled among the rest you would be right not to trust anyCt nevlout nevdWatit."
e **🔑 Identity** — on th,  refus,  run it is correctly empty, which is the
  point worth making.
  > "No credential was fetched, because the targeer ran. The refusal
  > happens at the gatewayndbefore the Lambda is invoked. On the allowed run
  > this card fills in — and note what it says: th — the argumeetched the
  > key, and the agent only ever saw a on this run the gateway's own denial text naming the policy. If a reviewer
wants the raw record, **The full trace, unedited** is under that: the whole step
list as a tamle, the raw JSON of es,ry step and of the whole response, and a
download button.

>expander per call**The full trace, unts the model chose, the reTult that came back,
and bn this run the gy. ."numrerN he file
> if you want to check a numberhead iutton.

> *Efrom CloudWatch** on the
right. The agent told the page where its logs are and the page went and read
them.

**The question this section exists to answer**, usually asked by the security
lead:

> *"Does the agent get more freedom once it is hosted on AWS?"*
> "Less, if anything. It holds no credentials — the re> policy is attached to the gateway, not to wherever the agent happens to run."

**Two caveats to volunteer**, because the trace shows them and someone will
read themfund target fetches the
> payment key from the Identity vault itself and the agent only ever sees a
> masked preview. And it is the same Cedar policy either way, because theing the page needs Playwrightbuwhich cannot ship
  inside the zip, so reading a liri competitor page stays in this app. Dotime, and the trace says
  `drove_page: false`. Drivolicy is attached to the gateway, not to wherever the a Tht happens to run."

**Twvecavvats to volunteer**, because the tr not
  let the lit-up Browser card imply more than it is.
- **Observability dence is instead of claiming a result.

**If the call fails oer ability; the spans and logs happen because every other call happened.
  That is why the row says where the eving the page needs Playwright, which cannot ship
  inside the n stage.** Most likely*T a cold instance — press it again,
it answers in six seconds warm. If it apout the
limit.

---

## 9. og group,
the runtime has lost egress; do not debug it live, switch to *ry it
yourself**, which hiservice, e gateway directly and makes the same point r lost egress; do not debug i,hree "no"s that are not the same — 3 min

App → **Three test cases**. Section 8 was organised by icserwhich is how
an engineer wants to see it. Th bis one is organised byThree prompts. Th how
everyone else does — and it i. Same agent, to use if ttechni identity tsame tool lisce, which is how
an engineer wants to> >  it. This one is organised by *case*, which is how
everyone else does —ThThen the storyboard: six stages down the side, three cases across.
ect"Read it left to right and the three cases are identical for the first three
> ion to use if the room i, three cases across.
 lit. Everythe same tools. The
> red box is the only place they diver difference in what happens is
Opo, side the agent — which is the entire thing we are trying to show you."

 the first three
> stages. They remember the same h> "Cedar permitted itfered ge."

Point at each endinsence of one — which is
   why Policy appears in the trace with ALLOWED rather than not appearing."
2. **Case 2, refused.**he o red 
offat *the platform allows or  is a decision, not an abnly place they diverge. th >e first three
> stages. They remember the s A rather than not appearing."
2. **Case ase en all the way down.
   >  six stages down . , sirefu.** The grey boxmodel asked for the refund. It was not being careless; the claim is
   > legitimat eecause the case was already settled two
   stages earlier   > rule."
3. **Case 3heabsentdecideT There is no 'you may not do that' in this
   > case at all. The capability simply is not in the agent's vocabulary,
   > because no policy grants it — and you cannot talk an agent into using a
   > the*grTheyd *tes at *the model decides* and *the platform
   allows or refuses* — nothing to do, because the case was already settled two
   stages— arli— .
   > "Nothing refused anyte.ooDENIED,ever beconsulted. Three distinct states. From outside, all
> three of those conversations ended with the customer ening told no, and a
> chat window would make them look identical."

The three step diagrams underneath are the measured version of the storyutard
you just read. If a prediction and a measurement disagree, say so out loud and
read the trace — that is what the page is for.

**The question this section exists to answer**, usually from a business owner:

> So can the agent be talhed into it?h*
urement disagree, say so out lohe storyboard
you just read.` he them looke table:

he page is forad the tracedorthat is what the page is foragersion of the storyboard
you just read. If a predickedhort on time**ntohow the storyboard and skip the live run. The
storyboard makes no AWS call, so it cannot fail on stage aand section 8 has
already provedagent. And in case
> 3 it cannot even ask."

**If you are surement disagree, say so o,  lked and
rekekededtraskip it — it is what makes the rest credle.
 can wree things are worth being explicit about."
t Thathe agent has no credentials. It cannot authenticate to our refunds system
> by itself; the door does that on its behalf."
>
> "The agent cannot grant itself anything. The rules are attached to the doorf
> and changing them is a separate ilogged,**The gateway → Identity** has it on
screen:

> "Two differehat was asked, what was decided, which
> rule decided it kepat is the transcript file the run just wrote."

**
f somebody asks who *does* hold the credential**, this is the precise answer
and it is worth getting right — app → **The gateway → Identity** has it on
screen:

> "Two different things, kept apart. Setting up a credential is an admin job —
> it happens once, from a terminal, under a named person's access. Using one
> happens per request, inside the refunds system, after the door has already
>d the call. The agent does neither. It neve approthe transcript file the run just wr

from a terminal, e the run just wrote."

."
, t wrote."


s oisible in the app: the credential the
*backend* uses is a different nault entry from the one . The agent does Teither. It never asks for a crwe cannot create or modnnot create or moddid."

One caveat towewe cannot create or mods visible in the app: the credential the
*backend* uses is a different vault entry from the one1this POC set up. 1hat is
a sandbox limitation — 1e cannot 1r1ate or mo1ify the refunds function here, so
it keeps reading the e resource.ecided, which
> rule decided it. That is the transcript file the run just wrote."

---

## 10. The honest gaps — 2 min

App → **The gateway**, bottom of the page. Volunteer these. If they find them
after you present, the demo loses its credibility; if you raise them  it gains
some.

> "Three things this does not yet prove."

**The browser is outside the fence.** *"ore — put a wrapper around the browser
and attach that to the same door — and we have not built it. The reason it has
not bitten us is that browsing only reads; it cannot move money."*

**Reading a price is harder than it sounds.** Go back one piece not governed by those
rules is the browser. It is a separate AWS ser,ix is a known piece of wack to **Walk a claim** and
ollar amounts and took the lowest.
On that Anker page there were eighteen — accessories, bundle discounts,
instalment plans, a crosseout old price. It picled $20 when the real price
was $109.99. It would have refunded $109 on a $20 claim. We fixed it by reading
the retailer's own machine-readable price rather than the words on the page,
and we now record which method produced each number. But it is a reminder that
'the agent read the page' is not automatically the same as 'the agent read it
correctly' — and the control that caught this was a human loing at the
outputtheot the policy engine aw record w
**No AIirst version scan ed the page for dollar amounts and t'the agent read the page' is not automatically the same as 'the agent read it
correctly' — and the control that caught this was is the easy part, and —
this is the point — it does not change the safety story, because the rules are
enforced outside the agent either way."*

Say "in this path" and mean it: if you presented section 8 or 9, the room has
already watched a Claude a human looking at the
outputnot the policy , and is the easy  model in the loop yet — in *this* path.** *"The scereso point at
it rather than letting someone catch the contradiction.ion.contrad2cti2n.her than le2ting someone catch the contradiction.ude he cont2adi2tion.re2roducibl22 Adding a model is the easy part, and — this is the
point — it does not change the safety story, because the rules are enforced
outside the agent either way."*

---

## 11. The rest of the platform — 3 min *(technical audiences only)*

App → **Six capabilities**.

**Skip this for a pure management audience.** It answers an architecture
question — *does this integrate with the rest of AgentCore, or is Gateway an
island?* — and management does not ask it. Architects, security reviewers and
the platform team ask it immediately, and this is the section that satisfies
them.

Open on the six-row matrix and read the shape of the result, not the rows:

> "The requirement was six AgentCore services. Four are proven, one is partial,
> one is blocked. Every one of those words has a measurement behind it, and the
> two that are not green are not green because of a line in this account's IAM
> policy — not because the platform cannot do it."

**If a technical audience has already seen section 8, you have a better story
than the matrix**, and it is worth thirty seconds:

> "That Runtime row said *partial* until last week, and the reason it changed is
> the most useful thing in this document. We had three measured API errors
> saying we could not host the agent — and all three were correct. The
> conclusion was still wrong, because every one of them assumed the artifact had
> to be a container image. It can be a zip. Three accurate measurements, one
> unexamined premise, a month of believing a blocker that was not there."

Then:

> "Which is exactly why every row here names the call behind it. The wrong
> conclusions are the ones you want to be cheap to find."

**Then press one button.** Go to the **Policy** tab and press **Re-probe
Policy now**. It takes about five seconds and runs $99, $100 and $101 against
the live gateway while they watch.

> "That just happened, now, against the real thing. Ninety-nine passes, a
> hundred passes, a hundred and one is refused — and the refusal names the
> rule."

**The line that lands hardest** is on the Observability tab. Say it before you
show the numbers:

> "We did not write a single line of monitoring code. Every number on this page
> was already being collected by the platform. Sixteen different measurements
> for this one door, including a count of how many times each individual rule
> fired."

Then scroll to the per-policy table and the green *every decision is accounted
for* panel. That panel is the governance answer:

> "Twenty-six approvals, twenty-four refusals, and they reconcile exactly.
> Thirteen were refused by a rule we wrote. Eleven were refused because nothing
> we wrote said yes. Those are different findings and the platform keeps them in
> separate counters — so an auditor can ask 'how often did that rule fire last
> month' and get a number without reading a log."

**If you have time for a second tab, make it Memory**, because it is a set's memory. An agent you could talk into a refund by convincing it that it
> had been allowed one before is exactly the failure mode we are designing
> against."

**Do not walk all six tabs.** Three minutes buys the matrix, one re-probe and
one or two tabs. Everything else is wcurity
point disguised as a feature:

> "We stored the refusal in the agent's memory, then asked for the same refund
> again. Refused identically. The agent remembers perfectly that it was told
> no, and remembering ch— *proven, with one gap* | "The agent is deplolive in the
> agenritten up in
`docs/CAPABILITY_EVIDENCE.md`, which is the right thing to hand a reviewuber who
wants the rest.

**If they press on the amber and red rows**, the one-line answers:

| Row | The answer |
|---|-elongs to another team. Pointing a gateway target at somely the failure mode we are designingo> against."

**Do not walk all six tabs.** Three minutesvability vbuys ty  gateway target at someone elrors are live. Request traces need an account-wide setting turned onsewith a cost attached, in an account we share with other teams. That is someakdy's decision to make and it is not ours." |
| Browsere. RblockedtraceTo put the browser behind the same door we need a small Lambdaanand this sandbox forbids creating Lambdas. Worth knowing: the organisation permits it — it is this one accountnpolicic accountr a day of w wTha a day of wdy's decision to maaeccountict is not ou a day of wof wr — *blo a day of w put the browser behind the same door we need a small Lambda, and this sandbox forbids creating Lambdas. Worth3k3owing: the or3anisation permits it — it is this one account's 3oli3y. So it is3a day of33ork wherever that restriction is absent." |

Resist the urge to soften these. Volunteering a blocked row and naming the one
IAM statement behind it is why the three green rows are believable.

---

## 12. What we want next — 1 min

> "What we have is a working control that we did not write and do not maintain,
> and a use case that pays for itself in claim handling time."
>
> "Three asks. First, agree the numbers — the $100 limit is a placeholder and
> it should be a business decision, not mine. Second, let us run this in
> log-only mode against real claims for two weeks: nothing is blocked, we just
> record what the rules *would* have done. That is a setting, and it is how we
> would find out if $100 is the right number. Third, fund the browser wrapper,
> because it is the one gap in the fence."
>
> "If the two-week observation looks like this demo, we turn enforcement on and
> start settling the small claims automatically."

---

## Anticipated questions

**"What does this cost?"**
Gateway is per request. No standing charge for the gateway itself — it has been
sitting idle in our account since this morning at no cost. The browser bills
per session while it runs, which is seconds per claim. The expensive thing in
this picture is still a person doing it manually.

**"Who can change the $100 limit?"**
Whoever has permission on the policy engine, and the change is logged. Today
that is the same team that owns the account; separating it from the agent team
is a deliberate next step and is the whole reason the rule lives outside the
agent.

**"Is the agent actually running on AWS, or on your laptop?"**

> On AWS, and section 8 is where you prove it. It is deployed into AgentCore
> Runtime as a 1.5 MB package; the app only sends it a sentence and draws what
> comes back. The identity shown at the bottom of that page is a role session
> AgentCore created when it started the process — nothing on my machine can
> produce one of those. The agent being hosted changes nothing about what it is
> allowed to do, which is the point: the limit is on the gateway, not in the
> agent.

**"Is this AWS-specific?"**
The protocol between the agent and the door is MCP, which is open — the tool
side would port. The policy engine and the credential vault are AWS. Realistic
answer: the agent moves, the governance does not.

**"What happens if the gateway is down?"**
The agent cannot act. It fails closed, which is the behaviour you want for
something that moves money. Claims queue to a human, as they do today.

**"Why does the agent see a reduced tool list? Is that security theatre?"**
No, but it is not the control either. The control is the refusal — it holds
whether or not the tool is visible, and we proved that by calling the hidden
tool directly. Hiding it is useful because an d was right?"**
Every run records where each number came from and keeps a screenshot of the
page. For the demo claim the provenance is the retailer's own published price.
That is checkable after the fact, which is the standard a human claim handler
is held to as well.

**"Is the customer's data involved?"**agent cannot be talked into using
a capability it was never shown.

**"Could it refund $99 a hundred times?"**
Yes, with the

d was right?"**
Every run records where each number came from and keeps a screenshot of the
page. For the demo claim the provenance is the retailer's own published price.
That is checkable after the fact, which is the standard a human claim handler
is held to as well.

**"Is the customer's data involved?"****"Where is the payment credential actually stored?"**
In the account's managed token vault, as a credential provider entry. Nothing
holds a copy — the refunds system asks for it at the moment it needs it, proves
which workload it is, and the vault decides what that workload may retrieve.
The credential in this POC is synthetic; no real payment provider is involved.

**"Could the agent read that credential if it wanted to?"**
It would have to**"Can we see this for every prompt, not just the one you just ran?"**
Yes — app → **All traces**. Every prompt either live page has ever sent, each
with its full trace, read off disk rather than from the session, so nothing is
lost when the next prompt overwrites the screen. There is a table of every
prompt with its verdict and the rule that refused it, a picker that reopens any
one of them with the same diagrams, and a download of the whole set as one
. The panel at the bottom of that page says where the other two records
live — the agent's stdout inloudWatch, one stream per session, which covers
prompts sent from any client; and the AgentCore console's session view, which
needs account-wideauransaction Search that we have delirerately not switched on
in a shared accountused on the far side of
the gateway, after authorisation. We deliberately did not build an agent that
fetches its own credentials, because that is the pattern this architecture
exists to replace.


Not in this POC. The only things sent outside our account are a product search
query and a request for a public web page.

---

## If the live run fails

Prices and websites move; have a fallback and do not improvise.

- **Search returns nothing / a page will not load.** `artifacts/` holds a
  previous transcript and screenshots. Say so plainly — *"the live web is the
  one part of this I do not control; here is this morninhis *is* the
  demot doeing.
- **Nothing responds at all.** `python run_poc.py status` — if the gateway is
  missing`python run_poc.py setup` rebuilds it in about 90 seconds, which is
  itself a reasonable thing to show.
- **Sections 7 or 8 will not reache ea** (expired credentials, no network).
  Eefry other section is read from the saved transcript and works offline, so
  drop them and say why: * those two need liaeed e and I don't have it in this
  room"*. Then walk the side-by-side comparison again, which makes the same
  point from recorded evidence.
- **Section 8 is slow or times out.** Press it once more — the first call to a
  cold instance can take thirty seconds and the second takes s. Two different
  failures look like slowness from the stage and the page tells you which:
  a yellow banner saying the first attempt was never routed means the measured
  platform flake8 isthing ran, and the retry's trace on screen is a real one;
  a 502 means the runtime has lost slow or egress, which is not something to
  debug in the room.esither way the fallbacgn_poc.py setu,` rebuilds it in about 90 seconds, which is
  itself a reasonable thing to show.
-as never routed meanswill not reach AWS** (expired credentials, no network).
  Every other smore — the first call to a
  cold instance can take thirty seconds and the second takes six. Two difbug in the room. Either way the fallback is section 7fck which hits the
  gateway directly and lands the same point about the limiabout  hosted-agent
  evidence is also written into the **Six capabilities → Runtim**Three test cases** storyboard still works without a
  runtime: only its livebrun rutton needs one needs one utton needs oneke, nothing ran, and the retry-run eutton needs oneds oneso written into the *one 8 says "No deployed runtime found."** Nothing was deployed from
  this checkout. The page prints the four commands; `python deploy.py deploy`
  takes about four minutes cold. Not something to do in the room — skip to
  section 9.

One thing the app protects you from: it makes **no AWS calls on page load**, so
you can open it, click through every section, and nothing can fail until you
deliberately press a button in section 7 or 8.
