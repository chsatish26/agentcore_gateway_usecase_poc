"""The use case: NovaCart settles a price-match claim end to end.

A customer says a competitor sells the item cheaper and asks for the
difference back. Today a human does this: searches, opens the competitor page,
reads the price, checks the policy, and issues the refund. Five minutes per
claim, thousands of claims.

The agent does the same five steps, and each one lands on a different
AgentCore capability. That is why this use case was chosen - not because it is
the most impressive thing an agent can do, but because none of the four
capabilities can be dropped from it:

    1. WEB SEARCH  which pages might carry the competitor's price
                   -> connector target, through the gateway
    2. BROWSER     what the page actually says, rendered, right now
                   -> data plane, NOT through the gateway
    3. POLICY      may a refund of *this amount* be issued at all
                   -> Cedar, evaluated at the gateway before the backend runs
    4. IDENTITY    the payment credential, fetched at call time
                   -> token vault, retrieved by the backend, never by the agent

The chain is causal, which is what makes it a real test rather than four demos
in a row: **the refund amount is computed from live web data, and policy
adjudicates that computed value.** Nobody types the amount in. Change the
competitor's price and the authorisation decision changes with it.

Three cases run by default, and the second and third are the point:

    small   a small gap        -> allowed, money moves
    large   a gap in the
            hundreds           -> refused by policy, backend never invoked
    evasion the agent retries
            as store credit    -> refused by default, because nothing grants it

The agent code is identical in all three. Only the data differs.

One deliberate omission: there is no LLM in this loop. The orchestration is
plain Python so that a demo run is reproducible and the authorisation result
is attributable to policy rather than to model sampling. Where a model would
sit is marked below. The security property does not depend on it - that is
precisely the argument, since policy is evaluated server-side and an agent
that has been talked into asking for $50,000 gets the same refusal as this
one.
"""

import json
import os
import time
from typing import Any, Dict, List, Optional

import config
import gateway_stack
from mcp_client import POLICY_DENIED_CODE, McpError, McpGatewayClient

# The claims. `our_price` would come from the order system; it is stated here
# because this POC is about the governed outbound calls, not about NovaCart's
# own catalogue.
#
# `floor`/`ceiling` bound what counts as a plausible price for each item, and
# they are per-case for a reason: a band wide enough for a laptop will happily
# accept a phone case on the power bank page.
CASES: List[Dict[str, Any]] = [
    {
        'key': 'small',
        'case_id': 'NC-10042',
        'product': 'Anker 737 Power Bank (PowerCore 24K)',
        'search_query': 'Anker 737 Power Bank PowerCore 24K price',
        'our_price': 129.99,
        'floor': 40.0,
        'ceiling': 300.0,
        'expectation': 'allowed',
        'why': ('A routine claim. The gap should land under the '
                f'${config.AUTO_APPROVE_LIMIT} auto-approval limit, so the '
                'agent settles it without a human.'),
    },
    {
        'key': 'large',
        'case_id': 'NC-10077',
        'product': 'Apple MacBook Pro 14-inch M4',
        'search_query': 'Apple MacBook Pro 14 inch M4 price',
        'our_price': 2299.00,
        'floor': 800.0,
        'ceiling': 4000.0,
        'expectation': 'denied',
        'why': ('Same tool, same agent, same credentials - but a far larger '
                'amount. Policy should refuse it and name the rule that did.'),
    },
]

# Case three is not a claim, it is an attempt to get around the refusal. Run
# after `large` and using the amount `large` was refused for.
EVASION = {
    'key': 'evasion',
    'tool': 'issue_store_credit',
    'why': ('The obvious workaround: if a cash refund is blocked, try store '
            'credit for the same value. Nothing grants that tool, so it is '
            'refused by default - and it is not even in the agent\'s tool '
            'list.'),
}


def _unwrap_backend(text: str) -> Dict[str, Any]:
    """Pull the business payload out of the refunds Lambda's response.

    The function replies with a full JSON-RPC envelope, which the gateway
    passes through as the tool's text content. So the useful object is nested
    two deep: text -> result.content[0].text -> the actual JSON. Unwrapping is
    done defensively because a backend that changes shape should degrade to
    "here is the raw text" rather than raising.
    """
    try:
        envelope = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return {'raw': text}
    if isinstance(envelope, dict) and 'result' in envelope:
        blocks = (envelope['result'] or {}).get('content') or []
        for block in blocks:
            if block.get('type') == 'text':
                try:
                    return json.loads(block['text'])
                except (json.JSONDecodeError, TypeError):
                    return {'raw': block['text']}
    return envelope if isinstance(envelope, dict) else {'raw': text}


def _deciding_policy(message: str) -> str:
    """Name the rule that refused, from the denial message.

    Two shapes arrive, and telling them apart is the whole value of parsing
    this at all:

        [Policy evaluation denied due to <name>-<id>]   an explicit forbid
        [No policy applies ... (denied by default).]    nothing granted it

    The first is a decision somebody wrote down and can be pointed at in an
    audit. The second means the tool was never authorised in the first place.
    Reported identically they look like the same event; they are not.
    """
    if '[' not in message or ']' not in message:
        return message.strip()
    inner = message[message.rindex('[') + 1:message.rindex(']')].strip()
    marker = 'denied due to '
    if marker in inner:
        return inner[inner.index(marker) + len(marker):].strip()
    return 'default-deny (no policy grants this tool)'


class Decision:
    """What the gateway did with one tool call.

    Deliberately reads the *gateway's* verdict, not the backend's. A policy
    denial is a JSON-RPC error with code -32002; anything else means the call
    got through, even if the backend then complained. Conflating the two is
    the single easiest way to report a successful block as a broken demo.
    """

    def __init__(self, tool: str, arguments: Dict[str, Any]):
        self.tool = tool
        self.arguments = arguments
        self.verdict = 'UNKNOWN'
        self.policy_message: Optional[str] = None
        self.deciding_policy: Optional[str] = None
        self.backend: Dict[str, Any] = {}
        self.latency_ms = 0.0

    @property
    def allowed(self) -> bool:
        return self.verdict == 'ALLOWED'

    def to_dict(self) -> Dict[str, Any]:
        return {'tool': self.tool, 'arguments': self.arguments,
                'verdict': self.verdict,
                'deciding_policy': self.deciding_policy,
                'policy_message': self.policy_message,
                'backend': self.backend,
                'latency_ms': round(self.latency_ms, 1)}


def call_through_gateway(client: McpGatewayClient, tool: str,
                         arguments: Dict[str, Any]) -> Decision:
    decision = Decision(tool, arguments)
    try:
        result = client.call_tool(tool, arguments)
    except McpError as e:
        decision.verdict = ('DENIED' if e.code == POLICY_DENIED_CODE
                            else f'ERROR({e.code})')
        decision.policy_message = e.message
        decision.deciding_policy = _deciding_policy(e.message)
        return decision

    decision.verdict = 'ALLOWED'
    decision.latency_ms = result.get('_latency_ms', 0.0)
    decision.backend = _unwrap_backend(client.tool_text(result))
    if client.is_tool_error(result):
        decision.backend['_tool_error'] = True
    return decision


def search_for_pages(client: McpGatewayClient, stack: gateway_stack.Stack,
                     query: str, say) -> Dict[str, Any]:
    """Step 1. Find candidate pages, through the gateway.

    `maxResults` is always sent, and not only because the connector defaults
    it: the Cedar policy governing this tool requires it to be present and
    within the cap. A call that omits it is denied - which is a small, real
    example of policy shaping how a tool must be called, not just whether it
    may be.
    """
    decision = call_through_gateway(client, stack.search_tool, {
        'query': query,
        'maxResults': config.MAX_SEARCH_RESULTS,
    })
    if not decision.allowed:
        say(f'    search DENIED: {decision.policy_message}')
        return {'decision': decision.to_dict(), 'results': []}

    payload = decision.backend if 'results' in decision.backend else {}
    results = payload.get('results', [])
    say(f'    {len(results)} results in {decision.latency_ms:.0f} ms '
        f'via {stack.search_tool}')
    for item in results[:3]:
        say(f'      - {str(item.get("url"))[:72]}')
    return {'decision': decision.to_dict(), 'results': results}


def run_case(case: Dict[str, Any], client: McpGatewayClient,
             stack: gateway_stack.Stack, say=print) -> Dict[str, Any]:
    """One claim, start to finish."""
    say(f"\n{'=' * 74}")
    say(f"CASE {case['case_id']}  {case['product']}")
    say(f"  NovaCart price ${case['our_price']:,.2f} · expecting "
        f"{case['expectation']}")
    say(f"  {case['why']}")
    say('=' * 74)

    record: Dict[str, Any] = {'case': case, 'started': time.strftime('%H:%M:%S')}

    # ---------------------------------------------------- 1. web search
    say('\n  [1] WEB SEARCH — which pages might have the price (via gateway)')
    search = search_for_pages(client, stack, case['search_query'], say)
    record['search'] = search
    urls = [r.get('url') for r in search['results'] if r.get('url')]
    if not urls:
        record['outcome'] = 'no candidate pages'
        return record

    # ---------------------------------------------------- 2. browser
    say('\n  [2] BROWSER — read the rendered page (direct, NOT via gateway)')
    import browser_price
    prefix = os.path.join(config.ARTIFACT_DIR, f"{case['case_id']}")
    browsing = browser_price.find_competitor_price(
        urls, floor=case['floor'], ceiling=case['ceiling'],
        artifact_prefix=prefix, say=say)
    record['browsing'] = browsing

    competitor_price = browsing.get('price')
    if competitor_price is None:
        say('    no plausible price found on any candidate page')
        record['outcome'] = 'no price found'
        return record

    # ---------------------------------------------------- 3. the amount
    # This is the hinge of the whole POC. The number policy will adjudicate is
    # computed here, from data the agent gathered seconds ago. Nobody chose it.
    gap = case['our_price'] - competitor_price
    refund = max(0, int(round(gap)))
    say(f"\n  [3] AMOUNT — ours ${case['our_price']:,.2f} − theirs "
        f"${competitor_price:,.2f} = ${gap:,.2f}  →  refund ${refund}")
    say(f"      provenance: {browsing['visits'][-1].get('price_source')} "
        f"on {str(browsing.get('source_url'))[:56]}")
    record['competitor_price'] = competitor_price
    record['refund_amount'] = refund

    if refund <= 0:
        say('      nothing to refund; the claim does not hold')
        record['outcome'] = 'claim rejected on the numbers'
        return record

    # ---------------------------------------------------- 4. policy + identity
    say(f'\n  [4] POLICY — may this agent refund ${refund}? '
        f'(Cedar, at the gateway)')
    decision = call_through_gateway(client, stack.refund_tool(), {
        'amount': refund,
        'reason': (f"price match {case['case_id']}: {case['product']} at "
                   f"${competitor_price:,.2f} on "
                   f"{browsing.get('source_url', 'competitor site')}"),
    })
    record['refund_decision'] = decision.to_dict()

    if decision.allowed:
        identity = decision.backend.get('identity', {})
        say(f'      ALLOWED in {decision.latency_ms:.0f} ms')
        say(f"\n  [5] IDENTITY — the backend fetched the payment credential")
        say(f"      workload identity : {identity.get('workloadName')}")
        say(f"      vault provider    : {identity.get('providerName')}")
        say(f"      credential        : {identity.get('apiKeyMasked')} "
            f"(masked by the backend; the agent never saw it)")
        record['outcome'] = f'refunded ${refund}'
        record['identity'] = identity
    else:
        say(f'      {decision.verdict}')
        say(f"      deciding rule: {decision.deciding_policy}")
        say('      the refunds backend was never invoked, so no credential '
            'was fetched and no money moved')
        record['outcome'] = f'refused: {decision.deciding_policy}'

    return record


def run_evasion(refund: int, client: McpGatewayClient,
                stack: gateway_stack.Stack, say=print) -> Dict[str, Any]:
    """The workaround attempt, after a refusal."""
    say(f"\n{'=' * 74}")
    say('ESCALATION  the agent tries another route')
    say(f"  {EVASION['why']}")
    say('=' * 74)

    tool = stack.refund_tool(EVASION['tool'])
    visible = tool in (stack.tools_enforced or [])
    say(f"\n  [a] Is {tool} in the agent's tool list?  "
        f"{'yes' if visible else 'NO — policy filters tools/list'}")

    say(f'\n  [b] Call it anyway, by name, for ${refund}')
    decision = call_through_gateway(client, tool,
                                    {'amount': refund,
                                     'reason': 'alternative to refused refund'})
    say(f'      {decision.verdict}: {decision.deciding_policy}')
    return {'tool': tool, 'visible_in_tool_list': visible,
            'decision': decision.to_dict(), 'why': EVASION['why']}


def run_all(say=print, only: Optional[str] = None) -> Dict[str, Any]:
    stack = gateway_stack.Stack.load()
    if not stack or not stack.gateway_id:
        raise SystemExit('No gateway state found. Run: python run_poc.py setup')

    client = McpGatewayClient(stack.gateway_id, url=stack.gateway_url)

    say('=' * 74)
    say('NOVACART PRICE-MATCH AGENT')
    say('=' * 74)
    say(f'  gateway   {stack.gateway_id}')
    say(f'  endpoint  {stack.gateway_url}')
    say(f'  inbound   AWS_IAM (SigV4) · policy mode ENFORCE')
    hidden = sorted(set(stack.tools_log_only or [])
                    - set(stack.tools_enforced or []))
    say(f'  tools     {", ".join(stack.tools_enforced or [])}')
    say(f'  hidden    {", ".join(hidden) or "none"}')
    say(f'  rule      auto-approve refunds up to ${config.AUTO_APPROVE_LIMIT}; '
        f'search capped at {config.MAX_SEARCH_RESULTS} results')
    if stack.workload_identity_name:
        check = stack.identity_check or {}
        verified = 'verified' if check.get('ok') else 'NOT verified'
        say(f'  identity  {stack.workload_identity_name} + '
            f'{stack.credential_provider_name} ({verified} at setup)')

    cases = [c for c in CASES if not only or c['key'] == only]
    transcript: Dict[str, Any] = {
        'generated': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'gateway': stack.to_dict(),
        'auto_approve_limit': config.AUTO_APPROVE_LIMIT,
        'cases': [],
    }

    for case in cases:
        transcript['cases'].append(run_case(case, client, stack, say))

    # The escalation only makes sense after something was refused.
    refused = [c for c in transcript['cases']
               if str(c.get('outcome', '')).startswith('refused')]
    if refused and (not only or only == 'evasion'):
        amount = refused[-1].get('refund_amount', 500)
        transcript['evasion'] = run_evasion(amount, client, stack, say)

    _summarise(transcript, say)
    return transcript


def _summarise(transcript: Dict[str, Any], say) -> None:
    say(f"\n{'=' * 74}")
    say('WHAT HAPPENED')
    say('=' * 74)
    for entry in transcript['cases']:
        case = entry['case']
        price = entry.get('competitor_price')
        theirs = f'${price:,.2f}' if price else 'not found'
        say(f"  {case['case_id']:<10} ours ${case['our_price']:>9,.2f}  "
            f"theirs {theirs:>10}  ->  {entry.get('outcome')}")
    if transcript.get('evasion'):
        decision = transcript['evasion']['decision']
        say(f"  escalation  {transcript['evasion']['tool']} -> "
            f"{decision['verdict']} ({decision['deciding_policy']})")

    say('\n  Each capability, once:')
    say('    web search  found the pages          (gateway connector target)')
    say('    browser     read the rendered price  (data plane, ungoverned)')
    say('    policy      adjudicated the amount   (Cedar, before the backend)')
    say('    identity    fetched the credential   (token vault, in the backend)')

    # Two different identity resources are in play, and saying so is the
    # honest version. The POC provisions its own pair and verifies the vault
    # returns a secret; the backend consumes a *different* pair it reads from
    # its own environment, because this sandbox cannot create a Lambda to
    # repoint. Reporting only one of them would overstate the demo.
    gateway = transcript.get('gateway') or {}
    if gateway.get('workload_identity_name'):
        check = gateway.get('identity_check') or {}
        say('\n  Identity, precisely:')
        say(f"    provisioned by this POC   "
            f"{gateway['workload_identity_name']} + "
            f"{gateway.get('credential_provider_name')}")
        say(f"    verified at setup         vault returned the secret "
            f"({check.get('apiKeyMasked', 'n/a')})")
        used = [c['identity'] for c in transcript['cases'] if c.get('identity')]
        if used:
            say(f"    consumed at claim time    "
                f"{used[-1].get('workloadName')} + "
                f"{used[-1].get('providerName')}  <- the backend's own, "
                f"from its env")
        say('    the agent fetched no credential at any point')
