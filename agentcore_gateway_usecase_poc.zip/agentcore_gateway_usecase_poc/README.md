# NovaCart price-match POC — six AgentCore services in one use case

A customer says a competitor sells the item cheaper and wants the difference
refunded. An agent settles the claim end to end: it searches the web, opens the
competitor's page in a real browser, reads the price, works out the gap, and
issues the refund — and a Cedar policy decides whether that refund is allowed
based on the amount it just computed.

**That last clause is the whole point.** Nobody types the amount in. It comes
from live web data gathered seconds earlier, and the authorisation decision
follows the data. Change the competitor's price and the outcome changes with it.

The use case was chosen because none of the capabilities can be dropped from it:

| Step | Capability | Where it runs |
|---|---|---|
| 1. Which pages might have the price? | **Web search** | Gateway connector target |
| 2. What does the page say *right now*? | **Browser** | Data plane — **not** the gateway |
| 3. May this agent refund *this amount*? | **Policy** | Cedar, at the gateway, before the backend |
| 4. What credential moves the money? | **Identity** | Token vault, fetched by the backend |

On top of that use case, the POC carries evidence for the full six-row
AgentCore integration requirement — Runtime, Identity, Policy, Observability,
Memory and Browser. See **[The six capabilities](#the-six-capabilities)** below
and `docs/CAPABILITY_EVIDENCE.md` for the measurements.

This is a companion to `../agentcore_gateway_evaluation`, which measures the
capabilities one API at a time. That suite answers *what can this service do*.
This one answers *what is it for*. It also leaves its gateway standing, so there
is something to open in the console — the evaluation tears its stack down in a
`finally:` and leaves nothing behind.

---

## Quick start

```bash
pip install -r requirements.txt

python run_poc.py setup          # builds the gateway; idempotent, ~90s
python run_poc.py status         # what exists right now
python run_poc.py run            # the scenario, against live AWS and the live web
python run_poc.py capabilities   # evidence for the six AgentCore services
python run_poc.py destroy        # deletes only what setup created

streamlit run streamlit_app.py   # the management walkthrough
```

The **Ask the hosted agent** page calls an agent running in AgentCore Runtime
rather than one running inside this app, so it needs that agent deployed once:

```bash
cd agentcore_runtime_deployment
python verify_local.py           # 4s, checks the /ping + /invocations contract
python deploy.py preflight       # role, bucket, subnet AZs, egress, gateway, model
python deploy.py deploy          # ~4 min cold: a 1.5 MB zip, no Docker
python invoke.py --demo          # three prompts: allowed, denied, absent
python invoke.py --demo --trace  # ... and every service interaction, in order
```

That module has its own README and `docs/RUNTIME_CONTRACT.md`, which records
the measured sandbox contract — including the six ways this deployment fails,
why an empty CloudWatch log group is itself a diagnosis, and the one failure
that is on the platform's side of the contract: about one fresh session in
three is never routed to an instance and simply hangs, which both clients here
now detect after 90 seconds and retry on a new session.

`setup` is safe to re-run: it adopts an existing gateway with the configured
name rather than creating a second one. The gateway it builds is **persistent**
— it outlives the demo on purpose.

```
Console → https://us-east-1.console.aws.amazon.com/bedrock-agentcore/gateways
Gateway   novacart-price-match-poc-qdnpxdyr1x

Console → https://us-east-1.console.aws.amazon.com/bedrock-agentcore/identity
Workload identity    novacart-price-match-poc
Credential provider  novacart-payments-poc
```

`python run_poc.py status` prints the same facts without opening a browser.

---

## Architecture

### What `setup` builds

```
                          ┌─────────────────────────────────────┐
   agent                  │  novacart-price-match-poc           │
   (no tool credentials)  │                                     │
          │               │  inbound identity : AWS_IAM (SigV4) │
          └── SigV4 POST ─▶  policy engine     : ENFORCE        │
              /mcp        │  MCP versions      : 2025-03-26,    │
                          │                      2025-11-25     │
                          └────────┬───────────────────┬────────┘
                                   │                   │
                      target "research"         target "novacart"
                      connector web-search      lambda RefundToolEcho
                      v1.2.0                    toolSchema inline
                      outbound: gateway role    outbound: gateway role
                                   │                   │
                                   ▼                   ▼
                           the live web        ┌───────────────────┐
                                               │ fetches payment   │
                                               │ credential from   │
                                               │ the TOKEN VAULT   │
                                               │ at call time      │
                                               └───────────────────┘

   BROWSER sits outside this box entirely:
       StartBrowserSession → CDP websocket → Playwright → StopBrowserSession
       authorised by IAM alone; the Cedar policy cannot see it
```

Two targets on one gateway is the shape worth showing: a managed AWS connector
and a private function, reached by the same caller, over the same protocol,
with the same credentials, governed by the same policy set.

### The path of one tool call

```
   agent ──① SigV4 ──▶ gateway
                          │
                          ② policy engine: may this principal call this
                          │    action with these arguments?
                          │
                          ▼
                       allowed ──③──▶ target ──▶ credential fetched
                          │                      for this target
                          ▼
                       denied: JSON-RPC -32002, backend never invoked
```

Authorisation happens at ② and **the backend runs at ③**. That ordering is the
security argument: an agent that has been prompt-injected into asking for $400
instead of $50 gets the same refusal as this one, because the decision is not
made by the agent, the prompt, or the model.

### The policies

Three Cedar statements, all `ACTIVE`, written against the live gateway ARN:

| Policy | What it says |
|---|---|
| `novacart_allow_small_refunds` | `permit` refunds where `context.input.amount <= 100 && > 0` |
| `novacart_block_large_refunds` | `forbid` refunds `unless context.input.amount <= 100` |
| `novacart_allow_bounded_research` | `permit` search where `context.input.maxResults <= 10` |

`context.input` **is the tool's arguments** — that is the capability IAM does
not have. IAM can say "this role may call `process_refund`". It cannot say
"…for amounts up to $100".

The second policy looks redundant next to default-deny, and functionally it is.
It exists for the message: an explicit `forbid` names itself in the denial, so
the audit trail says *denied by `novacart_block_large_refunds`* rather than
*access denied*. That difference is the gap between a control you can point at
in a review and a support ticket.

Nothing grants `issue_store_credit`. That is deliberate — see below.

### Identity — two resources, deliberately not one

This is the part most worth reading carefully, because the first version of the
POC got it wrong in a way that was invisible from the output.

| | Provisioned by this POC | Consumed at claim time |
|---|---|---|
| Workload identity | `novacart-price-match-poc` | `wid-nb-c5438d5f` |
| Credential provider | `novacart-payments-poc` | `demo-apikey-37d2ae24` |
| Who acts | an operator, once, at `setup` | the refunds backend, per request |
| Created by | `setup` | predates this POC |
| Removed by | `destroy` | **never** — other things depend on them |

Originally the POC provisioned *nothing* in Identity. The refunds Lambda
performs a genuine token-vault round trip, so the capability was demonstrated —
but against resources that pre-date this work, which the Lambda reads from its
own `WORKLOAD_IDENTITY_NAME` and `API_KEY_PROVIDER_NAME` environment variables.
Nothing on the console's Identity page therefore showed anything attributable
to this POC, which is the complaint that produced this section.

`setup` now creates a POC-owned pair and verifies the vault returns the stored
secret. But note what it deliberately does **not** do: the agent never calls
`GetResourceApiKey`. Provisioning a credential is an admin action; consuming
one happens inside the backend after the gateway has authorised the call. An
agent that fetches its own credentials is the design this architecture exists to
avoid, so demonstrating it would have argued against the POC's own conclusion —
even though it would have made the story tidier.

The honest statement is: **the POC owns and verifies its own identity pair, and
the use case consumes a different pair** belonging to a shared backend it must
not modify. Repointing the Lambda is one `UpdateFunctionConfiguration` call
away, and is not done because that function is shared.

The stored secret is synthetic, generated locally at `setup`, and only a masked
preview is ever shown.

One correction worth recording, because it was not obvious: **`CreateGateway`
auto-creates a workload identity named after the gateway ID.** So
`novacart-price-match-poc-qdnpxdyr1x` has existed in the identity directory
since `setup` first ran, alongside the explicitly created
`novacart-price-match-poc`. 38 of the 65 workload identities in this account
follow that gateway-named pattern. Whether `DeleteGateway` removes it is
untested — `destroy` deletes the two resources it created by name and does not
attempt to clean up the auto-created one.

The two families are easy to confuse and are not the same kind of thing:

| | Workload identity | API key credential provider |
|---|---|---|
| ARN segment | `workload-identity-directory/default/workload-identity/` | `token-vault/default/apikeycredentialprovider/` |
| Holds a secret | **no** — it is a name only | yes |
| Backed by | nothing | a Secrets Manager secret, `bedrock-agentcore-identity!default/apikey/<name>-<suffix>` |
| Console | not reliably surfaced; use `list_workload_identities` | listed, and links out to Secrets Manager |

The `!` in the secret name marks it service-managed, which is why the Identity
console links out instead of rendering it inline. Note the consequence:
anything with `secretsmanager:GetSecretValue` on that secret reads the key in
plaintext without going through the vault's workload-token check. Harmless here
only because the POC's stored key is synthetic.

---

## Measured results

Live run, 2026-10-06, `us-east-1`, account 196856463470. Real web search, real
Chrome, real policy evaluation. Prices are live, so the numbers move between
runs — which is itself the point.

### Case 1 — a $20 gap, approved

```
[1] WEB SEARCH   10 results in 580 ms via research___WebSearch
[2] BROWSER      managed Chrome 148.0.7778.258
                 read anker.com/products/a1289 — 10,386 chars rendered
                 price $109.99 USD via json-ld Product.offers.price
[3] AMOUNT       ours $129.99 − theirs $109.99 = $20.00  →  refund $20
[4] POLICY       ALLOWED in 1,290 ms
[5] IDENTITY     workload identity : wid-nb-c5438d5f
                 vault provider    : demo-apikey-37d2ae24
                 credential        : dem***123   ← masked by the backend
```

The agent never saw the credential. The backend called
`GetWorkloadAccessToken` then `GetResourceApiKey` against the account token
vault and returned a masked preview as proof it had it.

`artifacts/NC-10042_page1.png` is the screenshot — `$109.99` is visible on the
page, matching what was extracted.

### Case 2 — a $400 gap, refused

```
[1] WEB SEARCH   10 results in 522 ms
[2] BROWSER      read apple.com/us/shop/buy-mac/macbook-pro/14-inch-m4
                 price $1,899.00 USD via json-ld Product.offers.lowPrice
[3] AMOUNT       ours $2,299.00 − theirs $1,899.00 = $400.00  →  refund $400
[4] POLICY       DENIED — novacart_block_large_refunds
                 the backend was never invoked, so no credential was fetched
                 and no money moved
```

Same agent, same tool, same credentials, same code path. Only the amount
differs.

### Case 3 — the workaround, also refused

```
[a] Is novacart___issue_store_credit in the agent's tool list?
    NO — tools/list is filtered by policy
[b] Call it anyway, by name, for $400
    DENIED — default-deny (no policy grants this tool)
```

Two layers. The tool is **invisible** to the agent, and still refused when
called by name regardless.

---

## The six capabilities

The integration requirement is a six-row table: each AgentCore service, how it
integrates with Gateway, and what that integration does. `capabilities.py`
probes all six against live AWS and writes a timestamped evidence bundle.

```bash
python run_poc.py capabilities                      # all six
python run_poc.py capabilities --only policy memory # a subset
```

Measured 2026-10-11:

| AgentCore service | Integration | Status | Finding |
|---|---|---|---|
| Runtime | Direct | ✅ PROVEN | Deployed and READY on AWS as a 1.5 MB zip, invoked live, refused by `novacart_block_large_refunds-k0fahcb42r` from inside Runtime. Agent-*as*-gateway-target still not exercised. |
| Identity | Direct | ✅ PROVEN | Vault round trip returns the secret; CloudWatch counts both fetches under our provider's name. |
| Policy | Direct | ✅ PROVEN | $100/$101 boundary exact; CloudWatch counts decisions **per Cedar policy ID**. |
| Observability | Direct | ◐ PARTIAL | 16 metrics / 108 dimension sets exist and the POC instruments nothing. Traces off — Transaction Search not enabled. |
| Memory | Indirect | ✅ PROVEN | A refusal is stored, recalled in another process, and the repeat request is refused identically. |
| Browser | Optional/Indirect | 🛑 BLOCKED | Browser works and is load-bearing, but reached off the gateway. The claim as written needs a Lambda; `lambda:CreateFunction` is explicitly denied. |

**4 proven, 1 partial, 1 blocked.** A blocked requirement is a recorded finding,
not a failed run, so the command exits 0.

Runtime moved from partial to proven on 2026-10-11 without anything about the
account changing. The recorded blocker — *needs an ARM64 container image this
host cannot build* — rested on three correct measurements and one false
premise: that the artifact had to be a container. `codeConfiguration` runs a
zip from S3 instead, so there is no image to build. The correction is written
up rather than deleted, in `docs/CAPABILITY_EVIDENCE.md` §1.

The three findings that do not depend on trusting this POC's own transcripts,
because the service vends them and the POC emits nothing:

1. `DenyDecisions` is dimensioned by `Policy=novacart_block_large_refunds-k0fahcb42r`
   — CloudWatch records *which Cedar rule refused what*.
2. `ApiKeyFetchSuccess` is dimensioned by `ProviderName=novacart-payments-poc`.
3. `Invocations` and `Latency` are dimensioned by the published
   `<target>___<tool>` name.

Full measurements, the API errors behind each non-green row, and the measured
service constraints are in **`docs/CAPABILITY_EVIDENCE.md`**. The Streamlit app's
**Six capabilities** page shows the same bundle with a **Re-probe** button per
tab.

### New files for this

| File | What it is |
|---|---|
| `capabilities.py` | the six probes, the requirement text verbatim, the status rules |
| `observability.py` | CloudWatch + X-Ray queries, including dimension discovery |
| `memory_store.py` | Memory lifecycle, writes, recall |
| `runtime_agent.py` | the agent as Runtime wants it, the contract check, the live hosted-runtime probe |
| `agentcore_runtime_deployment/` | the deployment module: packages the zip, creates the runtime, invokes it |
| `runtime_view.py` | the **Ask the hosted agent** page — your prompt, the live runtime, every service it touched, and the ARNs it used |
| `testcase_view.py` | the **Three test cases** page — six stages × three cases, predicted then measured |
| `trace_log.py` | appends every invocation to `artifacts/traces/` so no trace is one button-press from gone |
| `traces_view.py` | the **All traces** page — every prompt ever sent, each with its full trace |
| `Dockerfile` | the ARM64 image, kept for the day a zip is not enough |
| `capability_view.py` | the Streamlit page |

---

## Four things this POC established that the docs do not say

**1. `tools/list` is filtered by policy, not just `tools/call`.** Attaching the
policy engine in `ENFORCE` mode with no policies written returned an **empty
tool list** while both targets were `READY`. An agent is not shown a tool it is
not allowed to call, which removes the temptation rather than just blocking the
action. It also creates a bootstrap problem: you cannot discover tool names in
order to write policies about them.

Measured, same gateway, one mode flip apart:

| Policy mode | Tools visible |
|---|---|
| `LOG_ONLY` | `research___WebSearch`, `novacart___process_refund`, `novacart___issue_store_credit` |
| `ENFORCE` | `research___WebSearch`, `novacart___process_refund` |

**2. So the rollout order is forced, and it is the right one anyway.** `setup`
attaches the engine in `LOG_ONLY`, reads the published tools, writes policies
against the real names, then flips to `ENFORCE`. Observe, then enforce — which
is how you would introduce this to a system already in production.

**3. Policy shapes *how* a tool must be called, not only *whether*.** The
research policy requires `maxResults` to be present and `<= 10`. A search
omitting it is denied, and a search for 25 results — within the connector's own
limit — is denied too. The policy engine is an input validator you cannot
bypass from the client.

**4. A browser gives you the DOM, and that is the difference between reading
and guessing.** The first version of the price reader scanned rendered text for
currency amounts. On the Anker page that found **eighteen** plausible prices —
accessories, bundle discounts, instalment plans, a strike-through was-price —
and picked `$20.00` against a true price of `$109.99`. It would have refunded
$109 on a $20 claim.

The fix was to read the retailer's own `schema.org` `Product.offers.price` out
of the page's JSON-LD. Extraction now runs in three layers and **records which
one answered**:

| Layer | Provenance recorded |
|---|---|
| 1 | `json-ld Product.offers.price` — the retailer's own machine-readable price |
| 2 | `meta[product:price:amount]` / `itemprop=price` |
| 3 | `page text (low confidence)` — last resort, flagged as such |

A refund traced to the retailer's declared offer is defensible. One traced to
"the smallest dollar figure we saw" is not. The distinction is invisible unless
you record it, which is why `price_source` is in the transcript.

---

## What this POC does *not* establish

- **No LLM drives the loop.** Orchestration is plain Python so a demo run is
  reproducible and the authorisation result is attributable to policy rather
  than model sampling. The security property does not depend on a model being
  involved — that is the argument, not a gap — but "the agent reasoned its way
  to this amount" is not demonstrated here.
- **No money moves.** The refunds target is an echo Lambda. It performs a real
  token-vault round trip and returns a masked credential, then stops. No payment
  provider is called.
- **`our_price` is hard-coded per case.** NovaCart's own catalogue is out of
  scope; the POC is about the governed outbound calls.
- **One competitor page per case.** `find_competitor_price` will try up to
  three, but in both measured cases the first page answered, so the fallback
  path is only lightly exercised.
- **No corporate SSO.** Inbound identity is `AWS_IAM`. Switching to
  `CUSTOM_JWT` against a real IdP changes one field and was not done.
- **Browser is ungoverned here, and stays that way.** Bringing it under Cedar
  needs a Lambda or MCP-server wrapper around `StartBrowserSession` /
  `InvokeBrowser`. This sandbox denies `lambda:CreateFunction`, so that wrapper
  is designed but not built. The design is in `docs/CAPABILITY_EVIDENCE.md`.
- **No traces are captured.** Transaction Search is an account-wide setting
  with a cost attached, in an account shared with other teams, so it was not
  enabled unilaterally. Metrics, latency and errors are live.
- **The hosted agent cannot drive a browser page.** It opens and closes a real
  managed Browser session from inside Runtime, but CDP needs Playwright, which
  ships compiled binaries and so cannot travel in a pure-Python zip. Reading a
  live page stays in the Streamlit app, where Playwright is installed.
- **Invoking the hosted agent is not reliable on the first try.** Measured
  2026-10-11: roughly one fresh session in three is accepted and then never
  routed to an instance — no agent process, no log stream, no response until
  the client gives up. It is on the platform side of the HTTP contract, so the
  mitigation is detection rather than a fix: both clients wait 90 seconds
  instead of 180, then retry once on a new session id and say on screen that
  they did. The retry is safe only because nothing ran on the first attempt.

---

## Layout

```
run_poc.py          CLI: setup | status | run | capabilities | destroy
gateway_stack.py    builds/adopts the gateway, targets, engine, policies
scenario.py         the three cases; one Decision per tool call
browser_price.py    managed Chrome over CDP; layered price extraction
identity.py         POC-owned workload identity + credential provider, and the
                    vault round trip that verifies them
mcp_client.py       SigV4-signed MCP client (carried over from the evaluation)
config.py           settings; the business rule the policies encode

capabilities.py     the six-capability probes and evidence bundle
runtime_view.py     the "Ask the hosted agent" page: one prompt -> the live
                    runtime -> a drawn trace of every service it touched,
                    plus the ARNs, the memory read-back and the full trace
testcase_view.py    the "Three test cases" page: six stages x three cases as a
                    storyboard, then the same three sent to the hosted agent
agentcore_runtime_deployment/
                    deploys that agent into AgentCore Runtime as a zip and
                    talks to it; docs/RUNTIME_CONTRACT.md has the measured
                    sandbox contract and the five ways it fails
observability.py    CloudWatch and X-Ray queries
memory_store.py     AgentCore Memory lifecycle, writes and recall
runtime_agent.py    the agent behind Runtime's HTTP contract
Dockerfile          the linux/arm64 image, for the day a zip is not enough

streamlit_app.py    management walkthrough
capability_view.py  the "Six capabilities" page
diagrams.py         the architecture graphs
SPEAKER_NOTES.md    presenter script: timings, anticipated questions
docs/CAPABILITY_EVIDENCE.md   the written evidence for the six rows
gateway_state.json  written by setup; read by run/status/destroy
artifacts/          run transcripts + page screenshots + evidence bundles
```

### Presenting it

`streamlit run streamlit_app.py` — eight sections: the business problem, one
claim walked step by step, the two cases side by side, a **live policy probe**,
a **live call to the hosted agent**, the **three test cases step by step**, the
**six capabilities** with their evidence, and the gateway with its gaps.

Almost every figure on screen is read back from the selected transcript or
evidence bundle in `artifacts/` rather than written into the app, so the
walkthrough cannot drift from the evidence. With no transcript present it says
so instead of inventing numbers.

The live sections are the ones worth building a meeting around:

- **Try it yourself** — set an amount, call the real gateway, watch the verdict.
  *Find the boundary* probes $99, $100 and $101 in sequence; the first two are
  approved and the third is refused by name.
- **Ask the hosted agent** — the one to build the meeting around. Type a
  prompt; it goes to an agent **running on AWS**, not in this app. The agent
  returns its own trace of every service it touched — Runtime, Memory,
  Gateway, Bedrock, Policy, Identity, Browser, Observability — and the page
  draws it: a card and a lit-up diagram per service, then every interaction in
  order with its latency and verdict. Three preset prompts give the three
  outcomes (allowed, refused by Cedar, tool absent entirely). Takes about six
  seconds warm, up to thirty on a cold instance.

  Scroll to **Check it yourself** for the part a sceptic asks for. Eight cards,
  one per service, each naming the resource it actually used: the runtime
  endpoint ARN with the API that invoked it and the role session it ran as; the
  Memory id and ARN with the actor and the ids of the events written this turn;
  the gateway id, its MCP endpoint, the policy-filtered tool list it offered
  and which of those were called; one row per Cedar decision with the verdict,
  the rule that refused (Cedar names the rule only on a refusal — the permit
  rows say so rather than inventing one) and the time it took; the workload
  identity, credential provider and the mask the agent saw; the browser session
  and CDP endpoint; the model with its token counts; and the log group and
  per-session stream. Above the cards the same thing as a diagram, where every
  box carries a real id instead of a service name, so an id can be read off the
  picture and looked up in the console. Then one expander per tool call with
  exactly what was sent and what came back — including, on the refused call,
  the gateway's own denial text naming the policy.

  All of it is reported by the agent process itself rather than assembled from
  this app's config, with a line saying which; the one locally-sourced value
  (the policy engine and its rule list, read from `gateway_state.json`) is
  labelled as such so it cannot borrow the rest's credibility. Two buttons go
  and check: one reads the written turns back out of AgentCore Memory with
  `ListEvents`, the other pulls this session's stdout from CloudWatch. Below
  that is the full trace as a table, as raw JSON, and as a one-click download.

  Requires a deployed runtime: `cd agentcore_runtime_deployment && python
  deploy.py deploy`. Without one the page says so and prints the commands
  rather than failing.
- **Three test cases** — the same three prompts, organised by *case* rather
  than by service, for an audience that needs no AWS background. Six stages
  (the ask arrives, the agent remembers, it asks what it is allowed to use, the
  model decides, the platform allows or refuses, it is written down) run across
  three columns, so the single stage where the cases diverge is visible rather
  than described. The storyboard half makes no AWS call and commits to a
  prediction; one button then sends all three prompts to the hosted agent and
  draws the real traces next to it, with a table whose `policy` column reads
  ALLOWED / DENIED / *never consulted* — the three distinct states that all
  sound like "no" from outside. About thirty seconds for all three.
- **All traces** — every prompt ever sent from either live page, each with the
  full trace the agent returned for it. The two pages above keep one result in
  session state, which means the previous prompt's trace is destroyed by the
  next one; `trace_log.py` writes each invocation to `artifacts/traces/` as it
  happens, so this page survives a restart of Streamlit and makes no AWS call
  of its own. A table of every prompt (with its policy verdict, its tools and
  the rule that refused), a picker that reopens any one of them with the same
  diagrams and cards as the live page, one flat table of every step of every
  prompt for sorting and searching, and a download of the whole lot as one
  JSON. It also states, in a panel, the two *other* places each prompt is
  recorded and what each is good for: the agent's stdout in CloudWatch, one log
  stream per session, which covers invocations from any client and outlives
  this folder; and the AgentCore console's session view, which needs
  account-wide CloudWatch Transaction Search that is deliberately **not**
  enabled here.
- **Six capabilities** — each tab has a **Re-probe** button. Press the one on
  the Policy tab: it runs the boundary sweep against the live gateway in about
  five seconds. The Runtime tab's button invokes the hosted agent for real.

None of them makes an AWS call until a button is pressed, so the app opens
instantly and a presenter is never caught by a network error mid-sentence.

`SPEAKER_NOTES.md` is the script to read alongside it, including what to do if
the live run fails.

### Why the agent code is so small

The entire agent-side integration is a SigV4 signature and JSON-RPC over
HTTPS. There is no `InvokeGateway` API and no AWS SDK call in the tool path:

```
POST https://<gatewayId>.gateway.bedrock-agentcore.us-east-1.amazonaws.com/mcp
Authorization: AWS4-HMAC-SHA256 ...
MCP-Protocol-Version: 2025-11-25
{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{...}}
```

The agent holds **no tool credentials** — only its own AWS identity. Every
credential the tools need lives in the token vault and is fetched per call.
For production, prefer `mcp-proxy-for-aws`, which wraps the same signing.

---

## Safety properties

- **`destroy` deletes only what `setup` created**: the gateway, its two targets,
  the policy engine, the three policies, the POC's own workload identity and
  credential provider, and the POC's own memory. The reused `RefundToolEcho`
  Lambda, its workload identity `wid-nb-c5438d5f` and its credential provider
  `demo-apikey-37d2ae24` are left alone — they predate this POC and other things
  depend on them.
- **The gateway persists until you destroy it.** There is no standing hourly
  charge for a gateway; you pay per request.
- **Browser sessions are stopped in `__exit__`**, unconditionally. A session is
  a running container and `sessionTimeoutSeconds` is a safety net, not a billing
  strategy.
- **Nothing pre-existing is modified.** The 28 other gateways, the 25 `READY`
  Runtimes and the other teams' custom browsers in this account are inspected
  read-only and never invoked.
- **The capability probes create nothing except the POC's own memory.** The
  Runtime deploy probes are expected to fail and are read for their error
  codes; the IAM check is a `simulate_principal_policy` call, which changes
  nothing.
- **CloudWatch Transaction Search was not enabled.** It is an account-wide
  change with a billing impact in a shared account.
- **No real credential is printed.** The only credential material that appears
  anywhere is the backend's own `dem***123` mask and the POC's synthetic
  `nov***2e6`.
