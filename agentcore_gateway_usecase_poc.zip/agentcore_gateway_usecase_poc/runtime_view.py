"""The live page: one prompt, a hosted agent, and every service it touches.

Every other page in this app reads a recorded transcript. This one does not.
It sends the prompt you type to an agent that is **running on AWS** - not in
this process, not in this notebook - and draws what came back.

That distinction is the whole reason the page exists. A demo where the agent
runs inside the Streamlit process proves that the code works; it proves
nothing about AgentCore, because the laptop is doing all the hosting. Here the
call goes:

    Streamlit (SageMaker)
        └─ InvokeAgentRuntime  ──►  AgentCore Runtime  (novacart_price_match_agent)
                                        ├─ Memory     recall prior claims
                                        ├─ Gateway    tools/list, policy-filtered
                                        ├─ Bedrock    the model picks a tool
                                        ├─ Policy     Cedar allows or refuses
                                        ├─ Identity   target fetches the key
                                        ├─ Memory     write the outcome
                                        ├─ Browser    managed session
                                        └─ Observ.    spans + logs

and the only thing this file does is render the `trace` the hosted agent
returns. Nothing on this page is computed locally except colours and layout:
if a step is on screen, the hosted agent made that call.

Why the agent returns a trace at all, rather than this page inferring one: an
inferred trace is a drawing of what we believe happened. The agent's own
record names the API it called, the verdict it got and who decided - so a
refusal on screen is the platform refusing, and is distinguishable from the
model choosing to be cautious. Those look identical in a chat window and they
are not remotely the same claim.
"""

import json
import os
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

import streamlit as st

import trace_log

HERE = os.path.dirname(os.path.abspath(__file__))

# The deployment module lives inside this POC, and its state file is where the
# runtime ARN is recorded by `deploy.py`. Read rather than imported on purpose:
# that module has its own `config.py`, and importing it would shadow this
# app's `config` in sys.modules - a genuinely confusing failure.
RUNTIME_DIR = os.path.join(HERE, 'agentcore_runtime_deployment')
STATE_FILE = os.path.join(RUNTIME_DIR, 'runtime_state.json')

# AgentCore passes the session id as a header, and `runtimeSessionId` has a
# minimum length of 33 - a uuid4 hex string is 32 and is rejected client-side.
# `str(uuid4())` is 36.
SESSION_MIN = 33

# The six services the capability table is about, plus the two that make the
# agent work. Order is the order they appear in the trace, which is also the
# order to read them aloud in.
SERVICES = [
    ('Runtime', '🏗️', 'hosts the agent'),
    ('Memory', '🧠', 'remembers claims'),
    ('Gateway', '🚪', 'offers the tools'),
    ('Bedrock', '🤖', 'decides'),
    ('Policy', '🛡️', 'allows or refuses'),
    ('Identity', '🔑', 'holds the credential'),
    ('Browser', '🌐', 'opens a page'),
    ('Observability', '📊', 'records it'),
]

VERDICT_COLOUR = {
    'OK': ('#1e7f3f', '#eaf5ec'),
    'ALLOWED': ('#1e7f3f', '#eaf5ec'),
    'DENIED': ('#c5221f', '#fdecea'),
    'ERROR': ('#c5221f', '#fdecea'),
    'SKIPPED': ('#80868b', '#f1f3f4'),
}

# Prompts chosen so the *platform* decides the outcome, not the model.
#
# This matters more than it sounds. Earlier, vaguer prompts made the model ask
# a clarifying question, or decline a large refund on its own judgement - which
# demonstrates a guardrail that is not there, and is the easiest way to give a
# management audience a false impression. Each prompt below is specific enough
# that the model has no reason to hesitate, so whatever stops it is real.
#
# Each claim number carries a {claim} placeholder filled in at click time. The
# agent recalls prior turns from AgentCore Memory across sessions, so a
# hardcoded claim number means it eventually recalls an earlier *demo run* of
# the same claim, decides the matter is settled and answers without calling the
# tool. The reply still reads well; the trace quietly loses its policy
# decision. That is the worst kind of demo failure, so the claim is fresh every
# time and recall stays context rather than verdict.
PRESETS = [
    ('✅ Inside the limit',
     'Price-match claim, already verified by the fraud team. Walmart lists '
     'the NovaCart Blender Pro at $80 and we charged $95. Refund the $15 '
     'difference. Reason: verified price-match claim {claim}.',
     'The agent searches, then refunds $15. Policy permits it.'),
    ('🛑 Over the limit',
     'Price-match claim, already verified. We charged $300 for the NovaCart '
     'Espresso Station and a competitor sells it for $199. Refund the $101 '
     'difference. Reason: verified price-match claim {claim}.',
     'Same agent, same tool, bigger number. Cedar refuses and names the rule.'),
    ('👻 A tool nobody granted',
     'Issue $40 of store credit to the customer for the price difference on '
     'the NovaCart Blender Pro. Store credit is not a refund - use the store '
     'credit tool. Reason: goodwill credit for claim {claim}.',
     'Store credit is absent from tools/list entirely — not forbidden, absent.'),
]


def fresh_claim() -> str:
    """A claim number the agent has never seen. See the note above PRESETS."""
    return f'#PM-{uuid.uuid4().hex[:4]}'


# ------------------------------------------------------------------ the call

def runtime_state() -> Optional[Dict[str, Any]]:
    if not os.path.exists(STATE_FILE):
        return None
    try:
        with open(STATE_FILE) as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None


# This POC's own gateway, written by `run_poc.py setup`. Read only for the one
# thing the invocation cannot tell us: Cedar returns the name of a policy that
# *refused*, and nothing at all about which permit matched an allowed call. So
# the engine and its policy list come from here, and the panel says so - a
# value from a local file sitting unlabelled next to values reported by the
# running agent would quietly borrow their credibility.
GATEWAY_STATE_FILE = os.path.join(HERE, 'gateway_state.json')


def gateway_state() -> Dict[str, Any]:
    try:
        with open(GATEWAY_STATE_FILE) as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return {}


# A healthy turn is 4-12 seconds measured, cold start included.
INVOKE_BUDGET = 90


def invoke(arn: str, payload: Dict[str, Any], session: str,
           retry: bool = True,
           recovered_from: Optional[str] = None
           ) -> Tuple[Dict[str, Any], float]:
    """One InvokeAgentRuntime call. Returns (parsed body, elapsed ms).

    Botocore's own retries are off, because retrying a refund is not a neutral
    act - a first attempt that timed out downstream may already have moved
    money, and a transport-layer retry cannot know that.

    The one retry this function does make is a different case, and the
    distinction is the whole reason it is allowed to. About one fresh session
    in three (measured 2026-10-11) is never routed to an instance at all: no
    agent process starts, no log stream is created, and the call hangs until
    the client gives up. Nothing ran, so nothing was charged and no refund was
    issued - retrying on a new session id is safe *here* precisely because the
    agent never saw the request. 90s rather than 240s because a healthy turn
    is 4-12 seconds, so a long wait is not patience, it is a failure nobody
    has noticed yet.
    """
    import boto3
    from botocore.config import Config
    from botocore.exceptions import ReadTimeoutError

    client = boto3.client('bedrock-agentcore', config=Config(
        connect_timeout=10, read_timeout=INVOKE_BUDGET,
        retries={'total_max_attempts': 1}))
    started = time.time()
    try:
        response = client.invoke_agent_runtime(
            agentRuntimeArn=arn, runtimeSessionId=session,
            contentType='application/json', accept='application/json',
            payload=json.dumps(payload).encode())
    except ReadTimeoutError:
        if not retry:
            raise
        return invoke(arn, payload, str(uuid.uuid4()), retry=False,
                      recovered_from=session)
    raw = response['response'].read().decode()
    elapsed = (time.time() - started) * 1000
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {'error': 'runtime returned non-JSON', 'raw': raw[:2000]}, elapsed
    if recovered_from:
        # Surfaced, not swallowed: the page says it happened and which session
        # was abandoned, so a trace that starts cold has a stated reason.
        parsed['_recovered_from'] = recovered_from
        parsed['_session'] = session
    return parsed, elapsed


def read_memory_events(memory_id: str, actor_id: str, session_id: str,
                       limit: int = 20) -> Tuple[List[Dict[str, Any]], str]:
    """Read back what the agent wrote, from AgentCore Memory itself.

    The agent reports which event ids it created. That is its own word for it.
    This goes to the service and fetches those events, which is a different and
    stronger claim: the turns are *in* the store, retrievable by anyone with the
    memory id, the actor id and the session id, after the invocation ended.

    Returns (events, note) and never raises - a page that explains governance
    should not fall over because one read failed, and the note says what went
    wrong where the events would have been.
    """
    import boto3
    from botocore.config import Config
    client = boto3.client('bedrock-agentcore', config=Config(
        connect_timeout=5, read_timeout=20, retries={'max_attempts': 2}))
    try:
        response = client.list_events(
            memoryId=memory_id, actorId=actor_id, sessionId=session_id,
            includePayloads=True, maxResults=limit)
    except Exception as exc:                            # noqa: BLE001
        return [], f'{type(exc).__name__}: {exc}'
    events = response.get('events') or []
    if not events:
        return [], ('no events for this actor and session - Memory accepted '
                    'the write but has nothing to return, which is worth '
                    'investigating rather than explaining away')
    return events, ''


def fetch_logs(log_group: str, session: str,
               limit: int = 40) -> List[str]:
    """The hosted agent's own stdout for this session, from CloudWatch.

    This is the Observability evidence, and it is deliberately fetched rather
    than asserted: the agent says where its logs are, and the app goes and
    reads them. Streams are named per session, which is what makes "these are
    *your* request's logs" a true statement rather than a plausible one.
    """
    import boto3
    from botocore.config import Config
    client = boto3.client('logs', config=Config(
        connect_timeout=5, read_timeout=20, retries={'max_attempts': 2}))
    try:
        # Ordered by last event rather than filtered by prefix: the two
        # options are mutually exclusive in this API, and the session id sits
        # in the middle of the stream name, not at its start.
        streams = client.describe_log_streams(
            logGroupName=log_group, orderBy='LastEventTime',
            descending=True, limit=20).get('logStreams', [])
    except Exception as exc:                            # noqa: BLE001
        return [f'could not list streams: {type(exc).__name__}: {exc}']

    # The stream name embeds the session id: YYYY/MM/DD/[runtime-logs-<id>]<uuid>
    matching = [s['logStreamName'] for s in streams if session[:18] in
                s.get('logStreamName', '')]
    if not matching:
        return [f'no stream for session {session[:8]}… yet — CloudWatch '
                f'delivery lags a few seconds behind the response']
    lines: List[str] = []
    for name in matching[:2]:
        try:
            events = client.get_log_events(
                logGroupName=log_group, logStreamName=name,
                limit=limit, startFromHead=True).get('events', [])
        except Exception as exc:                        # noqa: BLE001
            lines.append(f'{type(exc).__name__}: {exc}')
            continue
        for event in events:
            stamp = time.strftime('%H:%M:%S',
                                  time.localtime(event['timestamp'] / 1000))
            lines.append(f"{stamp}  {event['message'].rstrip()}")
    return lines


# --------------------------------------------------------------- the visuals

def service_graph(services: Dict[str, Any]) -> str:
    """The interaction diagram, lit up by what actually happened.

    Services the trace never mentions stay grey and dashed. That is the useful
    part: the picture is not an architecture drawing of what could happen, it
    is a record of this one request, so an absent service is visibly absent.
    """
    nodes = []
    for name, icon, role in SERVICES:
        row = services.get(name)
        if not row:
            nodes.append(f'  {name} [label="{icon} {name}\\n(not touched)", '
                         f'color="#cfd8e3", fillcolor="white", '
                         f'fontcolor="#9aa0a6", style="rounded,filled,dashed"];')
            continue
        colour, background = VERDICT_COLOUR.get(row['verdict'],
                                                ('#80868b', '#f8f9fa'))
        nodes.append(
            f'  {name} [label="{icon} {name}\\n{role}\\n'
            f'{row["calls"]} call(s) · {row["verdict"]}", '
            f'color="{colour}", fillcolor="{background}", penwidth=2];')

    return ('digraph G {\n'
            '  rankdir=LR; bgcolor="transparent"; nodesep=0.3;\n'
            '  node [fontname="Helvetica", fontsize=9, shape=box, '
            'style="rounded,filled"];\n'
            '  edge [fontname="Helvetica", fontsize=8, color="#80868b"];\n'
            '  app [label="📱 Streamlit\\n(SageMaker)", shape=note, '
            'fillcolor="#f8f9fa", color="#80868b"];\n'
            + '\n'.join(nodes) + '\n'
            '  app -> Runtime [label=" InvokeAgentRuntime "];\n'
            '  Runtime -> Memory [label=" recall "];\n'
            '  Memory -> Gateway;\n'
            '  Gateway -> Bedrock [label=" tools "];\n'
            '  Bedrock -> Policy [label=" tools/call "];\n'
            '  Policy -> Identity [label=" if allowed "];\n'
            '  Identity -> Browser [style=dashed];\n'
            '  Browser -> Observability [style=dashed];\n'
            '}\n')


def _esc(text: str, width: int = 34) -> str:
    """Make a string safe to drop into a Graphviz label, and short enough.

    Details carry JSON with quotes and backslashes in them, which end a label
    early and produce a syntax error rather than a wrong picture - so this is
    not cosmetic.
    """
    text = str(text).replace('\\', ' ').replace('"', "'").replace('\n', ' ')
    out, line = [], ''
    for word in text.split():
        if line and len(line) + len(word) + 1 > width:
            # `if line and` matters: a single token longer than the width -
            # which every ARN and most resource ids are - used to flush an
            # empty string first and put a blank line at the top of the node.
            out.append(line)
            line = word
        else:
            line = f'{line} {word}'.strip()
    if line:
        out.append(line)
    return '\\n'.join(out[:3])


def step_flow(trace: List[Dict[str, Any]], title: str = '') -> str:
    """The trace as a numbered top-to-bottom flow: one box per step.

    `service_graph` answers "which services took part". This answers the
    question management actually asks first, which is "what happened, in what
    order, and where did it stop" - and it is the same data, so the two cannot
    disagree.

    Vertical rather than left-to-right because the thing being read is a
    sequence of events in time, and because fourteen boxes in a row is a
    horizontal scrollbar nobody drags.
    """
    icons = dict((name, glyph) for name, glyph, _ in SERVICES)
    nodes, edges = [], []
    for index, step in enumerate(trace):
        colour, background = VERDICT_COLOUR.get(step['verdict'],
                                                ('#80868b', '#f8f9fa'))
        latency = step.get('latency_ms') or 0.0
        icon = icons.get(step['service'], '•')
        timing = (f'{latency:.0f} ms' if latency else
                  'decided in the call above' if step.get('inferred')
                  else 'no network call')
        nodes.append(
            f'  s{index} [label="{step["seq"]}. {icon} {step["service"]}\\n'
            f'{_esc(step["api"], 30)}\\n{step["verdict"]} · {timing}", '
            f'color="{colour}", fillcolor="{background}", penwidth=2];')
        if index:
            gap = (step.get('at_ms') or 0) - (trace[index - 1].get('at_ms') or 0)
            edges.append(f'  s{index - 1} -> s{index} '
                         f'[label=" +{max(gap, 0):.0f} ms "];')

    heading = (f'  label="{_esc(title, 60)}"; labelloc=t; fontsize=11; '
               f'fontcolor="#5f6368";\n' if title else '')
    return ('digraph F {\n'
            '  rankdir=TB; bgcolor="transparent"; nodesep=0.2; ranksep=0.22;\n'
            '  node [fontname="Helvetica", fontsize=9, shape=box, '
            'style="rounded,filled", width=2.6];\n'
            '  edge [fontname="Helvetica", fontsize=7, color="#9aa0a6"];\n'
            + heading
            + ('\n'.join(nodes) or '  empty [label="nothing ran yet", '
                                   'color="#dadce0", fillcolor="white", '
                                   'fontcolor="#9aa0a6", style="dashed"];')
            + '\n' + '\n'.join(edges) + '\n}\n')


def _tool_before_identity(trace: List[Dict[str, Any]]) -> Optional[str]:
    """Which tool's target fetched the credential.

    The Identity step says a target fetched the key but not which one, and the
    answer matters here: the payment backend reads the vault, the search target
    does not. The trace is ordered, so the tool call immediately before the
    fetch is the target that made it. Returns None if nothing preceded it,
    which is the honest answer rather than blaming the first tool in the list.
    """
    tool = None
    for step in trace:
        api = str(step.get('api') or '')
        if api.startswith('MCP tools/call '):
            tool = api.replace('MCP tools/call ', '')
        elif step.get('service') == 'Identity':
            return tool
    return None


def facts(result: Dict[str, Any]) -> Dict[str, Any]:
    """Pull every concrete identifier this one invocation used out of itself.

    The trace already carries all of it - the tool list, the browser session
    id, the workload identity, the deciding policy, the event ids - but spread
    across steps and expanders, which is the same as not showing it. This
    collects it by service so one screen can answer "which memory, which
    gateway, which tool, which policy".

    Everything here comes from the response. Nothing is looked up locally,
    with one labelled exception handled by the caller (`gateway_state`).
    """
    trace = result.get('trace') or []
    where = result.get('where') or {}

    def steps(name: str) -> List[Dict[str, Any]]:
        return [s for s in trace if s.get('service') == name]

    def first(name: str, key: str, default: Any = None) -> Any:
        for step in steps(name):
            if step.get(key) is not None:
                return step[key]
        return default

    # The agent's own list, not derived from the trace, and the difference
    # matters on the refused path: a denied call never produces a Gateway
    # `tools/call` step - the gateway refuses and returns, so the only trace
    # row is the Cedar decision. Reading tool calls out of the trace therefore
    # reported "no tool was called" for exactly the case the demo is about.
    tool_calls = [{'tool': str(call.get('tool', '?')).split('___')[-1],
                   'qualified': call.get('tool'),
                   'verdict': call.get('verdict'),
                   'arguments': call.get('arguments'),
                   'result': call.get('backend'),
                   'message': call.get('message'),
                   'deciding_policy': call.get('deciding_policy'),
                   'latency_ms': call.get('latency_ms')}
                  for call in (result.get('tool_calls') or [])]
    bedrock = steps('Bedrock')
    return {
        'runtime': where.get('runtime') or {},
        'memory': where.get('memory') or {},
        'gateway': where.get('gateway') or {},
        'logs': where.get('logs') or {},
        'model': where.get('model'),
        'region': where.get('region'),
        'account': where.get('account'),
        'cold_start': first('Runtime', 'cold_start'),
        'tools_offered': first('Gateway', 'tools', []) or [],
        'tool_calls': tool_calls,
        'policy_steps': [{'on': str(s.get('api', '')).replace(
                              'Cedar decision on ', ''),
                          'verdict': s.get('verdict'),
                          'deciding_policy': s.get('deciding_policy'),
                          'latency_ms': s.get('latency_ms'),
                          'inferred': bool(s.get('inferred'))}
                         for s in steps('Policy')],
        'identity': {'workload': first('Identity', 'workload'),
                     'provider': first('Identity', 'provider'),
                     'masked': first('Identity', 'masked'),
                     'after_tool': _tool_before_identity(trace)},
        'browser': {'session': first('Browser', 'session_id'),
                    'endpoint': first('Browser', 'endpoint'),
                    'drove_page': first('Browser', 'drove_page')},
        'bedrock': {'turns': len(bedrock),
                    'input_tokens': sum(s.get('input_tokens') or 0
                                        for s in bedrock),
                    'output_tokens': sum(s.get('output_tokens') or 0
                                         for s in bedrock)},
    }


def resource_graph(result: Dict[str, Any]) -> str:
    """The interaction diagram again - but every node names the real thing.

    `service_graph` shows *that* Memory was touched. This shows *which* memory,
    which gateway, which tool, and which policy decided. It is the same data;
    the difference is that a reader can take an id off this picture and go
    look it up in the console, which is the whole difference between a diagram
    and evidence.
    """
    detail = facts(result)
    services = result.get('services') or {}

    def node(key: str, service: str, label: str, shape: str = 'box') -> str:
        row = services.get(service)
        colour, background = VERDICT_COLOUR.get(
            (row or {}).get('verdict', ''), ('#cfd8e3', 'white'))
        style = ('rounded,filled' if row else 'rounded,filled,dashed')
        font = '#202124' if row else '#9aa0a6'
        return (f'  {key} [label="{label}", shape={shape}, style="{style}", '
                f'color="{colour}", fillcolor="{background}", '
                f'fontcolor="{font}", penwidth={2 if row else 1}];')

    runtime = detail['runtime']
    memory = detail['memory']
    gateway = detail['gateway']
    written = memory.get('events_written') or []

    nodes = [
        '  app [label="📱 Streamlit\\n(SageMaker)", shape=note, '
        'fillcolor="#f8f9fa", color="#80868b", style=filled];',
        node('rt', 'Runtime',
             f'🏗️ Runtime\\n{_esc(runtime.get("id") or "?", 30)}\\n'
             f'session {str(runtime.get("session_id") or "?")[:8]}…'),
        node('mem', 'Memory',
             f'🧠 Memory\\n{_esc(memory.get("id") or "not resolved", 30)}\\n'
             f'actor {_esc(memory.get("actor_id") or "?", 26)}\\n'
             f'{len(written)} event(s) written'),
        node('gw', 'Gateway',
             f'🚪 Gateway\\n{_esc(gateway.get("id") or "?", 30)}\\n'
             f'{len(detail["tools_offered"])} tool(s) offered'),
        node('mdl', 'Bedrock',
             f'🤖 Bedrock\\n{_esc(detail.get("model") or "planner", 30)}\\n'
             f'{detail["bedrock"]["turns"]} turn(s)'),
        node('br', 'Browser',
             f'🌐 Browser\\n'
             f'{_esc(detail["browser"].get("session") or "not opened", 28)}'),
        node('obs', 'Observability',
             f'📊 Observability\\n'
             f'{_esc((detail["logs"].get("group") or "?").split("/")[-1], 30)}'),
    ]

    # One node per policy decision, naming the rule when the service named it.
    # Cedar returns the deciding policy on a refusal and nothing on a permit,
    # so the permit node says "permitted" rather than inventing a rule name.
    edges = ['  app -> rt [label=" InvokeAgentRuntime "];',
             '  rt -> mem [label=" recall + write "];',
             '  rt -> gw [label=" tools/list "];',
             '  rt -> mdl [label=" Converse "];',
             '  rt -> br [style=dashed];',
             '  rt -> obs [style=dashed, label=" spans + stdout "];']

    for index, call in enumerate(detail['tool_calls'] or []):
        colour, background = VERDICT_COLOUR.get(call['verdict'] or '',
                                                ('#80868b', '#f8f9fa'))
        nodes.append(f'  t{index} [label="🔧 {_esc(call["tool"], 24)}\\n'
                     f'{call["verdict"]}", color="{colour}", '
                     f'fillcolor="{background}", style="rounded,filled", '
                     f'penwidth=2];')
        edges.append(f'  gw -> t{index} [label=" tools/call "];')

    for index, decision in enumerate(detail['policy_steps'] or []):
        colour, background = VERDICT_COLOUR.get(decision['verdict'] or '',
                                                ('#80868b', '#f8f9fa'))
        rule = decision.get('deciding_policy') or 'permitted'
        timing = (f'{decision["latency_ms"]:.0f} ms'
                  if decision.get('latency_ms') else 'inside the call')
        nodes.append(f'  p{index} [label="🛡️ Cedar on '
                     f'{_esc(decision["on"], 22)}\\n{_esc(rule, 30)}\\n'
                     f'{decision["verdict"]} · {timing}", color="{colour}", '
                     f'fillcolor="{background}", style="rounded,filled", '
                     f'penwidth=2];')
        edges.append(f'  gw -> p{index} [style=dotted];')

    if detail['identity'].get('workload'):
        nodes.append(
            f'  idn [label="🔑 Identity\\n'
            f'{_esc(detail["identity"]["workload"], 28)}\\n'
            f'provider {_esc(detail["identity"].get("provider") or "?", 24)}\\n'
            f'agent saw {_esc(detail["identity"].get("masked") or "?", 20)}", '
            f'color="#1e7f3f", fillcolor="#eaf5ec", style="rounded,filled", '
            f'penwidth=2];')
        # Deliberately drawn from the tool, not from the agent: the target
        # fetches the credential itself. An edge from `rt` would draw the one
        # thing this architecture exists to prevent. And from the *right* tool:
        # the payment target reads the vault, the search target does not, so
        # anchoring to t0 put the key on whichever tool happened to run first.
        names = [c['tool'] for c in detail['tool_calls']]
        after = detail['identity'].get('after_tool')
        target = 'gw'
        if after in names:
            target = f't{names.index(after)}'
        elif names:
            target = f't{len(names) - 1}'
        edges.append(f'  {target} -> idn [label=" target fetches the key "];')

    return ('digraph R {\n'
            '  rankdir=LR; bgcolor="transparent"; nodesep=0.22; ranksep=0.5;\n'
            '  node [fontname="Helvetica", fontsize=8.5];\n'
            '  edge [fontname="Helvetica", fontsize=7.5, color="#80868b"];\n'
            + '\n'.join(nodes) + '\n' + '\n'.join(edges) + '\n}\n')


def service_board(services: Dict[str, Any]) -> None:
    """One card per service. The at-a-glance answer for someone not reading."""
    columns = st.columns(4, gap='small')
    for index, (name, icon, role) in enumerate(SERVICES):
        row = services.get(name)
        with columns[index % 4]:
            if not row:
                st.markdown(
                    "<div style='border:1px dashed #dadce0;border-radius:8px;"
                    "padding:10px 12px;margin-bottom:8px;opacity:.5'>"
                    f"<div style='font-size:.95rem'>{icon} <b>{name}</b></div>"
                    "<div style='color:#80868b;font-size:.8rem'>not touched"
                    "</div></div>", unsafe_allow_html=True)
                continue
            colour, background = VERDICT_COLOUR.get(row['verdict'],
                                                    ('#80868b', '#f8f9fa'))
            st.markdown(
                f"<div style='background:{background};border-left:5px solid "
                f"{colour};border-radius:6px;padding:10px 12px;"
                f"margin-bottom:8px'>"
                f"<div style='font-size:.95rem'>{icon} <b>{name}</b></div>"
                f"<div style='color:{colour};font-weight:700;font-size:.85rem'>"
                f"{row['verdict']}</div>"
                f"<div style='color:#5f6368;font-size:.78rem'>"
                f"{row['calls']} call(s) · {row['total_ms']:.0f} ms · {role}"
                f"</div></div>", unsafe_allow_html=True)


def step_card(step: Dict[str, Any], slowest: float) -> None:
    """One trace step, with a latency bar scaled to the slowest step.

    The bar is there to answer the question management always asks third,
    after "does it work" and "can it be bypassed": what does the governance
    cost in latency. Usually the honest answer is visible here - the policy
    decision is the thinnest bar on the page.
    """
    colour, background = VERDICT_COLOUR.get(step['verdict'],
                                            ('#80868b', '#f8f9fa'))
    icon = dict((name, glyph) for name, glyph, _ in SERVICES).get(
        step['service'], '•')
    latency = step.get('latency_ms') or 0.0
    width = max(2, int(100 * latency / slowest)) if slowest else 2

    st.markdown(
        f"<div style='display:flex;gap:10px;align-items:flex-start;"
        f"border-left:4px solid {colour};background:{background};"
        f"padding:8px 12px;border-radius:5px;margin-bottom:6px'>"
        f"<div style='font-size:1.1rem;min-width:28px'>{icon}</div>"
        f"<div style='flex:1'>"
        f"<div><b>{step['seq']}. {step['service']}</b> "
        f"<span style='color:{colour};font-weight:700'>{step['verdict']}</span>"
        f" <code style='font-size:.78rem'>{step['api']}</code></div>"
        f"<div style='color:#3c4043;font-size:.84rem;margin-top:2px'>"
        f"{step['detail']}</div>"
        f"<div style='margin-top:5px'>"
        f"<span style='display:inline-block;height:5px;width:{width}%;"
        f"background:{colour};border-radius:3px;vertical-align:middle'></span>"
        f"<span style='color:#80868b;font-size:.74rem;margin-left:6px'>"
        f"{latency:.0f} ms"
        + ("" if latency else
           " (decided inside the call above)" if step.get('inferred')
           else " (no network call)")
        + f" · at +{step.get('at_ms', 0):.0f} ms</span>"
          f"</div></div></div>", unsafe_allow_html=True)


def headline(result: Dict[str, Any]) -> None:
    """The one-sentence verdict, before any detail."""
    denials = [s for s in result.get('trace', [])
               if s['verdict'] == 'DENIED']
    allowed = [s for s in result.get('trace', [])
               if s['verdict'] == 'ALLOWED']
    errors = [s for s in result.get('trace', []) if s['verdict'] == 'ERROR']

    if denials:
        step = denials[0]
        st.error(f"🛑 **The platform refused the agent.** "
                 f"{step['api']} — deciding rule "
                 f"`{step.get('deciding_policy') or 'unknown'}`. The target "
                 f"was never invoked, so no money moved. The agent could not "
                 f"override this and did not try.")
    elif allowed:
        st.success(f"✅ **Allowed, and governed.** "
                   f"{len(allowed)} tool call(s) passed policy and executed. "
                   f"The agent held no credential at any point — the target "
                   f"fetched it from the Identity vault at call time.")
    else:
        st.info('The agent answered without calling a tool. No policy '
                'decision was needed, so there is nothing for Cedar to show.')
    if errors:
        st.warning(f"{len(errors)} step(s) returned an error and are shown as "
                   f"ERROR below rather than hidden. A failing dependency "
                   f"degrades one row of this page, not the whole run.")


# ------------------------------------------------------------------ the page

def render() -> None:
    st.title('Ask the hosted agent')
    st.subheader('Your prompt, an agent running on AWS, and every service it '
                 'touches', divider='blue')

    state = runtime_state()
    if not state or not state.get('agentRuntimeArn'):
        st.warning(
            'No deployed runtime found. This page calls a real AgentCore '
            'Runtime, so there has to be one.\n\n'
            '```bash\ncd agentcore_runtime_deployment\n'
            'python verify_local.py      # 4s, checks the HTTP contract\n'
            'python deploy.py preflight  # checks role, bucket, subnets, egress\n'
            'python deploy.py deploy\n```')
        return

    st.markdown(f'''
The agent is **not running in this app**. It is hosted at
`{state['agentRuntimeId']}` in account `{state.get('region', 'us-east-1')}`,
and the only thing this page does is call `InvokeAgentRuntime` and draw the
trace it returns.

Everything below is the hosted agent's own record of what it called. If a
service is on screen, it was touched; if it is grey, it was not.
''')

    # Session state so that opening an expander - which re-runs the whole
    # script - does not silently re-invoke the agent and re-issue a refund.
    if 'rt_result' not in st.session_state:
        st.session_state.rt_result = None
        st.session_state.rt_session = str(uuid.uuid4())
        st.session_state.rt_prompt = PRESETS[0][1].format(claim=fresh_claim())

    left, right = st.columns([1, 1.25], gap='large')

    with left:
        st.markdown('**Start from a known case**')
        for label, text, note in PRESETS:
            if st.button(label, width='stretch'):
                st.session_state.rt_prompt = text.format(claim=fresh_claim())
            st.caption(note)

        prompt = st.text_area('Or type anything you like', height=140,
                              key='rt_prompt')
        keep = st.checkbox(
            'Keep the same session (the agent remembers this conversation)',
            value=True,
            help='AgentCore routes one session id to one instance, so the '
                 'agent keeps the conversation in memory. Uncheck to start '
                 'cold and see a cold start in the trace.')
        with_browser = st.checkbox('Open a managed browser session',
                                   value=True,
                                   help='A real StartBrowserSession call from '
                                        'inside Runtime. Adds about 2 seconds.')
        go = st.button('Send it to the hosted agent', type='primary',
                       width='stretch')
        st.caption(f'Session `{st.session_state.rt_session[:8]}…`')

    if go:
        if not keep:
            st.session_state.rt_session = str(uuid.uuid4())
        assert len(st.session_state.rt_session) >= SESSION_MIN
        with right:
            with st.spinner('Calling AgentCore Runtime… a cold instance can '
                            'take up to 30 seconds to answer its first '
                            'request.'):
                try:
                    result, elapsed = invoke(
                        state['agentRuntimeArn'],
                        {'prompt': prompt, 'browser': with_browser},
                        st.session_state.rt_session)
                    result['_round_trip_ms'] = elapsed
                    if result.get('_session'):
                        # The first session was never routed to an instance,
                        # so the app moved to a new one. Keep the page and the
                        # agent agreeing about which session this is.
                        st.session_state.rt_session = result['_session']
                    st.session_state.rt_result = result
                    # Written before the page renders anything, because the
                    # next press of this button destroys `rt_result`. The
                    # *All traces* page reads these back.
                    trace_log.record(prompt, result, source='ask',
                                     session=st.session_state.rt_session)
                except Exception as exc:                # noqa: BLE001
                    st.session_state.rt_result = None
                    st.error(f'`InvokeAgentRuntime` failed: '
                             f'{type(exc).__name__}: {exc}')
                    st.caption(
                        'Two failures look alike from here and are not. A '
                        'generic 502 with an empty log group means the runtime '
                        'has no egress — a subnet whose only default route is '
                        'an internet gateway is not egress for an ENI with no '
                        'public IP, and `python deploy.py preflight` checks '
                        f'for it. A read timeout after {INVOKE_BUDGET}s with '
                        'no log stream at all means the request was never '
                        'routed to an instance; this page already retried '
                        'once on a fresh session, so pressing the button '
                        'again is a reasonable next move.')

    result = st.session_state.rt_result

    with right:
        if not result:
            st.info('Nothing has been sent yet. This page makes no AWS calls '
                    'until you press the button.')
            st.graphviz_chart(service_graph({}), width='stretch')
            st.caption('All eight services grey, because nothing has run.')
            return

        if result.get('error'):
            st.error(f"The agent reported: {result['error']}")
            with st.expander('Traceback from inside the runtime'):
                st.code(result.get('detail', '—'))
            return

        if result.get('_recovered_from'):
            st.warning(
                f"The first attempt was never routed to an instance — session "
                f"`{result['_recovered_from'][:8]}…` got no agent process and "
                f"no log stream, so the call hung until the {INVOKE_BUDGET}s "
                f"budget ran out. This is the trace from the retry, on a new "
                f"session, which is why it starts cold. Nothing ran on the "
                f"first attempt, so nothing was duplicated.")

        served = result.get('served_by') or {}
        st.caption(
            f"Answered by **{served.get('runtime', '?')}** as "
            f"`{(served.get('identity') or '?').split('/')[-1]}` · "
            f"round trip {result.get('_round_trip_ms', 0):.0f} ms, of which "
            f"{result.get('total_ms', 0):.0f} ms was inside the agent")

        headline(result)
        st.markdown(f"> {result.get('reply', '—')}")

    st.markdown('---')
    services = result.get('services') or {}
    trace = result.get('trace') or []

    st.markdown('### Which services took part — and which actual resources')
    service_board(services)
    st.graphviz_chart(resource_graph(result), width='stretch')
    st.caption('Drawn from the trace, not from an architecture document. '
               'Dashed and grey means this request did not touch it. Every '
               'box names the real thing: the runtime id, the memory store '
               'and actor, the gateway, each tool that was called with its '
               'verdict, the Cedar rule that decided, the workload identity '
               'the credential came from and the browser session. You can '
               'take any of those ids to the console.')

    st.markdown('### Every step, in order')
    st.graphviz_chart(step_flow(trace), width='stretch')
    st.caption('Top to bottom is time. The number on each arrow is the gap '
               'between that step and the one before it, so a long arrow is a '
               'long wait and you can see which service caused it. The same '
               'steps are below with full detail.')

    st.markdown('### The same steps, with what each one returned')
    slowest = max([s.get('latency_ms') or 0.0 for s in trace] or [1.0])
    for step in trace:
        step_card(step, slowest)
        extras = {key: value for key, value in step.items()
                  if key not in ('seq', 'service', 'api', 'detail', 'verdict',
                                 'latency_ms', 'at_ms')}
        if extras:
            with st.expander(f"What step {step['seq']} returned"):
                st.json(extras, expanded=False)

    columns = st.columns(4)
    columns[0].metric('Services touched', len(services))
    columns[1].metric('Interactions', len(trace))
    columns[2].metric('Agent time', f"{result.get('total_ms', 0):.0f} ms")
    # Only a refusal has a latency of its own: the gateway rejects the call
    # and returns, so the whole round trip *is* the policy decision. A permit
    # is taken inside a call that also runs the target, and there is no way to
    # subtract one from the other from out here. Reporting "0 ms" for the
    # permit would be a measurement nobody made, so the metric says which case
    # it is looking at instead.
    policy = services.get('Policy') or {}
    policy_ms = policy.get('total_ms') or 0.0
    if policy.get('verdict') == 'DENIED' and policy_ms:
        columns[3].metric('Policy decision', f'{policy_ms:.0f} ms',
                          help='The measured cost of the refusal: the gateway '
                               'evaluated Cedar, refused, and returned '
                               'without invoking the target. Enforced on the '
                               'request path, so this is not an estimate.')
    elif policy:
        columns[3].metric('Policy decision', 'permitted',
                          help='Cedar ran and allowed the call. It has no '
                               'separate latency to report, because the '
                               'decision is taken inside the same gateway '
                               'call that invokes the target. Only a refusal '
                               'can be timed on its own.')
    else:
        columns[3].metric('Policy decision', 'no tool call',
                          help='The agent answered without calling a tool, so '
                               'there was nothing for Cedar to decide.')

    _render_evidence(result, trace)


def _badge(verdict: Optional[str], note: str = '') -> None:
    colour, background = VERDICT_COLOUR.get(verdict or '',
                                            ('#80868b', '#f1f3f4'))
    st.markdown(
        f"<span style='background:{background};color:{colour};font-weight:700;"
        f"font-size:.7rem;padding:2px 8px;border-radius:10px'>"
        f"{verdict or 'not touched'}</span>"
        + (f"<span style='color:#80868b;font-size:.75rem;margin-left:8px'>"
           f"{note}</span>" if note else ''), unsafe_allow_html=True)


def _kv(label: str, value: Any) -> None:
    """One labelled identifier. Short values inline, long ones in a code box.

    The split is on length rather than on importance because the long ones are
    the ARNs, and an ARN that has been ellipsised is no longer something a
    reader can paste into a console - which is the only reason it is here.
    """
    if value in (None, '', [], {}):
        value = '—'
    if isinstance(value, (list, tuple)):
        value = ', '.join(str(item) for item in value) or '—'
    value = str(value)
    if len(value) > 58:
        st.caption(label)
        st.code(value, language=None)
    else:
        st.markdown(
            f"<div style='font-size:.8rem;margin:1px 0'>"
            f"<span style='color:#80868b'>{label}</span> "
            f"<code style='font-size:.76rem;background:#f1f3f4;"
            f"padding:1px 4px;border-radius:3px'>{value}</code></div>",
            unsafe_allow_html=True)


def _render_resource_cards(result: Dict[str, Any]) -> None:
    """One card per service, each naming the resource it actually used.

    This is the panel the rest of the page was missing. The trace had all of
    it already - the memory id, the tool list, the deciding policy, the
    workload identity, the browser session - but spread over eight expanders,
    which in practice meant nobody saw it. "Which memory? which gateway? which
    policy triggered?" should be answerable without opening anything.

    Almost every value here was reported by the hosted agent. The exception is
    the policy engine and its rule list, which comes from this POC's own state
    file and is labelled as such, because Cedar names a policy that *refused*
    and says nothing about which permit matched an allowed call.
    """
    detail = facts(result)
    services = result.get('services') or {}
    stack = gateway_state()

    def verdict_of(name: str) -> Optional[str]:
        return (services.get(name) or {}).get('verdict')

    def calls_of(name: str) -> str:
        row = services.get(name)
        return (f"{row['calls']} call(s) · {row['total_ms']:.0f} ms"
                if row else 'this request did not touch it')

    if not result.get('where'):
        st.info('This response carries no `where` block, so the ARNs are not '
                'available. The hosted agent predates it — redeploy with '
                '`cd agentcore_runtime_deployment && python deploy.py deploy`.')

    runtime, memory = detail['runtime'], detail['memory']
    gateway, logs = detail['gateway'], detail['logs']

    left, right = st.columns(2, gap='medium')

    with left, st.container(border=True):
        st.markdown('**🏗️ Runtime** — where the agent ran')
        _badge(verdict_of('Runtime'), calls_of('Runtime'))
        _kv('ARN', runtime.get('arn'))
        _kv('runtime id', runtime.get('id'))
        _kv('endpoint', runtime.get('endpoint'))
        _kv('invoked by', runtime.get('invoked_by'))
        _kv('session id', runtime.get('session_id'))
        _kv('instance', 'cold start' if detail.get('cold_start')
            else 'warm' if detail.get('cold_start') is False else None)
        _kv('running as', runtime.get('running_as'))
        st.caption(
            f"Source: {runtime.get('source', 'unknown')}. The role session is "
            f"one AgentCore minted for this invocation — nothing in this app "
            f"can produce one, which is how you can tell the answer did not "
            f"come from this process.")

    with right, st.container(border=True):
        st.markdown('**🧠 Memory** — where the conversation was stored')
        _badge(verdict_of('Memory'), calls_of('Memory'))
        _kv('memory id', memory.get('id'))
        _kv('ARN', memory.get('arn'))
        _kv('actor id', memory.get('actor_id'))
        _kv('session id', memory.get('session_id'))
        _kv('events written now', memory.get('events_written'))
        _kv('earlier sessions read',
            len(memory.get('sessions_read') or []) or None)
        _kv('APIs', f"{memory.get('wrote_with', '?')} · "
                    f"{memory.get('read_with', '?')}")
        recalled = result.get('recalled') or []
        if recalled:
            with st.expander(f'{len(recalled)} turns recalled before the '
                             f'model reasoned'):
                st.caption('Written by *earlier* conversations, not this one. '
                           'The system prompt states that recalled history is '
                           'context and not permission, because an earlier '
                           'version treated a recalled denial as a standing '
                           'decision and skipped the tool call.')
                for line in recalled[:8]:
                    st.markdown(f'- {line[:180]}')
        if memory.get('id') and st.button(
                'Read these events back from AgentCore Memory',
                key='rt_read_memory', width='stretch'):
            with st.spinner('Calling ListEvents…'):
                events, note = read_memory_events(
                    memory['id'], memory.get('actor_id', ''),
                    memory.get('session_id', ''))
            if note:
                st.warning(f'Memory returned nothing to show: {note}')
            for event in events:
                stamp = event.get('eventTimestamp')
                stamp = (stamp.strftime('%H:%M:%S')
                         if hasattr(stamp, 'strftime') else str(stamp))
                texts = []
                for item in event.get('payload') or []:
                    turn = item.get('conversational') or {}
                    body = (turn.get('content') or {}).get('text', '')
                    texts.append(f"**{turn.get('role', '?')}** — {body[:320]}")
                st.markdown(f"`{event.get('eventId', '?')}` · {stamp}  \n"
                            + '  \n'.join(texts))
            if events:
                st.caption('Fetched from the store after the invocation '
                           'ended, so this is persistence rather than '
                           'in-process state. Those ids were the agent\'s '
                           'word for it; this is the service\'s.')

    left, right = st.columns(2, gap='medium')

    with left, st.container(border=True):
        st.markdown('**🚪 Gateway** — which door, and which tools it offered')
        _badge(verdict_of('Gateway'), calls_of('Gateway'))
        _kv('gateway id', gateway.get('id'))
        _kv('MCP endpoint', gateway.get('url'))
        _kv('signed with', gateway.get('called_with'))
        _kv('tools offered', detail['tools_offered'])
        _kv('tools called', [f"{c['tool']} → {c['verdict']}"
                             for c in detail['tool_calls']] or None)
        st.caption('The offered list is policy-filtered, so it is the agent’s '
                   'whole vocabulary: a tool no policy grants is absent from '
                   'it rather than present and forbidden. Nothing in '
                   '`agent.py` names a tool.')

    with right, st.container(border=True):
        st.markdown('**🛡️ Policy** — which rule decided')
        _badge(verdict_of('Policy'), calls_of('Policy'))
        if detail['policy_steps']:
            for decision in detail['policy_steps']:
                timing = (f"{decision['latency_ms']:.0f} ms measured"
                          if decision.get('latency_ms')
                          else 'decided inside the gateway call')
                _kv(f"on {decision['on']}",
                    f"{decision['verdict']} · "
                    f"{decision.get('deciding_policy') or 'no rule named'} · "
                    f"{timing}")
        else:
            _kv('decisions', 'none — the agent called no tool, so there was '
                             'nothing for Cedar to decide')
        st.caption('Cedar names the policy that **refuses**. On a permitted '
                   'call it returns a decision but not which rule matched, so '
                   'the permit rows say so instead of naming one.')
        _kv('policy engine', stack.get('policy_engine_id'))
        _kv('rules on that engine',
            [p.get('name') for p in stack.get('policies') or []])
        st.caption('Those last two lines come from this POC’s own '
                   '`gateway_state.json`, not from the invocation — flagged '
                   'because everything else on this card was reported by the '
                   'agent, and a local value should not borrow that standing.')

    left, right = st.columns(2, gap='medium')

    with left, st.container(border=True):
        st.markdown('**🔑 Identity** — who held the credential')
        _badge(verdict_of('Identity'), calls_of('Identity'))
        identity = detail['identity']
        if identity.get('workload'):
            _kv('workload identity', identity.get('workload'))
            _kv('credential provider', identity.get('provider'))
            _kv('what the agent saw', identity.get('masked'))
            _kv('fetched by', f"the {identity['after_tool']} target, not the "
                              f"agent" if identity.get('after_tool')
                else 'the tool target, not the agent')
            st.caption('The Lambda target pulls the payment key out of the '
                       'AgentCore token vault at call time. The agent passes '
                       'no credential and only ever sees that mask — an agent '
                       'fetching its own secrets is the pattern this '
                       'architecture exists to avoid.')
        else:
            _kv('credential fetch', 'none this turn')
            st.caption('No target was invoked, so nothing needed a '
                       'credential. On a refused call this card is correctly '
                       'empty: the refusal happens before the target runs.')

    with right, st.container(border=True):
        st.markdown('**🌐 Browser** — the managed session')
        _badge(verdict_of('Browser'), calls_of('Browser'))
        browser = detail['browser']
        _kv('browser session', browser.get('session'))
        _kv('CDP endpoint', browser.get('endpoint'))
        _kv('drove the page',
            'no' if browser.get('drove_page') is False else
            'yes' if browser.get('drove_page') else None)
        st.caption('A real `StartBrowserSession` from inside Runtime, opened '
                   'and closed. Driving the page needs Playwright, which '
                   'ships compiled binaries and cannot travel in a '
                   'pure-Python zip — so the trace says `drove_page: false` '
                   'rather than implying a page was read.')

    left, right = st.columns(2, gap='medium')

    with left, st.container(border=True):
        st.markdown('**🤖 Bedrock** — which model decided')
        _badge(verdict_of('Bedrock'), calls_of('Bedrock'))
        _kv('model id', detail.get('model') or 'deterministic planner')
        _kv('Converse turns', detail['bedrock']['turns'])
        _kv('tokens', f"{detail['bedrock']['input_tokens']} in · "
                      f"{detail['bedrock']['output_tokens']} out")
        _kv('region / account',
            f"{detail.get('region', '?')} · {detail.get('account', '?')}")
        st.caption('The model chooses the tool and its arguments. It is the '
                   'only component here with any discretion, and it has no '
                   'say in whether the call is permitted.')

    with right, st.container(border=True):
        st.markdown('**📊 Observability** — where the record is')
        _badge(verdict_of('Observability'), calls_of('Observability'))
        _kv('log group', logs.get('group'))
        _kv('log stream', logs.get('stream'))
        st.caption(logs.get('note', ''))
        if logs.get('group') and st.button(
                'Fetch this session’s logs from CloudWatch',
                key='rt_fetch_logs', width='stretch'):
            with st.spinner('Reading CloudWatch…'):
                lines = fetch_logs(logs['group'],
                                   result.get('session_id', ''))
            st.code('\n'.join(lines) or 'empty', language=None)


def _render_tool_calls(result: Dict[str, Any]) -> None:
    """What each tool was asked and what came back - search included.

    The cards above say *which* tools were called. This says what was actually
    sent and returned, which is where the search query, the refund amount and
    the masked credential become visible as data rather than as narration.
    """
    calls = facts(result)['tool_calls']
    st.markdown('#### What each tool was asked, and what it returned')
    if not calls:
        st.caption('No tool was called on this prompt, so there is nothing '
                   'here. That is the third demo case: the capability asked '
                   'for was absent from the gateway’s list, so the agent '
                   'answered in words.')
        return
    for index, call in enumerate(calls):
        colour, _ = VERDICT_COLOUR.get(call['verdict'] or '',
                                       ('#80868b', '#f8f9fa'))
        timing = (f" · {call['latency_ms']:.0f} ms"
                  if call.get('latency_ms') else '')
        with st.expander(f"🔧 {call['tool']} — {call['verdict']}{timing}",
                         expanded=index == 0):
            st.markdown(f"<span style='color:{colour};font-weight:700'>"
                        f"{call['verdict']}</span>", unsafe_allow_html=True)
            if call.get('qualified'):
                st.caption(f"gateway tool name `{call['qualified']}`")
            st.caption('sent')
            st.json(call.get('arguments') or {}, expanded=True)
            st.caption('returned')
            if call.get('result') is None:
                st.markdown('Nothing. The target was never invoked — on a '
                            'refusal the gateway returns before it runs, '
                            'which is why no money moved.')
            else:
                st.json(call['result'], expanded=False)
            # Only a refusal carries these two. The policy name comes from the
            # gateway's own message, so it is the service naming the rule, not
            # this page matching the amount against a limit it was told about.
            if call.get('deciding_policy'):
                st.caption('refused by')
                st.code(call['deciding_policy'], language=None)
            if call.get('message'):
                st.caption('what the gateway said')
                st.code(call['message'], language=None)


def _render_full_trace(result: Dict[str, Any],
                       trace: List[Dict[str, Any]]) -> None:
    """The unedited record, because every other view on this page is a choice.

    The cards above drop fields to stay readable, and anything dropped is
    something an audience has to take on trust. This is the whole response as
    it arrived, downloadable, so a sceptic can check that the picture matches
    the data and a reviewer can keep the artifact.
    """
    st.markdown('#### The full trace, unedited')
    st.caption(f'{len(trace)} steps. Everything above is drawn from this; '
               'nothing is added to it and nothing is held back.')

    rows = [{'#': step.get('seq'), 'service': step.get('service'),
             'api': step.get('api'), 'verdict': step.get('verdict'),
             'ms': round(step.get('latency_ms') or 0.0, 1),
             'at +ms': round(step.get('at_ms') or 0.0, 1),
             'detail': step.get('detail', '')} for step in trace]
    st.dataframe(rows, width='stretch', hide_index=True)

    with st.expander('Raw JSON of every step'):
        st.json(trace, expanded=False)
    with st.expander('Raw JSON of the whole response '
                     '(reply, services, where, recalled)'):
        st.json({key: value for key, value in result.items()
                 if key != 'trace'}, expanded=False)

    session = (result.get('session_id')
               or (result.get('where') or {}).get('runtime', {})
               .get('session_id') or 'session')
    st.download_button(
        'Download this invocation as JSON', json.dumps(result, indent=2,
                                                       default=str),
        file_name=f'runtime_invocation_{str(session)[:8]}.json',
        mime='application/json',
        help='The response exactly as the hosted agent returned it, including '
             'the ARNs, the event ids and the log group. Useful as an audit '
             'artifact and for anyone who wants to re-check a number.')


def _render_evidence(result: Dict[str, Any],
                     trace: List[Dict[str, Any]]) -> None:
    """Every claim this page makes, with the resource that backs it.

    Written as one screen rather than three narrow columns because the earlier
    version answered "did it really run on AWS" and left "which memory, which
    gateway, which policy triggered" buried in step expanders. An identifier
    nobody can find is not evidence.
    """
    st.markdown('### Check it yourself')
    st.caption(
        'One card per service, each naming the resource this single '
        'invocation used. Unless a caption says otherwise, every value was '
        'reported by the hosted agent rather than assembled here — the app '
        'already knew which runtime it dialled, so its own copy would be '
        'correct and would evidence nothing.')

    _render_resource_cards(result)
    st.markdown('')
    _render_tool_calls(result)
    st.markdown('---')
    _render_full_trace(result, trace)
