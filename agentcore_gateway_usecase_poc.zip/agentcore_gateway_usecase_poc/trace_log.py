"""Every invocation, kept on disk, so no trace is only one click from gone.

The *Ask the hosted agent* page keeps one result in `st.session_state`. That is
the right shape for the page - it answers "what just happened" - but it means
the previous prompt's trace is destroyed by the next prompt, and a demo where
the evidence only exists until someone presses the button again is not evidence
anybody can audit. Two people asked the same question in two different ways:
*where can I see all the traces for every prompt?*

So every invocation is appended here as its own JSON file, plus a one-line
summary in an index, and the *All traces* page reads them back. Three
properties worth stating, because each one is a decision:

- **Nothing here is allowed to break a demo.** Every function swallows its own
  errors and returns something usable. A failed disk write must cost a trace,
  never the invocation that produced it.
- **The response is stored verbatim.** The summary in the index is derived from
  it and is only an index; anything the summary gets wrong can be checked
  against the file it points at.
- **It is per-workspace, not per-session.** Restarting Streamlit or closing the
  browser loses nothing, which is the whole difference from session state.
"""

import json
import os
import time
import uuid
from typing import Any, Dict, List, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
TRACE_DIR = os.path.join(HERE, 'artifacts', 'traces')
INDEX_FILE = os.path.join(TRACE_DIR, 'index.jsonl')


def _summarise(record: Dict[str, Any]) -> Dict[str, Any]:
    """One flat row per invocation: enough to find a trace, not to replace it.

    Derived from the stored response rather than from the caller, so the index
    cannot disagree with the file about what happened - it can only be less
    detailed than it.
    """
    result = record.get('result') or {}
    trace = result.get('trace') or []
    services = result.get('services') or {}
    calls = result.get('tool_calls') or []
    policy = services.get('Policy') or {}
    runtime = ((result.get('where') or {}).get('runtime') or {})
    denial = next((c.get('deciding_policy') for c in calls
                   if c.get('deciding_policy')), None)
    return {
        'id': record.get('id'),
        'at': record.get('at'),
        'source': record.get('source'),
        'prompt': record.get('prompt') or '',
        'session': result.get('session_id') or record.get('session') or '',
        'runtime_id': runtime.get('id') or '',
        'steps': len(trace),
        'services': len(services),
        # Three distinct states that all sound like "no" from outside, which is
        # why the absent case says so instead of reading as a blank cell.
        'policy': policy.get('verdict') or 'never consulted',
        'deciding_policy': denial or '',
        'tools': ', '.join(f"{str(c.get('tool', '?')).split('___')[-1]}"
                           f"→{c.get('verdict')}" for c in calls),
        'agent_ms': round(result.get('total_ms') or 0.0),
        'round_trip_ms': round(result.get('_round_trip_ms') or 0.0),
        'error': (result.get('error') or '')[:200],
        'file': record.get('file'),
    }


def record(prompt: str, result: Dict[str, Any], source: str,
           session: str = '') -> Optional[str]:
    """Append one invocation. Returns the file written, or None if it could not.

    Called after the response is in hand and after it has been rendered, so a
    full disk or a read-only mount degrades the audit trail and nothing else.
    """
    try:
        os.makedirs(TRACE_DIR, exist_ok=True)
        stamp = time.strftime('%Y%m%d_%H%M%S', time.gmtime())
        # The random suffix is not decoration. Timestamp + session + source
        # collided immediately: three invocations in one batch share the
        # session and can share the second, so the second write silently
        # overwrote the first and the index pointed three rows at one file.
        ident = f'{stamp}_{(session or "nosession")[:8]}_{uuid.uuid4().hex[:4]}'
        path = os.path.join(TRACE_DIR, f'trace_{ident}_{source}.json')
        entry = {
            'id': ident,
            'at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'source': source,
            'prompt': prompt,
            'session': session,
            'file': os.path.basename(path),
            'result': result,
        }
        with open(path, 'w') as handle:
            json.dump(entry, handle, indent=1, default=str)
        with open(INDEX_FILE, 'a') as handle:
            handle.write(json.dumps(_summarise(entry), default=str) + '\n')
        return path
    except (OSError, TypeError, ValueError):
        return None


def history(limit: int = 500) -> List[Dict[str, Any]]:
    """Newest first. A damaged line is skipped, not fatal.

    `index.jsonl` is append-only and written one line at a time for exactly
    this reason: a truncated last line costs the newest row and leaves every
    earlier one readable, which a single re-serialised JSON array would not.
    """
    rows: List[Dict[str, Any]] = []
    try:
        with open(INDEX_FILE) as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except OSError:
        return []
    return list(reversed(rows))[:limit]


def load(name: str) -> Dict[str, Any]:
    """Read one stored invocation back by file name.

    `basename` is applied because the name arrives from a selector whose
    contents came off disk: it should stay a file in this directory even if the
    index is ever edited by hand.
    """
    try:
        with open(os.path.join(TRACE_DIR, os.path.basename(name))) as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return {}


def bundle(limit: int = 500) -> Dict[str, Any]:
    """Every stored invocation in one object, for the download button."""
    rows = history(limit)
    return {
        'exported_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'count': len(rows),
        'invocations': [load(row['file']) for row in rows if row.get('file')],
    }


def stats() -> Dict[str, Any]:
    """Counts for the page header, computed from the index alone."""
    rows = history()
    verdicts: Dict[str, int] = {}
    for row in rows:
        verdicts[row.get('policy') or '?'] = (
            verdicts.get(row.get('policy') or '?', 0) + 1)
    return {'total': len(rows),
            'sessions': len({r.get('session') for r in rows if r.get('session')}),
            'verdicts': verdicts,
            'first': rows[-1].get('at') if rows else None,
            'last': rows[0].get('at') if rows else None}
