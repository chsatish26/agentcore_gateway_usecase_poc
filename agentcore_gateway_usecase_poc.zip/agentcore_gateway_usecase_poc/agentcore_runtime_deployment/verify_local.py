"""Run the agent on this machine and check it against AgentCore's contract.

    python verify_local.py

Worth doing before every deploy. A packaging round trip is two minutes and a
CloudWatch read; this is four seconds, and it catches the failure that is
hardest to diagnose remotely - the agent not answering the health check the
way the service expects.

What it asserts, in the order the service checks them:

  1. the process binds 0.0.0.0:8080 without being run as __main__
  2. GET /ping returns 200 and *exactly* {"status": "Healthy"}
  3. POST /invocations returns JSON for a normal payload
  4. a malformed payload gets an error, not a hang or a dropped connection

(1) is the subtle one. This script imports agent.py rather than running it, so
if the server were started under a __main__ guard the import would return with
nothing listening and this check would fail - which is the point. The deployed
runtime does exec the file as a script, so a guard happens to work there, but
relying on that makes the one unrecoverable failure mode depend on a detail
nobody looks at.
"""

import json
import sys
import threading
import time
import urllib.error
import urllib.request
from typing import Any, Dict, Tuple

import config

BASE = f'http://127.0.0.1:{config.PORT}'
PASS, FAIL = '  pass  ', '  FAIL  '
results = []


def check(name: str, ok: bool, detail: str = '') -> bool:
    results.append(ok)
    print(f'{PASS if ok else FAIL}{name}' + (f' - {detail}' if detail else ''),
          flush=True)
    return ok


def get(path: str) -> Tuple[int, Any]:
    try:
        with urllib.request.urlopen(BASE + path, timeout=10) as response:
            return response.status, json.loads(response.read())
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode()[:200]


def post(path: str, payload: Any) -> Tuple[int, Any]:
    body = payload if isinstance(payload, (bytes, bytearray)) \
        else json.dumps(payload).encode()
    request = urllib.request.Request(
        BASE + path, data=body, method='POST',
        headers={'Content-Type': 'application/json',
                 config.SESSION_HEADER: 'verify-local-session'})
    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            return response.status, json.loads(response.read())
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode()
        try:
            return exc.code, json.loads(raw)
        except json.JSONDecodeError:
            return exc.code, raw[:300]


def main() -> int:
    print(f'importing agent.py (engine='
          f'{"bedrock" if config.USE_BEDROCK else "planner"})')
    # agent.py calls serve_forever() at import, so it has to be imported on a
    # thread that is allowed to block for the rest of the process's life.
    thread = threading.Thread(target=lambda: __import__('agent'), daemon=True)
    thread.start()

    for _ in range(50):
        time.sleep(0.2)
        try:
            urllib.request.urlopen(BASE + config.PING_PATH, timeout=1)
            break
        except Exception:                                   # noqa: BLE001
            continue

    status, body = get(config.PING_PATH)
    check('server listens on the port AgentCore probes', status == 200,
          f'GET {config.PING_PATH} -> {status}')
    check('health body is exactly the required shape',
          body == config.PING_BODY,
          f'got {json.dumps(body)}, need {json.dumps(config.PING_BODY)}')

    status, body = post(config.INVOKE_PATH,
                        {'prompt': 'Competitor lists this at $80, we charged '
                                   '$95. Refund the difference.',
                         'reset': True})
    check('a normal invocation returns 200 JSON', status == 200,
          f'-> {status}')
    if isinstance(body, dict):
        check('the reply is non-empty', bool(body.get('reply')),
              json.dumps(body.get('reply'))[:120])
        calls = body.get('tool_calls') or []
        check('at least one gateway tool was called', bool(calls),
              ', '.join(f'{c["tool"].split("___")[-1]}={c["verdict"]}'
                        for c in calls) or 'none')

    status, body = post(config.INVOKE_PATH, {'nothing': 'useful'})
    check('a payload with no prompt is reported, not crashed',
          status == 200 and isinstance(body, dict) and 'error' in body,
          f'-> {status} {json.dumps(body)[:120]}')

    status, body = post(config.INVOKE_PATH, b'{not json')
    check('malformed JSON returns an error response, not a dropped socket',
          status in (200, 500), f'-> {status}')

    status, _ = get('/nope')
    check('an unknown route 404s', status == 404, f'-> {status}')

    print()
    if all(results):
        print(f'{len(results)}/{len(results)} checks passed. '
              'Deploy with: python deploy.py deploy')
        return 0
    print(f'{sum(results)}/{len(results)} passed. Fix these before '
          'deploying - every one of them fails silently in the runtime.')
    return 1


if __name__ == '__main__':
    sys.exit(main())
