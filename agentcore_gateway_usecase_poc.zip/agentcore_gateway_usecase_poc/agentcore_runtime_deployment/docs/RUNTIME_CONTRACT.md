# What AgentCore Runtime actually hands your agent

Measured on 2026-10-11 in account 196856463470 / us-east-1 by deploying probe
agents and reading their responses. Everything below is observed output, not
documentation. Re-run the probes before trusting any of it in another account
or after a service update.

The method was deliberately crude: deploy an agent whose only job is to report
its own environment, invoke it, print the response. Four rounds of that pinned
down the contract, and each round was forced by the previous one being wrong.

---

## The contract

| | |
|---|---|
| listen on | `0.0.0.0:8080` |
| health check | `GET /ping` → `200` with body exactly `{"status": "Healthy"}` |
| invocation | `POST /invocations` → `200` with any JSON |
| session id | request header `x-amzn-bedrock-agentcore-runtime-session-id` |
| working directory | `/var/task` |
| entry file | `/var/task/agent.py`, `sys.argv == ['/var/task/agent.py']` |
| `__name__` | `__main__` — the file is exec'd as a script |
| interpreter | CPython 3.12.12 |
| architecture | `aarch64`, glibc 2.34, kernel 6.1 (Amazon Linux 2023) |
| `PYTHONPATH` | `/var/task` and nothing else |
| installed packages | **none** — there is no boto3 |
| credentials | instance metadata service; `boto3` resolves them as `iam-role` |
| identity | `arn:aws:sts::<account>:assumed-role/<role>/BedrockAgentCore-<uuid>` |

Raw probe output for the two that surprise people:

```
"boto3_error": "ModuleNotFoundError: No module named 'boto3'"

"creds_method": "iam-role",
"sts_arn": "arn:aws:sts::196856463470:assumed-role/SandboxServiceRole/
            BedrockAgentCore-946921a2-e2a7-4ab2-a1d6-2237ffb3410d"
```

There is no `AWS_CONTAINER_CREDENTIALS_RELATIVE_URI` or
`AWS_CONTAINER_CREDENTIALS_FULL_URI` in the environment, which looks like the
role was not attached. It was: IMDS answers, `boto3.Session()` with no
arguments is correct, and `169.254.169.254` is reachable (an IMDSv2 token
request returns one). No credential plumbing is needed in the agent.

The full environment is 33 variables, of which these matter:

| variable | what it is good for |
|---|---|
| `AGENTCORE_RUNTIME_URL` | the agent's own invoke URL, ARN-encoded |
| `OTEL_RESOURCE_ATTRIBUTES` | carries `service.name`, the log group name, and `cloud.resource_id` — the cheapest way for an agent to learn its own identity |
| `AGENT_OBSERVABILITY_ENABLED` | ADOT is wired up for you |
| `AWS_REGION` | set; `AWS_DEFAULT_REGION` too |

`agent.py` reads `service.name` out of `OTEL_RESOURCE_ATTRIBUTES` to report
which runtime served a response, which is how `invoke.py` can prove the answer
came from AWS and not from a local process.

`cloud.resource_id` in the same variable is the **full endpoint ARN**, measured
as:

```
arn:aws:bedrock-agentcore:us-east-1:196856463470:runtime/<runtimeId>/runtime-endpoint/DEFAULT:DEFAULT
```

Note the shape: the ARN identifies the *endpoint*, not the runtime, and the
qualifier appears twice — once as a path segment and once after the colon. That
matters because `agent.py`'s `where()` returns this string for the app to show,
and a caller who assumes a plain `runtime/<id>` ARN will mis-parse it. `where()`
reports it verbatim and says where it came from, falling back to assembling
`runtime/<id>` from the account and runtime id only if the variable is absent —
with `source` naming which of the two happened, so a reader can tell a measured
value from a constructed one.

---

## Logging

Log group `/aws/bedrock-agentcore/runtimes/<runtimeId>-DEFAULT`, which exists
only after the first invocation.

Streams, and this is the part worth knowing:

```
otel-rt-logs                                     service-vended, usually empty
spans                                            traces
2026/10/11/[runtime-logs-<sessionId>]<uuid>      *** your stdout ***
```

Your `print()` output lands in a **per-session** stream whose name embeds the
`runtimeSessionId`. So the log group is not a single chronological feed — a
session maps to a stream, and `filter_log_events` across the group is the only
way to read them in order. That is what `deploy.py logs` does.

Flush, or lose it. An agent that crashes during startup loses buffered output
and becomes indistinguishable from one that never started.

---

## The six ways this deployment fails

The first five in the order encountered; each one cost a deploy cycle, and
`deploy.py preflight` checks all five. The sixth is not a mistake you make and
preflight cannot catch it.

### 1. `codeConfiguration` is missing from your boto3

The zip-from-S3 deploy path needs no Docker, which is what makes this runnable
on a host without a Docker daemon. It is absent from older botocore service
models, and passing it then fails as a parameter validation error that reads
like you invented the field. Needs `boto3>=1.43`.

```python
{'codeConfiguration': {
    'code': {'s3': {'bucket': ..., 'prefix': ...}},
    'runtime': 'PYTHON_3_12',          # 3_10|3_11|3_12|3_13|3_14|NODE_22
    'entryPoint': ['agent.py']}}       # a list, 1-2 items
```

### 2. The runtime name grammar is not the gateway's

`[a-zA-Z][a-zA-Z0-9_]{0,47}` — **no hyphens**, 48 characters. Gateways accept
`([0-9a-zA-Z][-]?){1,48}`, so `novacart-price-match-agent` is a valid gateway
name and an invalid runtime name. The two services, one console.

### 3. A subnet in an unsupported availability zone

AgentCore Runtime runs in three us-east-1 zones. A subnet elsewhere **passes
validation**, the runtime is created, and then ~8 seconds later it goes
`CREATE_FAILED`:

```
The following subnets are in unsupported availability zones in region
us-east-1: subnet-073e48862888f6be5 in us-east-1f (ID: use1-az5) ...
Supported availability zones are: use1-az4, use1-az1, use1-az2
```

Note it reports zone **IDs**. Zone *names* are per-account aliases — this
account's `us-east-1a` is `use1-az4`, and someone else's is not — so filtering
on the name produces code that works here and breaks there. `deploy.py` filters
on `AvailabilityZoneId`.

This failure is only visible in `failureReason` on `GetAgentRuntime`. The
status alone tells you nothing.

### 4. A subnet whose only egress is an internet gateway

The expensive one, because nothing reports a problem.

A default route to an **IGW** is not egress for an AgentCore ENI: the ENI has
no public IP, so an IGW route goes nowhere. The runtime reaches `READY`, passes
its health check, and then every outbound call — to the gateway, to Bedrock —
fails. Observed symptom:

```
RuntimeClientError: Received error (502) from runtime.
Please check your CloudWatch logs for more information.
```

…and the log group contains **no session stream at all**, because log delivery
needs the same egress the agent does. An empty log group is therefore itself
the diagnosis.

A NAT gateway or a transit gateway works. In this account:

| VPC | usable subnets | 0.0.0.0/0 via | agent works |
|---|---|---|---|
| `vpc-02d65f45df09dcd82` | 3 | `igw-0f1be5f0dc9394c58` | no |
| `vpc-07b7fb5b5516a1072` | 1 | `tgw-0f0db5e5400a0428c` | yes |

`deploy.py` ranks subnets by egress type and prefers one working zone over
three broken ones. It warns loudly rather than refusing, because in some
accounts IGW-only is all there is.

### 5. `runtimeSessionId` shorter than 33 characters

`uuid4().hex` is 32. The minimum is 33 (max 256), so it is rejected client-side
before the request is sent:

```
ParamValidationError: Invalid length for parameter runtimeSessionId,
value: 32, valid min length: 33
```

`str(uuid4())` keeps the hyphens, is 36, and works.

### 6. A cold start that is never routed

Measured 2026-10-11 on a `READY` runtime that was answering other requests in
8-9 seconds either side of it. `InvokeAgentRuntime` is accepted and then
nothing happens at all:

```
botocore.exceptions.ReadTimeoutError: Read timeout on endpoint URL:
"https://bedrock-agentcore.us-east-1.amazonaws.com/runtimes/arn%3A.../invocations"
```

Three sequential single-prompt invocations, each on a fresh session id, with
nothing else running:

| attempt | wall clock | outcome |
|---|---|---|
| 1 | 8s | 7 services, normal trace |
| 2 | 361s | read timeout, no response |
| 3 | 9s | 7 services, normal trace |

Roughly one fresh session in three over the runs that afternoon. What makes it
diagnosable rather than mysterious:

- **No log stream exists for the session.** Not an empty stream - no stream.
  The instance never started, so it never printed its banner. Compare failure
  4, where the log *group* is empty for the same underlying reason (log
  delivery needs egress); here the group is full of other sessions' streams
  and this session simply has none.
- **A new session id works immediately.** The hang is per-session, not
  per-runtime. Attempt 3 above was issued seconds after attempt 2 gave up.
- **It is not the 30s initialization timeout.** That failure returns
  `RuntimeClientError` promptly and says so. This one returns nothing.

The 361s in attempt 2 is itself worth noting: the client was configured with
`retries={'max_attempts': 1}` and a 180s read timeout, and still spent two
timeouts. `max_attempts` counts differently in `standard` and `legacy` retry
modes; `retries={'total_max_attempts': 1}` is unambiguous and is what both
clients now use.

Nothing in `agent.py` can fix this, because `agent.py` is never reached. What a
caller can do is bound the wait and retry deliberately:

```python
INVOKE_BUDGET = 90           # a healthy turn is 4-12s measured
...
except ReadTimeoutError:
    # Safe to retry *here*: the agent never received the request, so nothing
    # ran, nothing was charged, and no refund was issued. A transport-level
    # retry of a call that may have succeeded downstream would not be safe,
    # which is why botocore's own retries stay off and this lives in the
    # calling code, where the two cases can be told apart.
    return call(payload, new_session(), runtime_arn, retry=False)
```

Both `invoke.py` and the app's `runtime_view.py` do this, and both announce the
retry rather than performing it silently - a demo that quietly re-asks is worse
than one that says what went wrong.

---

## The failure that is not on that list

```
RuntimeClientError: Runtime initialization time exceeded.
Please make sure that initialization completes in 30s.
```

This means nothing is listening on 8080 within 30 seconds. The usual causes,
in order of likelihood:

1. the HTTP server is started under `if __name__ == '__main__':` and that
   guard did not run
2. it is bound to `127.0.0.1` instead of `0.0.0.0`
3. it crashed on an import missing from the deploy zip
4. the image is amd64 (container mode only)

Measured, `__name__` **is** `__main__` in code mode, so (1) does not apply to
a zip deploy — but it is the first thing to check in a container, and it is why
`agent.py` starts its server at module level anyway. A guard that is
load-blocking for the process existing at all is a bad trade for two lines,
especially when the failure mode is a timeout with an empty log group.

`verify_local.py` catches (1), (2) and (3) in four seconds by importing
`agent.py` rather than running it.

---

## Other measured API behaviour

- **`UpdateAgentRuntime` requires** `agentRuntimeId`, `agentRuntimeArtifact`,
  `roleArn`. Echoing back the `networkConfiguration` that `GetAgentRuntime`
  returned **fails**, because it includes `requireServiceS3Endpoint`:

  ```
  ValidationException: Agents created after 2026-06-11T00:00:00Z cannot
  modify requireServiceS3Endpoint.
  ```

  Even setting it to the value it already has. Send only the fields you own.

- **Update is much faster than create.** Create took 264s on the first
  (cold-VPC) attempt and 24s later; updates settled in 16-20s. The variance is
  in the networking setup, not your code.

- **No `GetAgentRuntimeByName`.** The id is your name plus a service-assigned
  suffix (`novacart_price_match_agent-cLitH12n66`), so it cannot be
  constructed — you have to list and match.

- **Status values**: `CREATING`, `CREATE_FAILED`, `UPDATING`, `UPDATE_FAILED`,
  `READY`, `DELETING`, `DELETE_FAILED`.

- **`protocolConfiguration.serverProtocol`**: `HTTP | MCP | A2A | AGUI`. `MCP`
  is what makes a Runtime agent publishable as a Gateway target.

- **`lifecycleConfiguration` defaults**: `idleRuntimeSessionTimeout` 900s,
  `maxLifetime` 28800s. In-process session state dies with the instance, which
  is why conversation history in `agent.py` is explicitly labelled as
  throwaway.

- **A non-2xx response body is discarded** and replaced with the generic 502
  above. This is why `agent.py` returns `200` with an `error` key rather than
  `500` with a traceback — a 500 arrives as no information at all.

---

## Zip size

Vendoring `boto3` unpruned is 32 MB, of which 24 MB is `botocore/data` — a
JSON model for every AWS service. Keeping only the five services this agent
calls, and dropping `boto3/data` (the resource API, unused), gets the whole
artifact to **1.5 MB**:

```
packaged  agent.zip 1.5 MB (3 agent files + 209 vendored)
```

`deploy.py` prunes on the `KEEP_BOTOCORE_SERVICES` list in `config.py`. Call a
new service without adding it there and you get `UnknownServiceError` at
runtime rather than at package time, which is the one real downside of this
trick.
