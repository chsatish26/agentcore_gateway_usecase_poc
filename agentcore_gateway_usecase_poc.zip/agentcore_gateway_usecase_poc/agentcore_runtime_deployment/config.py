"""Settings for deploying an agent into AgentCore Runtime.

Everything here is overridable by environment variable so the same code can
deploy to another account without edits. The defaults are what was measured
working in account 196856463470 / us-east-1 on 2026-10-11.

Three of these constants encode findings that cost a failed deployment each to
discover. They are commented where they sit rather than in a document nobody
opens.
"""

import os

REGION = os.getenv('AWS_REGION', 'us-east-1')
ACCOUNT = os.getenv('AWS_ACCOUNT_ID', '196856463470')

# AgentCore Runtime's name grammar is NOT the gateway's. No hyphens, and 48
# characters. `novacart-price-match-agent` is rejected; the underscored form is
# the one to use. Pattern from the live service model:
#   [a-zA-Z][a-zA-Z0-9_]{0,47}
RUNTIME_NAME = os.getenv('RUNTIME_NAME', 'novacart_price_match_agent')

# The role AgentCore assumes to run the agent. It must trust
# `bedrock-agentcore.amazonaws.com` in its assume-role policy, and the caller
# must hold `iam:PassRole` for it. `deploy.py preflight` checks both rather
# than letting CreateAgentRuntime fail on the second one.
ROLE_ARN = os.getenv(
    'RUNTIME_ROLE_ARN', f'arn:aws:iam::{ACCOUNT}:role/SandboxServiceRole')

# --- how the code gets to AWS -------------------------------------------
#
# Two artifact types, and the choice matters more than it looks:
#
#   'code'      a zip in S3 run by a managed Python runtime. No Docker, no
#               image build, no ARM64 cross-compilation. This is the default
#               because it is the only one that works on a host without a
#               Docker daemon - which includes SageMaker Studio.
#   'container' an ECR image. The documented path, and the one to use when the
#               agent needs system packages a zip cannot carry. Requires
#               `docker buildx` and must be linux/arm64.
ARTIFACT_MODE = os.getenv('ARTIFACT_MODE', 'code')

CODE_BUCKET = os.getenv('CODE_BUCKET', f'agentcore-runtime-deploy-{ACCOUNT}')
CODE_PREFIX = os.getenv('CODE_PREFIX', f'{RUNTIME_NAME}/agent.zip')
PYTHON_RUNTIME = os.getenv('PYTHON_RUNTIME', 'PYTHON_3_12')

# `entryPoint` takes the file to run, as a list. Measured: ['agent.py'] is
# accepted. The list may hold up to two items.
ENTRY_POINT = [os.getenv('ENTRY_POINT', 'agent.py')]

# --- what the managed runtime does and does not give you -----------------
#
# Measured inside a live code-mode runtime on 2026-10-11 (see
# docs/RUNTIME_CONTRACT.md for the raw probe output):
#
#   cwd            /var/task          the zip is unpacked here
#   entry file     /var/task/agent.py run as a script, so __name__ == '__main__'
#   interpreter    3.12.12 on aarch64 you do not choose the arch, but zips are
#                                     arch-independent so it does not matter
#   PYTHONPATH     /var/task          only; no site-packages of your own
#   site-packages  empty of SDKs      *** there is no boto3 ***
#
# That last line is the one that matters. The managed runtime ships a bare
# interpreter: `import boto3` raises ModuleNotFoundError. Anything the agent
# imports has to travel inside the zip, which is why `deploy.py package`
# vendors dependencies into `vendor/` and `agent.py` puts that directory on
# sys.path as its first statement.
VENDOR_DIR = os.getenv('VENDOR_DIR', 'vendor')

# botocore carries a JSON model for every AWS service - 24 MB of which we need
# about 300 KB. Pruning to the services actually called takes the deploy zip
# from 32 MB to 1.5 MB. Add to this set if the agent starts calling something
# new; forgetting to is an UnknownServiceError at runtime, not at package time.
KEEP_BOTOCORE_SERVICES = set(os.getenv(
    'KEEP_BOTOCORE_SERVICES',
    'sts,bedrock,bedrock-runtime,bedrock-agentcore,bedrock-agentcore-control'
).split(','))

# --- credentials inside the runtime --------------------------------------
#
# There is no AWS_CONTAINER_CREDENTIALS_* variable in the environment, which
# looks alarming and is fine: the execution role arrives over the instance
# metadata service instead. Measured from inside:
#
#   boto3.Session().get_credentials().method  ->  'iam-role'
#   sts.get_caller_identity()['Arn']          ->  arn:aws:sts::196856463470:
#       assumed-role/SandboxServiceRole/BedrockAgentCore-946921a2-...
#
# So `boto3.Session()` with no arguments is correct and the agent needs no
# credential plumbing at all. The practical consequence for the demo: the
# identity that signs the gateway call is the *runtime's* role, not the
# developer's, and Cedar sees it that way.

ECR_REPO = os.getenv('ECR_REPO', RUNTIME_NAME.replace('_', '-'))
IMAGE_TAG = os.getenv('IMAGE_TAG', 'latest')


def image_uri() -> str:
    return (f'{ACCOUNT}.dkr.ecr.{REGION}.amazonaws.com/'
            f'{ECR_REPO}:{IMAGE_TAG}')


# --- networking ----------------------------------------------------------
#
# 'VPC' or 'PUBLIC'. PUBLIC is simpler and needs no subnets, but in this
# account it is refused outright:
#
#   AccessDeniedException ... explicit deny in an identity-based policy:
#   arn:aws:iam::196856463470:policy/Tetract-KeyStone-access
#
# That policy conditions on `bedrock-agentcore:subnets` and
# `securityGroups` being null, i.e. it exists to forbid public endpoints. VPC
# mode satisfies it, so VPC is the default here.
NETWORK_MODE = os.getenv('NETWORK_MODE', 'VPC')

# THE ONE THAT WILL BITE YOU. AgentCore Runtime does not run in every
# availability zone, and a subnet in the wrong one does not fail validation -
# it creates, then goes CREATE_FAILED about eight seconds later with:
#
#   The following subnets are in unsupported availability zones in region
#   us-east-1: subnet-xxx in us-east-1f (ID: use1-az5) ...
#   Supported availability zones are: use1-az4, use1-az1, use1-az2
#
# Note it reports zone *IDs*, not names. Zone names are shuffled per account
# (one account's us-east-1a is another's use1-az3), so filtering on the name
# is wrong in a way that works on your account and breaks on someone else's.
# `deploy.py` filters on AvailabilityZoneId for that reason.
SUPPORTED_AZ_IDS = set(
    os.getenv('SUPPORTED_AZ_IDS', 'use1-az1,use1-az2,use1-az4').split(','))

# Leave empty to auto-discover subnets in the supported zones.
SUBNET_IDS = [s for s in os.getenv('SUBNET_IDS', '').split(',') if s]
SECURITY_GROUP_IDS = [s for s in
                      os.getenv('SECURITY_GROUP_IDS', '').split(',') if s]

# 'HTTP' for a plain request/response agent, 'MCP' to publish the agent as an
# MCP server - which is what makes a Runtime agent usable as a Gateway target.
SERVER_PROTOCOL = os.getenv('SERVER_PROTOCOL', 'HTTP')

# --- the HTTP contract AgentCore requires --------------------------------
#
# Not configurable in any meaningful sense: these are the values the service
# probes. They are named here so `agent.py` and the verifier cannot drift
# apart. Get any of them wrong and the deployment succeeds, then fails health
# checks with nothing useful in the logs.
PORT = 8080
INVOKE_PATH = '/invocations'
PING_PATH = '/ping'
PING_BODY = {'status': 'Healthy'}

# --- the gateway the agent calls -----------------------------------------
#
# The point of hosting this particular agent is that it reaches Gateway tools
# from inside Runtime, and is refused by Cedar when it overreaches. Set
# GATEWAY_ID to your own gateway, or leave the default to use the price-match
# POC's.
GATEWAY_ID = os.getenv('GATEWAY_ID', 'novacart-price-match-poc-qdnpxdyr1x')
MCP_PROTOCOL_VERSION = os.getenv('MCP_PROTOCOL_VERSION', '2025-11-25')
MCP_SERVICE = 'bedrock-agentcore'
REFUND_TOOL = os.getenv('REFUND_TOOL', 'novacart___process_refund')
SEARCH_TOOL = os.getenv('SEARCH_TOOL', 'research___WebSearch')


def gateway_url() -> str:
    return (f'https://{GATEWAY_ID}.gateway.bedrock-agentcore.'
            f'{REGION}.amazonaws.com/mcp')


# --- the model that does the reasoning -----------------------------------
#
# The agent runs a real tool-use loop: the model is handed the gateway's
# tool list and decides what to call. Set USE_BEDROCK=0 to fall back to a
# deterministic planner instead - useful when demonstrating the deployment
# mechanics without depending on model access, and the reason a missing
# `bedrock:InvokeModel` grant degrades the demo rather than breaking it.
USE_BEDROCK = os.getenv('USE_BEDROCK', '1') not in ('0', 'false', 'False')

# Claude on Bedrock needs the cross-region inference-profile prefix: the bare
# `anthropic.claude-...` form is rejected with ValidationException. Both IDs
# below were verified invocable in this account on 2026-10-11.
MODEL_ID = os.getenv('MODEL_ID', 'us.anthropic.claude-haiku-4-5-20251001-v1:0')
MAX_TOKENS = int(os.getenv('MAX_TOKENS', '1024'))

# Claude 4.5+ rejects temperature and topP in the same request. Send one.
TEMPERATURE = float(os.getenv('TEMPERATURE', '0'))

# How many model/tool round trips before the loop gives up. A price-match
# claim needs two (search, then refund), so four leaves room to recover from
# one denial without letting a confused model spend money in a circle.
MAX_TURNS = int(os.getenv('MAX_TURNS', '4'))

# AgentCore passes the session id as a request header, not in the body. The
# agent uses it to keep per-session conversation history, which is what makes
# a follow-up like "try $80 instead" mean anything.
SESSION_HEADER = 'x-amzn-bedrock-agentcore-runtime-session-id'

# --- the other AgentCore services the hosted agent touches ---------------
#
# The agent reaches four more services from inside Runtime, and each one is
# recorded as a step in the trace it returns so the app can draw it. All four
# were confirmed reachable from the runtime's own role on 2026-10-11.

# Memory. The agent recalls prior settled claims before reasoning and writes
# the outcome afterwards, so a second question about the same customer has
# context the first one did not. This is the POC's existing memory resource -
# reused deliberately, so the Streamlit app's Memory page and the hosted
# agent are reading and writing the same store rather than two that merely
# look alike.
USE_MEMORY = os.getenv('USE_MEMORY', '1') not in ('0', 'false', 'False')
MEMORY_NAME = os.getenv('MEMORY_NAME', 'novacart_price_match_poc_memory')
MEMORY_ID = os.getenv('MEMORY_ID', '')          # blank = resolve by name
MEMORY_ACTOR_ID = os.getenv('MEMORY_ACTOR_ID', 'novacart-price-match-agent')

# Browser. Honest limit, stated here because it shapes what the trace can
# claim: the agent can open and close a managed browser session from inside
# Runtime - that is a real data-plane call and it is recorded as one - but it
# cannot *drive* the page. Driving CDP needs Playwright, which ships compiled
# binaries and a Chrome download, and so cannot travel in a pure-Python zip.
# Reading a price off a live page therefore stays in the Streamlit app
# (`browser_price.py`), which runs where Playwright is installed.
USE_BROWSER = os.getenv('USE_BROWSER', '1') not in ('0', 'false', 'False')
BROWSER_ID = os.getenv('BROWSER_ID', 'aws.browser.v1')
BROWSER_SESSION_TIMEOUT = int(os.getenv('BROWSER_SESSION_TIMEOUT', '60'))


def log_group(runtime_id: str) -> str:
    """Where this runtime's stdout goes. Only exists after the first invoke."""
    return f'/aws/bedrock-agentcore/runtimes/{runtime_id}-DEFAULT'


# Written by `deploy.py create`, read by `invoke.py`. Keeps the ARN out of
# shell history and lets the two scripts be used independently.
STATE_FILE = os.getenv('RUNTIME_STATE_FILE', 'runtime_state.json')

# `InvokeAgentRuntime` requires runtimeSessionId to be at least 33 characters
# (min=33, max=256 in the service model). A uuid4 hex string is 32 - one short,
# which is a genuinely annoying way to lose ten minutes. See invoke.new_session.
SESSION_ID_MIN = 33
