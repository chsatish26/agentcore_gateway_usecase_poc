"""Deploy `agent.py` into AgentCore Runtime. Run this, then run invoke.py.

    python deploy.py preflight     check everything that can be checked first
    python deploy.py deploy        package, upload, create-or-update, wait
    python deploy.py status        current state, version, failure reason
    python deploy.py logs          recent CloudWatch output from the agent
    python deploy.py destroy       delete the runtime (and its S3 artifact)

`deploy` is idempotent: it creates the runtime the first time and updates it
afterwards, so the edit/deploy loop is one command.

Why `preflight` exists as its own step: four of the five ways this deployment
fails are visible before anything is created, and the fifth - a subnet in an
unsupported availability zone - fails *asynchronously* eight seconds after a
successful-looking create, which is a miserable way to spend an afternoon.
Preflight checks all five.
"""

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from typing import Any, Dict, List, Optional, Tuple

import boto3
from botocore.exceptions import ClientError

import config

HERE = pathlib.Path(__file__).resolve().parent

# Shipped to the runtime alongside the vendored dependencies. Kept explicit
# rather than globbing the directory, so a scratch file or a notebook
# checkpoint never ends up inside the deployment artifact.
AGENT_FILES = ['agent.py', 'config.py', 'gateway_mcp.py']


def say(message: str) -> None:
    print(message, flush=True)


def control():
    return boto3.client('bedrock-agentcore-control', region_name=config.REGION)


# --- preflight ------------------------------------------------------------


def find_runtime() -> Optional[Dict[str, Any]]:
    """Look up the runtime by name. Returns None if it does not exist.

    There is no GetAgentRuntimeByName, and `get_agent_runtime` wants the id -
    which is the name plus a service-assigned suffix, so it cannot be
    constructed. Listing is the only way to go from a name you chose to an id
    you can use.
    """
    paginator = control().get_paginator('list_agent_runtimes')
    for page in paginator.paginate():
        for runtime in page.get('agentRuntimes', []):
            if runtime.get('agentRuntimeName') == config.RUNTIME_NAME:
                return runtime
    return None


def egress_kind(ec2, subnet: Dict[str, Any],
                tables: List[Dict[str, Any]]) -> str:
    """How - and whether - traffic from this subnet reaches the internet.

    This distinction is the whole reason this function exists. A subnet with a
    default route to an **internet gateway** looks connected and is not: the
    ENI AgentCore places in your subnet has no public IP, and an IGW route
    only works for instances that have one. The agent then starts fine, passes
    its health check, and every outbound call - to the gateway, to Bedrock -
    hangs until it fails. Nothing in the deployment reports a problem, because
    from the service's point of view there isn't one.

    A NAT gateway or a transit gateway does work. So: rank, do not just check.
    """
    explicit = next((t for t in tables for a in t['Associations']
                     if a.get('SubnetId') == subnet['SubnetId']), None)
    table = explicit or next(
        (t for t in tables if t['VpcId'] == subnet['VpcId']
         and any(a.get('Main') for a in t['Associations'])), None)
    if table is None:
        return 'none'
    for route in table['Routes']:
        if route.get('DestinationCidrBlock') != '0.0.0.0/0':
            continue
        if route.get('NatGatewayId'):
            return 'nat'
        if route.get('TransitGatewayId'):
            return 'tgw'
        if str(route.get('GatewayId', '')).startswith('igw-'):
            return 'igw'
    return 'none'


# Ranked best-first. 'igw' is deliberately below 'none' in usefulness but
# above it in rank, because it is still the only option in some accounts and a
# warning beats a refusal to deploy.
EGRESS_RANK = {'nat': 0, 'tgw': 0, 'igw': 1, 'none': 2}


def pick_network() -> Dict[str, Any]:
    """Build networkConfiguration, discovering subnets if none are configured.

    Two filters, both learned the hard way:

      * Availability zone, on `AvailabilityZoneId` and never on
        `AvailabilityZone`. Zone names are per-account aliases - your
        `us-east-1a` and mine are usually different physical zones - so a
        name-based filter is the kind of bug that passes review and then only
        fails in someone else's account. A subnet in an unsupported zone
        passes validation and then kills the runtime asynchronously.
      * Egress, per `egress_kind` above.
    """
    if config.NETWORK_MODE.upper() == 'PUBLIC':
        return {'networkMode': 'PUBLIC'}

    subnets = list(config.SUBNET_IDS)
    groups = list(config.SECURITY_GROUP_IDS)
    if subnets and groups:
        return {'networkMode': 'VPC',
                'networkModeConfig': {'subnets': subnets,
                                      'securityGroups': groups}}

    ec2 = boto3.client('ec2', region_name=config.REGION)
    tables = ec2.describe_route_tables()['RouteTables']
    usable: Dict[str, List[Tuple[str, str]]] = {}
    for subnet in ec2.describe_subnets()['Subnets']:
        if subnet['AvailabilityZoneId'] in config.SUPPORTED_AZ_IDS:
            usable.setdefault(subnet['VpcId'], []).append(
                (subnet['SubnetId'], egress_kind(ec2, subnet, tables)))
    if not usable:
        raise SystemExit(
            'No subnet in a zone AgentCore Runtime supports '
            f'({sorted(config.SUPPORTED_AZ_IDS)}). Create one, or set '
            'NETWORK_MODE=PUBLIC if this account permits public endpoints.')

    # Best egress first, then most zones - in that order, because a second
    # zone is worth less than working outbound traffic.
    def score(vpc_id: str) -> Tuple[int, int]:
        kinds = [kind for _, kind in usable[vpc_id]]
        return (min(EGRESS_RANK[kind] for kind in kinds), -len(kinds))

    vpc = min(usable, key=score)
    best = min(EGRESS_RANK[kind] for _, kind in usable[vpc])
    chosen = [(sid, kind) for sid, kind in usable[vpc]
              if EGRESS_RANK[kind] == best]
    subnets = subnets or [sid for sid, _ in chosen]
    kinds = sorted({kind for _, kind in chosen})
    if best == 1:
        say('  WARNING            the only usable subnets route 0.0.0.0/0 to '
            'an internet gateway. AgentCore ENIs have no public IP, so the '
            'agent will deploy, pass its health check, and then fail every '
            'outbound call. Add a NAT gateway or set SUBNET_IDS to a subnet '
            'behind one.')
    elif best == 2:
        say('  WARNING            the chosen subnets have no default route at '
            'all; the agent will not reach the gateway or Bedrock.')
    else:
        say(f'  egress             via {"/".join(kinds)}')
    if not groups:
        found = ec2.describe_security_groups(Filters=[
            {'Name': 'vpc-id', 'Values': [vpc]},
            {'Name': 'group-name', 'Values': ['default']}])['SecurityGroups']
        if not found:
            raise SystemExit(f'No default security group in {vpc}; '
                             'set SECURITY_GROUP_IDS.')
        groups = [found[0]['GroupId']]
    say(f'  network            VPC {vpc}, subnets {subnets}, sg {groups}')
    return {'networkMode': 'VPC',
            'networkModeConfig': {'subnets': subnets,
                                  'securityGroups': groups}}


def check_role() -> List[str]:
    """Confirm the execution role is both assumable by the service and passable.

    These are two different permissions and they fail at different times.
    A role the service cannot assume fails at create with a message about the
    trust policy; a role the *caller* cannot pass fails at create with
    AccessDenied on iam:PassRole, which reads like the API itself is denied.
    """
    problems = []
    iam = boto3.client('iam')
    role_name = config.ROLE_ARN.rsplit('/', 1)[-1]
    try:
        role = iam.get_role(RoleName=role_name)['Role']
        trust = json.dumps(role['AssumeRolePolicyDocument'])
        if 'bedrock-agentcore.amazonaws.com' not in trust:
            problems.append(
                f'{role_name} does not trust bedrock-agentcore.amazonaws.com; '
                'CreateAgentRuntime will refuse it.')
        else:
            say(f'  execution role     {role_name} trusts bedrock-agentcore')
    except ClientError as exc:
        say(f'  execution role     cannot read {role_name} '
            f'({exc.response["Error"]["Code"]}); trust unverified')

    try:
        sts = boto3.client('sts')
        who = sts.get_caller_identity()['Arn']
        # An assumed-role ARN is not a valid PolicySourceArn; simulate against
        # the underlying role instead.
        source = who
        if ':assumed-role/' in who:
            account = who.split(':')[4]
            source = (f'arn:aws:iam::{account}:role/'
                      f'{who.split("/")[1]}')
        verdict = boto3.client('iam').simulate_principal_policy(
            PolicySourceArn=source, ActionNames=['iam:PassRole'],
            ResourceArns=[config.ROLE_ARN])['EvaluationResults'][0]
        decision = verdict['EvalDecision']
        if decision != 'allowed':
            problems.append(f'iam:PassRole on {config.ROLE_ARN} is {decision}')
        else:
            say('  iam:PassRole       allowed')
    except ClientError as exc:
        say(f'  iam:PassRole       could not simulate '
            f'({exc.response["Error"]["Code"]}); will find out at create')
    return problems


def check_bucket() -> List[str]:
    s3 = boto3.client('s3', region_name=config.REGION)
    try:
        s3.head_bucket(Bucket=config.CODE_BUCKET)
        say(f'  code bucket        s3://{config.CODE_BUCKET} exists')
        return []
    except ClientError as exc:
        if exc.response['Error']['Code'] not in ('404', '403', 'NoSuchBucket'):
            return [f's3: {exc}']
    try:
        kwargs: Dict[str, Any] = {'Bucket': config.CODE_BUCKET}
        if config.REGION != 'us-east-1':
            kwargs['CreateBucketConfiguration'] = {
                'LocationConstraint': config.REGION}
        s3.create_bucket(**kwargs)
        say(f'  code bucket        created s3://{config.CODE_BUCKET}')
        return []
    except ClientError as exc:
        return [f'cannot create s3://{config.CODE_BUCKET}: '
                f'{exc.response["Error"]["Code"]}']


def check_gateway() -> List[str]:
    """The agent is only interesting if it can reach its tools."""
    try:
        import gateway_mcp
        tools = gateway_mcp.GatewayClient().list_tools()
    except Exception as exc:                            # noqa: BLE001
        return [f'gateway {config.GATEWAY_ID} unreachable: '
                f'{type(exc).__name__}: {exc}']
    if not tools:
        return [f'gateway {config.GATEWAY_ID} returned no tools - policy '
                'denies everything, so the agent will have nothing to call.']
    say(f'  gateway tools      {tools}')
    return []


def check_model() -> List[str]:
    if not config.USE_BEDROCK:
        say('  model              USE_BEDROCK=0, deterministic planner')
        return []
    try:
        boto3.client('bedrock-runtime', region_name=config.REGION).converse(
            modelId=config.MODEL_ID,
            messages=[{'role': 'user', 'content': [{'text': 'ok'}]}],
            inferenceConfig={'maxTokens': 8, 'temperature': 0})
        say(f'  model              {config.MODEL_ID} invocable')
        return []
    except ClientError as exc:
        return [f'{config.MODEL_ID}: {exc.response["Error"]["Code"]} - set '
                'USE_BEDROCK=0 to deploy without model access']


def preflight() -> int:
    say(f'preflight for {config.RUNTIME_NAME} in {config.REGION}')
    problems: List[str] = []
    problems += check_role()
    problems += check_bucket()
    problems += check_gateway()
    problems += check_model()
    try:
        pick_network()
    except SystemExit as exc:
        problems.append(str(exc))

    existing = find_runtime()
    say(f'  runtime            '
        + (f'{existing["agentRuntimeId"]} ({existing["status"]}) - '
           'deploy will update it' if existing else 'does not exist yet'))

    if problems:
        say('\nwould fail:')
        for problem in problems:
            say(f'  - {problem}')
        return 1
    say('\nall checks passed; run `python deploy.py deploy`')
    return 0


# --- packaging ------------------------------------------------------------


def vendor_into(target: pathlib.Path) -> int:
    """pip-install the agent's dependencies into the artifact.

    Two things make this work, and both are worth stating because they are
    what you lose by not using a container:

      * Every dependency must be pure Python. The runtime is aarch64 and this
        host is probably x86_64, so a wheel with compiled code would be the
        wrong architecture. `_check_pure` below fails the build rather than
        letting that reach AWS, where it surfaces as an import error in a log
        you have to go looking for.
      * botocore's service models get pruned to the services actually used.
        Unpruned, boto3 alone is 32 MB of mostly other people's APIs.
    """
    requirements = HERE / 'agent_requirements.txt'
    # --no-warn-conflicts because pip otherwise reports conflicts between
    # these pinned versions and whatever is installed in the *host*
    # environment, which is irrelevant: nothing here is installed into it.
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--quiet',
                    '--no-warn-conflicts', '--no-compile',
                    '--target', str(target), '-r', str(requirements)],
                   check=True, stdout=subprocess.DEVNULL)

    data = target / 'botocore' / 'data'
    if data.is_dir():
        for entry in sorted(data.iterdir()):
            if entry.is_dir() and entry.name not in config.KEEP_BOTOCORE_SERVICES:
                shutil.rmtree(entry)
        for service in (p for p in data.iterdir() if p.is_dir()):
            for version in (p for p in service.iterdir() if p.is_dir()):
                for leaf in version.iterdir():
                    if leaf.name not in ('service-2.json', 'service-2.json.gz'):
                        leaf.unlink()
    # boto3's resource JSON is for the resource API, which nothing here uses.
    shutil.rmtree(target / 'boto3' / 'data', ignore_errors=True)
    for junk in target.rglob('__pycache__'):
        shutil.rmtree(junk, ignore_errors=True)
    for info in list(target.glob('*.dist-info')) + list(target.glob('bin')):
        shutil.rmtree(info, ignore_errors=True)

    _check_pure(target)
    return sum(1 for f in target.rglob('*') if f.is_file())


def _check_pure(target: pathlib.Path) -> None:
    native = [str(f.relative_to(target))
              for f in target.rglob('*.so')][:5]
    if native:
        raise SystemExit(
            'Vendored dependencies contain compiled extensions, which were '
            f'built for this host and not for the runtime (aarch64): {native}. '
            'Either drop the dependency or switch to ARTIFACT_MODE=container '
            'and build with `docker buildx --platform linux/arm64`.')


def package() -> pathlib.Path:
    out = HERE / 'build' / 'agent.zip'
    out.parent.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        vendor = pathlib.Path(tmp) / config.VENDOR_DIR
        count = vendor_into(vendor)
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name in AGENT_FILES:
                archive.write(HERE / name, name)
            for found in vendor.rglob('*'):
                if found.is_file():
                    archive.write(found, str(
                        pathlib.Path(config.VENDOR_DIR)
                        / found.relative_to(vendor)))
    size = out.stat().st_size
    say(f'  packaged           {out.name} {size / 1e6:.1f} MB '
        f'({len(AGENT_FILES)} agent files + {count} vendored)')
    return out


def push(archive: pathlib.Path) -> Dict[str, Any]:
    boto3.client('s3', region_name=config.REGION).upload_file(
        str(archive), config.CODE_BUCKET, config.CODE_PREFIX)
    say(f'  uploaded           s3://{config.CODE_BUCKET}/{config.CODE_PREFIX}')
    return {'codeConfiguration': {
        'code': {'s3': {'bucket': config.CODE_BUCKET,
                        'prefix': config.CODE_PREFIX}},
        'runtime': config.PYTHON_RUNTIME,
        'entryPoint': config.ENTRY_POINT}}


def container_artifact() -> Dict[str, Any]:
    """The other artifact type, for when a zip is not enough.

    Not exercised by default - the whole reason the zip path is the default is
    that this one needs a Docker daemon and an arm64 builder. Dockerfile is in
    this directory if you need it.
    """
    return {'containerConfiguration': {'containerUri': config.image_uri()}}


# --- create / update ------------------------------------------------------


def wait_for(runtime_id: str, timeout: int = 600) -> Dict[str, Any]:
    """Poll until the runtime settles, and show *why* if it failed.

    `failureReason` is the single most useful field in this API and it is easy
    to miss, because the status alone (CREATE_FAILED) tells you nothing. The
    unsupported-availability-zone error only appears here.
    """
    started = time.time()
    last = None
    while time.time() - started < timeout:
        current = control().get_agent_runtime(agentRuntimeId=runtime_id)
        status = current['status']
        if status != last:
            say(f'  {int(time.time() - started):>4}s             {status}')
            last = status
        if status in ('READY', 'CREATE_FAILED', 'UPDATE_FAILED',
                      'DELETE_FAILED'):
            if current.get('failureReason'):
                say(f'  failureReason      {current["failureReason"]}')
            return current
        time.sleep(8)
    raise SystemExit(f'still {last} after {timeout}s')


def deploy(wait: bool = True) -> int:
    say(f'deploying {config.RUNTIME_NAME} ({config.ARTIFACT_MODE} artifact)')
    if config.ARTIFACT_MODE == 'container':
        artifact = container_artifact()
        say(f'  image              {config.image_uri()}')
    else:
        problems = check_bucket()
        if problems:
            say('\n'.join(f'  - {p}' for p in problems))
            return 1
        artifact = push(package())

    network = pick_network()
    existing = find_runtime()

    if existing:
        runtime_id = existing['agentRuntimeId']
        say(f'  updating           {runtime_id} (v{existing.get("agentRuntimeVersion")})')
        # Re-sending the networkConfiguration that GetAgentRuntime returns
        # fails: it includes `requireServiceS3Endpoint`, which runtimes
        # created after 2026-06-11 are not allowed to modify, even to the same
        # value. Send only the fields we own.
        result = control().update_agent_runtime(
            agentRuntimeId=runtime_id,
            agentRuntimeArtifact=artifact,
            roleArn=config.ROLE_ARN,
            networkConfiguration=network,
            protocolConfiguration={'serverProtocol': config.SERVER_PROTOCOL},
        )
    else:
        say(f'  creating           {config.RUNTIME_NAME}')
        result = control().create_agent_runtime(
            agentRuntimeName=config.RUNTIME_NAME,
            description='Price-match agent calling AgentCore Gateway tools',
            agentRuntimeArtifact=artifact,
            roleArn=config.ROLE_ARN,
            networkConfiguration=network,
            protocolConfiguration={'serverProtocol': config.SERVER_PROTOCOL},
        )
        runtime_id = result['agentRuntimeId']

    state = {
        'agentRuntimeId': runtime_id,
        'agentRuntimeArn': result['agentRuntimeArn'],
        'agentRuntimeVersion': result.get('agentRuntimeVersion'),
        'workloadIdentityArn': (result.get('workloadIdentityDetails') or {})
                                 .get('workloadIdentityArn'),
        'region': config.REGION,
        'deployed': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    (HERE / config.STATE_FILE).write_text(json.dumps(state, indent=2) + '\n')
    say(f'  arn                {state["agentRuntimeArn"]}')
    say(f'  workload identity  {state["workloadIdentityArn"]}')
    say(f'  state written to   {config.STATE_FILE}')

    if not wait:
        return 0
    final = wait_for(runtime_id)
    if final['status'] != 'READY':
        say(f'\n{final["status"]}. Nothing is serving. '
            'The reason above is the whole story; fix it and re-run deploy.')
        return 1
    say('\nREADY. Interact with it:\n'
        '  python invoke.py "Competitor sells this for $80, refund the '
        'difference"\n'
        '  python invoke.py --chat')
    return 0


# --- inspect / remove ----------------------------------------------------


def status() -> int:
    runtime = find_runtime()
    if not runtime:
        say(f'{config.RUNTIME_NAME} does not exist in {config.REGION}.')
        return 1
    full = control().get_agent_runtime(
        agentRuntimeId=runtime['agentRuntimeId'])
    for field in ('agentRuntimeName', 'agentRuntimeId', 'agentRuntimeArn',
                  'agentRuntimeVersion', 'status', 'failureReason',
                  'createdAt', 'lastUpdatedAt'):
        if full.get(field) is not None:
            say(f'  {field:<22} {full[field]}')
    say(f'  networkMode            '
        f'{full["networkConfiguration"]["networkMode"]}')
    say(f'  serverProtocol         '
        f'{full.get("protocolConfiguration", {}).get("serverProtocol")}')
    say(f'  log group              '
        f'/aws/bedrock-agentcore/runtimes/{runtime["agentRuntimeId"]}-DEFAULT')
    return 0


def logs(minutes: int = 30, limit: int = 60) -> int:
    """Read what the agent printed.

    The log group only exists once the runtime has been invoked at least once,
    and an *empty* group is itself a diagnosis: the process never reached its
    first print, which in practice means it crashed on import or never bound
    the port.
    """
    runtime = find_runtime()
    if not runtime:
        say(f'{config.RUNTIME_NAME} does not exist.')
        return 1
    group = (f'/aws/bedrock-agentcore/runtimes/'
             f'{runtime["agentRuntimeId"]}-DEFAULT')
    client = boto3.client('logs', region_name=config.REGION)
    try:
        events = client.filter_log_events(
            logGroupName=group,
            startTime=int((time.time() - minutes * 60) * 1000),
            limit=limit)['events']
    except ClientError as exc:
        say(f'{group}: {exc.response["Error"]["Code"]} - the group appears '
            'once the runtime has been invoked.')
        return 1
    if not events:
        say(f'{group} is empty for the last {minutes} min. If an invoke timed '
            'out, the agent never started: check that agent.py binds '
            f'0.0.0.0:{config.PORT} at module level.')
        return 0
    for event in events:
        stamp = time.strftime('%H:%M:%S',
                              time.gmtime(event['timestamp'] / 1000))
        say(f'{stamp}  {event["message"].rstrip()}')
    return 0


def destroy(yes: bool = False) -> int:
    runtime = find_runtime()
    if not runtime:
        say(f'{config.RUNTIME_NAME} does not exist; nothing to delete.')
        return 0
    say(f'This deletes runtime {runtime["agentRuntimeId"]} and '
        f's3://{config.CODE_BUCKET}/{config.CODE_PREFIX}.')
    say('It leaves the gateway, its policies and the S3 bucket itself alone - '
        'those are shared with the other demos.')
    if not yes:
        if input('type DELETE to confirm: ').strip() != 'DELETE':
            say('cancelled')
            return 1
    control().delete_agent_runtime(agentRuntimeId=runtime['agentRuntimeId'])
    say(f'  deleted runtime    {runtime["agentRuntimeId"]}')
    try:
        boto3.client('s3', region_name=config.REGION).delete_object(
            Bucket=config.CODE_BUCKET, Key=config.CODE_PREFIX)
        say(f'  deleted artifact   {config.CODE_PREFIX}')
    except ClientError as exc:
        say(f'  artifact           {exc.response["Error"]["Code"]}')
    state = HERE / config.STATE_FILE
    if state.exists():
        state.unlink()
        say(f'  removed            {config.STATE_FILE}')
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    parser.add_argument('command',
                        choices=['preflight', 'package', 'deploy', 'status',
                                 'logs', 'destroy'])
    parser.add_argument('--no-wait', action='store_true',
                        help='return as soon as the API accepts the request')
    parser.add_argument('--minutes', type=int, default=30,
                        help='logs: how far back to read')
    parser.add_argument('--yes', action='store_true',
                        help='destroy: skip the confirmation prompt')
    args = parser.parse_args()

    if args.command == 'preflight':
        return preflight()
    if args.command == 'package':
        package()
        return 0
    if args.command == 'deploy':
        return deploy(wait=not args.no_wait)
    if args.command == 'status':
        return status()
    if args.command == 'logs':
        return logs(minutes=args.minutes)
    return destroy(yes=args.yes)


if __name__ == '__main__':
    sys.exit(main())
