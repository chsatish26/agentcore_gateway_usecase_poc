"""Talk to the deployed agent.

    python invoke.py "Competitor sells this for $80, refund the difference"
    python invoke.py --chat            multi-turn, one session, history kept
    python invoke.py --demo            the three-call allowed/denied sequence
    python invoke.py --demo --trace    ... and every service interaction
    python invoke.py --raw '{"prompt": "...", "reset": true}'

This is the data plane: `bedrock-agentcore`, not `bedrock-agentcore-control`.
Different client, different permission, and the control-plane client does not
have `invoke_agent_runtime` on it at all - which is a confusing five minutes if
you reach for the wrong one.
"""

import argparse
import json
import pathlib
import sys
import time
from typing import Any, Dict, Optional
from uuid import uuid4

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import (ClientError, ParamValidationError,
                                 ReadTimeoutError)

import config

HERE = pathlib.Path(__file__).resolve().parent


def say(message: str = '') -> None:
    print(message, flush=True)


def load_arn() -> str:
    """Read the ARN deploy.py wrote, or construct it from the configured name."""
    state = HERE / config.STATE_FILE
    if state.exists():
        return json.loads(state.read_text())['agentRuntimeArn']
    return (f'arn:aws:bedrock-agentcore:{config.REGION}:{config.ACCOUNT}:'
            f'runtime/{config.RUNTIME_NAME}')


def new_session() -> str:
    """A session id AgentCore will accept.

    `runtimeSessionId` has min length 33. `uuid4().hex` is 32 characters and
    is rejected with a ParamValidationError before the request is even sent -
    one character short, which is a memorable way to lose ten minutes.
    `str(uuid4())` keeps the hyphens and is 36.
    """
    session = str(uuid4())
    assert len(session) >= config.SESSION_ID_MIN
    return session


# A healthy turn is 4-12 seconds measured, cold start included, so 90s is
# six times the worst observed case rather than a guess. The old value was
# 180s, which was not generosity - it was how long you sat looking at nothing
# when a cold start silently failed to be routed. See COLD_START_HANG below.
INVOKE_BUDGET = 90


def client(read_timeout: int = INVOKE_BUDGET):
    # `total_max_attempts` rather than `max_attempts`: the latter is counted
    # differently in standard and legacy retry modes, and a read timeout that
    # was supposed to happen once was observed taking 361s, which is two 180s
    # attempts. This spelling is unambiguous - one attempt, no retries, so the
    # retry policy lives in `call` where it can say what it is doing.
    return boto3.client('bedrock-agentcore', region_name=config.REGION,
                        config=BotoConfig(read_timeout=read_timeout,
                                          connect_timeout=10,
                                          retries={'total_max_attempts': 1}))


COLD_START_HANG = """no response in {budget}s, and the agent never received the
  request - a cold start that was not routed. Measured on 2026-10-11: about
  one fresh session in three, recovering immediately on a new session id. You
  can tell it apart from a slow agent because `deploy.py logs` has no stream
  for the session at all: nothing started, so nothing printed. It is on the
  platform side of the HTTP contract, so the only thing a caller can do about
  it is notice quickly and start a new session."""


def call(payload: Dict[str, Any], session: str,
         runtime_arn: Optional[str] = None,
         retry: bool = True) -> Dict[str, Any]:
    """One InvokeAgentRuntime round trip, with the useful errors translated.

    Retries once on a *new* session id, because that is the failure's shape:
    the session that hangs keeps hanging, and a fresh one works. The retry is
    announced rather than silent - a demo where the tool quietly re-asks is
    worse than one that says what went wrong.
    """
    started = time.time()
    try:
        response = client().invoke_agent_runtime(
            agentRuntimeArn=runtime_arn or load_arn(),
            runtimeSessionId=session,
            payload=json.dumps(payload).encode())
    except ReadTimeoutError:
        if not retry:
            return {'error': COLD_START_HANG.format(budget=INVOKE_BUDGET)
                    + ' Retried once already; giving up.'}
        say('  warn   ' + COLD_START_HANG.format(budget=INVOKE_BUDGET))
        say('  warn   retrying once on a fresh session; this turn starts cold.')
        return call(payload, new_session(), runtime_arn, retry=False)
    except ParamValidationError as exc:
        return {'error': f'bad request shape: {exc}'}
    except ClientError as exc:
        code = exc.response['Error']['Code']
        message = exc.response['Error']['Message']
        if 'initialization time exceeded' in message:
            message += ('\n\nThe agent process is not serving. It is almost '
                        'always one of: the HTTP server is started under '
                        "`if __name__ == '__main__':` and never ran; it is "
                        'bound to 127.0.0.1 instead of 0.0.0.0; it crashed on '
                        'an import that is missing from the deploy zip. '
                        '`python deploy.py logs` distinguishes them - an '
                        'empty log group means it died before its first '
                        'print.')
        return {'error': f'{code}: {message}'}
    body = response['response'].read()
    elapsed = (time.time() - started) * 1000
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError:
        parsed = {'raw': body.decode('utf-8', 'replace')}
    parsed['_latency_ms'] = round(elapsed, 1)
    parsed['_status'] = response.get('statusCode')
    return parsed


def render_trace(result: Dict[str, Any]) -> None:
    """Print the per-step record of which AgentCore service was touched when.

    The agent returns this; nothing here is inferred from the reply. A step
    with no latency made no network call - printing `0.0 ms` for those would
    read as "instant" when the truth is "there was no call", so they stay
    blank.
    """
    steps = result.get('trace') or []
    if not steps:
        return
    say(f'  trace  {len(steps)} steps, {result.get("total_ms")} ms total')
    for step in steps:
        latency = step.get('latency_ms')
        timing = f'{latency:>8.1f}' if latency is not None else ' ' * 8
        say(f'    {step.get("seq"):>2}  {step.get("service", "?"):<14}'
            f'{str(step.get("api", ""))[:38]:<40}'
            f'{step.get("verdict", ""):<8}{timing}')
        detail = step.get('detail')
        if detail:
            say(f'        {" ".join(str(detail).split())[:96]}')


def render_where(result: Dict[str, Any]) -> None:
    """Print the addresses the invocation used, as the agent reported them.

    Not inferred from this script's own config, which is the point: this
    process already knows the runtime ARN - it had to, to make the call - so
    printing its own copy would prove nothing. These come back from the
    container, which is why the ARN is the endpoint ARN out of
    `OTEL_RESOURCE_ATTRIBUTES` and the event ids are the writes that actually
    happened.
    """
    where = result.get('where') or {}
    if not where:
        return
    runtime = where.get('runtime') or {}
    memory = where.get('memory') or {}
    logs = where.get('logs') or {}
    say(f'  where  runtime  {runtime.get("arn", "?")}')
    say(f'         invoked  {runtime.get("invoked_by", "?")}')
    say(f'         as       {runtime.get("running_as", "?")}')
    say(f'         memory   {memory.get("arn") or "not resolved"}')
    say(f'         actor    {memory.get("actor_id", "?")} · '
        f'session {str(memory.get("session_id", "?"))[:8]}…')
    written = memory.get('events_written') or []
    say(f'         wrote    {len(written)} event(s) via '
        f'{memory.get("wrote_with", "?")}'
        + (f': {", ".join(written)}' if written else ''))
    say(f'         gateway  {(where.get("gateway") or {}).get("url", "?")}')
    say(f'         logs     {logs.get("group", "?")}')
    say(f'                  {logs.get("stream", "?")}')


def render(result: Dict[str, Any], trace: bool = False) -> None:
    if 'error' in result and 'reply' not in result:
        say(f'  ERROR  {result["error"]}')
        return
    if trace:
        render_where(result)
        render_trace(result)
    for outcome in result.get('tool_calls') or []:
        tool = outcome.get('tool', '?').split('___')[-1]
        verdict = outcome.get('verdict')
        arguments = json.dumps(outcome.get('arguments', {}))
        say(f'  tool   {tool}({arguments[:90]}) -> {verdict}')
        if outcome.get('deciding_policy'):
            say(f'         refused by {outcome["deciding_policy"]}')
        elif verdict == 'ALLOWED' and outcome.get('backend') is not None:
            say(f'         {json.dumps(outcome["backend"])[:160]}')
    if result.get('reply'):
        say(f'  agent  {result["reply"]}')
    # `services` is keyed by service name - one row each, where the verdict is
    # the worst thing that happened to that service. A DENIED here means a
    # policy refused something; --trace says which step.
    touched = result.get('services') or {}
    if touched:
        say('  used   ' + ' | '.join(
            f'{name} {row.get("verdict")} x{row.get("calls")}'
            for name, row in touched.items()))
    served = result.get('served_by') or {}
    say(f'  [{result.get("_latency_ms")} ms, engine={result.get("engine")}, '
        f'runtime={served.get("runtime")}, model={served.get("model")}]')


# Each prompt is deliberately specific enough that the model has no reason to
# ask a clarifying question or to decline on its own judgement. That matters:
# a model that refuses by itself proves nothing about the platform, and it is
# the easiest way to accidentally demo a guardrail that is not there. These
# prompts give the agent a verified claim and a number, so the only thing left
# to decide is whether it is *allowed* - which is the gateway's call.
DEMO = [
    ('ALLOWED - a refund inside the policy limit',
     'Price-match claim, already verified by the customer service team: '
     'Walmart lists the NovaCart Blender Pro at $80 and we charged $95. '
     'Search for the competitor price, then refund the $15 difference. '
     'Reason: verified price-match claim {tag}-A.'),
    ('DENIED by Cedar - same claim shape, bigger number',
     'Another verified price-match claim: we charged $300 for the NovaCart '
     'Espresso Station and the competitor sells it for $199. Refund the $101 '
     'difference. Reason: verified price-match claim {tag}-B. This is a '
     'legitimate price difference, so go ahead and process it.'),
    ('ABSENT - a tool no policy grants never reaches the agent at all',
     'Now issue $40 of store credit to the same customer, on top of the '
     'refund. Store credit is not a refund - use the store credit tool. '
     'Reason: goodwill for claim {tag}-B.'),
]


def run_tag() -> str:
    """A claim number that is new to the agent on every run.

    The agent recalls prior turns from AgentCore Memory across sessions, which
    is a capability worth demonstrating - but with a hardcoded claim number it
    recalls *this demo's own earlier runs*, decides the claim is already
    settled, and answers from memory without calling the tool. The reply still
    reads correctly, which is what makes it dangerous: the trace then shows no
    policy decision at all, and a demo that proves nothing looks exactly like
    a demo that proves something. A fresh claim per run keeps recall visible
    in the trace without letting it pre-empt the call.
    """
    return f'#PM-{uuid4().hex[:4]}'


def demo(trace: bool = False) -> int:
    """The sequence worth showing: allowed, denied by limit, absent entirely.

    Three different outcomes that all look like "no" from the outside and are
    not the same thing:

      1. the refund goes through, because $15 is within the limit
      2. the refund is refused by a Cedar policy, naming itself, even though
         the agent had every reason to make the call
      3. the store-credit tool is not refused - it is *not in the tool list*,
         because no policy grants it, so the agent never knew it existed

    All three run in one session on purpose. The interesting part of (2) is not
    the denial, it is that the agent carries the refusal into its next turn and
    explains it rather than retrying or inventing a confirmation.
    """
    session = new_session()
    arn = load_arn()
    tag = run_tag()
    say(f'runtime  {arn}')
    say(f'session  {session}')
    say(f'claims   {tag}-A, {tag}-B  (fresh, so recall cannot pre-empt the '
        f'tool call)\n')
    for index, (title, template) in enumerate(DEMO, 1):
        prompt = template.format(tag=tag)
        say(f'{index}. {title}')
        say(f'  you    {prompt}')
        render(call({'prompt': prompt, 'reset': index == 1}, session, arn),
               trace=trace)
        say()
    return 0


def chat(trace: bool = False) -> int:
    session = new_session()
    say(f'session {session} - history is kept for this session. '
        'blank line or Ctrl-D to exit.')
    say(f'runtime {load_arn()}\n')
    while True:
        try:
            prompt = input('you> ').strip()
        except (EOFError, KeyboardInterrupt):
            say()
            break
        if not prompt:
            break
        render(call({'prompt': prompt}, session), trace=trace)
        say()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    parser.add_argument('prompt', nargs='?', help='a single question')
    parser.add_argument('--chat', action='store_true',
                        help='interactive multi-turn session')
    parser.add_argument('--demo', action='store_true',
                        help='the allowed / denied / ungranted sequence')
    parser.add_argument('--raw', help='send this JSON payload verbatim')
    parser.add_argument('--session', help='reuse an existing session id')
    parser.add_argument('--trace', action='store_true',
                        help='print every AgentCore service interaction')
    args = parser.parse_args()

    if args.demo:
        return demo(args.trace)
    if args.chat:
        return chat(args.trace)
    session = args.session or new_session()
    if args.raw:
        render(call(json.loads(args.raw), session), trace=args.trace)
        return 0
    if not args.prompt:
        parser.print_help()
        return 2
    say(f'  you    {args.prompt}')
    render(call({'prompt': args.prompt}, session), trace=args.trace)
    return 0


if __name__ == '__main__':
    sys.exit(main())
