# Deploying an agent into AgentCore Runtime

A self-contained module: you run it, it hosts an agent on AWS, and then you
talk to the agent. It lives inside `agentcore_gateway_usecase_poc` but creates
nothing there — it *calls* the gateway that POC already stood up, as a client,
and reuses its Memory store on purpose so the app's Memory page and the hosted
agent read and write the same one rather than two that look alike.

The traffic in the other direction is one file: the POC's `runtime_view.py`
reads `runtime_state.json` to find the runtime, calls `InvokeAgentRuntime`, and
draws the trace this agent returns.

The agent it deploys is the price-match assistant: a customer claims a
competitor is cheaper, the agent searches for the competitor's price and refunds
the difference. Both tools come from AgentCore Gateway, so the agent holds no
credentials and enforces no spending limit of its own. That is the point of
hosting it: **moving an agent onto managed infrastructure does not change who
is allowed to do what.** The Cedar policy still refuses a $101 refund, and now
it refuses it to a workload running on AWS under its own IAM identity rather
than to a notebook.

Each invocation returns a **trace**: an ordered record of every AgentCore
service the agent touched, with the API, the verdict and the latency. That is
what makes the demo checkable rather than narrated — a refusal in the trace is
the platform refusing, which is indistinguishable in a chat window from the
model choosing to be cautious.

---

## Quick start

```bash
cd agentcore_gateway_usecase_poc/agentcore_runtime_deployment

python verify_local.py        # 4s   - run the agent here, check the contract
python deploy.py preflight    # 10s  - everything checkable before creating
python deploy.py deploy       # ~30s - package, upload, create, wait for READY
python invoke.py --demo       # 30s  - allowed / denied / absent
python invoke.py --demo --trace  #     ... and every service interaction
python invoke.py --chat       #        interactive, history kept
```

Nothing needs editing first. Defaults are the measured-working values for
account `196856463470` in `us-east-1`; every one is overridable by environment
variable in `config.py`.

Teardown is `python deploy.py destroy`. It deletes the runtime and its S3
artifact, and deliberately leaves the gateway, its policies and the bucket
alone — those are shared with the other demos.

---

## What you should see

`python invoke.py --demo`, verbatim from a live run on 2026-10-11, trimmed
only where a line ran past the margin:

```
claims   #PM-8cb5-A, #PM-8cb5-B  (fresh, so recall cannot pre-empt the tool call)

1. ALLOWED - a refund inside the policy limit
  tool   WebSearch({"query": "Walmart NovaCart Blender Pro price"})     -> ALLOWED
  tool   process_refund({"amount": 15, "reason": "...#PM-8cb5-A"})      -> ALLOWED
  agent  Perfect! I've successfully processed the $15 price-match refund ...
  used   Runtime OK x1 | Memory OK x3 | Gateway ALLOWED x3 | Bedrock OK x3 |
         Policy ALLOWED x2 | Identity OK x1 | Browser OK x2 | Observability OK x1
  [17224.4 ms, engine=bedrock, runtime=novacart_price_match_agent.DEFAULT]

2. DENIED by Cedar - same claim shape, bigger number
  tool   process_refund({"amount": 101, "reason": "...#PM-8cb5-B"})     -> DENIED
         refused by novacart_block_large_refunds-k0fahcb42r
  agent  The refund has been refused due to policy enforcement ... I cannot
         retry this call or work around the restriction.
  used   Runtime OK x1 | Memory OK x2 | Gateway OK x1 | Bedrock OK x2 |
         Policy DENIED x1 | Browser OK x2 | Observability OK x1
  [5590.9 ms, ...]

3. ABSENT - a tool no policy grants never reaches the agent at all
  agent  I don't have a store credit tool available. The only tool I have for
         customer compensation is the refund function ...
  used   Runtime OK x1 | Memory OK x2 | Gateway OK x1 | Bedrock OK x1 |
         Browser OK x2 | Observability OK x1
  [3657.3 ms, ...]
```

Three outcomes that all look like "no" from outside and are not the same thing:

| | what happened | enforced by |
|---|---|---|
| 1 | the call went through | Cedar, which permitted it — a decision, not an absence of one |
| 2 | the tool was called and **refused**, naming the rule | a Cedar policy at the gateway |
| 3 | the tool **was never in the list**, so the agent never knew it existed | `tools/list` is policy-filtered |

(3) is the one worth dwelling on in a demo. There is no "you may not do that"
anywhere — the capability is simply absent from the agent's vocabulary, because
no policy grants it. Nothing in `agent.py` hardcodes a tool name; it asks the
gateway what it may use and hands that list to the model, so revoking a policy
removes a capability without a redeploy.

The `runtime=` in the footer is read out of `OTEL_RESOURCE_ATTRIBUTES` inside
the container, which is how you can tell the answer came from AWS and not from
a local process.

Two details in that output are there because the first version of this demo
got them wrong, and both failures *read as successes*:

- **The claim number is generated per run.** With a hardcoded `#4417` the agent
  recalled its own earlier demo runs out of AgentCore Memory, concluded the
  claim was already settled, and answered without calling the tool at all. The
  reply was still articulate and still mentioned the policy. The trace,
  though, had no policy decision in it, because no decision had been asked
  for. A demo that proves nothing looks exactly like a demo that proves
  something, which is why the claim is new every time.
- **Case 1 shows `Policy ALLOWED`, not a missing Policy row.** Cedar runs on
  every call. Recording it only on refusal made an allowed trace read as "no
  policy was consulted" — the opposite of the truth, and the more dangerous of
  the two errors to put in front of an audience.

### The trace

Every response also carries `trace` — one step per service interaction — and
`services`, the same thing rolled up per service. `--trace` prints it:

```
python invoke.py --demo --trace
```

A step looks like this:

```json
{"seq": 5, "service": "Policy", "api": "Cedar decision on process_refund",
 "verdict": "DENIED", "latency_ms": 176.7, "at_ms": 2612.4,
 "deciding_policy": "novacart_block_large_refunds-k0fahcb42r",
 "detail": "process_refund({\"amount\": 101, ...}) refused by ... The target
            was never invoked, so no money moved."}
```

And here is case 1 in full — one prompt, eight services, 16 interactions,
8.0 seconds, verbatim from the same run:

| # | service | API | verdict | ms |
|---|---|---|---|---|
| 1 | Runtime | `POST /invocations` | OK | — |
| 2 | Memory | `ListMemories` | OK | 153.0 |
| 3 | Memory | `ListSessions` + `ListEvents` | OK | 309.9 |
| 4 | Gateway | MCP `tools/list` | OK | 191.8 |
| 5 | Bedrock | `Converse` | OK | 1010.3 |
| 6 | Gateway | MCP `tools/call WebSearch` | ALLOWED | 493.5 |
| 7 | Policy | Cedar decision on `WebSearch` | ALLOWED | — |
| 8 | Bedrock | `Converse` | OK | 1797.7 |
| 9 | Gateway | MCP `tools/call process_refund` | ALLOWED | 436.1 |
| 10 | Policy | Cedar decision on `process_refund` | ALLOWED | — |
| 11 | Identity | `GetResourceApiKey` *(by the target, not the agent)* | OK | — |
| 12 | Bedrock | `Converse` | OK | 1450.8 |
| 13 | Memory | `CreateEvent` | OK | 290.9 |
| 14 | Browser | `StartBrowserSession` | OK | 1579.0 |
| 15 | Browser | `StopBrowserSession` | OK | — |
| 16 | Observability | ADOT spans + stdout → CloudWatch | OK | — |

Four rows are worth reading carefully.

**Steps 7 and 10 have no latency and say so.** The permit is decided inside
the gateway call immediately above it, and there is no way to separate the two
from outside, so the step is marked `inferred: true` rather than given a
number nobody measured. Step 5 in the denied case *does* carry a real 176.7 ms,
because a refusal is the whole round trip: the gateway evaluated Cedar,
refused, and returned without invoking the target.

**Step 11 is not the agent's call.** The refund target fetches the payment key
from the Identity vault itself and returns `apiKeyMasked: dem***123`; the agent
passes no credential and never sees one.

**Step 16 is not a call at all.** Observability is a consequence of the other
fifteen, so the agent reports *where* the evidence is and the caller goes and
reads it — a stronger claim than the agent asserting it was observed.

The steps with no latency made no network call of their own. Showing them as
`0 ms` would have been the easy choice and reads as "free", so they say so
instead.

### `where`: the addresses, reported by the process that used them

Every response also carries a `where` block. It names the runtime endpoint ARN
and the API that invoked it, the memory ARN with the actor, the session and the
**ids of the events written this turn**, the gateway URL, the log group and the
per-session stream pattern, the model, the region and the account.

```json
"where": {
  "runtime": {
    "arn": "arn:aws:bedrock-agentcore:us-east-1:196856463470:runtime/novacart_price_match_agent-cLitH12n66/runtime-endpoint/DEFAULT:DEFAULT",
    "invoked_by": "bedrock-agentcore:InvokeAgentRuntime (data plane)",
    "running_as": "arn:aws:sts::196856463470:assumed-role/SandboxServiceRole/BedrockAgentCore-2e70be82-…",
    "source": "cloud.resource_id in OTEL_RESOURCE_ATTRIBUTES"
  },
  "memory": {
    "arn": "arn:aws:bedrock-agentcore:us-east-1:196856463470:memory/novacart_price_match_poc_memory-sDyhNiEF4r",
    "actor_id": "novacart-price-match-agent",
    "events_written": ["0000001791724671914#b29a8ed7", "…", "…"],
    "wrote_with": "bedrock-agentcore:CreateEvent"
  }
}
```

It is built **inside the agent** rather than by the caller, and that is the
whole point of it. `invoke.py` and the Streamlit page both know the runtime ARN
already — they had to, to make the call — so a panel assembled from their own
config would be correct and would prove nothing. These values come from the
process that ran: the ARN out of the container's own environment, the memory id
from the resolution it actually performed, the event ids from the writes it
actually made. Each sub-block carries a `source` or a `*_with` field, so a
value read out of the environment is distinguishable from one assembled out of
parts.

The POC's **Ask the hosted agent** page renders this under *Check it yourself*
as one card per service — joined there by the rest of the response, so the tool
that was called, the policy that decided and the credential mask sit beside the
addresses — with a button that calls `ListEvents` on those ids and shows the
stored turns, because the ids are still the agent's word for it and reading them
back out of Memory after the invocation ended is not.

One thing the page needs that the `where` block does not carry: **on a refused
call there is no Gateway `tools/call` step in the trace at all.** The gateway
refuses and returns, so the only trace row is the Cedar decision. The
authoritative per-tool record is the top-level `tool_calls` list, which carries
the arguments, the verdict, the `deciding_policy` and the gateway's message on
every path — read tool calls from there, not from the trace, or a refusal reads
as "no tool was called".

---

## Files

| file | what it is |
|---|---|
| `agent.py` | **the deployment artifact.** An HTTP server with an agent inside it |
| `gateway_mcp.py` | SigV4-signed MCP client, `urllib` only, ships inside the zip |
| `config.py` | every setting, each commented with what it cost to learn |
| `deploy.py` | `preflight` · `package` · `deploy` · `status` · `logs` · `destroy` |
| `invoke.py` | one-shot · `--chat` · `--demo` · `--raw` |
| `verify_local.py` | runs the agent here and asserts AgentCore's contract |
| `../runtime_view.py` | the POC's **Ask the hosted agent** page, which draws the trace and the `where` block this agent returns |
| `../testcase_view.py` | the POC's **Three test cases** page: six stages × three cases, predicted then sent to this agent |
| `Dockerfile` | the container path, for when a zip cannot carry the deps |
| `agent_requirements.txt` | vendored **into** the artifact. Pure Python only |
| `requirements.txt` | what you need locally to run the scripts |
| `docs/RUNTIME_CONTRACT.md` | the measured contract and all five failure modes |
| `runtime_state.json` | written by `deploy`, read by `invoke` |

---

## How it is deployed, and why that choice

AgentCore Runtime takes two artifact types:

| | `codeConfiguration` (default here) | `containerConfiguration` |
|---|---|---|
| artifact | a zip in S3 | an ECR image |
| needs Docker | no | yes, plus an arm64 builder |
| dependencies | vendored into the zip, **pure Python only** | anything |
| this module | `ARTIFACT_MODE=code` | `ARTIFACT_MODE=container` |

The zip path is the default because it is the only one that works from
SageMaker Studio, which has no Docker daemon. It is viable here because
everything the agent needs — `boto3`, `botocore`, `urllib3` — is pure Python,
which is also why `gateway_mcp.py` signs with `urllib` instead of pulling in
`requests`.

`deploy.py` fails the build if it finds a compiled extension in the vendored
tree, rather than shipping an x86_64 `.so` to an aarch64 runtime and letting
you discover it from a log. If you need such a dependency, the `Dockerfile` is
there and the switch is one environment variable.

### The agent is an HTTP server, not a framework plug-in

The whole runtime contract is three lines:

```
GET  /ping        -> 200 {"status": "Healthy"}      exactly that body
POST /invocations -> 200 <any JSON>
listening on      0.0.0.0:8080
```

Runtime has no concept of an agent. It knows how to run a process that answers
those routes; models, tools, memory and frameworks are entirely your problem
inside them. `agent.py` is written to show that rather than hide it behind a
decorator — it is ~120 lines of agent loop and ~40 lines of `BaseHTTPRequest
Handler`.

### Path of one invocation

```
  you
   │  python invoke.py "..."
   ▼
  InvokeAgentRuntime                      data plane: bedrock-agentcore
   │  runtimeSessionId (>= 33 chars)      *not* bedrock-agentcore-control
   ▼
  AgentCore Runtime
   │  POST /invocations           header: x-amzn-...-runtime-session-id
   ▼
  agent.py in /var/task on aarch64        role: SandboxServiceRole/
   │                                            BedrockAgentCore-<uuid>
   ├──► tools/list ──► Gateway ──► Cedar ──► filtered tool list
   │                                         (this is the vocabulary)
   ├──► Bedrock Converse  (model picks a tool)
   │
   └──► tools/call ──► Gateway ──► Cedar ──► ALLOWED  ──► Lambda target
                                    │                      (holds the API key)
                                    └──► DENIED -32002 ──► named policy
```

Two things to notice. The agent signs its gateway calls with **the runtime's**
IAM role, picked up from instance metadata with no credential plumbing — the
same `gateway_mcp.py` code signs as your notebook when run locally. And the
Lambda target is what holds the payment credential, fetched from the AgentCore
token vault at call time; the agent never sees it.

---

## The six ways this fails

The first five each cost a deploy cycle to find, and `deploy.py preflight`
checks all five before creating anything. Full detail, with the verbatim
errors, is in [`docs/RUNTIME_CONTRACT.md`](docs/RUNTIME_CONTRACT.md).

1. **`boto3 < 1.43`** — `codeConfiguration` is missing from the service model,
   so the zip path looks like an invented parameter.
2. **A hyphen in the runtime name** — runtimes are
   `[a-zA-Z][a-zA-Z0-9_]{0,47}`; gateways allow hyphens. Same console, different
   grammar.
3. **A subnet in an unsupported availability zone** — passes validation, then
   `CREATE_FAILED` eight seconds later. Only three zones work, and the error
   names zone **IDs** (`use1-az4`), which are not zone names. Filter on
   `AvailabilityZoneId` or your code works in your account only.
4. **A subnet whose only egress is an internet gateway** — the expensive one.
   AgentCore's ENI has no public IP, so an IGW route is not egress. The runtime
   goes `READY`, passes its health check, and every outbound call fails with a
   generic 502. The log group is *empty*, because log delivery needs the same
   egress — so an empty log group is itself the diagnosis. NAT or transit
   gateway works.
5. **`uuid4().hex` as a session id** — 32 characters, minimum is 33.

The sixth is not a mistake you make, and preflight cannot catch it:

6. **A cold start that is never routed.** The call is accepted, then nothing
   happens: no instance starts, no log stream is created for the session, and
   the client sits there until its read timeout. Measured on 2026-10-11, about
   **one fresh session in three** on an otherwise healthy `READY` runtime,
   recovering immediately on a new session id. It is on the platform side of
   the HTTP contract, so there is nothing in `agent.py` to fix; what a caller
   can do is notice quickly. Both clients here now wait 90 seconds rather than
   180 or 240 — a healthy turn is 4–12 seconds, so a long wait is not patience,
   it is a failure nobody has spotted yet — and then retry once on a fresh
   session, saying so rather than retrying silently.

   The retry is safe *specifically here*, and the reason matters: the agent
   never received the request, so nothing ran, nothing was charged and no
   refund was issued. A transport-level retry of a refund that may have
   succeeded downstream would not be safe, which is why botocore's own retries
   stay off (`total_max_attempts: 1`) and this one lives in the calling code
   where it can distinguish the two cases.

   Tell it apart from a slow agent with `python deploy.py logs`: a slow agent
   has a stream with its own banner in it, this has no stream at all.

And the one that is not in either list, because measurement ruled it out:

```
RuntimeClientError: Runtime initialization time exceeded.
```

means nothing bound 8080 in 30 seconds. `__name__` **is** `__main__` in code
mode, so a `if __name__ == '__main__':` guard does work — but `agent.py` starts
its server at module level anyway, because a guard that is load-bearing for the
process existing at all is a bad trade for two lines when the failure presents
as a timeout with no logs. `verify_local.py` imports `agent.py` rather than
running it, so it would catch exactly that.

---

## Debugging a deployed agent

```bash
python deploy.py status                 # state, version, failureReason
python deploy.py logs --minutes 30      # what the agent printed
```

`failureReason` on `GetAgentRuntime` is the most useful field in the API and
easy to miss — `CREATE_FAILED` on its own tells you nothing.

Your `print()` output goes to
`/aws/bedrock-agentcore/runtimes/<runtimeId>-DEFAULT`, in a **per-session**
stream whose name embeds the session id. The group does not exist until the
first invocation. `deploy.py logs` reads across streams so the ordering makes
sense.

`agent.py` returns `200` with an `error` key instead of `500` with a traceback,
on purpose: AgentCore replaces any non-2xx body with a generic
`RuntimeClientError ... (502)`, so a 500 carrying a perfectly good traceback
arrives as no information at all. Callers tell success from failure by reading
`error` in the body rather than the status line.

---

## Configuration

Everything is an environment variable; see `config.py` for the full set with
commentary. The ones you are most likely to want:

```bash
RUNTIME_NAME=my_agent              # no hyphens, <= 48 chars
RUNTIME_ROLE_ARN=arn:aws:iam::...  # must trust bedrock-agentcore.amazonaws.com
GATEWAY_ID=my-gateway-abc123       # which gateway's tools the agent gets
SUBNET_IDS=subnet-a,subnet-b       # skip auto-discovery
USE_BEDROCK=0                      # deterministic planner, no model needed
MODEL_ID=us.anthropic.claude-sonnet-4-6
ARTIFACT_MODE=container            # use the Dockerfile instead
```

`USE_BEDROCK=0` is there so the deployment mechanics can be demonstrated
without model access — a missing `bedrock:InvokeModel` grant degrades the demo
rather than breaking it. It replaces the agent loop with a fixed
search-then-refund sequence, and says so in its reply rather than pretending to
have reasoned.

Claude on Bedrock needs the `us.` inference-profile prefix, and Claude 4.5+
rejects `temperature` and `topP` in the same request — `config.py` sends one.

---

## What this does not demonstrate

Stated plainly so the demo is not oversold:

- **The agent opens a Browser session but cannot drive the page.**
  `StartBrowserSession` from inside Runtime is a real data-plane call and the
  trace records it as one, including `drove_page: false`. Driving CDP needs
  Playwright, which ships compiled binaries and downloads a Chrome, so it
  cannot travel in a pure-Python zip. Reading a live competitor page stays in
  the Streamlit app, which runs where Playwright is installed.
- **In-process history is still in-process.** The agent writes every outcome to
  AgentCore Memory and recalls across sessions, but the *conversation* is a dict
  keyed by session id, so follow-ups like "try $80 instead" stop working when
  the instance recycles or after `idleRuntimeSessionTimeout` (900s). Memory is
  the record; the dict is the conversation.
- **No Runtime-as-MCP-target.** `SERVER_PROTOCOL=HTTP`. Setting it to `MCP`
  would let this agent be published as a tool on a gateway, which is a
  different demo.
- **No custom authorizer.** Invocation is IAM-authorized, so the caller is
  whoever holds `bedrock-agentcore:InvokeAgentRuntime`. A JWT authorizer is
  what you would want for end-user auth.
- **The web search result is not verified.** The model is told to treat it as
  evidence, not proof, and in run 1 above it correctly reported that it could
  not find the specific listing while still processing the pre-verified claim.
  Do not read the refund as proof the price was checked.
- **One region, one account.** All the measured values are `us-east-1` in
  `196856463470`, including the three supported availability zones.
