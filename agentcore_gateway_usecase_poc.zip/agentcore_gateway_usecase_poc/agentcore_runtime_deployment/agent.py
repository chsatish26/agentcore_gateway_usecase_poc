"""The agent that gets hosted. This file is the deployment artifact.

AgentCore Runtime does not know what an agent is. It knows how to run a
container-or-zip that answers two HTTP routes, and everything else - models,
tools, memory, frameworks - is your problem inside those routes. The entire
contract is:

    GET  /ping          -> 200 {"status": "Healthy"}   exactly that body
    POST /invocations   -> 200 <whatever your agent returns>
    listening on        0.0.0.0:8080

So this file is an HTTP server with an agent inside it, not a framework
plug-in. That is the honest shape of the thing, and seeing it written out is
more instructive than a decorator that hides it.

What the agent does, in the order it does it - and each step is recorded in
the `trace` it returns, which is what the Streamlit app draws:

    Runtime        this process, under the runtime's own IAM identity
    Memory         recall settled claims for this customer before reasoning
    Gateway        ask which tools policy permits (the agent's vocabulary)
    Bedrock        the model picks a tool
    Policy         the gateway allows or refuses the call, naming the rule
    Identity       the target fetches the payment key from the token vault
    Memory         write the outcome, including refusals
    Browser        open and close a managed browser session
    Observability  spans and logs, which the app reads back from CloudWatch

The agent holds no tool credentials and enforces no spending limit of its
own. That is the point worth demonstrating from inside Runtime: the agent is
the least trusted component in the picture, and moving it onto managed
infrastructure does not change who is allowed to do what.

Two details about running here that are not obvious:

  * This file must put `vendor/` on sys.path before importing anything
    third-party, because the managed runtime has no boto3. That import must
    therefore be the first executable statement - above the other imports,
    which is why the usual import ordering is violated here on purpose.

  * The server starts at module level, not under `if __name__ ==
    '__main__':`. Measured, the runtime does exec this file as a script, so
    the guard would work - but a guard that is load-bearing for the process
    starting at all is a bad trade for two saved lines, and it is exactly the
    failure that is impossible to diagnose from the logs: the agent never
    starts, so it never logs, so CloudWatch shows an empty log stream and the
    invoke returns "Runtime initialization time exceeded".
"""

import os
import sys

sys.path.insert(0, os.path.join(
    os.path.dirname(os.path.abspath(__file__)), 'vendor'))

import datetime                                        # noqa: E402
import json                                            # noqa: E402
import time                                            # noqa: E402
import traceback                                       # noqa: E402
from http.server import BaseHTTPRequestHandler, HTTPServer  # noqa: E402
from typing import Any, Dict, List, Optional, Tuple    # noqa: E402

import config                                          # noqa: E402
import gateway_mcp                                     # noqa: E402

SYSTEM_PROMPT = """You are NovaCart's price-match assistant.

A customer claims a competitor sells an item cheaper and wants the difference
refunded. Your job:

1. Use the web search tool to check the competitor's claimed price. Treat the
   search result as evidence, not proof.
2. If the claim looks genuine, refund the difference using the refund tool.
3. Report what you did in two or three sentences.

Rules you must follow:
- Refund the price difference, never the full item price.
- You do not decide what you are allowed to do. If a tool call is refused,
  say so plainly, name the limit if the refusal names one, and do not retry
  the same call with the same arguments or try to work around it.
- Never invent a refund confirmation. Only report a refund as done if the
  tool returned success.
- Recalled history is background, not permission. Never conclude from it that
  a refund is already done or is not allowed - that is the platform's call,
  not yours. Make the tool call for the claim in front of you and report what
  comes back. If the history is relevant, mention it alongside the result.
- Use only a tool that actually does what was asked. If nothing in your tool
  list does it, say the capability is not available to you and name what you
  looked for. Never substitute a different tool because it is adjacent -
  issuing a refund is not issuing store credit.
"""


def log(message: str) -> None:
    """Print to stdout, flushed.

    Unflushed output is lost when the process is killed, which is how a
    crashing agent ends up with an empty CloudWatch stream. Everything printed
    here lands in /aws/bedrock-agentcore/runtimes/<runtimeId>-DEFAULT, in a
    stream named after the session.
    """
    print(f'[agent] {message}', flush=True)


# --- the trace ------------------------------------------------------------


class Trace:
    """An ordered record of every service the agent touched, with timings.

    This exists because of how the demo is consumed. A reply like "I refunded
    $15" is indistinguishable from a reply the model simply made up, and a
    refusal is indistinguishable from the agent deciding to be cautious. The
    trace is the difference: each step names the AWS service, the API, the
    verdict and who decided it, so what the audience sees is the platform
    working rather than the model's account of the platform working.

    Steps are deliberately flat and JSON-serialisable - they cross an HTTP
    boundary and get rendered by something that knows nothing about this file.
    """

    def __init__(self) -> None:
        self.steps: List[Dict[str, Any]] = []
        self.started = time.time()

    def add(self, service: str, api: str, detail: str,
            verdict: str = 'OK', latency_ms: Optional[float] = None,
            **extra: Any) -> Dict[str, Any]:
        step = {
            'seq': len(self.steps) + 1,
            'service': service,          # which AgentCore service, for the UI
            'api': api,                  # the actual call, so it is checkable
            'detail': detail,
            'verdict': verdict,          # OK | ALLOWED | DENIED | SKIPPED | ERROR
            'latency_ms': round(latency_ms, 1) if latency_ms else None,
            'at_ms': round((time.time() - self.started) * 1000, 1),
        }
        step.update(extra)
        self.steps.append(step)
        return step

    def services(self) -> Dict[str, Dict[str, Any]]:
        """Collapse the steps to one row per service, for the summary panel.

        A service's verdict is the worst thing that happened to it: a DENIED
        among four OKs is the interesting fact, not an average.
        """
        rank = {'ERROR': 0, 'DENIED': 1, 'SKIPPED': 2, 'ALLOWED': 3, 'OK': 4}
        rolled: Dict[str, Dict[str, Any]] = {}
        for step in self.steps:
            row = rolled.setdefault(step['service'], {
                'calls': 0, 'verdict': 'OK', 'total_ms': 0.0, 'apis': []})
            row['calls'] += 1
            row['total_ms'] += step.get('latency_ms') or 0.0
            if step['api'] not in row['apis']:
                row['apis'].append(step['api'])
            if rank.get(step['verdict'], 9) < rank.get(row['verdict'], 9):
                row['verdict'] = step['verdict']
        for row in rolled.values():
            row['total_ms'] = round(row['total_ms'], 1)
        return rolled


# --- conversation state ---------------------------------------------------
#
# Keyed by the runtime session id. AgentCore routes a given session id back to
# the same instance, so this works - but it is in-memory, so it dies with the
# instance and after `idleRuntimeSessionTimeout` (900s by default). That is
# precisely why the agent also writes to AgentCore Memory: this dict is the
# conversation, Memory is the record.
SESSIONS: Dict[str, List[Dict[str, Any]]] = {}

_GATEWAY: Optional[gateway_mcp.GatewayClient] = None
_MEMORY_ID: Optional[str] = None
_IDENTITY: Optional[str] = None


def gateway() -> gateway_mcp.GatewayClient:
    """One client for the process, built lazily.

    Lazily because an unreachable gateway must surface as an invocation error
    and not as a startup crash. A startup crash here presents as the 30-second
    init timeout, i.e. as a mystery.
    """
    global _GATEWAY
    if _GATEWAY is None:
        _GATEWAY = gateway_mcp.GatewayClient()
        log(f'gateway client -> {_GATEWAY.url}')
    return _GATEWAY


_CLIENTS: Dict[str, Any] = {}


def boto(service: str, read_timeout: int = 15):
    """A cached client with *bounded* timeouts.

    The bounds are not a nicety. botocore's defaults are a 60s connect and a
    60s read with up to five attempts, so a single unreachable endpoint inside
    a VPC does not fail - it hangs for minutes. Measured here: the first
    deployment of this version returned no reply and logged nothing at all,
    because an STS call sat in connect-retry until the caller's own 180s read
    timeout fired first. Nothing in CloudWatch, nothing in the response: the
    worst diagnostic position to be in.

    Bounded, the same failure takes a few seconds and arrives as an ERROR step
    in the trace with the service named. A slow dependency should degrade one
    row of the demo, not the whole invocation.
    """
    key = f'{service}:{read_timeout}'
    if key not in _CLIENTS:
        import boto3
        from botocore.config import Config
        _CLIENTS[key] = boto3.client(
            service, region_name=config.REGION,
            config=Config(connect_timeout=5, read_timeout=read_timeout,
                          retries={'max_attempts': 2, 'mode': 'standard'}))
    return _CLIENTS[key]


def whoami() -> str:
    """The identity this process runs as, cached.

    Worth putting in the trace: it is an `assumed-role/<role>/
    BedrockAgentCore-<uuid>` session, resolved from instance metadata with no
    credential plumbing in the agent. The gateway call is signed as *this*,
    which is what makes the Cedar decision a decision about the workload
    rather than about whoever deployed it.
    """
    global _IDENTITY
    if _IDENTITY is None:
        try:
            _IDENTITY = boto('sts').get_caller_identity()['Arn']
        except Exception as exc:                        # noqa: BLE001
            # Non-fatal on purpose: the agent can still work without knowing
            # its own name, and an identity lookup must never be the reason an
            # invocation fails. Logged because it means STS is unreachable,
            # which predicts trouble for every other call.
            log(f'sts.get_caller_identity failed: {type(exc).__name__}: {exc}')
            _IDENTITY = f'unresolved: {type(exc).__name__}'
    return _IDENTITY


def runtime_name() -> str:
    """This runtime's own service name, read out of the OTEL attributes.

    The cheapest way for an agent to learn its own identity, and the reason
    the app can prove a reply came from AWS rather than from a local process.
    """
    attributes = os.environ.get('OTEL_RESOURCE_ATTRIBUTES', '')
    if 'service.name=' in attributes:
        return attributes.split('service.name=')[-1].split(',')[0]
    return 'local'


# --- Memory ---------------------------------------------------------------


def memory_id(trace: Trace) -> Optional[str]:
    """Resolve the memory resource by name, once.

    By name rather than by hardcoded id so the agent and the Streamlit app
    cannot drift onto two different stores that look alike. `list_memories`
    returns ids shaped `<name>-<suffix>`, so the name alone is not enough to
    construct one.
    """
    global _MEMORY_ID
    if _MEMORY_ID is not None:
        return _MEMORY_ID or None
    if config.MEMORY_ID:
        _MEMORY_ID = config.MEMORY_ID
        return _MEMORY_ID
    started = time.time()
    try:
        # Paged by hand rather than with `get_paginator`, because the deploy
        # zip prunes botocore's data directory down to `service-2.json` per
        # service - which means `paginators-1.json` is not in the artifact and
        # `get_paginator` raises OperationNotPageableError inside the runtime
        # while working perfectly on the host that built the zip. A nextToken
        # loop has no such dependency.
        control = boto('bedrock-agentcore-control')
        token = None
        while True:
            response = control.list_memories(
                **({'nextToken': token} if token else {}))
            for memory in response.get('memories', []):
                if memory.get('id', '').startswith(config.MEMORY_NAME):
                    _MEMORY_ID = memory['id']
                    trace.add('Memory', 'ListMemories',
                              f'resolved {config.MEMORY_NAME} -> {_MEMORY_ID}',
                              latency_ms=(time.time() - started) * 1000)
                    return _MEMORY_ID
            token = response.get('nextToken')
            if not token:
                break
    except Exception as exc:                            # noqa: BLE001
        trace.add('Memory', 'ListMemories', f'{type(exc).__name__}: {exc}',
                  verdict='ERROR',
                  latency_ms=(time.time() - started) * 1000)
        _MEMORY_ID = ''
        return None
    trace.add('Memory', 'ListMemories',
              f'no memory named {config.MEMORY_NAME}', verdict='SKIPPED')
    _MEMORY_ID = ''
    return None


def recall(trace: Trace, session_id: str) -> List[str]:
    """Read what this actor has settled before, across sessions.

    Cross-session on purpose. Within one session the in-process history
    already covers it, so reading only this session would make Memory look
    like a slower version of a dict. The demonstration that matters is the
    agent knowing about a claim it settled in a *different* conversation.
    """
    identifier = memory_id(trace)
    if not identifier:
        return []
    data = boto('bedrock-agentcore')
    started = time.time()
    try:
        sessions = data.list_sessions(
            memoryId=identifier, actorId=config.MEMORY_ACTOR_ID,
            maxResults=5).get('sessionSummaries', [])
        found: List[str] = []
        for summary in sessions[:3]:
            events = data.list_events(
                memoryId=identifier, actorId=config.MEMORY_ACTOR_ID,
                sessionId=summary['sessionId'], maxResults=6).get('events', [])
            for event in events:
                for item in event.get('payload') or []:
                    text = ((item.get('conversational') or {})
                            .get('content') or {}).get('text')
                    if text:
                        found.append(text)
        trace.add('Memory', 'ListSessions + ListEvents',
                  f'recalled {len(found)} turns from {len(sessions)} prior '
                  f'session(s) for actor {config.MEMORY_ACTOR_ID}',
                  latency_ms=(time.time() - started) * 1000,
                  sessions=[s['sessionId'] for s in sessions[:3]])
        return found[:12]
    except Exception as exc:                            # noqa: BLE001
        trace.add('Memory', 'ListSessions + ListEvents',
                  f'{type(exc).__name__}: {str(exc)[:160]}', verdict='ERROR',
                  latency_ms=(time.time() - started) * 1000)
        return []


def remember(trace: Trace, session_id: str, prompt: str, reply: str,
             calls: List[Dict[str, Any]]) -> None:
    """Write the outcome, refusals included.

    Remembering only the successes would hide the case the whole POC is about.
    So a denial is written as a denial, naming the policy, and that is what a
    later turn recalls.
    """
    identifier = memory_id(trace)
    if not identifier:
        return
    settled = []
    for call in calls:
        name = call['tool'].split('___')[-1]
        if call['verdict'] == 'ALLOWED':
            settled.append(f'{name}({json.dumps(call["arguments"])}) was '
                           f'ALLOWED and completed.')
        else:
            settled.append(f'{name}({json.dumps(call["arguments"])}) was '
                           f'{call["verdict"]}'
                           + (f' by policy {call["deciding_policy"]}'
                              if call.get('deciding_policy') else '')
                           + '. No money moved.')
    turns = [('USER', prompt[:900])]
    if settled:
        turns.append(('ASSISTANT', ' '.join(settled)[:900]))
    turns.append(('ASSISTANT', (reply or 'no reply')[:900]))

    data = boto('bedrock-agentcore')
    started = time.time()
    written = []
    try:
        for role, text in turns:
            response = data.create_event(
                memoryId=identifier, actorId=config.MEMORY_ACTOR_ID,
                sessionId=session_id,
                eventTimestamp=datetime.datetime.now(datetime.timezone.utc),
                payload=[{'conversational': {'role': role,
                                             'content': {'text': text}}}])
            written.append(response['event']['eventId'])
        trace.add('Memory', 'CreateEvent',
                  f'wrote {len(written)} turns to session {session_id[:8]}... '
                  f'(including the verdict)',
                  latency_ms=(time.time() - started) * 1000,
                  event_ids=written)
    except Exception as exc:                            # noqa: BLE001
        trace.add('Memory', 'CreateEvent',
                  f'{type(exc).__name__}: {str(exc)[:160]}', verdict='ERROR',
                  latency_ms=(time.time() - started) * 1000)


# --- Browser --------------------------------------------------------------


def browser_session(trace: Trace) -> None:
    """Open and close a managed browser session from inside Runtime.

    Read the limit honestly, because it is the one place this demo could
    overclaim. This opens a real session and gets back a real CDP endpoint, so
    the Browser service is genuinely reachable from the hosted agent and the
    step in the trace is a real data-plane call. It does **not** read a page:
    driving CDP needs Playwright, which ships compiled binaries and downloads
    a Chrome, and so cannot travel inside a pure-Python zip.

    Reading a price off a live page therefore stays in the Streamlit app,
    where Playwright is installed. The trace says `SKIPPED` for that part
    rather than implying the agent did it.
    """
    if not config.USE_BROWSER:
        trace.add('Browser', 'StartBrowserSession', 'USE_BROWSER=0',
                  verdict='SKIPPED')
        return
    data = boto('bedrock-agentcore')
    started = time.time()
    session = None
    try:
        response = data.start_browser_session(
            browserIdentifier=config.BROWSER_ID,
            name=f'runtime-{int(time.time())}',
            sessionTimeoutSeconds=config.BROWSER_SESSION_TIMEOUT)
        session = response['sessionId']
        endpoint = ((response.get('streams') or {})
                    .get('automationStream') or {}).get('streamEndpoint', '')
        trace.add('Browser', 'StartBrowserSession',
                  f'session {session} open on {config.BROWSER_ID}; CDP '
                  f'endpoint returned. Page reading needs Playwright, which '
                  f'cannot ship in a pure-Python zip - the app does that part.',
                  latency_ms=(time.time() - started) * 1000,
                  session_id=session, endpoint=endpoint[:80],
                  drove_page=False)
    except Exception as exc:                            # noqa: BLE001
        trace.add('Browser', 'StartBrowserSession',
                  f'{type(exc).__name__}: {str(exc)[:160]}', verdict='ERROR',
                  latency_ms=(time.time() - started) * 1000)
    finally:
        if session:
            try:
                data.stop_browser_session(
                    browserIdentifier=config.BROWSER_ID, sessionId=session)
                trace.add('Browser', 'StopBrowserSession',
                          f'session {session} closed')
            except Exception as exc:                    # noqa: BLE001
                trace.add('Browser', 'StopBrowserSession',
                          f'{type(exc).__name__}', verdict='ERROR')


# --- the agent loop -------------------------------------------------------


def to_tool_config(specs: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Turn the gateway's MCP tool list into a Bedrock toolConfig.

    Note what is *not* here: a hardcoded tool list. The model is told about
    whatever the gateway says this caller may use, so revoking a policy
    removes the capability from the agent's vocabulary without a redeploy.
    """
    return {'tools': [{'toolSpec': {
        'name': spec['name'],
        'description': spec.get('description', spec['name']),
        'inputSchema': {'json': spec.get(
            'inputSchema', {'type': 'object', 'properties': {}})},
    }} for spec in specs]}


def identity_evidence(trace: Trace, outcome: Dict[str, Any]) -> None:
    """Record what the *target* did with credentials, if it said.

    The refund target fetches the payment provider's API key from the
    AgentCore token vault at call time and reports the workload identity, the
    provider and a mask. That is the Identity story, and it is evidence rather
    than narration: the agent passed no credential and only ever sees
    `dem***123`.
    """
    backend = outcome.get('backend')
    if not isinstance(backend, dict):
        return
    identity = backend.get('identity')
    if not isinstance(identity, dict):
        return
    trace.add('Identity', 'GetResourceApiKey (by the target, not the agent)',
              f"target fetched the payment key from the token vault as "
              f"workload {identity.get('workloadName')} via provider "
              f"{identity.get('providerName')}; the agent only ever sees the "
              f"mask {identity.get('apiKeyMasked')}",
              workload=identity.get('workloadName'),
              provider=identity.get('providerName'),
              masked=identity.get('apiKeyMasked'))


def run_agent(prompt: str, history: List[Dict[str, Any]], trace: Trace,
              session_id: str) -> Dict[str, Any]:
    """One turn of the agent. Appends to `history` in place."""
    calls: List[Dict[str, Any]] = []

    recalled = recall(trace, session_id) if config.USE_MEMORY else []

    started = time.time()
    specs = gateway().list_tool_specs()
    trace.add('Gateway', 'MCP tools/list',
              f'{len(specs)} tool(s) permitted: '
              f'{", ".join(s["name"] for s in specs)}. This list is '
              f'policy-filtered - an ungranted tool is absent, not forbidden.',
              latency_ms=(time.time() - started) * 1000,
              tools=[s['name'] for s in specs])
    log(f'tools offered by gateway: {[s["name"] for s in specs]}')

    if not config.USE_BEDROCK:
        text = _planner(prompt, specs, calls, trace)
        history.append({'role': 'user', 'content': [{'text': prompt}]})
        history.append({'role': 'assistant', 'content': [{'text': text}]})
        return {'reply': text, 'tool_calls': calls, 'engine': 'planner',
                'recalled': recalled}

    # The model is the one call that legitimately takes tens of seconds, so it
    # gets a longer read budget than the control-plane calls.
    client = boto('bedrock-runtime', read_timeout=90)
    tool_config = to_tool_config(specs)

    system = [{'text': SYSTEM_PROMPT}]
    if recalled:
        # Framing matters here, and cost a demo run to learn. Labelling this
        # "previously settled claims" made the model treat a recalled denial
        # as a standing decision and answer from memory without calling the
        # tool at all - which looks like the policy working while the policy
        # was never consulted. Memory is context; the gateway is the decision.
        system.append({'text': 'Earlier turns recalled from AgentCore Memory, '
                               'for context only. They do not authorise or '
                               'forbid anything you are asked to do now, and '
                               'they may refer to different claims:\n- '
                       + '\n- '.join(recalled)})

    history.append({'role': 'user', 'content': [{'text': prompt}]})
    reply = ''

    for turn in range(config.MAX_TURNS):
        started = time.time()
        response = client.converse(
            modelId=config.MODEL_ID, system=system, messages=history,
            toolConfig=tool_config,
            # One sampling parameter only - Claude 4.5+ rejects temperature
            # and topP together.
            inferenceConfig={'maxTokens': config.MAX_TOKENS,
                             'temperature': config.TEMPERATURE})
        elapsed = (time.time() - started) * 1000
        message = response['output']['message']
        history.append(message)
        stop = response.get('stopReason')
        usage = response.get('usage') or {}
        reply = ' '.join(block['text'] for block in message['content']
                         if 'text' in block).strip() or reply
        wants = [block['toolUse']['name'] for block in message['content']
                 if block.get('toolUse')]
        trace.add('Bedrock', 'Converse',
                  f'{config.MODEL_ID.split(".")[-1]} step {turn + 1}: '
                  + (f'asked for {", ".join(wants)}' if wants
                     else 'answered without a tool'),
                  latency_ms=elapsed, stop_reason=stop,
                  input_tokens=usage.get('inputTokens'),
                  output_tokens=usage.get('outputTokens'))
        log(f'turn {turn + 1}: stopReason={stop}')

        if stop != 'tool_use':
            return {'reply': reply, 'tool_calls': calls, 'engine': 'bedrock',
                    'turns': turn + 1, 'recalled': recalled}

        results = []
        for block in message['content']:
            use = block.get('toolUse')
            if not use:
                continue
            outcome = gateway().call_tool(use['name'], use['input'])
            calls.append(outcome)
            short = use['name'].split('___')[-1]
            if outcome['verdict'] == 'ALLOWED':
                trace.add('Gateway', f'MCP tools/call {short}',
                          f'{short}({json.dumps(use["input"])[:120]}) ran; '
                          f'the target executed and returned a result',
                          verdict='ALLOWED',
                          latency_ms=outcome.get('latency_ms'),
                          arguments=use['input'],
                          result=outcome.get('backend'))
                # Record the permit as well as the refusal. Cedar runs on every
                # call, so leaving Policy out of an allowed trace reads as "no
                # policy check happened" - the opposite of the truth, and the
                # more dangerous error of the two to put in front of an
                # audience. There is no separate latency to report because the
                # decision happens inside the call above, and `inferred` says
                # so rather than dressing an inference up as a measurement.
                trace.add('Policy', f'Cedar decision on {short}',
                          f'{short} was permitted. Cedar evaluates every call, '
                          'so this is a decision, not an absence of one - the '
                          'measured proof is that the same call with a larger '
                          'amount is refused. The decision is taken inside the '
                          'gateway call above and has no separate latency.',
                          verdict='ALLOWED', inferred=True)
                identity_evidence(trace, outcome)
            else:
                trace.add('Policy', f'Cedar decision on {short}',
                          f'{short}({json.dumps(use["input"])[:120]}) refused'
                          + (f' by {outcome["deciding_policy"]}'
                             if outcome.get('deciding_policy') else '')
                          + '. The target was never invoked, so no money '
                            'moved.',
                          verdict=outcome['verdict'],
                          latency_ms=outcome.get('latency_ms'),
                          arguments=use['input'],
                          deciding_policy=outcome.get('deciding_policy'),
                          message=outcome.get('message'))
            log(f'  {use["name"]}({json.dumps(use["input"])[:120]}) '
                f'-> {outcome["verdict"]}'
                + (f' by {outcome["deciding_policy"]}'
                   if outcome.get('deciding_policy') else ''))
            # A denial is given back to the model as a tool *result*, not as an
            # error, so it can explain the refusal to the customer. Returning
            # it as an error makes the model retry; returning it as content
            # makes it reason about it.
            results.append({'toolResult': {
                'toolUseId': use['toolUseId'],
                'content': [{'text': json.dumps(_for_model(outcome))}],
                'status': 'success' if outcome['verdict'] == 'ALLOWED'
                          else 'error'}})
        history.append({'role': 'user', 'content': results})

    return {'reply': reply or 'Stopped after the maximum number of steps.',
            'tool_calls': calls, 'engine': 'bedrock',
            'turns': config.MAX_TURNS, 'truncated': True,
            'recalled': recalled}


def _for_model(outcome: Dict[str, Any]) -> Dict[str, Any]:
    """What the model is told about a tool outcome.

    Narrow on purpose: the verdict, the refusal message, and `retry: False` to
    stop the model trying the same call again.

    Be aware of what this does *not* hide. The gateway's own message contains
    the deciding policy's name and id ("Policy evaluation denied due to
    novacart_block_large_refunds-k0fahcb42r"), so the model sees it and will
    happily repeat it to whoever is on the other end. Observed, not
    hypothetical. For an internal tool that is useful; for a customer-facing
    one, strip the message here and pass a generic refusal instead - the
    `deciding_policy` field is still on the outcome for your own logs.
    """
    if outcome['verdict'] == 'ALLOWED':
        return {'status': 'ok', 'result': outcome.get('backend')}
    return {'status': 'refused', 'reason': outcome.get('message'),
            'retry': False}


def _planner(prompt: str, specs: List[Dict[str, Any]],
             calls: List[Dict[str, Any]], trace: Trace) -> str:
    """The no-model fallback: search, then refund the number in the prompt.

    Exists so the deployment can be demonstrated without model access. It is
    not an agent - it cannot decide anything - and it says so in its reply
    rather than pretending otherwise.
    """
    names = {spec['name'] for spec in specs}
    amount = _first_number(prompt)
    trace.add('Bedrock', 'skipped', 'USE_BEDROCK=0, deterministic planner',
              verdict='SKIPPED')
    for tool, arguments in ((config.SEARCH_TOOL,
                             {'query': prompt[:200], 'maxResults': 3}),
                            (config.REFUND_TOOL,
                             {'amount': amount,
                              'reason': f'price-match claim: {prompt[:120]}'})):
        if tool not in names or (tool == config.REFUND_TOOL and amount is None):
            continue
        outcome = gateway().call_tool(tool, arguments)
        calls.append(outcome)
        short = tool.split('___')[-1]
        trace.add('Gateway' if outcome['verdict'] == 'ALLOWED' else 'Policy',
                  f'MCP tools/call {short}',
                  f'{short} -> {outcome["verdict"]}',
                  verdict=outcome['verdict'],
                  latency_ms=outcome.get('latency_ms'),
                  arguments=arguments,
                  deciding_policy=outcome.get('deciding_policy'))
        if outcome['verdict'] == 'ALLOWED':
            # Same reason as the Bedrock path: a permit is a policy decision.
            trace.add('Policy', f'Cedar decision on {short}',
                      f'{short} was permitted; the decision is taken inside '
                      'the gateway call above and has no separate latency.',
                      verdict='ALLOWED', inferred=True)
            identity_evidence(trace, outcome)
    verdicts = ', '.join(f'{c["tool"].split("___")[-1]}={c["verdict"]}'
                         for c in calls) or 'no tools available'
    return (f'Deterministic planner (USE_BEDROCK=0), no model reasoning. '
            f'Tool outcomes: {verdicts}.')


def _first_number(text: str) -> Optional[int]:
    import re
    found = re.findall(r'\$?\s*(\d+(?:\.\d+)?)', text)
    return int(float(found[0])) if found else None


# --- the invocation -------------------------------------------------------


def where(session_id: str, trace: Trace, runtime_id: str) -> Dict[str, Any]:
    """Name every address this invocation actually used.

    Built in here rather than in the app on purpose. The app could guess most
    of it from its own config, but a guess that happens to be right is not
    evidence - the point of this block is that the *process that ran* reports
    which runtime executed it, which memory it wrote to, and which log group
    its stdout went to. `source` names where a fact came from, so a reader can
    tell a value read out of the environment from one assembled out of parts.
    """
    identity = whoami()
    account = identity.split(':')[4] if identity.count(':') >= 4 else config.ACCOUNT
    arn = ''
    for pair in os.environ.get('OTEL_RESOURCE_ATTRIBUTES', '').split(','):
        if pair.startswith('cloud.resource_id='):
            arn = pair.split('=', 1)[1]
    written: List[str] = []
    sessions: List[str] = []
    for step in trace.steps:
        written.extend(step.get('event_ids') or [])
        sessions.extend(step.get('sessions') or [])

    return {
        'runtime': {
            'arn': arn or (f'arn:aws:bedrock-agentcore:{config.REGION}:'
                           f'{account}:runtime/{runtime_id}'),
            'id': runtime_id,
            'endpoint': runtime_name(),
            'invoked_by': 'bedrock-agentcore:InvokeAgentRuntime (data plane)',
            'session_id': session_id,
            'running_as': identity,
            'source': ('cloud.resource_id in OTEL_RESOURCE_ATTRIBUTES'
                       if arn else 'assembled from account + runtime id'),
        },
        'memory': {
            'id': _MEMORY_ID or None,
            'arn': (f'arn:aws:bedrock-agentcore:{config.REGION}:{account}:'
                    f'memory/{_MEMORY_ID}') if _MEMORY_ID else None,
            'actor_id': config.MEMORY_ACTOR_ID,
            'session_id': session_id,
            'events_written': written,
            'sessions_read': sessions,
            'wrote_with': 'bedrock-agentcore:CreateEvent',
            'read_with': 'bedrock-agentcore:ListSessions + ListEvents',
        },
        'gateway': {
            'id': config.GATEWAY_ID,
            'url': config.gateway_url(),
            'called_with': 'MCP over HTTPS, SigV4-signed as the runtime role',
        },
        'logs': {
            'group': config.log_group(runtime_id) if runtime_id else None,
            'stream': f'*[runtime-logs-{session_id}]*',
            'note': 'one stream per session; the group appears on first '
                    'invocation',
        },
        'model': config.MODEL_ID if config.USE_BEDROCK else None,
        'region': config.REGION,
        'account': account,
    }


def handle(payload: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """The body of POST /invocations."""
    prompt = (payload.get('prompt') or payload.get('input')
              or payload.get('message') or '')
    if not isinstance(prompt, str) or not prompt.strip():
        return {'error': 'Send {"prompt": "..."} - no prompt found in payload.',
                'received_keys': sorted(payload.keys())}

    trace = Trace()
    if payload.get('reset'):
        SESSIONS.pop(session_id, None)
    history = SESSIONS.setdefault(session_id, [])
    cold = not history

    # Log before the first network call, not after. Anything that blocks
    # earlier than this line is invisible: the caller gets a read timeout and
    # CloudWatch holds only the startup banner, which says nothing about why.
    log(f'session {session_id[:8]}... turn {len(history) // 2 + 1}: '
        f'{prompt[:120]}')

    identity = whoami()
    trace.add('Runtime', 'POST /invocations',
              f'{"cold start" if cold else "warm instance"}; running as '
              f'{identity}',
              identity=identity, session=session_id, cold_start=cold,
              runtime=runtime_name())
    result = run_agent(prompt, history, trace, session_id)

    if config.USE_MEMORY:
        remember(trace, session_id, prompt, result.get('reply', ''),
                 result.get('tool_calls') or [])
    if payload.get('browser', True):
        browser_session(trace)

    # Observability is not a call the agent makes - it is a consequence of
    # every other call. So the agent reports where the evidence will be and
    # the app goes and reads it, which is a stronger demonstration than the
    # agent asserting that it was observed.
    runtime_id = (os.environ.get('OTEL_RESOURCE_ATTRIBUTES', '')
                  .split('cloud.resource_id=')[-1].split('/runtime-endpoint')[0]
                  .split('runtime/')[-1])
    trace.add('Observability', 'ADOT spans + stdout -> CloudWatch',
              f'{len(trace.steps)} steps emitted as spans; stdout is in '
              f'{config.log_group(runtime_id) if runtime_id else "the runtime log group"}'
              f', stream named after this session',
              log_group=config.log_group(runtime_id) if runtime_id else None,
              session=session_id)

    result['trace'] = trace.steps
    result['services'] = trace.services()
    result['session_id'] = session_id
    result['history_messages'] = len(history)
    result['total_ms'] = round((time.time() - trace.started) * 1000, 1)
    result['where'] = where(session_id, trace, runtime_id)
    # Where the answer was computed. The whole point of the exercise is that
    # this says the runtime's identity, not the developer's laptop.
    result['served_by'] = {
        'runtime': runtime_name(),
        'identity': whoami(),
        'gateway': config.GATEWAY_ID,
        'model': config.MODEL_ID if config.USE_BEDROCK else None,
        'memory': _MEMORY_ID or None,
    }
    return result


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def _send(self, code: int, body: Dict[str, Any]) -> None:
        raw = json.dumps(body, default=str).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        # Must be exactly this body. A 200 with a different shape still fails
        # the health check, and the failure looks like a networking problem.
        if self.path.rstrip('/') == config.PING_PATH:
            self._send(200, dict(config.PING_BODY))
        else:
            self._send(404, {'error': f'no route {self.path}',
                             'routes': [config.PING_PATH,
                                        config.INVOKE_PATH]})

    def do_POST(self) -> None:
        length = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(length)
        if self.path.rstrip('/') not in (config.INVOKE_PATH, ''):
            self._send(404, {'error': f'no route {self.path}'})
            return
        session_id = (self.headers.get(config.SESSION_HEADER) or 'local')
        try:
            payload = json.loads(raw or b'{}')
            if not isinstance(payload, dict):
                payload = {'prompt': str(payload)}
            self._send(200, handle(payload, session_id))
        except Exception:                      # noqa: BLE001
            # Deliberately a 200 carrying an `error`, not a 500.
            #
            # This looks wrong and is the pragmatic choice here. AgentCore
            # proxies any non-2xx from the agent as a generic
            # `RuntimeClientError: Received error (502) from runtime. Please
            # check your CloudWatch logs` and discards the body - so a 500
            # with a perfectly good traceback in it arrives as no information
            # at all. The caller is left guessing, and the log group may be
            # empty, so there is nothing to check.
            #
            # Returning 200 keeps the diagnosis attached to the thing that
            # went wrong. The response always carries `error`, so a caller can
            # still tell success from failure - it just has to read the body
            # rather than the status line.
            detail = traceback.format_exc()
            log(f'invocation failed:\n{detail}')
            self._send(200, {'error': f'agent raised: '
                                      f'{detail.strip().splitlines()[-1]}',
                             'detail': detail})

    def log_message(self, *args: Any) -> None:
        """Silence per-request access logs.

        The health check runs constantly; left on, it buries the agent's own
        output in CloudWatch.
        """


def serve(port: int = config.PORT) -> Tuple[HTTPServer, str]:
    server = HTTPServer(('0.0.0.0', port), Handler)
    return server, f'0.0.0.0:{port}'


log(f'starting on port {config.PORT}; '
    f'routes {config.PING_PATH} and {config.INVOKE_PATH}; '
    f'engine={"bedrock:" + config.MODEL_ID if config.USE_BEDROCK else "planner"}; '
    f'memory={config.USE_MEMORY} browser={config.USE_BROWSER}')
_SERVER, _BOUND = serve()
log(f'listening on {_BOUND}')
_SERVER.serve_forever()
