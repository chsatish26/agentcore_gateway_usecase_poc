"""Build, inspect and destroy the one persistent gateway this POC runs on.

                     ┌──────────────────────────────┐
     agent ─ SigV4 ─▶│  novacart-price-match-poc    │
                     │  inbound identity: AWS_IAM   │
                     │  policy engine:    ENFORCE   │
                     └───────┬──────────────┬───────┘
                             │              │
              target "research"          target "novacart"
              connector web-search       lambda RefundToolEcho
              outbound: gateway role     outbound: gateway role
                                         (then vault lookup inside)

Two targets on one gateway is the shape worth showing: a managed AWS connector
and a private function, reached by the same caller over the same protocol with
the same credentials, each governed by the same Cedar policy set.

`setup` is idempotent. It adopts an existing gateway with the configured name
rather than making a second one, so re-running it after a partial failure
converges instead of multiplying resources. Everything it creates is recorded
in a state file for later processes.

One behaviour catches everyone the first time: **attaching a policy engine in
ENFORCE mode makes the gateway default-deny for every tool, including the
search tool.** A policy set that only covers the money-moving tool will leave
research broken, and the failure arrives as a policy denial rather than
anything that looks like a configuration problem. That is why POLICIES below
grants the research tool explicitly.
"""

import json
import os
import time
from typing import Any, Dict, List, Optional

import boto3
import botocore.exceptions

import config
import identity

CONNECTOR_ID = 'web-search'
CONNECTOR_VERSION = '1.2.0'

# The refunds backend accepts exactly one tool - process_refund(amount, reason)
# - so that half of the schema is dictated by the function, not chosen.
#
# `issue_store_credit` is declared here on purpose and backed by nothing. It is
# the "workaround" route an agent would reach for after a refund is refused,
# and no policy grants it. Declaring a tool the policy set does not mention is
# the only honest way to demonstrate default-deny: pointing the demo at a tool
# that some permit happens to cover proves nothing.
REFUND_TOOLS = [
    {
        'name': 'process_refund',
        'description': ('Refund money to a customer for a price-match claim. '
                        'Retrieves the payment provider credential from the '
                        'AgentCore token vault at call time.'),
        'inputSchema': {
            'type': 'object',
            'properties': {
                'amount': {'type': 'integer',
                           'description': 'Refund amount in whole dollars'},
                'reason': {'type': 'string',
                           'description': 'Why the refund is being issued'},
            },
            'required': ['amount', 'reason'],
        },
    },
    {
        'name': 'issue_store_credit',
        'description': ('Issue store credit instead of a cash refund. '
                        'Granted by no policy - exists to show default-deny.'),
        'inputSchema': {
            'type': 'object',
            'properties': {
                'amount': {'type': 'integer'},
                'reason': {'type': 'string'},
            },
            'required': ['amount', 'reason'],
        },
    },
]


def _action(target: str, tool: str) -> str:
    """The Cedar action name for a tool: <target>___<tool>, three underscores."""
    return f"{target}___{tool}"


def policy_set(gateway_arn: str, search_tool: str) -> List[Dict[str, str]]:
    """The four Cedar policies that govern this gateway.

    Written as a function rather than a constant because every statement has to
    name the live gateway ARN and the search tool's published name, neither of
    which is known until the gateway exists.

    Note what is *not* here: no policy mentions the caller. Every statement
    leaves `principal` unconstrained, so these rules apply to any identity the
    gateway admits. Narrowing by principal is a one-line change
    (`principal == AgentCore::IamEntity::"..."`) and is where a real deployment
    would separate a junior agent from a supervisor one.
    """
    refund = _action(config.TARGET_REFUNDS, 'process_refund')
    limit = config.AUTO_APPROVE_LIMIT
    return [
        {
            'name': 'novacart_allow_small_refunds',
            'description': f'Price-match refunds up to ${limit} are automatic.',
            'statement': f'''
permit (
    principal,
    action == AgentCore::Action::"{refund}",
    resource == AgentCore::Gateway::"{gateway_arn}"
) when {{
    context.input has amount &&
    context.input.amount <= {limit} &&
    context.input.amount > 0
}};'''.strip(),
        },
        {
            # Belt and braces, and better messaging. Default-deny alone would
            # already stop a large refund, but an explicit forbid names itself
            # in the denial message, which turns "access denied" into "denied
            # by novacart_block_large_refunds". That difference is the whole
            # gap between an auditable control and a support ticket.
            'name': 'novacart_block_large_refunds',
            'description': f'Anything over ${limit} needs a human.',
            'statement': f'''
forbid (
    principal,
    action == AgentCore::Action::"{refund}",
    resource == AgentCore::Gateway::"{gateway_arn}"
) unless {{
    context.input has amount &&
    context.input.amount <= {limit}
}};'''.strip(),
        },
        {
            # Required, not optional. Without this the research tool is
            # default-denied and the agent cannot even look up a price.
            'name': 'novacart_allow_bounded_research',
            'description': (f'Web research is allowed, capped at '
                            f'{config.MAX_SEARCH_RESULTS} results per call.'),
            'statement': f'''
permit (
    principal,
    action == AgentCore::Action::"{search_tool}",
    resource == AgentCore::Gateway::"{gateway_arn}"
) when {{
    context.input has maxResults &&
    context.input.maxResults <= {config.MAX_SEARCH_RESULTS}
}};'''.strip(),
        },
    ]


class Stack:
    """Identifiers for the persistent stack, persisted between processes."""

    def __init__(self, **kwargs):
        self.gateway_id: Optional[str] = kwargs.get('gateway_id')
        self.gateway_arn: Optional[str] = kwargs.get('gateway_arn')
        self.gateway_url: Optional[str] = kwargs.get('gateway_url')
        self.policy_engine_id: Optional[str] = kwargs.get('policy_engine_id')
        self.policy_engine_arn: Optional[str] = kwargs.get('policy_engine_arn')
        self.search_tool: Optional[str] = kwargs.get('search_tool')
        self.policies: List[Dict[str, Any]] = kwargs.get('policies') or []
        # The tool surface before and after enforcement was switched on. Kept
        # because the difference between the two is one of the clearest results
        # the POC produces.
        self.tools_log_only: List[str] = kwargs.get('tools_log_only') or []
        self.tools_enforced: List[str] = kwargs.get('tools_enforced') or []
        # Identity resources this POC owns. Provisioned and verified at setup,
        # deliberately not consumed by the agent at claim time - see
        # identity.py for why that distinction is load-bearing.
        self.workload_identity_name: Optional[str] = kwargs.get(
            'workload_identity_name')
        self.workload_identity_arn: Optional[str] = kwargs.get(
            'workload_identity_arn')
        self.credential_provider_name: Optional[str] = kwargs.get(
            'credential_provider_name')
        self.credential_provider_arn: Optional[str] = kwargs.get(
            'credential_provider_arn')
        self.identity_check: Dict[str, Any] = kwargs.get('identity_check') or {}
        self.created_at: Optional[str] = kwargs.get('created_at')

    def to_dict(self) -> Dict[str, Any]:
        return {
            'gateway_name': config.GATEWAY_NAME,
            'gateway_id': self.gateway_id,
            'gateway_arn': self.gateway_arn,
            'gateway_url': self.gateway_url,
            'policy_engine_id': self.policy_engine_id,
            'policy_engine_arn': self.policy_engine_arn,
            'search_tool': self.search_tool,
            'policies': self.policies,
            'tools_log_only': self.tools_log_only,
            'tools_enforced': self.tools_enforced,
            'workload_identity_name': self.workload_identity_name,
            'workload_identity_arn': self.workload_identity_arn,
            'credential_provider_name': self.credential_provider_name,
            'credential_provider_arn': self.credential_provider_arn,
            'identity_check': self.identity_check,
            'created_at': self.created_at,
            'region': config.REGION,
        }

    def save(self, path: str = None) -> str:
        path = path or config.STATE_FILE
        with open(path, 'w') as handle:
            json.dump(self.to_dict(), handle, indent=2)
        return path

    @classmethod
    def load(cls, path: str = None) -> Optional['Stack']:
        path = path or config.STATE_FILE
        if not os.path.exists(path):
            return None
        with open(path) as handle:
            return cls(**json.load(handle))

    def refund_tool(self, name: str = 'process_refund') -> str:
        return _action(config.TARGET_REFUNDS, name)


# --------------------------------------------------------------------- waiters

def _wait(fetch, terminal, timeout: int, label: str) -> str:
    deadline = time.time() + timeout
    status = 'UNKNOWN'
    while time.time() < deadline:
        status = fetch()
        if status in terminal:
            return status
        time.sleep(3)
    raise TimeoutError(f'{label} stuck in {status} after {timeout}s')


def _control():
    return boto3.client('bedrock-agentcore-control', region_name=config.REGION)


# ----------------------------------------------------------------------- build

def _find_gateway(control) -> Optional[Dict[str, Any]]:
    token = None
    while True:
        kwargs = {'maxResults': 60}
        if token:
            kwargs['nextToken'] = token
        page = control.list_gateways(**kwargs)
        for item in page.get('items', []):
            if item.get('name') == config.GATEWAY_NAME:
                return item
        token = page.get('nextToken')
        if not token:
            return None


def _find_policy_engine(control) -> Optional[Dict[str, Any]]:
    token = None
    while True:
        kwargs = {'maxResults': 20}
        if token:
            kwargs['nextToken'] = token
        page = control.list_policy_engines(**kwargs)
        for item in page.get('items', page.get('policyEngines', [])):
            if item.get('name') == config.POLICY_ENGINE_NAME:
                return item
        token = page.get('nextToken')
        if not token:
            return None


def ensure_policy_engine(control, say) -> Dict[str, str]:
    existing = _find_policy_engine(control)
    if existing:
        engine_id = existing['policyEngineId']
        say(f'  policy engine   {engine_id} (existing, adopted)')
        detail = control.get_policy_engine(policyEngineId=engine_id)
        return {'id': engine_id, 'arn': detail['policyEngineArn']}

    response = control.create_policy_engine(
        name=config.POLICY_ENGINE_NAME,
        description='Cedar rules for the NovaCart price-match POC')
    engine_id = response['policyEngineId']
    _wait(lambda: control.get_policy_engine(
              policyEngineId=engine_id)['status'],
          ('ACTIVE', 'CREATE_FAILED', 'FAILED'), 120, 'policy engine')
    say(f'  policy engine   {engine_id} (created)')
    return {'id': engine_id, 'arn': response['policyEngineArn']}


def ensure_gateway(control, policy_engine_arn: str, say,
                   mode: str = 'LOG_ONLY') -> Dict[str, Any]:
    existing = _find_gateway(control)
    if existing:
        gateway_id = existing['gatewayId']
        detail = control.get_gateway(gatewayIdentifier=gateway_id)
        say(f'  gateway         {gateway_id} (existing, adopted)')
        return detail

    response = control.create_gateway(
        name=config.GATEWAY_NAME,
        roleArn=config.GATEWAY_ROLE_ARN,
        protocolType='MCP',
        # AWS_IAM: the agent authenticates with the AWS identity it already
        # runs under. CUSTOM_JWT would put a corporate IdP here instead, and is
        # the only field that changes to do so.
        authorizerType='AWS_IAM',
        description=('NovaCart price-match POC - demonstrates websearch, '
                     'identity, policy and browser together'),
        # Explicit, because the default is narrower than anyone expects: a
        # gateway created without this accepts only 2025-03-26, so a client
        # pinned to a newer revision fails against a brand-new gateway while
        # working against an older one someone has since updated.
        protocolConfiguration={'mcp': {
            'supportedVersions': ['2025-03-26', '2025-11-25']}},
        policyEngineConfiguration={'arn': policy_engine_arn, 'mode': mode},
    )
    gateway_id = response['gatewayId']
    _wait(lambda: control.get_gateway(gatewayIdentifier=gateway_id)['status'],
          ('READY', 'FAILED'), 180, 'gateway')
    say(f'  gateway         {gateway_id} (created, policy mode={mode})')
    return control.get_gateway(gatewayIdentifier=gateway_id)


def set_policy_mode(control, gateway_id: str, mode: str, say) -> None:
    """Flip the gateway between LOG_ONLY and ENFORCE.

    UpdateGateway has replace semantics - `name`, `roleArn` and
    `authorizerType` are required and anything omitted is dropped - so the
    current configuration is read back and resubmitted with only the mode
    changed. Leaving out `protocolConfiguration` here would silently reset the
    gateway to accepting only 2025-03-26 and break every client.
    """
    detail = control.get_gateway(gatewayIdentifier=gateway_id)
    engine = detail.get('policyEngineConfiguration') or {}
    if engine.get('mode') == mode:
        say(f'  policy mode     {mode} (already)')
        return

    control.update_gateway(
        gatewayIdentifier=gateway_id,
        name=detail['name'],
        roleArn=detail['roleArn'],
        authorizerType=detail['authorizerType'],
        protocolType=detail['protocolType'],
        description=detail.get('description', ''),
        protocolConfiguration=detail.get('protocolConfiguration'),
        policyEngineConfiguration={'arn': engine['arn'], 'mode': mode},
    )
    _wait(lambda: control.get_gateway(gatewayIdentifier=gateway_id)['status'],
          ('READY', 'FAILED'), 180, 'gateway update')
    say(f'  policy mode     {mode}')


def _existing_targets(control, gateway_id: str) -> Dict[str, Dict[str, Any]]:
    items = control.list_gateway_targets(
        gatewayIdentifier=gateway_id, maxResults=20).get('items', [])
    return {t['name']: t for t in items}


def ensure_targets(control, gateway_id: str, say) -> None:
    present = _existing_targets(control, gateway_id)

    if config.TARGET_RESEARCH not in present:
        control.create_gateway_target(
            gatewayIdentifier=gateway_id,
            name=config.TARGET_RESEARCH,
            description='Managed web-search connector',
            targetConfiguration={'mcp': {'connector': {
                'source': {'connectorId': CONNECTOR_ID,
                           'version': CONNECTOR_VERSION},
                # parameterValues is the administrator's side of the filter.
                # Left empty here so the POC can show a caller-supplied filter
                # being merged with it rather than replacing it.
                'configurations': [{'name': 'WebSearch',
                                    'parameterValues': {}}]}}},
            credentialProviderConfigurations=[
                {'credentialProviderType': 'GATEWAY_IAM_ROLE'}],
        )
        say(f'  target          {config.TARGET_RESEARCH} '
            f'(connector {CONNECTOR_ID} {CONNECTOR_VERSION})')
    else:
        say(f'  target          {config.TARGET_RESEARCH} (existing)')

    if config.TARGET_REFUNDS not in present:
        control.create_gateway_target(
            gatewayIdentifier=gateway_id,
            name=config.TARGET_REFUNDS,
            description='NovaCart refunds backend (Lambda)',
            targetConfiguration={'mcp': {'lambda': {
                'lambdaArn': config.REFUNDS_LAMBDA_ARN,
                'toolSchema': {'inlinePayload': REFUND_TOOLS}}}},
            credentialProviderConfigurations=[
                {'credentialProviderType': 'GATEWAY_IAM_ROLE'}],
        )
        say(f'  target          {config.TARGET_REFUNDS} '
            f'(lambda {config.REFUNDS_LAMBDA_ARN.split(":")[-1]})')
    else:
        say(f'  target          {config.TARGET_REFUNDS} (existing)')

    deadline = time.time() + 180
    while time.time() < deadline:
        items = _existing_targets(control, gateway_id).values()
        if items and all(t.get('status') in ('READY', 'FAILED') for t in items):
            for target in items:
                if target.get('status') == 'FAILED':
                    raise RuntimeError(
                        f"target {target['name']} FAILED: "
                        f"{target.get('statusReasons')}")
            return
        time.sleep(3)
    raise TimeoutError('targets did not become READY')


def visible_tools(gateway_id: str, gateway_url: str) -> List[str]:
    """What this caller can see through tools/list.

    Worth naming precisely, because `tools/list` is **filtered by policy**.
    Under ENFORCE a tool no policy grants is not returned at all - the agent
    does not see a tool it may not call. Measured here, not assumed: with the
    policy engine attached in ENFORCE and no policies written yet, this
    returned an empty list even though both targets were READY.
    """
    from mcp_client import McpGatewayClient
    client = McpGatewayClient(gateway_id, url=gateway_url)
    return sorted(client.tool_names())


def discover_search_tool(gateway_id: str, gateway_url: str) -> str:
    """Ask the gateway what the connector actually published.

    Not hard-coded, because the connector owns its tool names and a version
    bump could change them - so the Cedar policy below is written against a
    name read from the live gateway rather than one we assumed.

    This is also why `setup` attaches the policy engine in LOG_ONLY first.
    Discovery has to happen while the tools are still visible; under ENFORCE
    with no policies there is nothing to discover, which is a chicken-and-egg
    that only resolves in one direction.
    """
    names = visible_tools(gateway_id, gateway_url)
    prefix = f'{config.TARGET_RESEARCH}___'
    candidates = [n for n in names if n.startswith(prefix)]
    if not candidates:
        raise RuntimeError(
            f'research target published no tools; saw {names}. If this list is '
            f'empty the gateway is probably in ENFORCE mode with no policy '
            f'granting the connector.')
    return candidates[0]


def ensure_policies(control, engine_id: str, gateway_arn: str,
                    search_tool: str, say) -> List[Dict[str, Any]]:
    existing = {}
    token = None
    while True:
        kwargs = {'policyEngineId': engine_id, 'maxResults': 50}
        if token:
            kwargs['nextToken'] = token
        page = control.list_policies(**kwargs)
        for item in page.get('items', page.get('policies', [])):
            existing[item.get('name')] = item
        token = page.get('nextToken')
        if not token:
            break

    recorded = []
    for spec in policy_set(gateway_arn, search_tool):
        if spec['name'] in existing:
            policy_id = existing[spec['name']]['policyId']
            detail = control.get_policy(policyEngineId=engine_id,
                                        policyId=policy_id)
            say(f"  policy          {spec['name']} "
                f"({detail.get('status')}, existing)")
            recorded.append({'name': spec['name'], 'policyId': policy_id,
                             'status': detail.get('status')})
            continue

        response = control.create_policy(
            policyEngineId=engine_id,
            name=spec['name'],
            description=spec['description'],
            definition={'cedar': {'statement': spec['statement']}},
            # ACTIVE, not LOG_ONLY. A real rollout would start LOG_ONLY, read
            # the decisions for a week, then flip - the two dials (gateway mode
            # and per-policy enforcement mode) exist so that is possible
            # without rewriting anything.
            enforcementMode='ACTIVE',
        )
        policy_id = response['policyId']
        # Validation is asynchronous for semantic findings: CreatePolicy
        # returns CREATING and the Cedar verdict lands later. Reading the
        # status immediately would conclude every policy is fine.
        detail = _wait_policy(control, engine_id, policy_id)
        status = detail.get('status')
        say(f"  policy          {spec['name']} ({status})")
        if status != 'ACTIVE':
            raise RuntimeError(
                f"policy {spec['name']} did not activate: {status} "
                f"{detail.get('statusReasons')}")
        recorded.append({'name': spec['name'], 'policyId': policy_id,
                         'status': status})
    return recorded


def _wait_policy(control, engine_id: str, policy_id: str,
                 timeout: int = 120) -> Dict[str, Any]:
    deadline = time.time() + timeout
    last: Dict[str, Any] = {}
    while time.time() < deadline:
        last = control.get_policy(policyEngineId=engine_id, policyId=policy_id)
        last.pop('ResponseMetadata', None)
        if last.get('status') in ('ACTIVE', 'CREATE_FAILED', 'UPDATE_FAILED',
                                  'FAILED'):
            return last
        time.sleep(2)
    return last


def setup(verbose: bool = True, enforce: bool = True) -> Stack:
    """Create (or adopt) the whole stack and return it, saved to disk.

    The order below is not arbitrary - it is the order a real rollout has to
    use, for two independent reasons:

    1. **Policies name tools, so targets must publish first.** A statement
       referencing a tool that does not exist yet is refused by Cedar
       validation with an "unrecognized action" finding. That is the system
       working correctly, but it means the dependency runs targets -> policies.
    2. **Discovery needs LOG_ONLY.** `tools/list` is policy-filtered, so a
       gateway in ENFORCE with no policies shows an empty tool list and there
       is nothing to write policies against. The engine therefore goes on in
       LOG_ONLY, the tools are read, the policies are written, and only then
       is enforcement switched on.

    Which is exactly how you would introduce this to a running system:
    observe, then enforce.
    """
    say = (lambda msg: print(msg)) if verbose else (lambda msg: None)
    control = _control()

    say(f'Building the POC gateway in {config.REGION}')

    # Identity first, and owned by the POC. The refunds backend does its own
    # vault round trip against resources that predate this work, which proved
    # the capability but left nothing on the console's Identity page
    # attributable to the POC. These two fix that.
    say('Identity (this POC owns these):')
    identity_info = identity.ensure_identity(say)
    identity_check = identity.verify_round_trip(
        identity_info['workload_identity_name'],
        identity_info['credential_provider_name'], say)

    engine = ensure_policy_engine(control, say)
    gateway = ensure_gateway(control, engine['arn'], say, mode='LOG_ONLY')
    gateway_id = gateway['gatewayId']
    gateway_arn = gateway['gatewayArn']
    gateway_url = gateway.get('gatewayUrl') or config.gateway_url(gateway_id)

    # Observe. Nothing is blocked yet, so the full published surface is visible.
    set_policy_mode(control, gateway_id, 'LOG_ONLY', say)
    ensure_targets(control, gateway_id, say)

    search_tool = discover_search_tool(gateway_id, gateway_url)
    before = visible_tools(gateway_id, gateway_url)
    say(f'  search tool     {search_tool} (published by the connector)')
    say(f'  tools visible   {len(before)} in LOG_ONLY: {", ".join(before)}')

    policies = ensure_policies(control, engine['id'], gateway_arn,
                               search_tool, say)

    # Enforce.
    after = before
    if enforce:
        set_policy_mode(control, gateway_id, 'ENFORCE', say)
        after = visible_tools(gateway_id, gateway_url)
        hidden = sorted(set(before) - set(after))
        say(f'  tools visible   {len(after)} in ENFORCE: {", ".join(after)}')
        if hidden:
            say(f'  now invisible    {", ".join(hidden)} '
                f'(granted by no policy)')

    stack = Stack(gateway_id=gateway_id, gateway_arn=gateway_arn,
                  gateway_url=gateway_url, policy_engine_id=engine['id'],
                  policy_engine_arn=engine['arn'], search_tool=search_tool,
                  policies=policies,
                  tools_log_only=before, tools_enforced=after,
                  identity_check=identity_check,
                  created_at=time.strftime('%Y-%m-%dT%H:%M:%S'),
                  **identity_info)
    path = stack.save()
    say(f'\nReady. State written to {path}')
    base = (f'https://{config.REGION}.console.aws.amazon.com/bedrock-agentcore')
    say(f'Console, gateway   {base}/gateways/{gateway_id}'
        f'?region={config.REGION}')
    say(f'Console, identity  {base}/identity?region={config.REGION}'
        f'   ({stack.workload_identity_name} / '
        f'{stack.credential_provider_name})')
    return stack


# --------------------------------------------------------------------- inspect

def status(verbose: bool = True) -> Dict[str, Any]:
    control = _control()
    gateway = _find_gateway(control)
    if not gateway:
        if verbose:
            print(f'No gateway named {config.GATEWAY_NAME} exists. '
                  f'Run: python run_poc.py setup')
        return {'exists': False}

    gateway_id = gateway['gatewayId']
    detail = control.get_gateway(gatewayIdentifier=gateway_id)
    targets = control.list_gateway_targets(
        gatewayIdentifier=gateway_id, maxResults=20).get('items', [])
    engine_config = detail.get('policyEngineConfiguration') or {}

    policies = []
    engine = _find_policy_engine(control)
    if engine:
        page = control.list_policies(policyEngineId=engine['policyEngineId'],
                                     maxResults=50)
        for item in page.get('items', page.get('policies', [])):
            policies.append({'name': item.get('name'),
                             'status': item.get('status'),
                             'enforcementMode': item.get('enforcementMode')})

    report = {
        'exists': True,
        'gateway_id': gateway_id,
        'gateway_url': detail.get('gatewayUrl'),
        'status': detail.get('status'),
        'authorizerType': detail.get('authorizerType'),
        'policy_mode': engine_config.get('mode'),
        'mcp_versions': ((detail.get('protocolConfiguration') or {})
                         .get('mcp', {}).get('supportedVersions')),
        'targets': [{'name': t['name'], 'status': t.get('status')}
                    for t in targets],
        'policies': policies,
        'identity': _identity_status(control),
    }
    if verbose:
        print(json.dumps(report, indent=2, default=str))
    return report


def _identity_status(control) -> Dict[str, Any]:
    """Whether the POC's own identity resources are present.

    Reported by `status` because "I cannot see anything in the console's
    Identity page" is a question this command should be able to answer without
    anybody opening a browser.
    """
    found: Dict[str, Any] = {}
    for key, name, fetch in [
            ('workload_identity', config.WORKLOAD_IDENTITY_NAME,
             control.get_workload_identity),
            ('credential_provider', config.CREDENTIAL_PROVIDER_NAME,
             control.get_api_key_credential_provider)]:
        try:
            fetch(name=name)
            found[key] = {'name': name, 'present': True}
        except botocore.exceptions.ClientError as exc:
            found[key] = {'name': name, 'present': False,
                          'error': exc.response['Error']['Code']}
    return found


# --------------------------------------------------------------------- destroy

def destroy(verbose: bool = True) -> List[str]:
    """Delete everything this POC created, and nothing it merely borrowed.

    The reused Lambda, the workload identity and the credential provider it
    reads are untouched: they existed before this POC and other things depend
    on them.
    """
    say = (lambda msg: print(msg)) if verbose else (lambda msg: None)
    control = _control()
    problems: List[str] = []

    def attempt(label, fn):
        try:
            fn()
            say(f'  deleted {label}')
        except botocore.exceptions.ClientError as e:
            problems.append(f"{label}: {e.response['Error']['Code']}")
        except Exception as e:  # noqa: BLE001 - teardown must not raise
            problems.append(f'{label}: {type(e).__name__}')

    engine = _find_policy_engine(control)
    gateway = _find_gateway(control)

    if engine:
        engine_id = engine['policyEngineId']
        page = control.list_policies(policyEngineId=engine_id, maxResults=50)
        for item in page.get('items', page.get('policies', [])):
            attempt(f"policy {item.get('name')}",
                    lambda p=item: control.delete_policy(
                        policyEngineId=engine_id, policyId=p['policyId']))

    if gateway:
        gateway_id = gateway['gatewayId']
        for target in _existing_targets(control, gateway_id).values():
            attempt(f"target {target['name']}",
                    lambda t=target: control.delete_gateway_target(
                        gatewayIdentifier=gateway_id, targetId=t['targetId']))
        time.sleep(4)
        attempt(f'gateway {gateway_id}',
                lambda: control.delete_gateway(gatewayIdentifier=gateway_id))

    if engine:
        time.sleep(3)
        attempt(f"policy engine {engine['policyEngineId']}",
                lambda: control.delete_policy_engine(
                    policyEngineId=engine['policyEngineId']))

    # The two identity resources the POC provisioned. Deleting the credential
    # provider destroys the synthetic secret with it.
    identity.destroy_identity(say)

    # The memory created by the capability probes, if it exists. Imported here
    # rather than at module scope because `run`, `setup` and `status` have no
    # reason to load it, and it matches strictly on MEMORY_NAME so it cannot
    # reach the other demos' memories in this account.
    try:
        import memory_store
        memory_store.destroy_memory(say)
    except Exception as e:                      # noqa: BLE001 - see above
        problems.append(f'memory: {type(e).__name__}')

    if os.path.exists(config.STATE_FILE):
        os.remove(config.STATE_FILE)
        say(f'  removed {config.STATE_FILE}')

    say('\nLeft alone (pre-existing, not ours): '
        f'{config.REFUNDS_LAMBDA_ARN.split(":")[-1]}, and the workload '
        'identity and credential provider it reads from its own environment '
        '(wid-nb-*, demo-apikey-*). Other demos share those.')
    return problems
