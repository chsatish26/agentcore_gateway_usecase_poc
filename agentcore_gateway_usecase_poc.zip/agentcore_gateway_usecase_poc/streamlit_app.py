"""Management walkthrough of the NovaCart price-match POC.

    streamlit run streamlit_app.py

Deliberately not the same kind of app as the one next door in
`../agentcore_gateway_evaluation`. That one is a *deck*: eleven slides arguing
what the four capabilities can and cannot do. This one is a *walkthrough* of a
single claim being settled, and almost everything on screen is read back from
the last real run in `artifacts/` rather than typed in here.

That constraint is the point. A deck can say "policy blocked the refund"; this
app shows the amount that was refused, the rule that refused it, the page the
price came from, and the screenshot taken at the time. If `run_poc.py run` has
never been executed, the walkthrough says so instead of inventing numbers.

Five sections, in presentation order:

* **The claim**       - the business problem, in money and minutes.
* **Walk a claim**    - one claim, four steps, real data and the real screenshot.
* **Same agent,
   different answer** - the two cases side by side. This is the slide that
                        actually settles the risk question.
* **Try it yourself** - a live call to the real gateway. Move the amount past
                        the limit and watch the verdict flip. Nothing is mocked.
* **The gateway**     - what exists in the account, and the honest gaps.

The live section calls AWS when a button is pressed and never on page load, so
the app opens instantly and offline, and a presenter is never surprised by a
network error mid-sentence.
"""

import glob
import json
import os
from typing import Any, Dict, List, Optional

import streamlit as st

import capabilities
import capability_view
import config
import diagrams
import runtime_view
import testcase_view
import traces_view

HERE = os.path.dirname(os.path.abspath(__file__))

st.set_page_config(page_title='NovaCart price-match — AgentCore POC',
                   page_icon='🧾', layout='wide')

VERDICT_STYLE = {
    'ALLOWED': ('#1e7f3f', '#eaf5ec', '✅'),
    'DENIED': ('#c5221f', '#fdecea', '🛑'),
}

# Plain-language gloss for each policy. The Cedar source is shown next to it;
# this is what gets read aloud.
POLICY_PLAIN = {
    'novacart_allow_small_refunds':
        f'Refunds of ${config.AUTO_APPROVE_LIMIT} or less are approved '
        f'automatically.',
    'novacart_block_large_refunds':
        f'Anything above ${config.AUTO_APPROVE_LIMIT} is refused, and the '
        f'refusal names this rule so it can be audited.',
    'novacart_allow_bounded_research':
        f'A web search may ask for at most {config.MAX_SEARCH_RESULTS} '
        f'results, and must say how many it wants.',
}

CEDAR_SOURCE = {
    'novacart_allow_small_refunds': '''permit (
  principal,
  action == AgentCore::Action::"novacart___process_refund",
  resource
) when {
  context.input has amount &&
  context.input.amount <= %d &&
  context.input.amount > 0
};''' % config.AUTO_APPROVE_LIMIT,
    'novacart_block_large_refunds': '''forbid (
  principal,
  action == AgentCore::Action::"novacart___process_refund",
  resource
) unless {
  context.input has amount &&
  context.input.amount <= %d
};''' % config.AUTO_APPROVE_LIMIT,
    'novacart_allow_bounded_research': '''permit (
  principal,
  action == AgentCore::Action::"research___WebSearch",
  resource
) when {
  context.input has maxResults &&
  context.input.maxResults <= %d
};''' % config.MAX_SEARCH_RESULTS,
}


# --------------------------------------------------------------------- loading

@st.cache_data(show_spinner=False)
def load_transcript(path: str, _mtime: float) -> Dict[str, Any]:
    """Load one run transcript. `_mtime` busts the cache when the file changes."""
    with open(path) as handle:
        return json.load(handle)


def available_runs() -> List[str]:
    pattern = os.path.join(HERE, config.ARTIFACT_DIR, 'run_*.json')
    return sorted(glob.glob(pattern), reverse=True)


@st.cache_data(show_spinner=False)
def load_bundle(path: str, _mtime: float) -> Dict[str, Any]:
    """Load one capability-evidence bundle, cached on the file's mtime.

    Separate from `load_transcript` because a re-probe rewrites the file in
    place and the page has to pick up the new numbers without a restart.
    """
    return capabilities.load_bundle(path)


def artifact_path(recorded: Optional[str]) -> Optional[str]:
    """Resolve a screenshot path recorded in a transcript.

    Transcripts store paths relative to the POC directory, which is only the
    working directory if Streamlit happened to be started from here.
    """
    if not recorded:
        return None
    candidate = (recorded if os.path.isabs(recorded)
                 else os.path.join(HERE, recorded))
    return candidate if os.path.exists(candidate) else None


def no_run_yet() -> None:
    st.warning(
        'No run transcript found in `artifacts/`. This page shows measured '
        'results only, so there is nothing to display yet.\n\n'
        'Produce one with:\n\n'
        '```bash\npython run_poc.py setup   # once, builds the gateway\n'
        'python run_poc.py run\n```')


# ------------------------------------------------------------------ components

def verdict_banner(verdict: str, headline: str, detail: str = '') -> None:
    colour, background, icon = VERDICT_STYLE.get(
        verdict, ('#80868b', '#f8f9fa', 'ℹ️'))
    st.markdown(
        f"<div style='background:{background};border-left:6px solid {colour};"
        f"padding:14px 18px;border-radius:4px'>"
        f"<div style='color:{colour};font-weight:700;font-size:1.05rem'>"
        f"{icon} {verdict} — {headline}</div>"
        + (f"<div style='color:#3c4043;margin-top:6px'>{detail}</div>"
           if detail else '')
        + '</div>', unsafe_allow_html=True)


def money(value: Any) -> str:
    try:
        return f'${float(value):,.2f}'
    except (TypeError, ValueError):
        return '—'


# -------------------------------------------------------------- 1. the claim

def render_claim(transcript: Optional[Dict[str, Any]]) -> None:
    st.title('A customer says a competitor is cheaper')
    st.subheader('And wants the difference back', divider='blue')

    left, right = st.columns([1.1, 1], gap='large')
    with left:
        st.markdown(f'''
Settling one of these claims is five minutes of entirely mechanical work:
search the web, open the competitor's page, read the price, subtract, check
the policy, issue the refund. We pay people to do it, thousands of times.

An agent can do all five steps. **The reason we have not shipped one is the
last step.** To settle a claim an agent has to be able to move money, and
nobody approves an agent with an open cheque book and a prompt that can be
argued with.

So the question this POC answers is not *can the agent do the work*. It is:

> **can we put a hard limit around it that the agent itself cannot move?**

The limit here is ${config.AUTO_APPROVE_LIMIT}. It is not in the agent's code
and not in its prompt. It is configuration on the platform, enforced before
the agent's request reaches anything that can pay out.
''')
        st.info('**The one thing to remember** — the rule lives outside the '
                'agent, so the agent cannot exceed it even when it is wrong, '
                'confused, or deliberately manipulated.')
    with right:
        st.graphviz_chart(diagrams.use_case_flow(), width='stretch')
        st.caption('Blue is governed by policy. Amber is not — the browser is '
                   'the one gap, and it only reads.')

    st.markdown('---')
    st.markdown('#### Why this use case and not a simpler one')
    st.markdown('''
Four capabilities, and none of them can be dropped:

| Step | Capability | Where it runs |
|---|---|---|
| 1. Which pages might have the price? | **Web search** | Gateway connector target |
| 2. What does the page say *right now*? | **Browser** | Data plane — **not** the gateway |
| 3. May this agent refund *this amount*? | **Policy** | Cedar, at the gateway, before the backend |
| 4. What credential moves the money? | **Identity** | Token vault, fetched by the backend |

The chain is causal, which is what makes it a test rather than four demos in a
row: **the refund amount is computed from live web data, and policy adjudicates
that computed value.** Nobody types the amount in. Change the competitor's
price and the authorisation outcome changes with it.
''')

    if transcript:
        st.caption(f"Figures throughout this app come from the run of "
                   f"**{transcript.get('generated', 'unknown')}** against "
                   f"account 196856463470 / {config.REGION}.")


# ----------------------------------------------------------- 2. walk a claim

def render_step_search(entry: Dict[str, Any]) -> None:
    search = entry.get('search') or {}
    decision = search.get('decision') or {}
    results = search.get('results') or []

    st.markdown('#### ① Web search — *which pages might have the price?*')
    cols = st.columns(3)
    cols[0].metric('Results', len(results))
    cols[1].metric('Latency', f"{decision.get('latency_ms', 0):.0f} ms")
    cols[2].metric('Verdict', decision.get('verdict', '—'))

    st.caption(f"Through the gateway, as tool `{decision.get('tool')}`. The "
               f"call asks for `maxResults="
               f"{(decision.get('arguments') or {}).get('maxResults')}` "
               f"because the Cedar policy requires it to be present and "
               f"within the cap — policy shaping *how* a tool is called, not "
               f"just whether.")

    if results:
        with st.expander(f'The {len(results)} pages it found'):
            for item in results:
                st.markdown(f"- [{item.get('title') or item.get('url')}]"
                            f"({item.get('url')})")


def render_step_browser(entry: Dict[str, Any]) -> None:
    browsing = entry.get('browsing') or {}
    visits = browsing.get('visits') or []
    visit = visits[-1] if visits else {}

    st.markdown('#### ② Browser — *what does the page say right now?*')

    left, right = st.columns([1, 1.15], gap='large')
    with left:
        st.metric('Price read from the page', money(browsing.get('price')),
                  help='Extracted from the rendered DOM, not from a cache.')
        st.markdown(f'''
- **Browser** managed Chrome `{browsing.get('browser_version', '—')}`, running in AWS
- **Page** `{str(visit.get('final_url') or browsing.get('source_url') or '—')[:70]}`
- **Rendered** {visit.get('rendered_chars', 0):,} characters, {visit.get('jsonld_blocks', 0)} JSON-LD blocks
- **Provenance** `{visit.get('price_source', '—')}`
''')
        source = str(visit.get('price_source') or '')
        if source.startswith('json-ld'):
            st.success('**Defensible.** The number is the retailer\'s own '
                       'published offer price, not a figure we inferred from '
                       'the words on the page.')
        elif source:
            st.warning(f'Provenance `{source}` — weaker than JSON-LD. Worth '
                       'a look before relying on this amount.')

        found = visit.get('text_prices_found') or []
        if found:
            with st.expander(f'⚠️ Why provenance matters — {len(found)} '
                             f'plausible prices were on this page'):
                st.markdown(f'''
Our first version scanned the rendered text for currency amounts and took the
lowest. On this page that approach sees **{len(found)} candidate prices** —
accessories, bundle discounts, instalment plans, a strike-through was-price:

`{', '.join(money(p) for p in found[:14])}`

The lowest is {money(min(found))} against a true price of
{money(browsing.get('price'))}. It would have refunded the wrong amount. The
fix was to read the retailer's own machine-readable price instead, and to
**record which method answered** — which is why `price_source` is in the
transcript above.

Worth saying plainly: the control that caught this was a human reading the
output, not the policy engine.
''')

    with right:
        shot = artifact_path(browsing.get('screenshot')
                             or visit.get('screenshot'))
        if shot:
            st.image(shot, caption=f"Screenshot taken at the time of the run — "
                                   f"{money(browsing.get('price'))} is visible "
                                   f"on the page",
                     width='stretch')
        else:
            st.info('Screenshot not found on disk for this run.')

    st.caption('This step bypasses the gateway entirely. It is authorised by '
               'IAM alone and Cedar cannot see it — the one structural gap in '
               'this POC. It only reads, so it cannot move money.')


def render_step_amount(entry: Dict[str, Any]) -> None:
    case = entry.get('case') or {}
    ours = case.get('our_price')
    theirs = entry.get('competitor_price')
    refund = entry.get('refund_amount')

    st.markdown('#### ③ The amount — *computed, not chosen*')
    cols = st.columns(4)
    cols[0].metric('We charged', money(ours))
    cols[1].metric('Competitor', money(theirs))
    try:
        cols[2].metric('Gap', money(float(ours) - float(theirs)))
    except (TypeError, ValueError):
        cols[2].metric('Gap', '—')
    cols[3].metric('Refund requested', f'${refund}' if refund else '—')

    st.caption('This is the hinge of the POC. The number policy is about to '
               'adjudicate was produced by the two steps above, seconds ago, '
               'from a live web page. Nobody typed it.')


def render_step_policy(entry: Dict[str, Any]) -> None:
    decision = entry.get('refund_decision') or {}
    verdict = decision.get('verdict', 'UNKNOWN')
    refund = entry.get('refund_amount')

    st.markdown('#### ④ Policy — *may this agent refund this amount?*')

    if verdict == 'ALLOWED':
        verdict_banner(
            'ALLOWED', f'refund of ${refund} approved in '
                       f"{decision.get('latency_ms', 0):.0f} ms",
            f'${refund} is within the ${config.AUTO_APPROVE_LIMIT} '
            f'auto-approval limit, so no human was involved.')
    else:
        verdict_banner(
            'DENIED', f'refund of ${refund} refused',
            f"Deciding rule: <code>{decision.get('deciding_policy')}</code>"
            '<br/>The refunds backend was <b>never invoked</b>, so no '
            'credential was fetched and no money moved.')

    with st.expander('The exact message the gateway returned'):
        st.code(decision.get('policy_message')
                or 'No error — the call was permitted.', language='text')
        st.caption('A named rule in the denial is the difference between a '
                   'control you can point at in an audit and a support '
                   'ticket that says "access denied".')

    identity = (decision.get('backend') or {}).get('identity') or {}
    if identity:
        st.markdown('#### ⑤ Identity — *which credential moves the money?*')
        cols = st.columns(3)
        cols[0].metric('Workload identity', identity.get('workloadName', '—'))
        cols[1].metric('Vault provider', identity.get('providerName', '—'))
        cols[2].metric('Credential', identity.get('apiKeyMasked', '—'))
        st.caption('Fetched from the account token vault at the moment of use '
                   'by the backend, and returned masked. The agent holds no '
                   'credentials of any kind — nothing in a config file, '
                   'nothing in an environment variable, nothing in a log. '
                   'This is the backend\'s own pair; the POC provisions a '
                   'separate one of its own — see **The gateway → Identity** '
                   'for why those are deliberately different.')


def render_walkthrough(transcript: Optional[Dict[str, Any]]) -> None:
    st.title('One claim, start to finish')
    if not transcript:
        no_run_yet()
        return

    cases = transcript.get('cases') or []
    if not cases:
        no_run_yet()
        return

    labels = {}
    for entry in cases:
        case = entry.get('case') or {}
        outcome = str(entry.get('outcome') or '')
        icon = '✅' if outcome.startswith('refunded') else '🛑'
        labels[f"{icon} {case.get('case_id')} — {case.get('product')}"] = entry

    chosen = st.radio('Claim', list(labels), horizontal=True,
                      label_visibility='collapsed')
    entry = labels[chosen]
    case = entry.get('case') or {}

    st.subheader(f"{case.get('case_id')} · {case.get('product')}",
                 divider='blue')
    st.caption(case.get('why', ''))

    render_step_search(entry)
    st.markdown('---')
    render_step_browser(entry)
    st.markdown('---')
    render_step_amount(entry)
    st.markdown('---')
    render_step_policy(entry)


# ------------------------------------------------- 3. same agent, two answers

def render_comparison(transcript: Optional[Dict[str, Any]]) -> None:
    st.title('Same agent. Same code. Different answer.')
    st.subheader('This is the slide that settles the risk question',
                 divider='blue')

    if not transcript or not transcript.get('cases'):
        no_run_yet()
        return

    cases = transcript['cases']
    columns = st.columns(len(cases), gap='large')
    for column, entry in zip(columns, cases):
        case = entry.get('case') or {}
        decision = entry.get('refund_decision') or {}
        with column:
            st.markdown(f"##### {case.get('case_id')} · "
                        f"{case.get('product')}")
            st.markdown(f"{money(case.get('our_price'))} − "
                        f"{money(entry.get('competitor_price'))} = "
                        f"**${entry.get('refund_amount')}**")
            verdict = decision.get('verdict', 'UNKNOWN')
            if verdict == 'ALLOWED':
                verdict_banner('ALLOWED', 'the claim was settled',
                               'Within the limit. No human involved.')
            else:
                verdict_banner(
                    'DENIED', 'the claim was refused',
                    f"by <code>{decision.get('deciding_policy')}</code>")
            st.caption(f"tool `{decision.get('tool')}` · "
                       f"price via "
                       f"`{((entry.get('browsing') or {}).get('visits') or [{}])[-1].get('price_source', '—')}`")

    st.markdown('---')
    st.markdown(f'''
Nothing about the agent changed between those two columns. Same tool, same
credentials, same code path, same permissions. **Only the amount differs**, and
the amount came from a live web page.

That is the control you are being asked to rely on, and it is doing the work.
An agent that had been prompt-injected into asking for $50,000 gets the same
refusal, because the decision is not made by the agent, the prompt, or the
model — it is made at the gateway, after the request and before anything runs.
''')

    evasion = transcript.get('evasion')
    if evasion:
        st.markdown('---')
        st.markdown('#### And the obvious workaround?')
        st.caption(evasion.get('why', ''))
        decision = evasion.get('decision') or {}
        left, right = st.columns(2, gap='large')
        with left:
            st.markdown(f"**(a) Is `{evasion.get('tool')}` even offered to "
                        f"the agent?**")
            if evasion.get('visible_in_tool_list'):
                st.warning('Yes — it is in the tool list.')
            else:
                verdict_banner('DENIED', 'not in the agent\'s tool list',
                               '`tools/list` is filtered by the same policies. '
                               'The agent is not resisting temptation — it has '
                               'not been told the option exists.')
        with right:
            st.markdown('**(b) Call it anyway, by name, bypassing the agent.**')
            verdict_banner(decision.get('verdict', 'UNKNOWN'),
                           str(decision.get('deciding_policy')),
                           'Nothing grants this tool, so it is denied by '
                           'default. A capability has to be explicitly '
                           'allowed to work.')
        st.markdown('So the limit holds two ways: through the front door, and '
                    'around the side.')


# ------------------------------------------------------------ 4. try it live

def render_live() -> None:
    st.title('Try it yourself')
    st.subheader('A real call to the real gateway — nothing here is mocked',
                 divider='blue')

    st.markdown(f'''
Move the amount past **${config.AUTO_APPROVE_LIMIT}** and watch the verdict
flip. This sends a signed request to the live gateway in account
196856463470 and shows you exactly what came back.

The refunds backend performs the identity flow but does not call a payment
provider, so an approved request here moves no actual money.
''')

    try:
        import gateway_stack
        import scenario
        from mcp_client import McpGatewayClient
    except Exception as exc:                        # noqa: BLE001
        st.error(f'Could not import the POC modules: {exc}')
        return

    stack = gateway_stack.Stack.load()
    if not stack or not stack.gateway_id:
        st.warning('No gateway state found. Run `python run_poc.py setup` '
                   'first — it takes about 90 seconds.')
        return

    st.caption(f'Gateway `{stack.gateway_id}` · policy mode ENFORCE · '
               f'inbound identity AWS_IAM')

    tools = {
        f'Cash refund  ·  {stack.refund_tool()}': ('refund', stack.refund_tool()),
        f'Store credit  ·  {stack.refund_tool("issue_store_credit")}':
            ('credit', stack.refund_tool('issue_store_credit')),
    }

    left, right = st.columns([1, 1.4], gap='large')
    with left:
        label = st.radio('Which tool should the agent call?', list(tools))
        kind, tool = tools[label]
        if kind == 'credit':
            st.caption('No policy grants this tool. It is the workaround an '
                       'agent would reach for after a refusal.')
        amount = st.number_input('Amount (USD)', min_value=1, max_value=50_000,
                                 value=config.AUTO_APPROVE_LIMIT - 1, step=25)
        go = st.button('Call the gateway', type='primary')
        sweep = st.button(f'Find the boundary '
                          f'(probes ${config.AUTO_APPROVE_LIMIT - 1}, '
                          f'${config.AUTO_APPROVE_LIMIT}, '
                          f'${config.AUTO_APPROVE_LIMIT + 1})')

    with right:
        if not (go or sweep):
            st.info('Nothing has been sent yet. The app makes no AWS calls '
                    'until you press a button.')
            return

        client = McpGatewayClient(stack.gateway_id, url=stack.gateway_url)
        amounts = ([config.AUTO_APPROVE_LIMIT - 1, config.AUTO_APPROVE_LIMIT,
                    config.AUTO_APPROVE_LIMIT + 1] if sweep else [int(amount)])

        for value in amounts:
            with st.spinner(f'Calling the gateway for ${value}…'):
                decision = scenario.call_through_gateway(
                    client, tool,
                    {'amount': value,
                     'reason': 'streamlit walkthrough'})

            if decision.allowed:
                verdict_banner('ALLOWED', f'${value}',
                               f'Returned in {decision.latency_ms:.0f} ms.')
            else:
                verdict_banner(decision.verdict, f'${value}',
                               f'Deciding rule: '
                               f'<code>{decision.deciding_policy}</code>')

            with st.expander(f'What came back for ${value}'):
                st.json(decision.to_dict(), expanded=False)

        if sweep:
            st.success(f'The boundary is exactly where the policy says it is: '
                       f'${config.AUTO_APPROVE_LIMIT} passes, '
                       f'${config.AUTO_APPROVE_LIMIT + 1} does not. Raising '
                       f'it is a policy change, not a code change — no '
                       f'developer and no deployment.')


# ------------------------------------------------------------- 5. the gateway

def render_identity(gateway: Dict[str, Any],
                    transcript: Optional[Dict[str, Any]]) -> None:
    """The identity resources, and the two-resource split told honestly.

    This block exists because the console's Identity page showed nothing
    attributable to the POC. It now does, and the distinction between
    *provisioning* a credential and *consuming* one at request time is the
    thing to explain while it is on screen.
    """
    st.markdown('#### Identity — two different things, kept separate')

    if not gateway.get('workload_identity_name'):
        st.info('This transcript predates the POC owning its own identity '
                'resources. Re-run `python run_poc.py setup` and then `run` to '
                'populate this section.')
        return

    check = gateway.get('identity_check') or {}
    used = [c['identity'] for c in (transcript or {}).get('cases', [])
            if c.get('identity')]

    left, right = st.columns(2, gap='large')
    with left:
        st.markdown('**Provisioned by this POC** — an operator action')
        st.markdown(f'''
- workload identity `{gateway['workload_identity_name']}`
- credential provider `{gateway.get('credential_provider_name')}`
''')
        if check.get('ok'):
            st.success(f"Vault round trip verified at `setup` — a workload "
                       f"token was issued and the stored secret came back "
                       f"(`{check.get('apiKeyMasked')}`).")
        elif check:
            st.error(f"Vault round trip failed: {check.get('error')}")
        st.caption('Created by `setup`, deleted by `destroy`. The secret is '
                   'synthetic and generated locally — nothing real is '
                   'protected by it. These are what you now see on the '
                   'console\'s Identity page.')
    with right:
        st.markdown('**Consumed at claim time** — the backend, not the agent')
        if used:
            st.markdown(f'''
- workload identity `{used[-1].get('workloadName')}`
- credential provider `{used[-1].get('providerName')}`
- returned to the agent as `{used[-1].get('apiKeyMasked')}`
''')
        st.caption('A different pair, read from the refunds Lambda\'s own '
                   'environment. This sandbox denies `lambda:CreateFunction`, '
                   'so the POC reuses a function it cannot modify, and '
                   'repointing it would break other demos that share it.')

    st.info('**Why two.** *Provisioning* a credential is an admin action — it '
            'happens once, from a terminal, under a human\'s identity. '
            '*Consuming* one happens per request, inside the backend, after '
            'the gateway has authorised the call. The agent does neither. An '
            'agent that fetches its own credentials is the design this whole '
            'architecture exists to avoid, so the POC deliberately does not '
            'demonstrate that — even though it would have made this section '
            'tidier.')


def render_gateway(transcript: Optional[Dict[str, Any]]) -> None:
    st.title('What exists in the account')
    st.subheader('And what this POC does not prove', divider='blue')

    gateway = (transcript or {}).get('gateway') or {}

    left, right = st.columns([1, 1], gap='large')
    with left:
        if gateway:
            st.markdown(f'''
- **Gateway** `{gateway.get('gateway_id')}`
- **Created** {gateway.get('created_at')} · region `{gateway.get('region')}`
- **Targets** `{config.TARGET_RESEARCH}` (web-search connector),
  `{config.TARGET_REFUNDS}` (Lambda)
- **Policy engine** `{gateway.get('policy_engine_id')}`
- **MCP** stateless, `2025-11-25`
''')
            st.caption('This gateway is **persistent** — it is still in the '
                       'console. The capability evaluation next door tears '
                       'its stack down automatically, which is why nothing '
                       'from it was ever visible.')
            st.code(f"https://{config.REGION}.console.aws.amazon.com/"
                    f"bedrock-agentcore/gateways", language='text')
        else:
            no_run_yet()
    with right:
        st.graphviz_chart(diagrams.gateway_stack(), width='stretch')

    st.markdown('---')
    render_identity(gateway, transcript)

    st.markdown('---')
    st.markdown('#### Where authorisation happens')
    left, right = st.columns([1.3, 1], gap='large')
    with left:
        st.graphviz_chart(diagrams.decision_path(), width='stretch')
    with right:
        st.markdown('''
Policy runs at **②**, the backend at **③**. That ordering *is* the security
argument — a refused call never reaches a credential, so a block is not
"the payment failed", it is "the payment was never attempted".

`context.input` **is the tool's arguments**, which is the thing IAM cannot do.
IAM can say *this role may call `process_refund`*. It cannot say
*…for amounts up to $100*.
''')

    st.markdown('---')
    st.markdown('#### The three rules, in both languages')
    for name, plain in POLICY_PLAIN.items():
        with st.expander(f'`{name}` — {plain}'):
            st.code(CEDAR_SOURCE[name], language='text')
    st.caption('Nothing grants `issue_store_credit`. That is deliberate: a '
               'demo pointed at a tool some policy happens to cover would '
               'prove nothing about default-deny.')

    st.markdown('---')
    st.markdown('#### A finding worth knowing before you roll this out')
    left, right = st.columns([1, 1.2], gap='large')
    with left:
        st.markdown('''
**`tools/list` is filtered by policy, not just `tools/call`.** Attaching the
policy engine in `ENFORCE` with no policies written returns an **empty tool
list** while both targets are `READY`.

That is good behaviour — an agent cannot be talked into using a capability it
was never shown — but it creates a bootstrap problem: you cannot discover tool
names in order to write policies about them.

So the rollout order is forced, and it happens to be the right one anyway:
**observe, then enforce.**
''')
        if gateway:
            log_only = set(gateway.get('tools_log_only') or [])
            enforced = set(gateway.get('tools_enforced') or [])
            st.markdown('| Policy mode | Tools visible |\n|---|---|\n'
                        f"| `LOG_ONLY` | {len(log_only)} |\n"
                        f"| `ENFORCE` | {len(enforced)} |")
            hidden = sorted(log_only - enforced)
            if hidden:
                st.caption('Hidden by policy under ENFORCE: '
                           + ', '.join(f'`{t}`' for t in hidden))
    with right:
        st.graphviz_chart(diagrams.tool_visibility(), width='stretch')

    st.markdown('---')
    st.markdown('#### The honest gaps')
    st.markdown(f'''
Raise these yourself. If the room finds them afterwards the demo loses its
credibility; if you volunteer them it gains some.

- **The browser is outside the fence.** It is a separate service and Cedar
  cannot see it, so an agent could browse somewhere we would rather it did
  not. The fix is a wrapper around `StartBrowserSession` attached to the same
  gateway. This sandbox denies `lambda:CreateFunction`, so it is described and
  not built. It has not bitten us because browsing only reads.
- **Reading a price is harder than it looks.** See the walkthrough — the first
  version picked the wrong number off a real page. Provenance is now recorded
  per run, but "the agent read the page" is not automatically "the agent read
  it correctly".
- **Per-call limits are not rate limits.** With these three rules an agent
  could refund ${config.AUTO_APPROVE_LIMIT - 1} repeatedly. Cedar can express a
  cumulative limit; we have not written one.
- **No model in the loop.** Orchestration is plain Python so a run is
  reproducible and the verdict is attributable to policy rather than sampling.
  The safety property does not depend on a model being involved — that is the
  argument, not a gap — but agent *reasoning* is not demonstrated here.
- **The backend moves no money.** It performs the real identity flow and
  returns a masked credential, then stops.
- **Inbound identity is `AWS_IAM`, not corporate SSO.** Switching to
  `CUSTOM_JWT` against a real IdP changes one field and was not done.
''')

    st.markdown('---')
    st.markdown('#### What we are asking for')
    st.markdown(f'''
1. **Agree the number.** ${config.AUTO_APPROVE_LIMIT} is a placeholder. It
   should be a business decision, not an engineering one.
2. **Two weeks in `LOG_ONLY` against real claims.** Nothing is blocked; we
   record what the rules *would* have done. That is a setting, and it is how we
   find out whether ${config.AUTO_APPROVE_LIMIT} is right.
3. **Fund the browser wrapper.** It is the one gap in the fence.
''')


# --------------------------------------------------------------------- shell

SECTIONS = {
    'The claim': render_claim,
    'Walk a claim': render_walkthrough,
    'Same agent, different answer': render_comparison,
    'Try it yourself': render_live,
    'Ask the hosted agent': runtime_view.render,
    'Three test cases': testcase_view.render,
    'All traces': traces_view.render,
    'Six capabilities': capability_view.render,
    'The gateway': render_gateway,
}

# What each section reads. 'transcript' sections take a scenario run,
# 'bundle' takes capability evidence, 'nothing' calls AWS itself when a button
# is pressed. Kept as data rather than an if-chain in main() so adding a
# section is one line in each dict.
SECTION_INPUT = {
    'Try it yourself': 'nothing',
    # The only page that calls a *hosted* agent rather than the gateway
    # directly, so it reads no recorded artifact at all.
    'Ask the hosted agent': 'nothing',
    # The storyboard half needs no artifact and the live half calls the hosted
    # agent, so this page has nothing to read either.
    'Three test cases': 'nothing',
    # Reads `artifacts/traces/` off disk and makes no AWS call at all - it is
    # the record of calls already made.
    'All traces': 'nothing',
    'Six capabilities': 'bundle',
}


def main() -> None:
    runs = available_runs()

    st.sidebar.title('🧾 NovaCart price match')
    st.sidebar.caption('AgentCore Gateway POC — websearch, identity, policy, '
                       'browser, in one use case')

    section = st.sidebar.radio('Section', list(SECTIONS))
    needs = SECTION_INPUT.get(section, 'transcript')

    if needs == 'bundle':
        st.sidebar.markdown('---')
        bundles = capabilities.available_bundles()
        if bundles:
            labels = {os.path.basename(path): path for path in bundles}
            chosen = st.sidebar.selectbox(
                'Capability evidence', list(labels),
                help='Written by `python run_poc.py capabilities`. Newest '
                     'first. Nothing on that page is asserted without a '
                     'probe behind it in this file.')
            path = labels[chosen]
            bundle = load_bundle(path, os.path.getmtime(path))
            counts = (bundle.get('summary') or {}).get('counts') or {}
            st.sidebar.caption(
                f"Probed {bundle.get('generated', '?')} — "
                f"{counts.get('PROVEN', 0)} proven, "
                f"{counts.get('PARTIAL', 0)} partial, "
                f"{counts.get('BLOCKED', 0)} blocked")
            with open(path, 'rb') as handle:
                st.sidebar.download_button('Download this evidence', handle,
                                           file_name=os.path.basename(path),
                                           mime='application/json')
        else:
            bundle = None
            st.sidebar.warning('No capability evidence in `artifacts/` yet.')
        st.sidebar.markdown('---')
        st.sidebar.caption(
            'Presenter notes are in `SPEAKER_NOTES.md`; the written evidence '
            'for these six rows is `docs/CAPABILITY_EVIDENCE.md`.')
        SECTIONS[section](bundle)
        return

    st.sidebar.markdown('---')
    transcript: Optional[Dict[str, Any]] = None
    if runs:
        labels = {os.path.basename(path): path for path in runs}
        chosen = st.sidebar.selectbox(
            'Run transcript', list(labels),
            help='Every figure in this app is read from the selected run.')
        path = labels[chosen]
        transcript = load_transcript(path, os.path.getmtime(path))
        st.sidebar.caption(f"Run of {transcript.get('generated', '?')}")
        with open(path, 'rb') as handle:
            st.sidebar.download_button('Download this transcript', handle,
                                       file_name=os.path.basename(path),
                                       mime='application/json')
    else:
        st.sidebar.warning('No runs in `artifacts/` yet.')

    st.sidebar.markdown('---')
    st.sidebar.caption(
        'Presenter notes are in `SPEAKER_NOTES.md`, with timings, the lines to '
        'say and the anticipated questions. The written write-up is '
        '`README.md`.')

    if needs == 'nothing':
        SECTIONS[section]()
    else:
        SECTIONS[section](transcript)


main()
