"""What AgentCore Observability already knows about this gateway.

This module reads; it never instruments anything. That is the finding worth
leading with, because it was a surprise: **nothing in this POC emits a single
metric, and yet every number below exists.** The gateway is vending them on its
own, per request, dimensioned by resource ARN, tool name, target type and - the
one that matters for an audit - the *ID of the Cedar policy that decided*.

So the Observability row of the requirements table is not satisfied by work we
did. It is satisfied by work we did not have to do, and the evidence is that
`observe()` below can be pointed at a gateway built by someone who had never
heard of CloudWatch and still come back with the allow/deny split.

## The two namespaces

Three names look plausible and only two exist:

    AWS/Bedrock-AgentCore   service-vended. Note the hyphen. This is the one.
    bedrock-agentcore       where the ADOT/OTel collector puts *application*
                            metrics - Strands event-loop cycles, Bedrock token
                            usage. Different data, different producer.
    AWS/BedrockAgentCore    the natural guess. Empty. There is no such namespace.

Measured 2026-10-11 in account 196856463470: 500+ metric streams in the first,
152 in the second, 0 in the third.

## The dimension trap

Gateway-invocation metrics are keyed on **`Resource`, the full gateway ARN**.
Policy-decision metrics are keyed on **`TargetResource`, the bare gateway ID**.
Same gateway, two different dimension names and two different value formats, in
the same namespace. Querying with the wrong one returns an empty series rather
than an error, which reads exactly like "the integration is not working".

That is why `discover()` exists and runs first: rather than assuming a
dimension set, it asks CloudWatch which ones are actually populated for this
gateway and reports them. A demo that queries blind and shows zeros has proved
nothing; a demo that shows the dimension list has proved the service is
publishing.
"""

import datetime
from typing import Any, Dict, List, Optional

import boto3
import botocore.exceptions

import config


def _cloudwatch():
    return boto3.client('cloudwatch', region_name=config.REGION)


def _logs():
    return boto3.client('logs', region_name=config.REGION)


def _window(days: Optional[int] = None):
    end = datetime.datetime.now(datetime.timezone.utc)
    return end - datetime.timedelta(days=days or config.METRIC_LOOKBACK_DAYS), end


# The metrics this POC claims are vended, split by what they tell you. The
# split is the useful part: the first group answers "is the gateway working",
# the second answers "is policy doing anything", the third answers "did
# identity hand out a credential". Three different questions, one namespace.
GATEWAY_METRICS = [
    ('Invocations', 'Sum', 'Tool calls and listings that reached the gateway'),
    ('Latency', 'Average', 'End-to-end milliseconds, gateway in to gateway out'),
    ('TargetExecutionTime', 'Average', 'Of that, how long the backend took'),
    ('UserErrors', 'Sum', 'Rejected for something the caller did — 4xx-shaped'),
    ('SystemErrors', 'Sum', 'Rejected for something the service did — 5xx-shaped'),
    ('Throttles', 'Sum', 'Refused for rate'),
]

POLICY_METRICS = [
    ('AllowDecisions', 'Sum', 'Tool calls Cedar permitted'),
    ('DenyDecisions', 'Sum', 'Tool calls Cedar refused'),
    ('DeterminingPolicies', 'Sum', 'Decisions that had a policy to point at'),
    ('NoDeterminingPolicies', 'Sum',
     'Decisions with no matching policy — the default-deny path'),
]

IDENTITY_METRICS = [
    ('WorkloadAccessTokenFetchSuccess', 'Sum',
     'Workload tokens issued from the identity directory'),
    ('ApiKeyFetchSuccess', 'Sum',
     'Secrets retrieved from the token vault by the backend'),
]


def discover(gateway_id: str, gateway_arn: str) -> Dict[str, Any]:
    """Ask CloudWatch which metric streams exist for this gateway.

    Returns a mapping of metric name -> list of dimension dicts. Reported
    rather than assumed, because the whole point is that the service chose
    these, not us.
    """
    cloudwatch = _cloudwatch()
    found: Dict[str, List[Dict[str, str]]] = {}
    needles = [n for n in (gateway_id, gateway_arn) if n]

    paginator = cloudwatch.get_paginator('list_metrics')
    for page in paginator.paginate(Namespace=config.METRIC_NAMESPACE):
        for metric in page.get('Metrics', []):
            dimensions = {d['Name']: d['Value'] for d in metric['Dimensions']}
            # Dimension values are truncated by CloudWatch at 255 chars, and
            # ARNs in the `Resource` dimension are sometimes cut mid-string, so
            # match on containment in either direction rather than equality.
            if not any(needle in value or value in needle
                       for value in dimensions.values() for needle in needles
                       if value):
                continue
            found.setdefault(metric['MetricName'], []).append(dimensions)

    return {'namespace': config.METRIC_NAMESPACE,
            'metric_count': len(found),
            'stream_count': sum(len(v) for v in found.values()),
            'metrics': {k: found[k] for k in sorted(found)}}


def _series(queries: List[Dict[str, Any]], days: Optional[int] = None
            ) -> Dict[str, Dict[str, Any]]:
    """Run a GetMetricData batch and flatten it into something renderable."""
    if not queries:
        return {}
    start, end = _window(days)
    cloudwatch = _cloudwatch()
    out: Dict[str, Dict[str, Any]] = {}

    # GetMetricData caps at 500 queries per call; batch defensively even though
    # this POC sends about twenty.
    for chunk in (queries[i:i + 100] for i in range(0, len(queries), 100)):
        response = cloudwatch.get_metric_data(
            MetricDataQueries=chunk, StartTime=start, EndTime=end,
            ScanBy='TimestampAscending')
        for result in response.get('MetricDataResults', []):
            values = result.get('Values') or []
            out[result['Id']] = {
                'label': result.get('Label'),
                'status': result.get('StatusCode'),
                'points': [
                    {'at': timestamp.isoformat(), 'value': value}
                    for timestamp, value in zip(result.get('Timestamps') or [],
                                                values)],
                'total': round(sum(values), 2) if values else 0.0,
                # Average-of-averages is wrong for latency across buckets of
                # unequal population, and saying so is cheaper than pretending
                # otherwise. It is indicative, which is all a demo needs.
                'mean': round(sum(values) / len(values), 1) if values else None,
            }
    return out


def _query(query_id: str, metric: str, stat: str,
           dimensions: Dict[str, str], period: int = 86400) -> Dict[str, Any]:
    return {
        'Id': query_id,
        'MetricStat': {
            'Metric': {
                'Namespace': config.METRIC_NAMESPACE,
                'MetricName': metric,
                'Dimensions': [{'Name': k, 'Value': v}
                               for k, v in dimensions.items()],
            },
            'Period': period,
            'Stat': stat,
        },
        'ReturnData': True,
    }


def gateway_health(gateway_arn: str, days: Optional[int] = None
                   ) -> Dict[str, Any]:
    """Invocations, latency and errors for the gateway as a whole."""
    dimensions = {'Resource': gateway_arn, 'Operation': 'InvokeGateway',
                  'Protocol': 'MCP'}
    queries = [_query(f'gw{i}', metric, stat, dimensions)
               for i, (metric, stat, _) in enumerate(GATEWAY_METRICS)]
    series = _series(queries, days)
    return {metric: {**series.get(f'gw{i}', {}), 'stat': stat,
                     'means': meaning}
            for i, (metric, stat, meaning) in enumerate(GATEWAY_METRICS)}


def per_tool(gateway_arn: str, tools: List[str], days: Optional[int] = None
             ) -> Dict[str, Dict[str, Any]]:
    """Invocation count and latency broken out by tool name.

    The `Name` dimension carries the published `<target>___<tool>` string, so
    this is the view that shows which capability the agent actually leaned on.
    """
    queries = []
    index = {}
    for position, tool in enumerate(tools):
        dimensions = {'Resource': gateway_arn, 'Operation': 'InvokeGateway',
                      'Protocol': 'MCP', 'Method': 'tools/call', 'Name': tool}
        for metric, stat in (('Invocations', 'Sum'), ('Latency', 'Average')):
            query_id = f't{position}{metric[:3].lower()}'
            index[query_id] = (tool, metric)
            queries.append(_query(query_id, metric, stat, dimensions))

    series = _series(queries, days)
    out: Dict[str, Dict[str, Any]] = {tool: {} for tool in tools}
    for query_id, (tool, metric) in index.items():
        out[tool][metric] = series.get(query_id, {})
    return out


def policy_decisions(gateway_id: str, policy_ids: List[str] = None,
                     days: Optional[int] = None) -> Dict[str, Any]:
    """Allow/deny counts for the gateway, and per Cedar policy where known.

    The per-policy breakdown is the single most useful thing in this module for
    a governance conversation. `DenyDecisions` dimensioned by
    `Policy=novacart_block_large_refunds-k0fahcb42r` means an auditor can ask
    "how often did that specific rule fire last month" and get a number out of
    CloudWatch, without reading a log line or trusting this POC's transcripts.
    """
    overall = {'TargetResource': gateway_id, 'OperationName': 'AuthorizeAction'}
    queries = [_query(f'pd{i}', metric, stat, overall)
               for i, (metric, stat, _) in enumerate(POLICY_METRICS)]

    index = {}
    for position, policy_id in enumerate(policy_ids or []):
        for metric in ('AllowDecisions', 'DenyDecisions'):
            query_id = f'pp{position}{metric[0].lower()}'
            index[query_id] = (policy_id, metric)
            queries.append(_query(
                query_id, metric, 'Sum',
                {'Policy': policy_id, 'TargetResource': gateway_id,
                 'OperationName': 'AuthorizeAction'}))

    series = _series(queries, days)

    by_policy: Dict[str, Dict[str, Any]] = {}
    for query_id, (policy_id, metric) in index.items():
        by_policy.setdefault(policy_id, {})[metric] = series.get(query_id, {})

    return {
        'overall': {metric: {**series.get(f'pd{i}', {}), 'means': meaning}
                    for i, (metric, _, meaning) in enumerate(POLICY_METRICS)},
        'by_policy': by_policy,
    }


def identity_activity(workload_name: str = None, provider_name: str = None,
                      days: Optional[int] = None) -> Dict[str, Any]:
    """Token-vault activity, as seen from outside the POC's own logs.

    Worth having because it corroborates `identity.verify_round_trip()` from a
    completely independent source. The round trip says "the vault gave me the
    secret"; `ApiKeyFetchSuccess` says the *service* counted a retrieval
    against this provider name. One of those is this POC marking its own
    homework and the other is not.
    """
    workload_name = workload_name or config.WORKLOAD_IDENTITY_NAME
    provider_name = provider_name or config.CREDENTIAL_PROVIDER_NAME

    queries = [
        _query('idtok', 'WorkloadAccessTokenFetchSuccess', 'Sum',
               {'WorkloadIdentityDirectory': 'default',
                'WorkloadIdentity': workload_name}),
        _query('idkey', 'ApiKeyFetchSuccess', 'Sum',
               {'ProviderName': provider_name, 'TokenVault': 'default'}),
    ]
    series = _series(queries, days)
    return {
        'WorkloadAccessTokenFetchSuccess': {
            **series.get('idtok', {}),
            'dimension': f'WorkloadIdentity={workload_name}',
            'means': IDENTITY_METRICS[0][2]},
        'ApiKeyFetchSuccess': {
            **series.get('idkey', {}),
            'dimension': f'ProviderName={provider_name}',
            'means': IDENTITY_METRICS[1][2]},
    }


def log_groups(gateway_id: str, memory_id: str = None) -> Dict[str, Any]:
    """Which AgentCore log groups exist, and which belong to this POC.

    Reported honestly, because the answer is partly negative: AgentCore vends
    log groups for Runtime and Memory but **not for Gateway**. Gateway
    observability is metrics-only unless you turn on the account-level
    observability setting that ships traces to CloudWatch. So this function
    exists to show the shape of what is there rather than to claim a log group
    we do not have.
    """
    client = _logs()
    out: Dict[str, Any] = {'prefixes': {}, 'ours': []}
    for prefix in ('/aws/bedrock-agentcore',
                   '/aws/vendedlogs/bedrock-agentcore'):
        names: List[str] = []
        try:
            paginator = client.get_paginator('describe_log_groups')
            for page in paginator.paginate(logGroupNamePrefix=prefix):
                names.extend(g['logGroupName'] for g in page.get('logGroups', []))
        except botocore.exceptions.ClientError as exc:
            out['prefixes'][prefix] = {
                'error': exc.response['Error']['Code']}
            continue
        out['prefixes'][prefix] = {'count': len(names)}
        for name in names:
            if gateway_id in name or (memory_id and memory_id in name):
                out['ours'].append(name)

    out['gateway_has_log_group'] = any(gateway_id in n for n in out['ours'])
    return out


def observe(gateway_id: str, gateway_arn: str, tools: List[str] = None,
            policy_ids: List[str] = None, memory_id: str = None,
            days: Optional[int] = None, say=print) -> Dict[str, Any]:
    """Everything above, in one pass, shaped for the artifact and the app."""
    start, end = _window(days)
    say(f'  observability      reading {config.METRIC_NAMESPACE} over '
        f'{(end - start).days}d')

    result: Dict[str, Any] = {
        'namespace': config.METRIC_NAMESPACE,
        'window_days': (end - start).days,
        'window_start': start.isoformat(),
        'window_end': end.isoformat(),
        'instrumented_by_poc': False,
    }

    try:
        result['discovered'] = discover(gateway_id, gateway_arn)
        say(f"  observability      {result['discovered']['metric_count']} metrics, "
            f"{result['discovered']['stream_count']} dimension sets vended "
            f"for this gateway")
    except botocore.exceptions.ClientError as exc:
        result['discovered'] = {'error': exc.response['Error']['Code']}
        say(f"  observability      discover failed: "
            f"{exc.response['Error']['Code']}")

    try:
        result['gateway'] = gateway_health(gateway_arn, days)
        invocations = result['gateway'].get('Invocations', {}).get('total', 0)
        latency = result['gateway'].get('Latency', {}).get('mean')
        say(f'  observability      {invocations:.0f} invocations, '
            f"mean latency {latency if latency is not None else '—'} ms")
    except botocore.exceptions.ClientError as exc:
        result['gateway'] = {'error': exc.response['Error']['Code']}

    if tools:
        try:
            result['per_tool'] = per_tool(gateway_arn, tools, days)
        except botocore.exceptions.ClientError as exc:
            result['per_tool'] = {'error': exc.response['Error']['Code']}

    try:
        result['policy'] = policy_decisions(gateway_id, policy_ids, days)
        allowed = result['policy']['overall'].get(
            'AllowDecisions', {}).get('total', 0)
        denied = result['policy']['overall'].get(
            'DenyDecisions', {}).get('total', 0)
        say(f'  observability      policy decisions: {allowed:.0f} allowed, '
            f'{denied:.0f} denied')
    except botocore.exceptions.ClientError as exc:
        result['policy'] = {'error': exc.response['Error']['Code']}

    try:
        result['identity'] = identity_activity(days=days)
    except botocore.exceptions.ClientError as exc:
        result['identity'] = {'error': exc.response['Error']['Code']}

    try:
        result['logs'] = log_groups(gateway_id, memory_id)
    except botocore.exceptions.ClientError as exc:
        result['logs'] = {'error': exc.response['Error']['Code']}

    return result
