"""Settings for the NovaCart price-match POC.

Different in one important way from the capability evaluation next door: that
suite created a stack and deleted it in a `finally:` block, so nothing was ever
visible in the AgentCore console afterwards. This POC does the opposite. It
builds **one named, persistent gateway** and leaves it standing, because the
point is to have something you can open in the console, show to people, and
call repeatedly.

That makes cleanup a deliberate act (`python run_poc.py destroy`) rather than
something that happens automatically. A gateway has no standing hourly charge -
you pay per request - so leaving it up between demos costs nothing measurable.
"""

import os

from dotenv import load_dotenv

load_dotenv()

REGION = os.getenv('AWS_REGION', 'us-east-1')

# --- The persistent stack ---------------------------------------------------
# Fixed names, not random suffixes. A demo you cannot find in the console twice
# is not a demo. `setup` is idempotent: it adopts an existing gateway with this
# name rather than creating a second one.
GATEWAY_NAME = os.getenv('GATEWAY_NAME', 'novacart-price-match-poc')
POLICY_ENGINE_NAME = os.getenv('POLICY_ENGINE_NAME', 'novacart_poc_policies')

# Target names matter more than they look. Tools are published as
# `<targetName>___<toolName>` (three underscores) and that full string is what
# Cedar authorises as an `AgentCore::Action`. So these two strings are the
# vocabulary the whole policy set is written against - renaming one silently
# stops every policy referencing it from matching.
TARGET_REFUNDS = os.getenv('TARGET_REFUNDS', 'novacart')
TARGET_RESEARCH = os.getenv('TARGET_RESEARCH', 'research')

# Where `setup` records what it built, so `run`, `status` and `destroy` can
# find it in a later process without guessing.
STATE_FILE = os.getenv('STATE_FILE', 'gateway_state.json')

# --- Identity, owned by this POC --------------------------------------------
# These two exist because the AgentCore console's Identity page showed nothing
# attributable to this POC: the refunds backend performs a real token-vault
# round trip, but against a workload identity and credential provider that
# predate us (see REFUNDS_LAMBDA_ARN below). Reusing them proved the capability
# and left no trace, which is the same complaint as having no gateway.
#
# `setup` now creates both under POC names, verifies the vault round trip, and
# `destroy` removes them. They are deliberately NOT consumed by the agent at
# claim time - an agent that fetches its own credentials is the thing this
# architecture is supposed to avoid. See identity.py for that distinction.
WORKLOAD_IDENTITY_NAME = os.getenv('WORKLOAD_IDENTITY_NAME',
                                   'novacart-price-match-poc')
CREDENTIAL_PROVIDER_NAME = os.getenv('CREDENTIAL_PROVIDER_NAME',
                                     'novacart-payments-poc')

# --- Reused account resources -----------------------------------------------
GATEWAY_ROLE_ARN = os.getenv(
    'GATEWAY_ROLE_ARN', 'arn:aws:iam::196856463470:role/SandboxServiceRole')

# The refunds backend. This sandbox denies lambda:CreateFunction outright, so
# the POC reuses a function that already exists - and it happens to be a better
# backend than one we would have written. `RefundToolEcho` performs the real
# outbound identity flow: GetWorkloadAccessToken -> GetResourceApiKey against
# the account token vault, returning only a masked preview of the credential.
# That is precisely the behaviour the identity half of this POC needs to show,
# executed by the backend rather than simulated by us.
#
# It is never modified, and `destroy` does not touch it.
REFUNDS_LAMBDA_ARN = os.getenv(
    'REFUNDS_LAMBDA_ARN',
    'arn:aws:lambda:us-east-1:196856463470:function:RefundToolEcho')

# --- Managed browser --------------------------------------------------------
BROWSER_ID = os.getenv('BROWSER_ID', 'aws.browser.v1')
BROWSER_SESSION_TIMEOUT = int(os.getenv('BROWSER_SESSION_TIMEOUT', '300'))
BROWSER_NAV_TIMEOUT_MS = int(os.getenv('BROWSER_NAV_TIMEOUT_MS', '45000'))

# --- Memory -----------------------------------------------------------------
# AgentCore Memory is an *indirect* Gateway integration: the agent reaches its
# tools through the gateway and its conversation history through Memory, and
# the two never touch. That independence is the thing worth demonstrating, so
# the POC owns a memory resource of its own rather than narrating the idea.
#
# Name charset is the policy-engine one, not the gateway one: `[A-Za-z][A-Za-z0-9_]*`
# with no hyphens. `novacart-price-match-poc` is rejected; underscores work.
MEMORY_NAME = os.getenv('MEMORY_NAME', 'novacart_price_match_poc_memory')

# Days before an event expires. 7 is the shortest useful window for a demo and
# keeps nothing around longer than a sprint.
MEMORY_EVENT_EXPIRY_DAYS = int(os.getenv('MEMORY_EVENT_EXPIRY_DAYS', '7'))

# The agent's name in Memory. Distinct from WORKLOAD_IDENTITY_NAME on purpose:
# that is who the agent *is* to Identity, this is who it is to Memory, and
# conflating them hides the fact that they are separate services.
MEMORY_ACTOR_ID = os.getenv('MEMORY_ACTOR_ID', 'novacart-price-match-agent')

# --- Runtime ----------------------------------------------------------------
# What `setup` would name the hosted agent if this sandbox could host one. It
# cannot: see runtime_agent.py for the measured blocker chain. The name is kept
# so the deploy attempt and its recorded failure refer to a real intention.
RUNTIME_NAME = os.getenv('RUNTIME_NAME', 'novacart_price_match_agent')

# Runtime serves HTTP on 8080 and requires exactly two routes. Hard-coded by
# the service, not configurable - listed here because the local harness has to
# match them exactly for the artifact to be worth anything.
RUNTIME_PORT = int(os.getenv('RUNTIME_PORT', '8080'))
RUNTIME_INVOKE_PATH = '/invocations'
RUNTIME_PING_PATH = '/ping'

# --- Observability ----------------------------------------------------------
# Two namespaces, and the difference between them caused real confusion:
#
#   AWS/Bedrock-AgentCore  - service-vended metrics. Note the hyphen. Gateway
#                            invocations, latency, and policy allow/deny counts
#                            dimensioned by the deciding policy ID.
#   bedrock-agentcore      - the namespace the ADOT/OTel collector writes
#                            application metrics into. Different data entirely.
#
# `AWS/BedrockAgentCore` (no hyphen) is the natural guess and is empty.
METRIC_NAMESPACE = os.getenv('METRIC_NAMESPACE', 'AWS/Bedrock-AgentCore')
METRIC_NAMESPACE_APP = os.getenv('METRIC_NAMESPACE_APP', 'bedrock-agentcore')

# How far back the observability section looks. The gateway bills per request
# and sees no traffic between demos, so an hour-wide window usually reads zero
# and makes a working integration look broken.
METRIC_LOOKBACK_DAYS = int(os.getenv('METRIC_LOOKBACK_DAYS', '7'))

# --- MCP --------------------------------------------------------------------
# Accepted MCP revisions are per-gateway configuration, not a service constant,
# so `setup` sets them explicitly and the client negotiates anyway.
MCP_PROTOCOL_VERSION = os.getenv('MCP_PROTOCOL_VERSION', '2025-11-25')
MCP_SERVICE = 'bedrock-agentcore'

# --- Policy thresholds ------------------------------------------------------
# The business rule the Cedar policy encodes, kept here so the narrative and
# the policy cannot disagree. Raising this number is a policy change, not a
# code change - which is the point of the whole exercise.
AUTO_APPROVE_LIMIT = int(os.getenv('AUTO_APPROVE_LIMIT', '100'))

# How much of the web one search call may pull back. Also enforced in Cedar,
# to show that policy governs the research tool and not only the money tool.
MAX_SEARCH_RESULTS = int(os.getenv('MAX_SEARCH_RESULTS', '10'))

# --- Output -----------------------------------------------------------------
ARTIFACT_DIR = os.getenv('ARTIFACT_DIR', 'artifacts')


def gateway_url(gateway_id: str, region: str = None) -> str:
    return (f"https://{gateway_id}.gateway.bedrock-agentcore."
            f"{region or REGION}.amazonaws.com/mcp")
