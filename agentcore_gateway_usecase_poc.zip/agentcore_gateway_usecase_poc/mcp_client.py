"""A minimal SigV4-signed MCP client for AgentCore Gateway.

There is no `InvokeGateway` API. A gateway is an MCP server reachable over
HTTPS, and with `authorizerType=AWS_IAM` the request must be SigV4-signed
against the `bedrock-agentcore` service. That is the whole integration:

    POST https://<gatewayId>.gateway.bedrock-agentcore.<region>.amazonaws.com/mcp
    Authorization: AWS4-HMAC-SHA256 ...
    MCP-Protocol-Version: 2025-11-25
    {"jsonrpc":"2.0","id":1,"method":"tools/list"}

This file is carried over from the capability evaluation deliberately: the
whole agent-side integration for this POC is ~200 lines of signing and JSON-RPC
with no AWS SDK call anywhere, and showing that is part of the argument. The
agent holds no tool credentials, only its own AWS identity.

For production, prefer `mcp-proxy-for-aws` (`pip install mcp-proxy-for-aws`),
which wraps the same signing in an `aws_iam_streamablehttp_client` and plugs
into the official `mcp` SDK. Nothing here is special; it is just explicit.

Protocol version note, measured 2026-10-06: the gateway advertises
`2025-11-25` and `2026-07-28`. Under `2025-11-25` a bare `tools/list` works with
no `initialize` handshake and no session id. Under `2026-07-28` every request is
rejected with `Missing required '_meta'` - MCP's 2026-07-28 revision made the
protocol stateless and added a governed extension envelope, and this client does
not implement it. Omitting the header entirely makes the gateway assume
`2025-03-26`, which it does not support, so the header is mandatory in practice.
"""

import json
import time
from typing import Any, Dict, Optional, Tuple

import boto3
import requests
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest

import config


# The revisions this client actually implements. 2026-07-28 is deliberately
# excluded: it requires a `_meta` envelope on every request, so offering it
# during negotiation would pick a version this client cannot speak. Negotiation
# must intersect what the gateway accepts with what the client can do - taking
# the gateway's newest version unconditionally is a bug that only shows up on
# gateways that have been updated.
CLIENT_SUPPORTED_VERSIONS = ('2025-03-26', '2025-11-25')

# Policy denials arrive as this JSON-RPC error code, not as a tool-level error.
POLICY_DENIED_CODE = -32002


class McpError(Exception):
    """A JSON-RPC level error returned by the gateway."""

    def __init__(self, code: int, message: str, data: Any = None):
        super().__init__(f"[{code}] {message}")
        self.code = code
        self.message = message
        self.data = data


class McpGatewayClient:
    """Talks JSON-RPC to one AgentCore Gateway.

    The client is stateless by design, matching the 2025-11-25 transport: each
    call is an independent signed POST. That keeps the latency numbers in the
    report honest, because no handshake cost is hidden in a first call.
    """

    def __init__(self, gateway_id: str, region: str = None,
                 protocol_version: str = None, url: str = None,
                 session: boto3.Session = None):
        self.gateway_id = gateway_id
        self.region = region or config.REGION
        self.protocol_version = protocol_version or config.MCP_PROTOCOL_VERSION
        self.url = url or config.gateway_url(gateway_id, self.region)
        self._session = session or boto3.Session()
        self._http = requests.Session()
        self._id = 0

    # ------------------------------------------------------------- internals

    def _next_id(self) -> int:
        self._id += 1
        return self._id

    def _signed_headers(self, body: str, protocol_version: str,
                        extra: Dict[str, str] = None) -> Dict[str, str]:
        """SigV4-sign the body and return headers ready for requests.

        Signing happens over an AWSRequest that mirrors the real POST exactly.
        Any header added *after* signing that the service includes in the signed
        set would break the signature, so `extra` is folded in before signing.
        """
        headers = {
            'Content-Type': 'application/json',
            # Gateways may stream; accepting both keeps non-streaming replies
            # from being rejected by content negotiation.
            'Accept': 'application/json, text/event-stream',
            'MCP-Protocol-Version': protocol_version,
        }
        if extra:
            headers.update(extra)

        request = AWSRequest(method='POST', url=self.url, data=body,
                             headers=headers)
        credentials = self._session.get_credentials().get_frozen_credentials()
        SigV4Auth(credentials, config.MCP_SERVICE, self.region).add_auth(request)
        return dict(request.headers)

    def raw(self, payload: Dict[str, Any], protocol_version: str = None,
            extra_headers: Dict[str, str] = None,
            timeout: int = 120) -> Tuple[int, str, float]:
        """Send an arbitrary payload. Returns (http_status, body, latency_ms).

        Exposed because several checks care about the HTTP status and the error
        envelope rather than a successful result - probing an unsupported
        protocol version, for instance.
        """
        body = json.dumps(payload)
        pv = protocol_version or self.protocol_version
        headers = self._signed_headers(body, pv, extra_headers)

        started = time.time()
        response = self._http.post(self.url, data=body, headers=headers,
                                   timeout=timeout)
        latency_ms = (time.time() - started) * 1000
        return response.status_code, response.text, latency_ms

    def call(self, method: str, params: Dict[str, Any] = None,
             protocol_version: str = None, timeout: int = 120,
             negotiate: bool = True) -> Dict[str, Any]:
        """Invoke a JSON-RPC method and return `result`, raising on error.

        The returned dict carries a `_latency_ms` key so callers can report
        per-call timing without a second measurement path.

        `negotiate` handles a trap worth naming: the set of MCP versions a
        gateway accepts is **per-gateway configuration**, not an account or
        service constant. A gateway created without an explicit
        `protocolConfiguration.mcp.supportedVersions` accepts only `2025-03-26`,
        while a gateway that has been updated may accept `2025-11-25` and
        `2026-07-28` and reject `2025-03-26`. So a client with one hard-coded
        version works against some gateways in an account and not others. When
        the gateway rejects a version it helpfully enumerates what it does
        accept, so one retry is enough.
        """
        payload: Dict[str, Any] = {
            'jsonrpc': '2.0', 'id': self._next_id(), 'method': method}
        if params is not None:
            payload['params'] = params

        attempted = protocol_version or self.protocol_version
        status, text, latency_ms = self.raw(
            payload, protocol_version=attempted, timeout=timeout)

        try:
            envelope = json.loads(text) if text else {}
        except json.JSONDecodeError:
            raise McpError(-1, f"non-JSON response (HTTP {status}): {text[:200]}")

        if 'error' in envelope:
            err = envelope['error']
            supported = (err.get('data') or {}).get('supported') or []
            if negotiate and supported and 'protocol version' in err.get('message', ''):
                # Intersect with what this client implements, newest first.
                # Picking the gateway's newest unconditionally selects
                # 2026-07-28 on updated gateways, which then rejects every
                # request for a missing `_meta` envelope - a failure that looks
                # like a broken gateway rather than a client limitation.
                mutual = sorted(set(supported) & set(CLIENT_SUPPORTED_VERSIONS))
                if not mutual:
                    raise McpError(
                        err.get('code', -1),
                        f"no mutually supported MCP version; gateway offers "
                        f"{sorted(supported)}, client implements "
                        f"{list(CLIENT_SUPPORTED_VERSIONS)}", err.get('data'))
                chosen = mutual[-1]
                self.protocol_version = chosen
                self.negotiated_from = attempted
                payload['id'] = self._next_id()
                status, text, latency_ms = self.raw(
                    payload, protocol_version=chosen, timeout=timeout)
                envelope = json.loads(text) if text else {}
                if 'error' in envelope:
                    err = envelope['error']
                    raise McpError(err.get('code', -1), err.get('message', ''),
                                   err.get('data'))
            else:
                raise McpError(err.get('code', -1), err.get('message', ''),
                               err.get('data'))

        result = envelope.get('result', {})
        if isinstance(result, dict):
            result['_latency_ms'] = latency_ms
        return result

    def supported_protocol_versions(self) -> list:
        """Ask the gateway what it accepts by offering something it cannot."""
        try:
            self.call('tools/list', protocol_version='1999-01-01',
                      negotiate=False)
            return []
        except McpError as e:
            return (e.data or {}).get('supported') or []

    # ------------------------------------------------------------ MCP surface

    def list_tools(self) -> Dict[str, Any]:
        return self.call('tools/list')

    def tool_names(self) -> list:
        return [t['name'] for t in self.list_tools().get('tools', [])]

    def call_tool(self, name: str, arguments: Dict[str, Any],
                  timeout: int = 120) -> Dict[str, Any]:
        """Invoke one tool.

        Failures arrive on two different channels and callers must handle both:

        * A failure *inside* the backend comes back as `result.isError=true`
          with HTTP 200, so inspecting `isError` is necessary.
        * A **policy denial is a JSON-RPC error**, code -32002 ("Tool Execution
          Denied"), and therefore raises `McpError` here. Measured 2026-10-06;
          an earlier version of this docstring claimed denials arrived as
          `isError`, which made the enforcement check report an exception
          instead of the successful block it had actually observed. The error
          message names the policy that denied, which is what makes it
          debuggable.
        """
        return self.call('tools/call',
                         {'name': name, 'arguments': arguments},
                         timeout=timeout)

    @staticmethod
    def tool_text(result: Dict[str, Any]) -> str:
        """Flatten the content blocks of a tools/call result to text."""
        parts = []
        for block in result.get('content', []) or []:
            if block.get('type') == 'text':
                parts.append(block.get('text', ''))
        return '\n'.join(parts)

    @staticmethod
    def is_tool_error(result: Dict[str, Any]) -> bool:
        return bool(result.get('isError'))
