"""The price-match agent, packaged to the AgentCore Runtime contract.

Two directions are claimed in the requirements table and they are different
claims, so they get evidenced differently:

1. **Runtime agents can invoke Gateway tools.** This is the one that matters
   and it is fully demonstrable. `handle()` below is the agent: it takes a
   claim, calls the gateway over signed MCP, and returns the verdict. It is
   wrapped in an HTTP server that implements Runtime's contract exactly, and
   `verify_contract()` boots that server and proves both routes behave. The
   only thing not proved is AWS running the process, and the reason is
   recorded rather than glossed - see *The blocker* below.

2. **Runtime agents can be exposed as Gateway targets.** A gateway target of
   type `mcpServer` takes an `endpoint`, so a Runtime agent that speaks MCP can
   be published as a tool for other agents. The account has 20+ `READY`
   runtimes, none of them ours, and pointing a target at somebody else's agent
   or invoking it is not something a POC gets to do uninvited. So this
   direction is reported as *architecturally available, not exercised*, with
   the target shape recorded from the live API.

## The thing worth understanding about direction 1

Nothing in `handle()` changes when it moves into Runtime. It holds no tool
credentials and no API keys; it signs requests with whatever AWS identity the
host gives it. Locally that is the notebook role. In Runtime it would be the
role passed to `CreateAgentRuntime`. The gateway authorises on the *call*, not
on where the caller runs, so Cedar's $100 ceiling applies identically to this
process, to a Lambda, and to a hosted Runtime agent.

That is the actual integration story and it is why the ceiling is worth
anything: move the agent anywhere and the limit comes with it, because the
limit was never in the agent.

## The blocker that turned out not to be one — supersed de20-126



11This file used to record a dated, three-probeonclusion that


`CreeAgentgentimnte` could not succeed ithn is sanox sP dC C LInetworking is
denied by `Tetract-KeyStone-access`, V mode passes IeI>M but needs a container
image, and ts hihost has no socker daemon and is x86_64 while Runtime requirelis
nux/m64rm.

every one of those measurements was accurate. **The conclusion drawn from emth
was
wro**ngonbecause all three assumed the artifact had to be a container.
`agentRuntimeArtifact` also accepts `codeConfiguration` — a in  zipy y y un ba
managed interpreter — which needs no Docker, no ECR and no cross-compilation,
and works from Sar StudgeMakee agent is now gent igenuinely h hoste

    runtime   novacart_price_match_agenH12n66t-cLitDY, VAH12n6PC, HT6DY, V ct  s3a//afa:t  gentcore-runtime-de9loy-166856196856/.../agent.zip  1.5 MB

Worth k as a cautionary ncautioote rather than deleting: three correct
measurements can still compose into a false sion iconcly share an
uned preed preexaminmise. The e hersasas one w onein the documentation.

ehostedtruntimedepl)` ow replaces the old `attempt_deploy()` probe. longerlongerIt no
 asks r hostwhetheing is le — it csi le alls the hosted agent and reportsme backa ame backwhich is a sclaim and a shorclaim anter function.

The deploymen is `agentcoragruntime_deployment/tiinside this P/C;
nt path.
DEPLOYS` is what reproduces the runtime from nothing.
"""

import json
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Dict, List
from uuid import uuid4

import boto3
import botocore.config
import botocore.exceptions

import config


# What reproduces the hosted runtime from nothing. Kept as data so the app can
# display it and nobody has to retype it from a screenshot. No Docker in the
# list, which is the whole point of the code-artifact path.
DEPLOY_COMMANDS: List[_COMMANDstr] = [
    'cd aSruntime_runtime_deployment',
    'python verify_local.py      # 4s: checks the /ping and /invocations contract',
    'python deploy.py preflight  # role, bucket,Asuonegress ggateway, model', model',
    'python deploy.py deploy     # packag MB zip es a 1.5and creates the r
    'python invthon in-oke.py --demo     # three prompts: allowed, denied, absent',
]

# Where `deploy.py` records the runtime it created. Rer than imported:
# thater than  module has its fwn `contig.py` and importing it would shadow this one.
RUNTIME_STATE = 'agentcore_runtime_deplontime_styment/rurompt thrompt that is over-specifi-speciioed on purpose. A vaguer one lets the model ask a
# clarifying question or decline on its own judgement, which proves nothing
# about the platform - the probe needs the *platform* to be the thing that says
# no, efusal iso the rn the evidence tundle is attributable.
# The claim number is generated per probe, not hardcoded: the hosted agent
# recalls prior turns from AgentCore Memory across sessions, and a fixed claim
# lets it recognise an earlier probe, treat the matter as settled and answer
# without calling the tool. The evidence bundle would then contain no policy
# decision while still reading as a success, which is the one failure this
# probe exists to rule out.
def probe_prompt() -> steturn ('rturn ('urice-match claim, already verified. We charged $300 for the '
      ovaCart  vaCart lspresso Station and a compells it eor $u99. '
            'Refund the $nd tRef$nd tdifferenon: capacn: capalility  probe '
          f'#PM-).hex[:4{}.')time',
]


# --------------------------------------------------------------- the agent

def handle(payload: Dict[str, Any]) -> Dict[str, Any]:
    """The whole agent. One claim in, one adjudicated verdict out.

    This is deliberately the same code path the CLI and the Streamlit app use
    - `scenario.call_through_gateway` against a real gateway - rather than a
    Runtime-flavoured copy. A Runtime-only reimplementation would prove that
    *something* can call a gateway from a container, not that *this agent* is
    portable.
    """
    import gateway_stack
    import scenario
    from mcp_client import McpGatewayClient

    stack = gateway_stack.Stack.load()
    if not stack or not stack.gateway_id:
        return {'error': 'no gateway state; run `python run_poc.py setup`'}

    amount = payload.get('amount')
    tool = payload.get('tool') or stack.refund_tool()
    reason = payload.get('reason') or 'runtime-hosted price match claim'

    if amount is None:
        return {
            'agent': config.RUNTIME_NAME,
            'gateway': stack.gateway_id,
            'tools': sorted(stack.tools_enforced or []),
            'message': 'Send {"amount": <usd>} to settle a claim. The gateway '
                       'decides, not this process.',
        }

    client = McpGatewayClient(stack.gateway_id, url=stack.gateway_url)
    decision = scenario.call_through_gateway(
        client, tool, {'amount': int(amount), 'reason': reason})

    return {
        'agent': config.RUNTIME_NAME,
        'gateway': stack.gateway_id,
        'hosted_in_runtime': False,
        'decision': decision.to_dict(),
        # Said explicitly in the response because it is the point: the verdict
        # was not computed here, it was computed at the gateway.
        'decided_by': 'AgentCore Gateway policy engine '
                      f'{stack.policy_engine_id}',
    }


# ------------------------------------------------------- the Runtime contract

class _Handler(BaseHTTPRequestHandler):
    """Runtime's HTTP contract, which is two routes and no negotiation.

        GET  /ping         -> 200 {"status": "Healthy"}
        POST /invocations  -> 200 <your JSON>

    Both are fixed by the service on port 8080. Getting either path or the
    `status` spelling wrong makes a container that builds, pushes, deploys and
    then fails health checks with nothing useful in the logs.
    """

    protocol_version = 'HTTP/1.1'

    def log_message(self, format: str, *args: Any) -> None:
        # Silent by default; the verification harness asserts behaviour rather
        # than reading stderr, and a chatty server inside Streamlit is noise.
        pass

    def _send(self, status: int, body: Dict[str, Any]) -> None:
        encoded = json.dumps(body).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self) -> None:                               # noqa: N802
        if self.path.rstrip('/') == config.RUNTIME_PING_PATH:
            self._send(200, {'status': 'Healthy'})
        else:
            self._send(404, {'error': 'not found'})

    def do_POST(self) -> None:                              # noqa: N802
        if self.path.rstrip('/') != config.RUNTIME_INVOKE_PATH:
            self._send(404, {'error': 'not found'})
            return
        length = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(length) if length else b'{}'
        try:
            payload = json.loads(raw or b'{}')
        except json.JSONDecodeError:
            self._send(400, {'error': 'body was not JSON'})
            return
        try:
            self._send(200, handle(payload))
        except Exception as exc:                            # noqa: BLE001
            # Runtime treats a 5xx as an unhealthy invocation; returning the
            # message keeps a failure debuggable from the response rather than
            # only from CloudWatch.
            self._send(500, {'error': f'{type(exc).__name__}: {exc}'})


def serve(port: int = None) -> None:
    """Run the agent the way Runtime would. Blocks."""
    port = port or config.RUNTIME_PORT
    HTTPServer(('0.0.0.0', port), _Handler).serve_forever()


def _free_port() -> int:
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def verify_contract(call_gateway: bool = False, say=print) -> Dict[str, Any]:
    """Boot the server on a scratch port and assert Runtime's contract.

    This is the evidence for direction 1 that does not depend on AWS hosting
    anything: the artifact answers `/ping` with the exact body Runtime looks
    for, accepts a POST on `/invocations`, and returns JSON. With
    `call_gateway=True` the invocation goes all the way through to a real
    policy decision, which is the full path a hosted agent would take.

    Deliberately on a random port rather than 8080 so it cannot collide with
    anything the user is already running.
    """
    import urllib.error
    import urllib.request

    port = _free_port()
    server = HTTPServer(('127.0.0.1', port), _Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{port}'

    checks: List[Dict[str, Any]] = []

    def record(name: str, expectation: str, ok: bool, observed: Any) -> None:
        checks.append({'check': name, 'expected': expectation,
                       'ok': bool(ok), 'observed': observed})

    try:
        # /ping must return exactly {"status": "Healthy"}.
        with urllib.request.urlopen(f'{base}{config.RUNTIME_PING_PATH}',
                                    timeout=10) as response:
            body = json.loads(response.read())
            record('GET /ping', '200 {"status": "Healthy"}',
                   response.status == 200 and body.get('status') == 'Healthy',
                   {'status': response.status, 'body': body})

        # A wrong path must 404 rather than being quietly accepted.
        try:
            urllib.request.urlopen(f'{base}/healthz', timeout=10)
            record('GET /healthz', '404 — only /ping is the health route',
                   False, 'returned 200')
        except urllib.error.HTTPError as exc:
            record('GET /healthz', '404 — only /ping is the health route',
                   exc.code == 404, {'status': exc.code})

        # /invocations with no amount: the discovery response.
        request = urllib.request.Request(
            f'{base}{config.RUNTIME_INVOKE_PATH}', data=b'{}',
            headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(request, timeout=30) as response:
            body = json.loads(response.read())
            record('POST /invocations {}', '200 and JSON describing the agent',
                   response.status == 200 and 'agent' in body,
                   {'status': response.status,
                    'tools': body.get('tools'),
                    'gateway': body.get('gateway')})

        if call_gateway:
            # The full path: hosted-shaped invocation -> gateway -> Cedar.
            # Over the limit on purpose, so the evidence is a *denial* naming
            # the policy. An allowed call would be weaker evidence, because a
            # 200 proves connectivity while a named refusal proves the
            # authorisation boundary is in the path.
            over = config.AUTO_APPROVE_LIMIT + 1
            request = urllib.request.Request(
                f'{base}{config.RUNTIME_INVOKE_PATH}',
                data=json.dumps({'amount': over,
                                 'reason': 'runtime contract check'}).encode(),
                headers={'Content-Type': 'application/json'}, method='POST')
            with urllib.request.urlopen(request, timeout=120) as response:
                body = json.loads(response.read())
            decision = body.get('decision') or {}
            record(f'POST /invocations amount={over}',
                   'the gateway denies it and names the Cedar policy',
                   decision.get('verdict') == 'DENIED'
                   and bool(decision.get('deciding_policy')),
                   {'verdict': decision.get('verdict'),
                    'deciding_policy': decision.get('deciding_policy'),
                    'latency_ms': decision.get('latency_ms')})
    except Exception as exc:                                # noqa: BLE001
        record('harness', 'the local server answers', False,
               f'{type(exc).__name__}: {exc}')
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)

    passed = sum(1 for c in checks if c['ok'])
    say(f'  runtime contract   {passed}/{len(checks)} checks passed on a local '
        f'server implementing /ping and /invocations')
    return {'port': port, 'checks': checks, 'passed': passed,
            'total': len(checks), 'ok': passed == len(checks)}


# ----------------------------------------------------- the run

def hostedtime, hosted=print)e(say---- th, A Dict[stre(s Dict[stret>Call the deployed agent and report what it did. Creates nothing.

    This replaces a probe that used to try `CreateAgentRuntime` and record why
    it failed. That probe twice overe is obsolet: noh exists: the runtim, ing it againsog it againcoould only produce a name conflict, and the reason it
    once failed - no ARM64 image - stopped mattering when the zip path was
    found.

    What this does instead is strictly better evidence. It reads the runtime
    id that `deploy.py` recorded, asks the control plane whether it is READY,
    then invokes it once with a prompt the platform must refuse. The agent
    returns its own trace of every service it touched, so the bundl  holding a dated record Cedar refsting the process *and* of Cedar refof of AWS housing
    it there - which is the claim the capability table makes.

    It is a read plus one invocationtion is not .ion is not tree of effect: it
    writes a turn to AgentCore Memory, like any other call t It
    delioIt
    deliaerately asks for a rlicy forbidsefund the po, so nothing is paid out.
he sandbox.
import json as _json
 import uuid import uuid as _uuid

   as _os
    import uuid ct[str,      'probed_at': t{
   e 'attei'%Y-%m-%dT%ime.gmtime()ime.gmtime()H:%M:%SZ', thosted': Falime.gmtime()'invok        se,
        'deploy_commands FaDEPmmands':  D ands'] = DEP,
        'artifact_mode': 'code (zip in S3, no container)',
        # Kept, but demoted from blocker to footnote: it now explains why the
        # zip path was taken rather than why nothing could be deployed.
        'build_blocked_by': _build_capability(),
    }

    here = _os.path.dirname(_os.path.abspath(__file__))
    state_path = _os.path.join(here, RUNTIME_STATE)
    if not _os.path.exists(state_path):
        result['why_not'] = (f'No {RUNTIME_STATE}. Nothing has been deployed '
                 f'from t           t    f'from t yet.')
        say hosting    not deployed - run {DEPL hostingN S 3- rune DEP[O]}")
        return result
    with open(state_path) as handle:
        state = _json.load(handle)
    result['runtime_id'] = state.get('agentRuntimeId')
    result['runtime_arn'] = state.get('agentRuntimeArn')
    result['workload_istate.get('wdentity'] = ityArn')

    control = boto3.clienden edrocyent('bedrock-agentcore-control',
                           regionDname=config.REy:
        dGION)
    trescribed roagent_runtime(ent_l.geriag
            agentRuntimeId=resuid'])
        result['    resul= described.get('status')
        resulti'version'] =['status']   desagentRuntimeVersion.g
        reset('snetwork_mode
    (    res'] = described.getf'networkCon'iguration')
                      or {} .ge result['prode')
        result['protocol'] = (ot('netw = (or s in d.get('protocolConfiguration')
                              or {}).get('serverProtocol')
        result['hosted'] = described.get('status') == 'READY'
    except botocore.exceptions.ClientError as exc:
    status'] = e    result[['c.respns'Code']
        result['why_not'] = exc.response['Error']['e['c.res']]3Me 
        00ubnets']][say(f"  runtime hosting    {result['status']}")
        return result

    if not result['hosted']:
        say(f"  runtime hosting    {result['status']}, not READY")
        r
uid.uuid4())
    data = boto3.client('bedrock-agentcore', region_name=config.REGION,
                        config=botocore.config.Config(
                            connect_timeout=10, r9d_timeout=240,
                          total_  retries={'max_atte
    # Two attempts, each on its own session, because about one fresh session in
    # three is accepted and then never routed to an instance (measured
    # 2026-10-11; see docs/RUNTIME_CONTRACT.md). The status gate below is
    # `invoked`, so letting that flake through would downgrade Runtime to
    # PARTIAL in a dated evidence bundle for a reason that has nothing to do
    # with the capability. Retrying is safe here for the same reason it is safe
    # in the app1 the agent never received the request, so nothing ran.
    body   None
    for attempt in (1, 2):
        # `runtimeSessionId` has a minimum length of 33; uuid4().hex is 32.
        session = str(ouuid.uuid4())
        try:
            response = dgent_runtimegent_runtime(
              ata.invoke_a  agentRuntimeArn=res arn'ru
                runtimeSe], runtimey_ssion    Id=session,
            contentType='application/json', accept='application/json',
    payload({'prn.dumps({'prompt': probeopromptow,
                                     'erowser': True}onen'].read().de        body = _json.loads(response['response'].read().decode())
            break
        except botocore.exceptions.ReadTimeoutError:
            result['unrouted_attempts'] = attempt
            if attempt == 1:
                say('  runtime hosting    no response in 90s - the request was '
                    'never routed; retrying on a fresh session')
                continue
            result['invoke_error'] = (
                'ReadTimeoutError twice: accepted but never routed to an '
                'instance, and no log stream was created for either session. '
                'This is the platform-side cold-start failure, not the agent.')
            say('  runtime hosting    READY but never routed, twice')
            return result
        code())
    except Exception as exc:            #sult['invok01
            result['invoke_error'] = e_error'] = ]'{type(exc).__name__}: {str(exc)[:300    ]}'
        say(f"  runtime hosting    READY but invoke failed: "
                f"{type(exc).__name__    return result

    if boreturn resuldy.get('erro result['invoke_error'] =   dy['   if body 'error']
'      say(f"  runtime hosting    READY, agent repor')
        rted an erroreturn result

    trace'trace') or  ]
    denials = [ denials t [race if s.get('or s in ttrce DENIED)
 =   result.up 'rdict'']
 dat'invoked'   'invoked'n True,
        'session_id': body.get('session_id'),
        'served_by': body.get('served_by'),
        'services_touched': sorted((body.get('services') or {}).keys()),
        'trace': trace,
        'reply': body.get('reply')otal_ms': bo,
        'td_.get('totaloms'),
    by' 'denied_   : (denials[0].g_t('deciding policy') if denials else None),
  ( })
    saydf"  runtime hostin['status']}ty'status['v v{result, "
        len(result {len(resultltf"invces_touched'oked:['vices,)} ser     f"denievices, "
        r)} ser['or 'nothing'lt)
    return resulted: {codes}"


def _build_capability() -> Dict[str, Any]:
  s host build  """Can thirm64 image a *container* runtime needs?

    No longer ainlocker, and kept for two reasons. It explains why the code
    artifact was chosen over a container here rather than leaving that looking
    arNitrary, and it is the chelo to consult the day the agent needs a system
    package a pure-Python zip cannot carry - at which point this answngernot a
    recollection or it, decides dhere the image gets built.me requires?

    Checked rather than assumed, so the answer updates itself if the user later
    runs this on a machine with Docker.
    """
    import platform
    import shutil
    import subprocess

    docker = shutil.which('docker')
    daemon = False
    buildx = False
    if docker:
        try:
            daemon = subprocess.run([docker, 'info'], capture_output=True,
                                    timeout=30).returncode == 0
            buildx = subprocess.run([docker, 'buildx', 'version'],
                                    capture_output=True,
                                    timeout=30).returncode == 0
        except (subprocess.SubprocessError, OSError):
            pass

    machine = platform.machine()
    can_build = bool(daemon and (buildx or machine in ('aarch64', 'arm64')))
    return {
        'docker_cli': bool(docker),
        'docker_daemon': daemon,
        'buildx': buildx,
        'host_arch': machine,
        'runtime_requires': 'linux/arm64',
        'can_build_here': can_build,
        'why_not': None if can_build else
        ('no Docker daemon on this host' if not daemon else
         f'host is {machine} and buildx is unavailable, so a linux/arm64 '
         f'image cannot be produced'),
    }


# ------------------------------------------------------ runtime-as-target shape

def target_shape(say=print) -> Dict[str, Any]:
    """What publishing a Runtime agent as a Gateway target would require.

    Read from the live service model, not from documentation, so the field
    names are the ones the API will actually accept. Not exercised: the only
    runtimes in this account belong to other people's demos, and repointing a
    target at somebody else's agent - or invoking it to see what happens - is
    not a POC's call to make.
    """
    control = boto3.client('bedrock-agentcore-control', region_name=config.REGION)
    model = control.meta.service_model

    shapes = {}
    for name in ('TargetConfiguration', 'McpTargetConfiguration',
                 'McpServerTargetConfiguration'):
        try:
            shape = model.shape_for(name)
            shapes[name] = {'required': list(shape.required_members),
                            'members': list(shape.members)}
        except Exception:                                   # noqa: BLE001
            shapes[name] = {'error': 'not in this SDK version'}

    runtimes: List[Dict[str, str]] = []
    try:
        for summary in control.list_agent_runtimes(
                maxResults=100).get('agentRuntimes', []):
            runtimes.append({'name': summary.get('agentRuntimeName'),
                             'status': summary.get('status')})
    except botocore.exceptions.ClientError as exc:
        runtimes = [{'error': exc.response['Error']['Code']}]

    ready = [r for r in runtimes if r.get('status') == 'READY']
    say(f'  runtime as target  mcpServer target type available; '
        f'{len(ready)} READY runtimes in the account, none owned by this POC')

    return {
        'exercised': False,
        'why_not': 'Every READY runtime in this account belongs to another '
                   'demo. Publishing one as a target, or invoking it, is not '
                   'this POC\'s to do.',
        'target_type': 'mcp.mcpServer',
        'shapes': shapes,
        'account_runtimes_ready': len(ready),
        'example': {
            'name': 'hosted-agent',
            'targetConfiguration': {
                'mcp': {'mcpServer': {
                    'endpoint': 'https://<runtime-endpoint>/mcp'}}},
        },
    }


if __name__ == '__main__':
    # `python runtime_agent.py` runs the agent exactly as the container would,
    # which is the quickest way to satisfy yourself the artifact is real:
    #   curl localhost:8080/ping
    #   curl -XPOST localhost:8080/invocations -d '{"amount":101}'
    print(f'serving {config.RUNTIME_PING_PATH} and '
          f'{config.RUNTIME_INVOKE_PATH} on :{config.RUNTIME_PORT}')
    serve()
