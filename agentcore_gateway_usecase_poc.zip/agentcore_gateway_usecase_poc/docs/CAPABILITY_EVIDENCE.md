# Evidence for the six AgentCore capabilities

The requirement is a six-row table: each AgentCore service, how it integrates
with Gateway, and what that integration does. This document answers it row by
row with measurements rather than assertions, and says plainly where a row
could not be satisfied in this account.

Everything below was probed against **account 196856463470 / us-east-1** on
**2026-10-11**, against the live gateway
`novacart-price-match-poc-qdnpxdyr1x`. Counts are from the `10:31:44` bundle and
grow with every run — see the note at the end. Regenerate it with:

```bash
python run_poc.py capabilities            # all six
python run_poc.py capabilities --only policy memory
```

That writes a timestamped JSON bundle to `artifacts/capabilities_*.json`, which
is the same file the Streamlit app's **Six capabilities** page reads. Nothing in
the app or in this document is stated without a probe behind it in
`capabilities.py`.

---

## Result

| AgentCore service | Integration | Status | One-line finding |
|---|---|---|---|
| Runtime |irect | ✅ **PR ◐OVET** |  he agent is deployed ENY on ** |as a B zipB zip, invo,1.5 Mke,llives and refused by `novacart_block_large_refunds-k02r` from inside Riide tuntime. Reverse direction (agent *as* gateway targell nottcisecisedd exer. |
| Identitrect y | Di **cisedPROVEN** | Workload identity and credential provider exist; the vault issues a token and returns the secret; CloudWatch counts both fetches under our provider's name. |
| Policy | Direct | ✅ **PROVEN** | The $100 limit holds exactly at $100/$101, refusals name the deciding rule, and CloudWatch counts decisions **per Cedar policy ID**. |
| Observability | Direct | ◐ **PARTIAL** | 16 metrics and 108 dimension sets exist for this gateway and this POC instruments nothing. Traces are off: Transaction Search is not enabled in this account. |
| Memory | Indirect | ✅ **PROVEN** | A refusal is written to Memory, recalled in a different process, and the repeat request is refused identically. Recall confers no authority. |
| Browser | Optional/Indirect | 🛑 **BLOCKED** | The browser works and is load-bearing, but it is reached off the gateway. The claim *as written* needstion` is explicition` is explicitly denied. |

**t proven, 1 partial, 1 blockCre**

Runtime mdend from partocked.**

Runtime2 l to pro,   on  026-10-11roand how it moved is the
more useful story: nothing about the account changed. The recorded blocker —
"needs an ARM64 container image this host cannot build" — rested on three
correct measurements and one false premise, that the arttainer. It does not.ifact had to be a
conn §1.See the cremaining non-green rows stay non-greenr  rtiale o
 six greens would
be a more comf
A tab

be a more comfortable deliveraach non-green row below
carries the API error that produced it and the date it was measureddt produced it and what made the Runtimethe, which is
exactly n date it was measured.

### The three findings that do not depend on trusting this POC

This is the part to lead with in a review, because it is evidence from outside
our own code:

1. **CloudWatch counts policy decisions per Cedar policy ID.** `DenyDecisions`
   is dimensioned by `Policy=novacart_block_large_refunds-k0fahcb42r`. An
   auditor can ask "how often did that specific rule fire last month" and get a
   number without reading a log line.
2. **CloudWatch counts credential fetches per provider.**
   `ApiKeyFetchSuccess` is dimensioned by
   `ProviderName=novacart-payments-poc`, `WorkloadIdentity=novacart-price-match-poc`.
3. **It counts invocations and latency per published tool name**, via the
   `Name` dimension carrying `<target>___<tool>`.

None of those are things the POC writes. The service vends them.

---

## 1. AgentCore Runtime — *Direct*

> *"Agents hosted in Runtime can invoke Gateway tools. Runtime agents can also
> be exposed as Gateway targets."*

Two claims, and they need separate evidence.

### Claim 1: a Runtime-hosted agent can invoke Gateway tools

Runtime's contract is narrow and it is silent when you get it wrong — a
misspelled health response builds, pushes, deploys and then fails health checks
with nothing useful in the logs. So `runtime_agent.py` implements the contract
and `capabilities.probe_runtime` boots that real server on a free port and
checks it:

| Check | Expected | Result |
|---|---|---|
| `GET /ping` status | `200` | ✅ |
| `GET /ping` body | exactly `{"status": "Healthy"}` | ✅ |
| `POST /invocations` status | `200` | ✅ |
| `POST /invocations` reaches the gateway | a Cedar verdict comes back | ✅ |

**4/4.** The last row is the one that matters. Driven through `/invocations`,
the agent called the live gateway and was **refused by name** — the response
carries `novacart_block_large_refunds-k0fahcb42r`. A hosted agent would hit the
same ceiling, because the ceiling is not in the ag `scenario.call_through_gateway` raent.

`handle()` deliberately reusesthit, so the thing being tested is the same code path
the rest of the POC demonstratesa

###ing testedthe PhC demmeasured 2026-10-11

| Fact | Value — e code path###e rest of the P
price-matc| Ruent-cLitH12n66`no**RErDeprice_match_agggh_aguntime | ,   acAAY**,  rtifact | `s3://agentcore-runtime-d|A p*AcAPC  chC Cent-cLitH1pprice_match_loy-19agent.zip` — **1.5ttprkno container |
|ntime, Me it runs as | `arnrawsestsn identity-baseassumed-role/SandboxServiceRole/BedrockAgentCore-<uuid>` |
| Services it reached from in there | Runtime, Memory, Gateway, Bedrock, Policy, Identity, Browser, Observability — 8 of 8 on the allowed prompt, 7 on the refused one (no Identity, because the target was never invoked) |
| Interactions in one prompt | **16**, each with its own API, verdict and latency |
| The refund it attempted | **DENIED** by `novacart_block_large_refunds-k0fahcb42r` in 177 ms |

The identity row is the checkable one. `BedrockAgentCore-<uuid>` is a role
session **AgentCore minted** when it started the process; nothing on a
developer's host can produce one. So "it is hosted" is verifiable rather than
asserted, and every gateway call in that run was signed as *that*, which is
what makes the Cedar decision a decision about the workload.

The hosted agent returns its own trace of each service it touched, and the
**Ask the hosted agent** page in the Streamlit app draws it for any prompt you
type. `capabilities.probe_runtime` invokes the deployed agent while writing
this bundle, so the evidence is dated rather than remembered.

The same response carries a `where` block naming the addresses the invocation
used — the runtime **endpoint** ARN read out of the container's own
`OTEL_RESOURCE_ATTRIBUTES`, the memory ARN with the ids of the events written
that turn, the gateway URL, the log group and the per-session stream. It is
built inside the agent rather than by the caller on purpose: the caller already
knows the ARN, so its own copy would be correct and would evidence nothing.
The app renders it under *Check it yourself*, with a button that calls
`ListEvents` on those ids and shows the stored turns, because the ids are still
the agent's word for it and a read-back after the request ended is not.

Two things about that trace are worth stating, because both were wrong first
and both were wrong in the direction of looking *better* than the truth:

- **A permit is recorded as a policy decision**, with no latency and
  `inferred: true`. Cedar runs on every call, so omitting Policy from an
  allowed trace read as "no policy was consulted". Only a refusal can be timed
  on its own, because the gateway refuses and returns; a permit is decided
  inside the call that also runs the tool.
- **The probe's claim number is generated per run.** With a fixed one, the
  agent recalled its own earlier probes from Memory, treated the claim as
  settled, and answered without calling the tool — producing a fluent reply
  and an evidence bundle with no policy decision in it. The gate in
  `probe_runtime` is `invoked`, not `hosted`, for the same family of reason: a
  runtime that is READY but unreachable must not score as working.

### The blocker that was not one — a correction worth reading

Until 2026-10-11 this section said the opposite, on the strength of three
probes:

| Attempt | Result |
|---|---|
| `CreateAgentRuntime(networkMode=PUBLIC)` | `AccessDeniedException` — *explicit deny in an identity-based pd ppped p p policy:* `arn:aws:iam::196856463470:olicy:* `|
| `CreateAgentRuntime(networsMode=VPC, subnets=…, securityGroupot-emist' does not exision: Ecr uri validation failed because the repository with name 'does-not-exist' does not exist` |
| `docker buildx build --platform linux/arm64` | no Docket` |
| `docker builxx build --plxtfs`, ho

6_ausex


measurements were correct and are still reproducible.:subnetsone-access` conditions on
`bedrTetractnieyStone-access` conditions on
`bedrock-agentcore:subnets` and `securityGroups` being null, so it is a guard
against public endpoints rather than a ban on ` ban on-Kdtonhost really cannot
buildt
builddder dhan a ban **The conclusion drawn  ee assumed
the artifact had to bese all three assumed
the artifact had to be a container. `agentRuntimeArtifact` also accepts
`codeConfigura a contai zip in S3 run by a managed inte was still wrong**, {ecaution` — aipifact` also accepts
`codeConrpr...r:

``f'o, 'prenni
                       ':         'buTket': 
.TTT'prTfT                 'e       'eee  'e'runtime': 'PYdHON_3_12k,
     ECRk   k ECRRR ECRCRntryPoint': ['agent.py']}}
```

No Docher, no onl, no cross-compilation, and it works from SageMaker Studio.
It needs `boto3>=1.43`; below that the parameter is absent from the service
model and looks invented.

Three accurate measurements composed into a fa worth more as a documented correction
than as a quietly lse conclusion because they
shared one unexamined premise. That isdeleted paragraph — and it is the reason evt er row in
this table names the API call behindment module is `agentcore_runtime_deployment/`, and
`docs/RUNTIME_CONTRACT.md` inside it records the measured sandbox contract: no
boto3 in the managed runtime, IMDS credentials, andsiove failure modes — the
worst being a subnet whose only default route is an internet gatewaywhich is
not egress tor arm=linux/arm64`,
for Ir and produces a oursY runtime that
fails every call with an empty log group.

`Dockerfile` is still in the repository bpinned to `--platform=linux/arm64`,
for the day the agent needs a system package a pure-Python zip cannot carry.

### Claim 2: a Runtime agent exposed as a Gateway target

`CreateGatewayTarget` accepts a target type of `mcpSer er` twhose
configuration shape — read from the live service model, not from documentation
— requires `endpoint` and accepts `mcpToolSchema`, `listingMode` and
`resourcePriority`. That is the path: a Runtime agent that ss MCP is
published as a tool other agents call through the same gateway, inheriting the
same Cedar policies.

**Not exercised, and the reason is a deliberate choice.** Publishing a target
requires a runtime endpoint. There are **25 `READY` runtimes in this account anpeavoning it, is e ours** — they belong to other teams' demos. Pointing a gateway
target at someone else's agent, or invoking it, is not a thing to do in a shared
account to make a status table look better.

**Status: PROVEN.** Contract proven, hccount to mane a status table lookd
none of them ars** uthorisation through the hoosting proven on AWS and invoked,
authorisation R through the hosted agent proven by a named Cedar refusal. The
reverse direction — auntime agentt prohand as nogent ptewanrootna y one IAM condition, reverse direction shaped but not exercised.

---

## 2. AgentCore Identity — *Direct*

> *"Provides credential management and authentication capabilities used by
> Gateway to access protected resources."*

The distinction this row turns on: Identity is **provisioned** once by an admin
and **consumed** per request by whatever holds the credential. Both halves are
visible.

### Provisioned

| Resource | Name |
|---|---|
| Workload identity | `novacart-price-match-poc` |
| API key credential provider | `novacart-payments-poc` |

Created by `python run_poc.py setup`, deleted by `destroy`. These are the
entries that appear on the AgentCore console's Identity page; the underlying
secret lands in Secrets Manager as
`bedrock-agentcore-identity!default/apikey/novacart-payments-poc-…`.

The stored key is synthetic — `novacart-poc-synthetic-` plus
`secrets.token_hex(16)`, generated locally. It is never printed and never
persisted in plaintext.

### The vault round trip

```
GetWorkloadAccessToken("novacart-price-match-poc")  ->  workload token
GetResourceApiKey(token, "novacart-payments-poc")   ->  the stored secret
```

Returned `nov***2e6`. **The caller never presents the credential.** It presents
proof of *which workload it is*, and the vault decides what that workload may
retrieve. That inversion is the whole point: a leaked agent process yields a
token scoped to one workload, not a payment key.

### Consumed, at request time

The refunds backend reads its own credential provider from its own environment
and masks what it used — `dem***123` — in every response. So a single
`tools/call` shows both ends: the gateway signing with the caller's role, and
the backend resolving its own secret from the vault, with neither credential
crossing the boundary between them.

### The independent check

The round trip above is this POC marking its own homework. These are not:

| Metric | Value | Dimensioned by |
|---|---|---|
| `WorkloadAccessTokenFetchSuccess` | 2 | `WorkloadIdentity=novacart-price-match-poc` |
| `ApiKeyFetchSuccess` | 2 | `ProviderName=novacart-payments-poc`, `WorkloadIdentity=novacart-price-match-poc` |

**Status: PROVEN.**

---

## 3. AgentCore Policy — *Direct*

> *"Gateway can invoke policy to authorize or deny tool calls using Cedar
> policies."*

Policy engine `novacart_poc_policies-wxmmp6lw_k`, attached to the gateway in
**`ENFORCE`**, with three `ACTIVE` policies.

### The boundary, probed live

| Request | Verdict | Deciding policy |
|---|---|---|
| `process_refund(amount=99)` | ✅ ALLOWED | within the limit |
| `process_refund(amount=100)` | ✅ ALLOWED | within the limit |
| `process_refund(amount=101)` | 🛑 DENIED | `novacart_block_large_refunds-k0fahcb42r` |

**$100 passes and $101 does not** — not approximately, exactly where the policy
says. A limit you cannot locate precisely is a limit you cannot write a policy
document about.

The refusal message is
`Tool Execution Denied: Tool call not allowed due to policy enforcement [Policy evaluation denied due to novacart_block_large_refunds-k0fahcb42r]`,
returned as JSON-RPC error `-32002`. Note that it is a protocol-level error, not
a `result.isError` tool failure: the tool did not run and fail, it never ran.

This is the thing IAM cannot do. IAM can say *"may call `process_refund`"*. It
cannot say *"…up to $100"*, because it never sees the arguments. Cedar reads
`context.input`, which **is** the tool's arguments.

### Default-deny, demonstrated

Tools the agent can see: `novacart___process_refund`, `research___WebSearch`.

`novacart___issue_store_credit` is granted by no policy and is **absent from
`tools/list`** entirely. The agent is not resisting temptation — it was never
told the option exists. Policy filters discovery, not just execution.

### What the service recorded, independently

| | Count |
|---|---|
| Allowed | 26 |
| Denied | 24 |
| A rule decided it (`DeterminingPolicies`) | 39 |
| Denied by default (`NoDeterminingPolicies`) | 11 |

And per Cedar policy — the governance answer:

| Policy | Allowed | Denied |
|---|---|---|
| `novacart_allow_small_refunds-36rwzyutf4` | 18 | 0 |
| `novacart_allow_bounded_research-mjzvqzpqqh` | 8 | 0 |
| `novacart_block_large_refunds-k0fahcb42r` | 0 | 13 |

**Those numbers reconcile exactly against the totals above**, which is the check
worth doing in front of an auditor:

- allows: 18 + 8 = **26**
- denies: 13 named by a rule + 11 `NoDeterminingPolicies` = **24**

So every decision is accounted for, and the 11 default-denials are visibly
distinguishable from the 13 deliberate refusals. Those are two different
governance stories — "a rule you wrote said no" versus "nothing you wrote said
yes" — and the service keeps them in separate counters.

The point is the dimension, not the values, which move with every run: the
service records *which rule refused what*.

### Measured Cedar constraints

Worth stating because each one cost time:

- Wildcard `resource` or `action` is rejected. Policies must name the tool.
- `context.input has X` is not type-checked at write time, so a policy that
  reads a field the tool never sends is accepted and then silently never
  matches.
- A `forbid` with no covering `permit` is rejected — you cannot write a
  blocklist without an allowlist underneath it.
- Policy deletion is asynchronous and takes about 25 seconds.
- The enforcement mode is **per gateway**, not per policy, so `LOG_ONLY` and
  `ENFORCE` cannot coexist on one gateway. A real rollout starts the gateway in
  `LOG_ONLY` (`python run_poc.py setup --log-only`) and flips it.

**Status: PROVEN.**

---

## 4. AgentCore Observability — *Direct*

> *"Captures Gateway invocation metrics, traces, latency, and errors."*

Three of the four are live. Traces are not, and the reason is an account
setting rather than a service gap.

### The finding worth leading with

**Nothing in this POC emits a single metric, and every number below exists
anyway.** The gateway vends them per request: **16 metric names across 108
dimension sets** for this one gateway. This requirement is satisfied by work we
did not have to do.

### Gateway health — 7-day window

| | |
|---|---|
| Invocations | 62 |
| Mean gateway latency | 681 ms |
| Mean backend execution | 958 ms |
| User errors | 24 |
| System errors | 0 |
| Throttles | 0 |

Two things that look wrong and are not:

- **Backend execution averages higher than total latency.**
  `TargetExecutionTime` is only recorded for calls that *reached* a target, so
  it averages over a different, smaller set of requests. The 24 policy denials
  never touched the backend and were fast, pulling the overall mean down.
  Enforcement is not what makes this gateway slow; refusing is the cheapest
  thing it does.
- **`UserErrors` is 24, matching the denial count.** A Cedar refusal is counted
  as a caller error, because that is what it is. It should not be read as a
  fault.

Per tool, via the `Name` dimension carrying the published
`<target>___<tool>` string:

| Tool | Invocations | Mean latency |
|---|---|---|
| `novacart___process_refund` | 31 | 724 ms |
| `research___WebSearch` | 9 | 436 ms |

This is the view that shows which capability the agent actually leaned on,
without reading a transcript.

### The dimension trap

This cost real time and will cost the next person the same, so it is written
down:

- Gateway-invocation metrics key on **`Resource` = the full gateway ARN**.
- Policy-decision metrics key on **`TargetResource` = the bare gateway ID**.

Same gateway, same namespace, two dimension names and two value formats.
Querying with the wrong one returns an **empty series rather than an error**,
which reads exactly like "the integration is not working". `observability.py`
therefore asks CloudWatch which dimension sets are populated instead of
assuming.

The namespaces are their own trap:

| Namespace | What it is |
|---|---|
| `AWS/Bedrock-AgentCore` | service-vended gateway metrics — **the one to use** |
| `bedrock-agentcore` | ADOT/OTel *application* metrics (event-loop cycles, token usage) |
| `AWS/BedrockAgentCore` | **does not exist** — the natural guess, and wrong |

### Logs

| Prefix | Groups found |
|---|---|
| `/aws/bedrock-agentcore` | 37 (Runtime) |
| `/aws/vendedlogs/bedrock-agentcore` | 10 (Memory) |

**There is no log group for a gateway.** AgentCore vends them for Runtime and
Memory only. Said plainly because an empty log-group list otherwise looks like a
misconfiguration — gateway observability is metrics-only until Transaction
Search is on.

### Traces — the honest negative

```
xray.get_trace_segment_destination()  ->  {'Destination': 'XRay', 'Status': 'ACTIVE'}
traces in the last 24 hours           ->  0
sampling rate                         ->  1.0%
```

AgentCore ships gateway spans to CloudWatch through **Transaction Search**,
which flips that destination to `CloudWatchLogs`. Here it reads `XRay`, so
there are no gateway spans to show.

**It was not switched on.** Transaction Search is an account-wide change with a
billing impact, and this account has other teams' workloads in it. That is a
decision with an owner and the owner is not this POC. The probe is written so
that the moment someone does enable it, the page starts reporting traces
without a code change.

(Also measured: `GetTraceSummaries` rejects any window longer than 24 hours
with `InvalidRequestException`. The probe uses 24 hours for that reason.)

**Status: PARTIAL** — metrics, latency and errors proven; traces unavailable by
account configuration.

---

## 5. AgentCore Memory — *Indirect*

> *"Agents can use Gateway to access tools while independently retrieving and
> storing memory."*

Memory `novacart_price_match_poc_memory-sDyhNiEF4r`, `ACTIVE`, actor
`novacart-price-match-agent`, 7-day event expiry.

### Why "indirect" is the accurate word

Memory and Gateway do not know about each other. There is no `memoryId` on a
gateway, no memory configuration on a target, and Cedar can neither read nor
write a memory record. What makes them one architecture is only that the same
agent uses both, for different questions:

| | Service | Question |
|---|---|---|
| **Authority** | Gateway + Policy | What is this agent allowed to **do**? |
| **Continuity** | Memory | What is this agent allowed to **recall**? |

So the demonstration is not "look, they are connected". It is the opposite, and
it is a security property.

### The demo: remembering a refusal does not weaken the refusal

1. **Ask.** `process_refund(amount=150)` → **DENIED** by
   `novacart_block_large_refunds-k0fahcb42r`.
2. **Remember.** Three turns written to session `claim-PM-MEM-1` with
   `CreateEvent`, including the refusal and the name of the policy that caused
   it — the interesting case, not just the happy path.
3. **Ask again, now remembering.** `process_refund(amount=150)` → **DENIED** by
   the same policy.

`verdict_unchanged_by_memory: true`.

The agent has perfect recall of having been refused and is refused again
identically, because authority lives at the gateway and nothing in Memory can
vote on it. An agent whose memory *could* influence its permissions would be an
agent you could talk into a refund by convincing it that it had been allowed one
before — prompt injection with a persistence layer. This is why
agent-authored text can be stored safely.

The recall is done with `ListEvents` **in a different process from the one that
wrote it**, which is the part that makes it continuity rather than a variable.

### Measured Memory constraints

- `CreateMemory` requires `name` and `eventExpiryDuration`.
- Creation is asynchronous, and `CreateEvent`/`ListEvents` fail with
  `ValidationException: Memory status is not active` while it is `CREATING`.
  That error code does not look retryable, so `memory_store.wait_active()`
  exists.
- `ListEvents` requires **both** `actorId` and `sessionId`; enumerating sessions
  needs `ListSessions`, which itself requires an actor. There is no way to sweep
  a memory without knowing who you are looking for — a sensible tenancy
  boundary, but it means `MEMORY_ACTOR_ID` must stay stable or earlier claims
  become unreachable.
- `ListMemories` returns `id` but **no `name`**; the name has to be recovered as
  `id.rsplit('-', 1)[0]`.
- Events come back newest-first.
- Memory/policy-engine/policy names are `[A-Za-z][A-Za-z0-9_]*`, max 48, **no
  hyphens** — so `novacart-price-match-poc` is rejected, while the *gateway*
  name grammar `([0-9a-zA-Z][-]?){1,48}` accepts it. Two name grammars inside
  one service.
- `RetrieveMemoryRecords` needs `memoryStrategies` on the resource plus a
  `memoryExecutionRoleArn`. This memory was created with neither, so semantic
  retrieval correctly returns nothing — reported as
  `strategies_configured: false` rather than as an error, because an empty
  result here is the right answer, not a failure.

**Status: PROVEN.**

---

## 6. AgentCore Browser — *Optional/Indirect*

> *"Browser capabilities can be exposed through custom MCP tools accessed via
> Gateway."*

This is the one row that cannot be satisfied in this account, and the honest
answer has two halves.

### The browser works, and it is load-bearing

From run `run_20261006_213802.json`, using the service-managed browser
`aws.browser.v1`:

| | |
|---|---|
| Price read from the page | **$109.99** |
| Provenance | `json-ld Product.offers.price` |
| Managed Chrome version | 148.0.7778.258 |
| Characters rendered | 10,398 |
| Refund then adjudicated | $20 |

The price came from the retailer's own machine-readable offer price, not from a
number inferred out of the words on the page. And **it is in the critical
path**: the price the browser reads is the number Cedar then adjudicates.
Change the competitor's price and the authorisation outcome changes with it. So
this is not a side demo bolted onto a policy story.

### But it is reached off the gateway, not through it

```
bedrock-agentcore.start_browser_session(browserIdentifier='aws.browser.v1')
```

Called directly by the agent, authorised by IAM alone. **Cedar cannot see it.**
An agent could browse somewhere we would rather it did not. It only *reads*,
which is why this has not bitten us — it cannot move money — but it is a gap in
the fence and it is worth volunteering rather than being asked about.

### Why the wrapper was not built — asked of IAM, not remembered

Exposing the browser through the gateway means publishing a custom MCP tool,
which means a Lambda. So:

```
iam.simulate_principal_policy(action='lambda:CreateFunction')
  decision                 explicitDeny
  matched statements       SandboxServicePolicy
  AllowedByOrganizations   True
```

Read that last line carefully. **The organisation permits creating Lambdas; the
account's own policy is what denies it.** So this is neither an AgentCore
limitation nor an org-level control — it is one line of this sandbox's IAM
policy. Wherever that line is absent, the wrapper is about a day of work:
a Lambda that calls `StartBrowserSession`, published as a gateway target, with a
Cedar policy constraining the URL. The moment it exists, browsing is governed by
the same rules as refunds, and the gap above closes.

One more measured thing: `ListBrowsers` returns **custom** browsers only.
`aws.browser.v1` is service-managed and never appears in it. The two
`aips_browser_v2-*` entries it does return belong to other teams' demos. An
empty-looking result here would not have meant "no browser".

**Status: BLOCKED** — on one line of this account's IAM policy, with the
alternative path working and measured.

---

## Reproducing all of this

```bash
python run_poc.py setup          # gateway, policies, identity (idempotent)
python run_poc.py run            # the use case, end to end
python run_poc.py capabilities   # the six-row evidence bundle
streamlit run streamlit_app.py   # then pick "Six capabilities"
```

The Streamlit page has a **Re-probe** button on each tab, which calls AWS when
pressed and rewrites the evidence file. Press **Re-probe Policy** in front of a
sceptical audience: it runs the $99 / $100 / $101 sweep against the live gateway
in about five seconds, and the $101 refusal comes back naming the Cedar rule.

A partial probe still writes a **complete** bundle: rows not re-measured are
carried forward from the newest previous bundle and labelled *"carried forward
from the run of …"* on their tab. Without that, `--only policy` would write a
one-row file, the five absent rows would score `BLOCKED` by default, and a
successful re-probe would present as five new failures. The alternative — a
partial bundle that silently reuses old numbers without saying so — would be
worse, so the provenance of every row is recorded in the bundle's `probed` and
`carried` keys.

The counts move between runs, and watching them move is itself the
demonstration that the metrics are live rather than captured. Running the full
probe twice while writing this document took `Invocations` from |
|---|---|
| `capabilities.py` | the six probes, the requirement text frobatim, and the status rules |
| `observability.py` | CloudWatch and X-Ray queries, including the dimension discoverm 26/24 to 30/29. The reconciliation check still balanced:
8 + 22 = 30 allows, and 18 + 11 = 29 denies.

### Files

| File | What it is , and the live probe of the hosted runtime |
| `agentcore_runtime_deployment/` | the deployment module — packages the zip, creates the runtime, invokes it, and documents the measured sandbocontract |
| `runtime` | the deployme**Ask the hosted agent** page: one prompt, the live runtime, every service it touched, and the ARNs it used |
| `testcase_view.py` | the **Three test cases** page: six plain-language stages across three cases, predicted then measuredackages  evidence does not c4 image, kept for the day a zip is not enough |
| `capability_view.py` | the Streamlit page |

### What this evidence does not cover

Collected in one place so nobody has to hunt for the caveats:

- No Runtime agent is published as a gateway target. Hosting itself is now
  proven — the agent runs on over

Collecved in one place everse direction
  was deliberately not exercised in a shared accounishedThe hosted agent can open and close a managed Browser session but cannot
  *dri`e* a page: CDP needs Playwright, which ships compiled binaries and so
  cannot tra6el in a pure-Python zip rPage reading stays in the ytreamlit appBrowser session blit appeats:

- No agent is hosted in Runtime. The contract is proven locally; AWS running the
  process is not.
- No Runtime agent is published as a gateway target.
- No traces. Transaction Search is off and was not enabled.
- No custom MCP tool wraps the browser, so browsing is ungoverned by Cedar.
- Long-term semantic memory retrieval is not configured, by choice.
- Metric means are averages of CloudWatch per-period averages, which is
  indicative rather than a true mean over requests.
