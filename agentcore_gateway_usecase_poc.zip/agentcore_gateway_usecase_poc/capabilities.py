"""The six AgentCore services, what each one needs from the gateway, and proof.

This module exists because a requirements table arrived with six rows in it and
"we support that" is not an answer. Each row below carries:

* the claim, **quoted from the requirement** rather than paraphrased, so nobody
  has to trust that it was faithfully restated;
* what this POC actually built for it;
* the live API calls that produce evidence;
* where to click in the Streamlit app to see it;
* and a verdict out of three: `PROVEN`, `PARTIAL` or `BLOCKED`.

`PARTIAL` and `BLOCKED` are load-bearing. Two of the six cannot be fully
demonstrated in this sandbox, and the measured reason is recorded next to each
with a timestamp. A table of six greens would be a more comfortable deliverable
and a worse one: the first person to try `CreateAgentRuntime` in this account
would find out in about ten seconds that one of them was a lie.

## What "evidence" means here

Running `python run_poc.py capabilities` calls AWS and writes
`artifacts/capabilities_<timestamp>.json`. Everything the app shows on the
**Six capabilities** page is read back from that file. Nothing on that page is
written in the app, so the app cannot claim something the probe did not
observe - the same constraint the rest of this POC already works under.

Three of the six are corroborated from *outside* the POC's own code, which is
the strongest evidence available and worth pointing at during a demo:

* **Policy** - CloudWatch counts `DenyDecisions` dimensioned by
  `Policy=novacart_block_large_refunds-k0fahcb42r`. The service, not this POC,
  is recording which Cedar rule refused what.
* **Identity** - `ApiKeyFetchSuccess` dimensioned by
  `ProviderName=novacart-payments-poc` counts vault retrievals independently of
  `identity.verify_round_trip()`.
* **Gateway** - `Invocations` and `Latency` per tool name, vended without this
  POC emitting a single metric.
"""

import datetime
import glob
import json
import os
from typing import Any, Dict, List, Optional

import boto3
import botocore.exceptions

import config

PROVEN = 'PROVEN'
PARTIAL = 'PARTIAL'
BLOCKED = 'BLOCKED'

STATUS_MEANING = {
    PROVEN: 'Demonstrated live in this account, with evidence recorded.',
    PARTIAL: 'The core claim is demonstrated; a named part of it is not.',
    BLOCKED: 'Cannot be demonstrated in this sandbox. The measured reason is '
             'recorded.',
}


# The requirement, verbatim in `claim`. Do not paraphrase these - they are the
# thing being checked against.
REQUIREMENTS: List[Dict[str, Any]] = [
    {
        'key': 'runtime',
        'service': 'AgentCore Runtime',
        'integration': 'Direct',
        'claim': 'Agents hosted in Runtime can invoke Gateway tools. Runtime '
                 'agents can also be exposed as Gateway targets.',
        'built': [
            '`runtime_agent.py` — the price-match agent behind Runtime\'s exact '
            'HTTP contract (`POST /invocations`, `GET /ping`, port 8080).',
            '`agentcore_runtime_deployment/` — the deployment module that '
            'packages that agent into a 1.5 MB zip and hosts it on AWS. No '
            'Docker: `codeConfiguration` runs a zip from S3.',
            'A local harness that boots the server and asserts the contract, '
            'then drives a claim through it to a real Cedar decision.',
            'A live invocation of the **deployed** agent, which returns its own '
            'trace of every AgentCore service it touched from in there, plus '
            'the `mcpServer` target shape for the reverse direction.',
        ],
        'evidence_calls': ['GetAgentRuntime', 'InvokeAgentRuntime (the hosted '
                           'agent, for real)',
                           'local HTTP against /ping and /invocations',
                           'tools/call through the live gateway',
                           'the hosted agent\'s own calls to Memory, Browser, '
                           'Bedrock and STS'],
        'demo': 'Ask the hosted agent, then Six capabilities → Runtime',
        'talking_point':
            'The agent holds no tool credentials and signs with whatever AWS '
            'identity its host hands it. We moved it from a notebook into '
            'Runtime and the $100 ceiling came with it unchanged — the hosted '
            'copy is refused by the same named rule, because the ceiling was '
            'never in the agent.',
    },
    {
        'key': 'identity',
        'service': 'AgentCore Identity',
        'integration': 'Direct',
        'claim': 'Provides credential management and authentication '
                 'capabilities used by Gateway to access protected resources.',
        'built': [
            'A workload identity and an API-key credential provider owned by '
            'this POC, created at `setup` and deleted at `destroy`.',
            'A vault round trip at provisioning time: `GetWorkloadAccessToken` '
            'then `GetResourceApiKey`, returning only a masked preview.',
            'The refunds backend behind the gateway fetching its own '
            'credential at request time — the agent never sees one.',
        ],
        'evidence_calls': ['GetWorkloadIdentity',
                           'GetApiKeyCredentialProvider',
                           'GetWorkloadAccessToken', 'GetResourceApiKey',
                           'CloudWatch ApiKeyFetchSuccess'],
        'demo': 'Six capabilities → Identity, and The gateway → Identity',
        'talking_point':
            'Two different things kept apart: provisioning a credential is an '
            'admin action that happens once from a terminal; consuming one '
            'happens per request inside the backend, after the gateway has '
            'authorised the call. The agent does neither.',
    },
    {
        'key': 'policy',
        'service': 'AgentCore Policy',
        'integration': 'Direct',
        'claim': 'Gateway can invoke policy to authorize or deny tool calls '
                 'using Cedar policies.',
        'built': [
            'A policy engine in `ENFORCE` with three Cedar policies attached '
            'to the gateway.',
            'A boundary sweep: $99 and $100 allowed, $101 refused, and the '
            'refusal names the rule.',
            '`tools/list` filtered by the same policies, so an ungranted tool '
            'is not merely refused — it is never offered.',
        ],
        'evidence_calls': ['ListPolicies', 'GetPolicyEngine',
                           'tools/list', 'tools/call',
                           'CloudWatch AllowDecisions / DenyDecisions'],
        'demo': 'Try it yourself, and Six capabilities → Policy',
        'talking_point':
            'Cedar reads `context.input` — the tool\'s actual arguments. IAM '
            'can say "this role may call process_refund". It cannot say '
            '"…for amounts up to $100". That gap is the whole reason this '
            'service exists.',
    },
    {
        'key': 'observability',
        'service': 'AgentCore Observability',
        'integration': 'Direct',
        'claim': 'Captures Gateway invocation metrics, traces, latency, and '
                 'errors.',
        'built': [
            '`observability.py` — reads the vended `AWS/Bedrock-AgentCore` '
            'metrics for this gateway: invocations, latency, target execution '
            'time, user and system errors, throttles.',
            'Per-tool breakdown on the `Name` dimension, and per-policy '
            'allow/deny on the `Policy` dimension.',
            'Independent corroboration of the Identity round trip via '
            '`ApiKeyFetchSuccess`.',
        ],
        'evidence_calls': ['ListMetrics', 'GetMetricData',
                           'DescribeLogGroups',
                           'XRay GetTraceSummaries',
                           'XRay GetTraceSegmentDestination'],
        'demo': 'Six capabilities → Observability',
        'talking_point':
            'This POC emits no telemetry of its own and every number on that '
            'page still exists. The gateway vends them per request — '
            'including the ID of the Cedar policy that decided, which is what '
            'turns "we have a control" into "here is how often it fired".',
    },
    {
        'key': 'memory',
        'service': 'AgentCore Memory',
        'integration': 'Indirect',
        'claim': 'Agents can use Gateway to access tools while independently '
                 'retrieving and storing memory.',
        'built': [
            'A memory resource owned by this POC, created at `setup` and '
            'deleted at `destroy`.',
            'Settled claims written as conversation events — including '
            'refusals and the Cedar policy that caused them — and read back '
            'in a later process.',
            'The demonstration that matters: recalling a refusal does not '
            'weaken the refusal.',
        ],
        'evidence_calls': ['CreateMemory', 'GetMemory', 'CreateEvent',
                           'ListEvents', 'ListSessions',
                           'RetrieveMemoryRecords'],
        'demo': 'Six capabilities → Memory',
        'talking_point':
            'Memory and Gateway do not know about each other, and that is the '
            'security property, not a missing feature. Ask for the same '
            'refund twice: the agent remembers being refused perfectly and '
            'gets refused again identically, because authority lives at the '
            'gateway and nothing in Memory can vote on it.',
    },
    {
        'key': 'browser',
        'service': 'AgentCore Browser',
        'integration': 'Optional/Indirect',
        'claim': 'Browser capabilities can be exposed through custom MCP tools '
                 'accessed via Gateway.',
        'built': [
            '`browser_price.py` — a managed-browser session that renders the '
            'competitor page and reads the retailer\'s own JSON-LD offer '
            'price, with a screenshot kept per run.',
            'The price it reads is the number Cedar then adjudicates, so the '
            'browser is load-bearing in the use case rather than decorative.',
            'The honest part: it is reached on the data plane, **not** through '
            'the gateway. Wrapping it as an MCP tool needs a Lambda this '
            'sandbox will not let us create.',
        ],
        'evidence_calls': ['StartBrowserSession', 'ListBrowsers',
                           'IAM SimulatePrincipalPolicy for '
                           'lambda:CreateFunction'],
        'demo': 'Walk a claim → step ②, and Six capabilities → Browser',
        'talking_point':
            'This is the one gap in the fence and it is worth volunteering. '
            'The browser is authorised by IAM alone and Cedar cannot see it. '
            'It only reads, so it cannot move money — but an agent could '
            'browse somewhere we would rather it did not.',
    },
]

REQUIREMENTS_BY_KEY = {row['key']: row for row in REQUIREMENTS}


# ----------------------------------------------------------------- the probes

def probe_runtime(stack, say=print) -> Dict[str, Any]:
    """Direction 1 locally *and* on AWS; direction 2 as a recorded shape.

    This row was PARTIAL until 2026-10-11 on the grounds that AWS was not
    hosting the process. It is now PROVEN, and the upgrade is earned by
    `hosted_runtime()` invoking a deployed agent rather than by a change of
    opinion: the evidence bundle carries the runtime id, its READY status, the
    role session AgentCore minted for it, and its own trace of the six
    services it touched from in there.
    """
    import runtime_agent

    contract = runtime_agent.verify_contract(call_gateway=bool(stack), say=say)
    hosted = runtime_agent.hosted_runtime(say=say)
    target = runtime_agent.target_shape(say=say)

    # PROVEN requires the hosted agent to have *answered*, not merely to
    # exist. A READY runtime that cannot reach anything is the exact failure
    # the egress trap produces, and it would be dishonest to score it as
    # working - so the gate is `invoked`, not `hosted`.
    if hosted.get('invoked'):
        status = PROVEN
    elif contract.get('ok'):
        status = PARTIAL
    else:
        status = BLOCKED

    proven = [
        'The agent answers `GET /ping` with `{"status": "Healthy"}` and '
        'accepts `POST /invocations`, which is the entire Runtime contract.',
        'Driven through that interface, it reaches the live gateway and '
        'receives a Cedar denial naming the policy — so a hosted agent '
        'is governed by exactly the same ceiling.',
    ]
    not_proven = [
        'Publishing a Runtime agent as a gateway target — the target type '
        'exists and its shape is recorded, but every READY runtime in this '
        'account belongs to another demo.',
    ]

    if hosted.get('invoked'):
        served = hosted.get('served_by') or {}
        proven += [
            f"**AWS is hosting the agent.** Runtime "
            f"`{hosted.get('runtime_id')}` is {hosted.get('status')} "
            f"(v{hosted.get('version')}, {hosted.get('network_mode')} "
            f"networking) and was invoked for this bundle. The artifact is a "
            f"1.5 MB zip in S3 — no container, no ECR, no ARM64 build.",
            f"The hosted agent runs as `{served.get('identity', '?')}`, a "
            f"role session AgentCore created. Nothing on the developer's host "
            f"can produce one, which is what makes the hosting checkable "
            f"rather than asserted.",
            f"From inside Runtime it reached "
            f"{len(hosted.get('services_touched') or [])} services in "
            f"{hosted.get('total_ms', 0):.0f} ms: "
            f"{', '.join(hosted.get('services_touched') or [])}.",
        ]
        if hosted.get('denied_by'):
            proven.append(
                f"The refund it attempted from in there was refused by "
                f"`{hosted['denied_by']}`. The ceiling followed the agent onto "
                f"managed infrastructure, because the ceiling was never in the "
                f"agent.")
        else:
            not_proven.append(
                'The hosted invocation produced no policy denial this run, so '
                'the refusal is evidenced by the local run above rather than '
                'the hosted one.')
    else:
        not_proven.insert(0, 'AWS hosting the agent: '
                             + (hosted.get('why_not')
                                or hosted.get('invoke_error')
                                or f"runtime status "
                                   f"{hosted.get('status', 'unknown')}"))

    return {
        'status': status,
        'contract': contract,
        'hosted': hosted,
        # Kept under the old key as well, because `capability_view` and the
        # written evidence both reach for `deploy`. Same object, new meaning:
        # it used to say why hosting was impossible and now says where it runs.
        'deploy': hosted,
        'as_target': target,
        'proven': proven,
        'not_proven': not_proven,
    }


def probe_identity(stack, say=print) -> Dict[str, Any]:
    """The POC's own identity resources, the vault round trip, and the counters."""
    import identity
    import observability

    control = boto3.client('bedrock-agentcore-control', region_name=config.REGION)
    resources: Dict[str, Any] = {}

    for label, call, kwargs in (
            ('workload_identity', control.get_workload_identity,
             {'name': config.WORKLOAD_IDENTITY_NAME}),
            ('credential_provider', control.get_api_key_credential_provider,
             {'name': config.CREDENTIAL_PROVIDER_NAME})):
        try:
            response = call(**kwargs)
            resources[label] = {
                'name': kwargs['name'], 'exists': True,
                'arn': response.get('workloadIdentityArn')
                       or response.get('credentialProviderArn')}
        except botocore.exceptions.ClientError as exc:
            resources[label] = {'name': kwargs['name'], 'exists': False,
                                'error': exc.response['Error']['Code']}

    round_trip = identity.verify_round_trip(say=say)
    counters = observability.identity_activity()

    present = all(r.get('exists') for r in resources.values())
    status = PROVEN if (present and round_trip.get('ok')) else PARTIAL

    return {
        'status': status,
        'resources': resources,
        'round_trip': round_trip,
        'metrics': counters,
        'consumed_at_request_time': {
            'backend': config.REFUNDS_LAMBDA_ARN,
            'note': 'The refunds Lambda performs its own '
                    'GetWorkloadAccessToken -> GetResourceApiKey against the '
                    'vault and returns only a masked preview. That is the '
                    'architecture: the backend fetches the credential, not '
                    'the agent.',
        },
        'proven': [
            'A workload identity and credential provider exist under POC names '
            'and are visible on the console Identity page.',
            'The vault returns the stored secret to a caller that presents only '
            'proof of which workload it is — so rotating the secret never '
            'touches the workload and revoking the workload never touches the '
            'secret.',
            'CloudWatch counts the retrievals independently of this POC.',
        ],
        'not_proven': [
            'Inbound identity is `AWS_IAM`, not corporate SSO. Switching to '
            '`CUSTOM_JWT` against a real IdP changes one field and was not '
            'done.',
            'The POC\'s own provider is deliberately not the one the backend '
            'reads — that one predates this work and lives in the Lambda\'s '
            'environment.',
        ],
    }


def probe_policy(stack, say=print) -> Dict[str, Any]:
    """The Cedar rules, the boundary, and the service's own decision counts."""
    import observability
    import scenario
    from mcp_client import McpGatewayClient

    control = boto3.client('bedrock-agentcore-control', region_name=config.REGION)
    policies: List[Dict[str, Any]] = []
    policy_ids: List[str] = []
    try:
        response = control.list_policies(
            policyEngineId=stack.policy_engine_id, maxResults=50)
        for item in response.get('policies', []):
            policies.append({'id': item.get('policyId'),
                             'name': item.get('name'),
                             'status': item.get('status')})
            if item.get('policyId'):
                policy_ids.append(item['policyId'])
    except botocore.exceptions.ClientError as exc:
        policies = [{'error': exc.response['Error']['Code']}]

    # The boundary, live. Three calls, and the middle one is the one people
    # remember: exactly at the limit is allowed.
    client = McpGatewayClient(stack.gateway_id, url=stack.gateway_url)
    sweep = []
    limit = config.AUTO_APPROVE_LIMIT
    for amount in (limit - 1, limit, limit + 1):
        decision = scenario.call_through_gateway(
            client, stack.refund_tool(),
            {'amount': amount, 'reason': 'capability evidence sweep'})
        sweep.append({'amount': amount, 'verdict': decision.verdict,
                      'deciding_policy': decision.deciding_policy,
                      'latency_ms': round(decision.latency_ms, 1)})
        say(f"  policy boundary    ${amount} -> {decision.verdict}"
            + (f' ({decision.deciding_policy})'
               if decision.deciding_policy else ''))

    # Default-deny: a tool no policy grants should not even be listed.
    try:
        visible = client.tool_names()
    except Exception as exc:                                # noqa: BLE001
        visible = [f'error: {type(exc).__name__}']
    ungranted = stack.refund_tool('issue_store_credit')

    decisions = observability.policy_decisions(stack.gateway_id, policy_ids)

    boundary_holds = ([s['verdict'] for s in sweep]
                      == ['ALLOWED', 'ALLOWED', 'DENIED'])
    named = any(s['deciding_policy'] for s in sweep if s['verdict'] == 'DENIED')

    return {
        'status': PROVEN if (boundary_holds and named) else PARTIAL,
        'policy_engine_id': stack.policy_engine_id,
        'mode': 'ENFORCE',
        'policies': policies,
        'boundary': sweep,
        'boundary_holds': boundary_holds,
        'tools_visible': visible,
        'ungranted_tool': ungranted,
        'ungranted_tool_hidden': ungranted not in visible,
        'metrics': decisions,
        'proven': [
            f'${limit} is allowed and ${limit + 1} is refused — the limit is '
            f'exactly where the policy says it is, not approximately.',
            'The refusal names the Cedar rule that caused it, which is the '
            'difference between an auditable control and a support ticket '
            'saying "access denied".',
            f'`{ungranted}` is granted by no policy and is absent from '
            f'`tools/list` — the agent is not resisting temptation, it was '
            f'never told the option exists.',
            'CloudWatch counts allow and deny decisions per policy ID, so the '
            'enforcement record does not depend on trusting this POC.',
        ],
        'not_proven': [
            f'Per-call limits are not rate limits. An agent could request '
            f'${limit} repeatedly and nothing here would stop it.',
            'No per-user or per-role differentiation — every caller is held to '
            'the same ceiling.',
        ],
    }


def probe_observability(stack, memory_id: str = None, say=print
                        ) -> Dict[str, Any]:
    """Read what the service already publishes, and be straight about traces."""
    import observability

    # The state file records `policyId`; so does ListPolicies. Guard both
    # spellings because an older state file used `id`.
    policy_ids = [p.get('policyId') or p.get('id')
                  for p in (stack.policies or [])
                  if isinstance(p, dict) and (p.get('policyId') or p.get('id'))]
    if not policy_ids:
        try:
            control = boto3.client('bedrock-agentcore-control',
                                   region_name=config.REGION)
            policy_ids = [
                p['policyId'] for p in control.list_policies(
                    policyEngineId=stack.policy_engine_id,
                    maxResults=50).get('policies', [])
                if p.get('policyId')]
        except botocore.exceptions.ClientError:
            policy_ids = []

    tools = sorted(set((stack.tools_enforced or [])
                       + [stack.refund_tool(), stack.search_tool or '']) - {''})

    data = observability.observe(
        stack.gateway_id, stack.gateway_arn, tools=tools,
        policy_ids=policy_ids, memory_id=memory_id, say=say)
    data['traces'] = probe_traces(stack, say=say)

    metrics_live = bool(
        (data.get('discovered') or {}).get('metric_count'))
    # PARTIAL on purpose: the requirement says "metrics, traces, latency, and
    # errors" and three of those four are live. Claiming PROVEN would be
    # claiming the traces.
    status = PARTIAL if metrics_live else BLOCKED

    data['status'] = status
    data['proven'] = [
        f"{(data.get('discovered') or {}).get('metric_count', 0)} metrics are "
        f"vended for this gateway without this POC instrumenting anything.",
        'Invocations, latency, target execution time, user errors, system '
        'errors and throttles, per tool name.',
        'Allow and deny counts dimensioned by the deciding Cedar policy ID.',
    ]
    data['not_proven'] = [
        'Traces. AgentCore ships gateway spans through CloudWatch Transaction '
        'Search, which is not enabled in this account — the X-Ray segment '
        f"destination reads `{(data['traces'] or {}).get('destination')}` and "
        f"there are no traces in the last 24 hours. Enabling it is an "
        f"account-wide change with a billing impact, and this is a shared "
        f"account, so it was not switched on unilaterally.",
        'There is no CloudWatch log group for a gateway. AgentCore vends them '
        'for Runtime and Memory; gateway observability is metrics-only until '
        'Transaction Search is on.',
    ]
    return data


def probe_traces(stack, say=print) -> Dict[str, Any]:
    """Is trace collection actually on? Asked rather than assumed.

    Reported because the honest answer is no, and a reader is entitled to know
    whether that is a service limitation or an account setting. It is an
    account setting.
    """
    xray = boto3.client('xray', region_name=config.REGION)
    out: Dict[str, Any] = {}
    try:
        out['destination'] = xray.get_trace_segment_destination().get(
            'Destination')
    except botocore.exceptions.ClientError as exc:
        out['destination'] = f"error: {exc.response['Error']['Code']}"

    # GetTraceSummaries refuses a window wider than 24 hours.
    end = datetime.datetime.now(datetime.timezone.utc)
    start = end - datetime.timedelta(hours=24)
    try:
        summaries = xray.get_trace_summaries(
            StartTime=start, EndTime=end).get('TraceSummaries', [])
        out['traces_last_24h'] = len(summaries)
    except botocore.exceptions.ClientError as exc:
        out['traces_last_24h'] = None
        out['error'] = exc.response['Error']['Code']

    try:
        rules = xray.get_indexing_rules().get('IndexingRules', [])
        out['sampling'] = [
            (r.get('Rule') or {}).get('Probabilistic', {}).get(
                'DesiredSamplingPercentage') for r in rules]
    except botocore.exceptions.ClientError:
        out['sampling'] = None

    out['transaction_search_enabled'] = out.get('destination') == 'CloudWatchLogs'
    out['note'] = (
        'Gateway spans reach CloudWatch only when Transaction Search is '
        'enabled, which changes the X-Ray segment destination to '
        '`CloudWatchLogs`. Here it is `%s`.' % out.get('destination'))
    say(f"  traces             transaction search "
        f"{'on' if out['transaction_search_enabled'] else 'off'}, "
        f"{out.get('traces_last_24h')} traces in 24h")
    return out


def probe_memory(stack, say=print) -> Dict[str, Any]:
    """Own a memory, write a claim into it, read it back, and show the limit."""
    import memory_store

    ensured = memory_store.ensure_memory(say=say)
    memory_id = ensured['memory_id']
    if ensured.get('status') != 'ACTIVE':
        memory_store.wait_active(memory_id, say=say)

    # A claim the gateway actually adjudicated, so what gets remembered is a
    # real verdict rather than a sentence written here.
    import scenario
    from mcp_client import McpGatewayClient

    client = McpGatewayClient(stack.gateway_id, url=stack.gateway_url)
    over = config.AUTO_APPROVE_LIMIT + 50
    decision = scenario.call_through_gateway(
        client, stack.refund_tool(),
        {'amount': over, 'reason': 'memory evidence claim'})

    entry = {
        'case': {'case_id': 'PM-MEM-1', 'product': 'LG C4 65" OLED',
                 'our_price': 1299, 'competitor_name': 'a competitor'},
        'refund_amount': over,
        'refund_decision': decision.to_dict(),
        'browsing': {'price': 1299 - over,
                     'visits': [{'price_source': 'capability probe'}]},
        'search': {'decision': {'tool': stack.search_tool}},
    }
    session_id = 'claim-PM-MEM-1'
    written = memory_store.remember_claim(memory_id, entry,
                                          session_id=session_id, say=say)
    recalled = memory_store.recall(memory_id, session_id, say=say)

    # The point of the whole section: ask again, having remembered.
    repeat = scenario.call_through_gateway(
        client, stack.refund_tool(),
        {'amount': over, 'reason': 'asking again, now that I remember'})
    say(f'  memory vs policy   repeat request for ${over} -> {repeat.verdict}'
        + (f' ({repeat.deciding_policy})' if repeat.deciding_policy else ''))

    retrieved = memory_store.retrieve(memory_id, 'the LG C4 claim', say=say)
    all_sessions = memory_store.sessions(memory_id)

    round_trip_ok = bool(written.get('ok') and recalled.get('count'))
    unchanged = decision.verdict == repeat.verdict

    return {
        'status': PROVEN if (round_trip_ok and unchanged) else PARTIAL,
        'memory_id': memory_id,
        'memory_arn': ensured.get('memory_arn'),
        'actor_id': config.MEMORY_ACTOR_ID,
        'expiry_days': config.MEMORY_EVENT_EXPIRY_DAYS,
        'wrote': written,
        'recalled': recalled,
        'sessions': all_sessions,
        'long_term': retrieved,
        'first_request': decision.to_dict(),
        'repeat_request': repeat.to_dict(),
        'verdict_unchanged_by_memory': unchanged,
        'proven': [
            'The POC owns a memory resource; claims are written as '
            'conversation events and read back in a separate process.',
            'Refusals are remembered, including the Cedar policy that caused '
            'them — the interesting case, not just the happy path.',
            f'Asking for the same ${over} refund again, with the refusal in '
            f'memory, produces the same verdict. Recall does not confer '
            f'authority.',
            'Gateway and Memory share no configuration: no memoryId on the '
            'gateway, no policy on the memory. The independence is the '
            'integration.',
        ],
        'not_proven': [
            'Long-term semantic memory. `RetrieveMemoryRecords` needs a '
            '`memoryStrategy` on the resource and an execution role for the '
            'extraction job; the resource is created with none, so retrieval '
            'correctly returns nothing. That is a cost and role-trust '
            'decision, not a code change.',
            'No agent reasoning consumes the recalled context — orchestration '
            'here is plain Python so the verdict stays attributable to policy '
            'rather than to a model having a good day.',
        ],
    }


def probe_browser(stack, say=print) -> Dict[str, Any]:
    """The browser works and is load-bearing; it is also outside the fence."""
    control = boto3.client('bedrock-agentcore-control', region_name=config.REGION)

    # `ListBrowsers` returns *custom* browsers only. The one this POC uses,
    # `aws.browser.v1`, is the service-managed one and never appears in that
    # list — which looks like an empty result meaning "no browser" unless you
    # know. The custom browsers that do come back belong to other demos.
    browsers: List[Dict[str, Any]] = []
    try:
        for item in control.list_browsers(maxResults=20).get(
                'browserSummaries', []):
            browsers.append({'id': item.get('browserId'),
                             'name': item.get('name'),
                             'status': item.get('status'),
                             'ours': False})
    except botocore.exceptions.ClientError as exc:
        browsers = [{'error': exc.response['Error']['Code']}]

    # Why it is not a gateway tool, asked of IAM rather than remembered. A
    # simulation changes nothing and returns the policy that denies.
    wrapper: Dict[str, Any] = {'action': 'lambda:CreateFunction'}
    try:
        iam = boto3.client('iam')
        result = iam.simulate_principal_policy(
            PolicySourceArn=config.GATEWAY_ROLE_ARN,
            ActionNames=['lambda:CreateFunction'],
            ResourceArns=[f'arn:aws:lambda:{config.REGION}:196856463470:'
                          f'function:novacart-browser-tool'])
        evaluation = result['EvaluationResults'][0]
        wrapper.update({
            'decision': evaluation['EvalDecision'],
            'matched_policies': [s.get('SourcePolicyId') for s in
                                 evaluation.get('MatchedStatements', [])],
            'allowed_by_organizations': (
                evaluation.get('OrganizationsDecisionDetail') or {}).get(
                    'AllowedByOrganizations'),
        })
        say(f"  browser wrapper    lambda:CreateFunction -> "
            f"{evaluation['EvalDecision']} "
            f"({', '.join(wrapper['matched_policies']) or 'no named policy'})")
    except botocore.exceptions.ClientError as exc:
        wrapper['error'] = exc.response['Error']['Code']

    # Did the browser actually carry the use case? Read from the last run
    # rather than re-driven, because a browser session costs ~40 seconds and
    # the transcript is the real evidence either way.
    last_run = _latest(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        config.ARTIFACT_DIR, 'run_*.json'))
    used: Dict[str, Any] = {'from_run': os.path.basename(last_run)
                            if last_run else None}
    if last_run:
        try:
            with open(last_run) as handle:
                transcript = json.load(handle)
            for case in transcript.get('cases', []):
                browsing = case.get('browsing') or {}
                if browsing.get('price') is not None:
                    visit = (browsing.get('visits') or [{}])[-1]
                    used.update({
                        'price_read': browsing.get('price'),
                        'browser_version': browsing.get('browser_version'),
                        'price_source': visit.get('price_source'),
                        'rendered_chars': visit.get('rendered_chars'),
                        'screenshot': browsing.get('screenshot')
                                      or visit.get('screenshot'),
                        'refund_adjudicated': case.get('refund_amount'),
                    })
                    break
        except (OSError, json.JSONDecodeError):
            pass

    return {
        # BLOCKED refers to the claim as written — "exposed through custom MCP
        # tools accessed via Gateway" — which is precisely the part that cannot
        # be built here. The browser itself works and is in the critical path.
        'status': BLOCKED,
        'browser_id': config.BROWSER_ID,
        'browsers': browsers,
        'reached_via': 'data plane (StartBrowserSession), not the gateway',
        'wrapper_blocked_by': wrapper,
        'used_in_use_case': used,
        'proven': [
            'The managed browser renders the competitor page and reads the '
            'retailer\'s own JSON-LD offer price, with a screenshot kept per '
            'run.',
            'That price is the number Cedar then adjudicates — so the browser '
            'is in the critical path of the authorisation decision, not a '
            'side demo.',
        ],
        'not_proven': [
            'The claim as written. Exposing the browser *through* the gateway '
            'needs a custom MCP tool, which needs a Lambda, and '
            '`lambda:CreateFunction` is explicitly denied to this role by '
            '`SandboxServicePolicy` — checked live, not remembered. The '
            'organisation permits it; the account\'s own policy does not.',
            'So the browser is authorised by IAM alone and Cedar cannot see '
            'it. It only reads, which is why this has not bitten us, but an '
            'agent could browse somewhere we would rather it did not.',
        ],
    }


# ------------------------------------------------------------- orchestration

PROBES = {
    'runtime': probe_runtime,
    'identity': probe_identity,
    'policy': probe_policy,
    'observability': probe_observability,
    'memory': probe_memory,
    'browser': probe_browser,
}


def probe_all(only: Optional[List[str]] = None, say=print) -> Dict[str, Any]:
    """Run every capability probe and return the evidence bundle."""
    import gateway_stack

    stack = gateway_stack.Stack.load()
    if not stack or not stack.gateway_id:
        raise SystemExit(
            'No gateway state. Run `python run_poc.py setup` first.')

    keys = only or list(PROBES)
    say(f'Capability evidence — {len(keys)} of {len(PROBES)} requirements')
    say(f'  gateway            {stack.gateway_id}')

    evidence: Dict[str, Any] = {}
    carried: Dict[str, str] = {}
    memory_id = None

    # A partial probe must not write a partial bundle. `summarise()` scores a
    # missing row as BLOCKED and the Streamlit page reads all six, so
    # `--only policy` would otherwise turn one refreshed probe into five false
    # failures. Carry the untouched rows forward from the newest bundle and
    # record which run each one came from, so a stale row is visibly stale
    # rather than quietly passed off as today's measurement.
    if only:
        earlier_bundles = available_bundles()
        if earlier_bundles:
            earlier = load_bundle(earlier_bundles[0])
            stamp = earlier.get('generated', 'an earlier run')
            for key, found in (earlier.get('evidence') or {}).items():
                if key not in keys:
                    evidence[key] = found
                    carried[key] = stamp
            memory_id = (evidence.get('memory') or {}).get('memory_id')
            say(f'  carried forward    {len(carried)} rows from {stamp}')

    # Memory runs before observability so the log-group sweep can look for the
    # memory's own vended group.
    order = [k for k in ('runtime', 'identity', 'policy', 'memory',
                         'observability', 'browser') if k in keys]

    for key in order:
        say(f'\n[{key}]')
        try:
            if key == 'observability':
                result = probe_observability(stack, memory_id=memory_id,
                                             say=say)
            else:
                result = PROBES[key](stack, say=say)
            if key == 'memory':
                memory_id = result.get('memory_id')
        except botocore.exceptions.ClientError as exc:
            result = {'status': BLOCKED,
                      'error': exc.response['Error']['Code'],
                      'message': exc.response['Error']['Message'][:300]}
            say(f"  FAILED             {exc.response['Error']['Code']}")
        except Exception as exc:                            # noqa: BLE001
            result = {'status': BLOCKED,
                      'error': type(exc).__name__, 'message': str(exc)[:300]}
            say(f'  FAILED             {type(exc).__name__}: {exc}')
        evidence[key] = result

    bundle = {
        'generated': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'account': '196856463470',
        'region': config.REGION,
        'gateway_id': stack.gateway_id,
        'gateway_arn': stack.gateway_arn,
        'requirements': REQUIREMENTS,
        'evidence': evidence,
        'probed': order,
        'carried': carried,
    }
    bundle['summary'] = summarise(bundle)
    return bundle


def summarise(bundle: Dict[str, Any]) -> Dict[str, Any]:
    counts = {PROVEN: 0, PARTIAL: 0, BLOCKED: 0}
    rows = []
    for row in REQUIREMENTS:
        key = row['key']
        found = (bundle.get('evidence') or {}).get(key) or {}
        status = found.get('status', BLOCKED)
        counts[status] = counts.get(status, 0) + 1
        rows.append({'key': key, 'service': row['service'],
                     'integration': row['integration'], 'status': status})
    return {'counts': counts, 'rows': rows,
            'total': len(REQUIREMENTS)}


def write_evidence(bundle: Dict[str, Any], directory: str = None) -> str:
    directory = directory or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), config.ARTIFACT_DIR)
    os.makedirs(directory, exist_ok=True)
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    path = os.path.join(directory, f'capabilities_{stamp}.json')
    with open(path, 'w') as handle:
        json.dump(bundle, handle, indent=2, default=str)
    return path


def _latest(pattern: str) -> Optional[str]:
    matches = sorted(glob.glob(pattern), reverse=True)
    return matches[0] if matches else None


def available_bundles(directory: str = None) -> List[str]:
    directory = directory or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), config.ARTIFACT_DIR)
    return sorted(glob.glob(os.path.join(directory, 'capabilities_*.json')),
                  reverse=True)


def load_bundle(path: str) -> Dict[str, Any]:
    with open(path) as handle:
        return json.load(handle)
