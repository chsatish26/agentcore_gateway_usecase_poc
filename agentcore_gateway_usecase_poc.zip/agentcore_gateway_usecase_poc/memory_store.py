"""AgentCore Memory, and why its relationship to the gateway is *indirect*.

The requirements table calls this integration indirect, and that word is doing
real work. Memory and Gateway do not know about each other. There is no
`memoryId` field on a gateway, no memory configuration on a target, and Cedar
cannot read or write a memory record. What makes them one architecture is only
that the same agent uses both, for different things:

    Gateway  -> what the agent is allowed to *do*      (authority)
    Memory   -> what the agent is allowed to *recall*  (continuity)

So the useful demonstration is not "look, they are connected". It is the
opposite, and it is a security property worth stating out loud:

**Remembering a refusal does not weaken the refusal.**

`remember_claim()` writes the outcome of a gateway-authorised tool call into
Memory, including denials and the Cedar policy that caused them. `recall()`
reads it back in a later process. Then the thing to try on stage is asking for
the same refund again: the agent now has perfect recall of having been refused,
and gets refused again in exactly the same way, because the authority lives at
the gateway and nothing in Memory can vote on it.

An agent whose memory *could* influence its permissions would be an agent you
could talk into a refund by telling it, convincingly, that it had been allowed
one before. That is prompt injection with a persistence layer. The reason this
POC can write agent-authored text straight into Memory without worrying about
it is precisely that the text has no authority.

## Short-term and long-term

Events are the short-term layer and work immediately - `CreateEvent` then
`ListEvents` and the turns come back in reverse-chronological order. Long-term
memory (`RetrieveMemoryRecords`) requires `memoryStrategies` on the resource
and a `memoryExecutionRoleArn` for the extraction job to assume. The POC
creates the resource with no strategies, so `retrieve()` is expected to return
nothing and says so rather than looking broken. Adding a semantic strategy is
one `CreateMemory` argument and a role; it is a cost and a role-trust decision,
not a code change, which is why it is left as a documented next step.

## Names

`MEMORY_NAME` must match `[A-Za-z][A-Za-z0-9_]*` - the policy-engine charset,
not the gateway one. `novacart-price-match-poc` is rejected outright; the
hyphens have to become underscores. Two different name grammars inside one
service is a sharp edge worth knowing before a live demo.
"""

import datetime
from typing import Any, Dict, List, Optional

import boto3
import botocore.exceptions

import config


def _control():
    return boto3.client('bedrock-agentcore-control', region_name=config.REGION)


def _data():
    return boto3.client('bedrock-agentcore', region_name=config.REGION)


def _now():
    return datetime.datetime.now(datetime.timezone.utc)


# ------------------------------------------------------------------ provision

def find_memory(control=None) -> Optional[Dict[str, Any]]:
    """Locate this POC's memory by name.

    `GetMemory` takes an ID, not a name, and the ID carries a random suffix
    assigned at creation. So adopting an existing resource across processes
    means listing and matching on name - the same adopt-don't-duplicate pattern
    `setup` uses for the gateway.
    """
    control = control or _control()
    paginator = control.get_paginator('list_memories')
    for page in paginator.paginate():
        for summary in page.get('memories', []):
            # ListMemories returns `id`, and older shapes used `name`; derive
            # the name from the ID prefix when it is absent.
            name = summary.get('name') or str(summary.get('id', '')).rsplit(
                '-', 1)[0]
            if name == config.MEMORY_NAME:
                return summary
    return None


def ensure_memory(say=print) -> Dict[str, Any]:
    """Create or adopt the POC's memory resource.

    Creation is asynchronous and `CreateEvent` fails with a `ValidationException`
    - not a retryable error code - while the status is `CREATING`. So callers
    must wait, and `wait_active()` below does.
    """
    control = _control()
    existing = find_memory(control)
    if existing:
        memory_id = existing['id']
        status = existing.get('status', 'UNKNOWN')
        say(f'  memory             {memory_id} ({status.lower()}, existing)')
        return {'memory_id': memory_id,
                'memory_arn': existing.get('arn'),
                'status': status,
                'created': False}

    created = control.create_memory(
        name=config.MEMORY_NAME,
        description='NovaCart price-match POC — claim history for the agent',
        eventExpiryDuration=config.MEMORY_EVENT_EXPIRY_DAYS)['memory']
    say(f"  memory             {created['id']} (created, "
        f'{config.MEMORY_EVENT_EXPIRY_DAYS}d expiry)')
    return {'memory_id': created['id'],
            'memory_arn': created.get('arn'),
            'status': created.get('status'),
            'created': True}


def wait_active(memory_id: str, timeout: int = 180, say=print) -> str:
    """Block until the memory can accept events, or report what it is stuck on."""
    control = _control()
    deadline = _now() + datetime.timedelta(seconds=timeout)
    status = 'UNKNOWN'
    while _now() < deadline:
        memory = control.get_memory(memoryId=memory_id)['memory']
        status = memory.get('status', 'UNKNOWN')
        if status == 'ACTIVE':
            return status
        if status == 'FAILED':
            say(f"  memory             FAILED: "
                f"{memory.get('failureReason', 'no reason given')}")
            return status
        import time
        time.sleep(5)
    say(f'  memory             still {status} after {timeout}s')
    return status


# --------------------------------------------------------------------- write

def _turn(role: str, text: str) -> Dict[str, Any]:
    return {'conversational': {'role': role, 'content': {'text': text}}}


def remember_claim(memory_id: str, entry: Dict[str, Any],
                   session_id: str = None, say=print) -> Dict[str, Any]:
    """Write one settled claim into Memory as a conversation.

    The content is deliberately the *whole* story including the verdict and the
    deciding policy, because the interesting demo is recalling a refusal. An
    implementation that only remembered successes would be hiding the case that
    matters.
    """
    case = entry.get('case') or {}
    decision = entry.get('refund_decision') or {}
    browsing = entry.get('browsing') or {}
    session_id = session_id or f"claim-{case.get('case_id', 'unknown')}"

    verdict = decision.get('verdict', 'UNKNOWN')
    if verdict == 'ALLOWED':
        outcome = (f"Refund of ${entry.get('refund_amount')} was ALLOWED and "
                   f"the claim is settled.")
    else:
        outcome = (f"Refund of ${entry.get('refund_amount')} was {verdict} by "
                   f"policy {decision.get('deciding_policy')}. No money moved "
                   f"and the backend was never invoked.")

    turns = [
        ('USER',
         f"I bought {case.get('product')} on order {case.get('case_id')} for "
         f"${case.get('our_price')}. {case.get('competitor_name', 'A competitor')} "
         f"is selling it cheaper and I want the difference back."),
        ('ASSISTANT',
         f"I searched the web through gateway tool "
         f"{(entry.get('search') or {}).get('decision', {}).get('tool', 'the research target')}, "
         f"then read ${browsing.get('price')} off the live page "
         f"(provenance: {((browsing.get('visits') or [{}])[-1]).get('price_source', 'unknown')})."),
        ('ASSISTANT', outcome),
    ]

    data = _data()
    written = []
    for role, text in turns:
        try:
            response = data.create_event(
                memoryId=memory_id,
                actorId=config.MEMORY_ACTOR_ID,
                sessionId=session_id,
                eventTimestamp=_now(),
                payload=[_turn(role, text)])
            written.append(response['event']['eventId'])
        except botocore.exceptions.ClientError as exc:
            say(f"  memory             CreateEvent failed: "
                f"{exc.response['Error']['Code']} — "
                f"{exc.response['Error']['Message'][:120]}")
            return {'session_id': session_id, 'ok': False,
                    'error': exc.response['Error']['Code'],
                    'event_ids': written}

    say(f'  memory             wrote {len(written)} turns to session '
        f'{session_id}')
    return {'session_id': session_id, 'ok': True, 'event_ids': written,
            'turns': len(written)}


# ---------------------------------------------------------------------- read

def recall(memory_id: str, session_id: str, limit: int = 20,
           say=print) -> Dict[str, Any]:
    """Read a session's turns back.

    Returned newest-first by the service. Left in that order deliberately: it
    is what the API does, and quietly reversing it in a POC that claims to show
    measured behaviour would be a small lie about the service.
    """
    data = _data()
    try:
        response = data.list_events(
            memoryId=memory_id, actorId=config.MEMORY_ACTOR_ID,
            sessionId=session_id, maxResults=limit)
    except botocore.exceptions.ClientError as exc:
        return {'ok': False, 'error': exc.response['Error']['Code'],
                'session_id': session_id, 'events': []}

    events = []
    for event in response.get('events', []):
        for item in event.get('payload') or []:
            conversational = item.get('conversational') or {}
            events.append({
                'event_id': event.get('eventId'),
                'at': str(event.get('eventTimestamp')),
                'role': conversational.get('role'),
                'text': (conversational.get('content') or {}).get('text'),
            })

    say(f'  memory             recalled {len(events)} turns from session '
        f'{session_id}')
    return {'ok': True, 'session_id': session_id, 'events': events,
            'count': len(events)}


def sessions(memory_id: str, limit: int = 20) -> List[str]:
    """Which claim sessions this memory holds, for the POC's actor.

    `ListSessions` needs an `actorId` and `ListEvents` needs both an `actorId`
    and a `sessionId` — there is no way to sweep a memory without knowing who
    you are looking for. That is a sensible tenancy boundary rather than a gap,
    but it means `MEMORY_ACTOR_ID` has to stay stable across runs or earlier
    claims become unreachable.
    """
    data = _data()
    found: List[str] = []
    try:
        response = data.list_sessions(
            memoryId=memory_id, actorId=config.MEMORY_ACTOR_ID,
            maxResults=limit)
    except botocore.exceptions.ClientError:
        return found
    for session in response.get('sessionSummaries', []):
        session_id = session.get('sessionId')
        if session_id and session_id not in found:
            found.append(session_id)
    return found


def retrieve(memory_id: str, query: str, say=print) -> Dict[str, Any]:
    """Semantic retrieval over long-term memory.

    Expected to come back empty on this resource and that is not a failure. The
    POC creates the memory with no `memoryStrategies`, so there is no
    extraction job turning events into records, so there are no records to
    retrieve. Reported as `strategies_configured: False` rather than as an
    error, because an empty result with no explanation is the kind of thing
    that gets presented as "the service does not work".
    """
    control = _control()
    strategies = []
    try:
        memory = control.get_memory(memoryId=memory_id)['memory']
        strategies = memory.get('strategies') or []
    except botocore.exceptions.ClientError as exc:
        return {'ok': False, 'error': exc.response['Error']['Code'],
                'strategies_configured': False, 'records': []}

    if not strategies:
        say('  memory             no strategies configured — long-term '
            'retrieval not available (expected)')
        return {'ok': True, 'strategies_configured': False, 'records': [],
                'note': 'Short-term events work; long-term records require a '
                        'memoryStrategy and an execution role.'}

    data = _data()
    try:
        response = data.retrieve_memory_records(
            memoryId=memory_id,
            namespace=f'/{config.MEMORY_ACTOR_ID}',
            searchCriteria={'searchQuery': query, 'topK': 5})
    except botocore.exceptions.ClientError as exc:
        return {'ok': False, 'error': exc.response['Error']['Code'],
                'strategies_configured': True, 'records': []}

    records = [{'content': str(r.get('content'))[:300],
                'score': r.get('score')}
               for r in response.get('memoryRecordSummaries', [])]
    return {'ok': True, 'strategies_configured': True, 'records': records}


# ------------------------------------------------------------------- teardown

def destroy_memory(say=print) -> List[str]:
    """Delete only the memory this POC created.

    The account holds several memories belonging to other demos
    (`travel_agent_mem`, `financial_agent_mem` and friends). Matching strictly
    on `MEMORY_NAME` is what keeps this from being destructive.
    """
    control = _control()
    existing = find_memory(control)
    if not existing:
        say(f'  memory             {config.MEMORY_NAME} already gone')
        return []
    try:
        control.delete_memory(memoryId=existing['id'])
        say(f"  deleted memory     {existing['id']}")
        return [existing['id']]
    except botocore.exceptions.ClientError as exc:
        say(f"  could not delete memory {existing['id']}: "
            f"{exc.response['Error']['Code']}")
        return []
