"""A SigV4-signed MCP client with no third-party HTTP dependency.

The price-match POC's client uses `requests`. This one uses `urllib` from the
standard library instead, for one reason: this file gets zipped and shipped to
a managed Python runtime, and the fewer things that have to be vendored into
that zip, the fewer ways the deployment can fail for reasons unrelated to the
agent. `botocore` still has to come along - it does the signing - but botocore
is pure Python, which is why the zip path works at all from an x86_64 host.

There is no `InvokeGateway` API. An AgentCore Gateway is an MCP server over
HTTPS, and with `authorizerType=AWS_IAM` the request must be SigV4-signed
against the `bedrock-agentcore` service:

    POST https://<gatewayId>.gateway.bedrock-agentcore.<region>.amazonaws.com/mcp
    Authorization: AWS4-HMAC-SHA256 ...
    MCP-Protocol-Version: 2025-11-25
    {"jsonrpc":"2.0","id":1,"method":"tools/call","params":{...}}

That is the entire agent-side integration. Inside Runtime it is identical:
boto3 picks up the task role from the container credential provider, so the
same code signs with the Runtime's role instead of a notebook's without a line
changing. The agent holds no tool credentials either way.
"""
# Ported into this project verbatim so the deploy zip is built only from
# files in this folder. The ONLY change from the original is the
# `import agent_config as config` line. The MCP version negotiation and
# SigV4 signing here were measured against live gateways - do not tidy
# without re-measuring.


import json
import time
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest

import agent_config as config

# A policy denial arrives as a JSON-RPC error, not as a tool result with
# isError set. Worth knowing: `result.isError` means the tool ran and failed,
# while -32002 means the tool never ran at all. Conflating them turns "refused"
# into "broken".
POLICY_DENIED_CODE = -32002


class McpError(RuntimeError):
    """A JSON-RPC error returned by the gateway."""

    def __init__(self, code: int, message: str, data: Any = None) -> None:
        super().__init__(f'[{code}] {message}')
        self.code = code
        self.message = message
        self.data = data

    @property
    def denied_by_policy(self) -> bool:
        return self.code == POLICY_DENIED_CODE


class GatewayClient:
    """Signs and sends JSON-RPC to an AgentCore Gateway."""

    def __init__(self, url: Optional[str] = None,
                 region: Optional[str] = None,
                 timeout: int = 60) -> None:
        self.url = url or config.gateway_url()
        self.region = region or config.REGION
        self.timeout = timeout
        self._session = boto3.Session()
        self._next_id = 0

    def _sign(self, body: str) -> Dict[str, str]:
        credentials = self._session.get_credentials()
        if credentials is None:
            raise RuntimeError(
                'No AWS credentials. Inside Runtime these come from the task '
                'role automatically; locally, configure a profile.')
        headers = {
            'Content-Type': 'application/json',
            # Mandatory in practice. Omit it and the gateway assumes
            # 2025-03-26, which it does not support, and every call fails.
            'MCP-Protocol-Version': config.MCP_PROTOCOL_VERSION,
            # The gateway speaks Streamable HTTP; it will reply with either
            # JSON or an SSE frame, so accept both and unwrap below.
            'Accept': 'application/json, text/event-stream',
        }
        request = AWSRequest(method='POST', url=self.url, data=body,
                             headers=headers)
        SigV4Auth(credentials.get_frozen_credentials(),
                  config.MCP_SERVICE, self.region).add_auth(request)
        return dict(request.headers)

    def call(self, method: str,
             params: Optional[Dict[str, Any]] = None) -> Tuple[Any, float]:
        """Send one JSON-RPC request. Returns (result, elapsed_ms)."""
        self._next_id += 1
        body = json.dumps({'jsonrpc': '2.0', 'id': self._next_id,
                           'method': method, 'params': params or {}})
        headers = self._sign(body)
        request = urllib.request.Request(self.url, data=body.encode(),
                                         headers=headers, method='POST')
        started = time.time()
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as resp:
                raw = resp.read().decode()
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode()
        elapsed = (time.time() - started) * 1000

        payload = _unwrap(raw)
        if 'error' in payload:
            error = payload['error']
            raise McpError(error.get('code', 0),
                           error.get('message', ''), error.get('data'))
        return payload.get('result'), elapsed

    def list_tools(self) -> List[str]:
        """The tools this caller may see.

        Note this is *policy-filtered*: a tool no Cedar policy grants is
        absent from the list entirely, not present-but-forbidden. An empty
        list means the policies deny everything, not that the targets are
        broken.
        """
        return [tool['name'] for tool in self.list_tool_specs()]

    def list_tool_specs(self) -> List[Dict[str, Any]]:
        """The same call, but keeping each tool's name/description/inputSchema.

        The agent hands these straight to the model. MCP's `inputSchema` is
        already JSON Schema, which is also what Bedrock's `toolSpec` wants, so
        no translation is needed - and more usefully, the model is told about
        exactly the tools policy permits, because this list is the filtered
        one. Nothing in the agent hardcodes a tool name.
        """
        result, _ = self.call('tools/list')
        return list((result or {}).get('tools', []))

    def call_tool(self, name: str,
                  arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke one tool and normalise the outcome.

        Never raises for a denial. A refusal is a legitimate answer to a
        question about authority, so it comes back as a verdict rather than an
        exception - which is also what lets the agent report it to the caller.
        """
        # Timed here as well as in `call`, because `call` raises on a denial
        # and takes its own measurement with it. A refusal that reports 0 ms
        # is worse than no number: it gets rendered as "the policy check is
        # free", when what actually happened is that the timing was thrown
        # away. The denial round trip is real and worth showing - it is the
        # honest answer to "what does the governance cost".
        started = time.time()
        try:
            result, elapsed = self.call('tools/call',
                                        {'name': name, 'arguments': arguments})
        except McpError as exc:
            return {
                'tool': name,
                'arguments': arguments,
                'verdict': 'DENIED' if exc.denied_by_policy else 'ERROR',
                'deciding_policy': _policy_from(exc.message),
                'message': exc.message,
                'latency_ms': round((time.time() - started) * 1000, 1),
            }
        return {
            'tool': name,
            'arguments': arguments,
            'verdict': 'ALLOWED',
            'deciding_policy': None,
            'message': None,
            'backend': _tool_payload(result),
            'latency_ms': round(elapsed, 1),
        }


def _unwrap(raw: str) -> Dict[str, Any]:
    """Parse a response that may be JSON or a Server-Sent Events frame."""
    text = raw.strip()
    if text.startswith('event:') or text.startswith('data:'):
        for line in text.splitlines():
            if line.startswith('data:'):
                return json.loads(line[5:].strip())
    try:
        return json.loads(text or '{}')
    except json.JSONDecodeError:
        return {'error': {'code': -1, 'message': text[:400]}}


def _policy_from(message: str) -> Optional[str]:
    """Pull the Cedar policy name out of a denial message.

    Two shapes exist and they mean different things:
      [Policy evaluation denied due to <name>-<id>]  - a rule you wrote said no
      [No policy applies to the request ...]         - nothing said yes
    """
    marker = 'Policy evaluation denied due to '
    if marker in message:
        return message.split(marker, 1)[1].rstrip('] ').strip()
    if 'No policy applies' in message:
        return 'default-deny (no policy grants this tool)'
    return None


def _tool_payload(result: Any, depth: int = 3) -> Any:
    """Dig the useful part out of an MCP tool result.

    Recursive, because a Lambda target that is itself an MCP server returns a
    JSON-RPC envelope *inside* the content text - so the useful payload is two
    or three unwraps down. Measured on this gateway's refund target: the
    outer result's text parses to `{"jsonrpc": ..., "result": {"content":
    [{"text": "{\\"status\\": \\"OK\\" ...}"}]}}`. Unwrapping once leaves the
    envelope on screen and buries the part anyone cares about.
    """
    if depth <= 0 or not isinstance(result, dict):
        return result
    if 'result' in result and 'jsonrpc' in result:
        return _tool_payload(result['result'], depth - 1)
    for item in result.get('content') or []:
        if item.get('type') == 'text':
            try:
                return _tool_payload(json.loads(item['text']), depth - 1)
            except (json.JSONDecodeError, KeyError, TypeError):
                return item.get('text')
    return result
