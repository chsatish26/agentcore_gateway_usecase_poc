"""Cedar policy lifecycle and gateway verdicts.

Ported from the price-match POC's `policy_types.py`, `gateway_stack.py` and
`scenario.py`, reduced to what this project uses, so nothing here imports
another project. The waits and the parsing are measured behaviour and the
comments say what each one is for - they look like defensive padding and are
not.

Three things worth knowing before changing anything in this file:

* **Policy validation is asynchronous.** `CreatePolicy` returns `CREATING` and
  the Cedar verdict lands seconds later. Reading the status straight back
  concludes that every policy is fine, including the ones that are not.
* **Deletion lags.** A policy disappears from `ListPolicies` before it stops
  being enforced, and a policy still `CREATING` refuses deletion with
  `ConflictException` for a few seconds. A caller that deletes and immediately
  measures is measuring the deleted policy.
* **A denial is an answer, not an exception.** `call_through_gateway` returns a
  verdict rather than raising, which is what lets the agent report a refusal to
  the user instead of crashing on it.
"""

import time
from typing import Any, Dict, List, Optional

import botocore.exceptions

import fm_config
import fm_mcp
import fm_resources

# The MCP error code a gateway uses for a policy refusal. Anything else is a
# genuine failure and must not be reported as a denial.
POLICY_DENIED_CODE = -32002


def action(target: str, tool: str) -> str:
    """The Cedar action id for a tool: `<target>___<tool>`, three underscores."""
    return f'{target}___{tool}'


# ------------------------------------------------------------------- verdicts

class Decision:
    """The outcome of one governed call, with the reason it went that way."""

    def __init__(self, tool: str, arguments: Dict[str, Any]):
        self.tool = tool
        self.arguments = arguments
        self.verdict = 'UNKNOWN'
        self.deciding_policy: Optional[str] = None
        self.policy_message: Optional[str] = None
        self.latency_ms: float = 0.0
        self.backend: Dict[str, Any] = {}

    @property
    def allowed(self) -> bool:
        return self.verdict == 'ALLOWED'

    def to_dict(self) -> Dict[str, Any]:
        return {'tool': self.tool, 'arguments': self.arguments,
                'verdict': self.verdict,
                'deciding_policy': self.deciding_policy,
                'policy_message': self.policy_message,
                'latency_ms': self.latency_ms, 'backend': self.backend}


def deciding_policy(message: str) -> Optional[str]:
    """Pull the policy name out of a denial message.

    Two shapes, and they mean different things - one is a rule somebody wrote
    saying no, the other is nothing saying yes:

        [Policy evaluation denied due to <name>-<id>]
        [No policy applies to the request (denied by default)]
    """
    marker = 'Policy evaluation denied due to '
    if marker in (message or ''):
        return message.split(marker, 1)[1].rstrip('] ').strip()
    if 'No policy applies' in (message or ''):
        return 'default-deny (no policy grants this)'
    return None


def call_through_gateway(client, tool: str,
                         arguments: Dict[str, Any]) -> Decision:
    """Invoke one tool through the gateway and record the verdict."""
    decision = Decision(tool, arguments)
    try:
        result = client.call_tool(tool, arguments)
    except fm_mcp.McpError as exc:
        decision.verdict = ('DENIED' if exc.code == POLICY_DENIED_CODE
                            else f'ERROR({exc.code})')
        decision.policy_message = exc.message
        decision.deciding_policy = deciding_policy(exc.message)
        return decision
    decision.verdict = 'ALLOWED'
    decision.latency_ms = result.get('_latency_ms', 0.0)
    decision.backend = _unwrap_backend(client.tool_text(result))
    if client.is_tool_error(result):
        decision.backend['_tool_error'] = True
    return decision


def _unwrap_backend(text: str) -> Dict[str, Any]:
    """Parse a tool's text payload, which may be JSON or a JSON-RPC envelope.

    Recursive, because a Lambda target that is itself an MCP server returns an
    envelope *inside* the content text, so the useful payload is two or three
    unwraps down.
    """
    import json
    current: Any = text
    for _ in range(4):
        if isinstance(current, str):
            try:
                current = json.loads(current)
            except (json.JSONDecodeError, TypeError):
                return {'text': str(current)[:2000]}
        if isinstance(current, dict):
            if 'result' in current and 'jsonrpc' in current:
                content = (current.get('result') or {}).get('content') or []
                current = (content[0].get('text') if content
                           else current['result'])
                continue
            return current
        return {'value': current}
    return {} if not isinstance(current, dict) else current


def mcp_client_for(gateway: Dict[str, Any]):
    """An MCP client for a discovered gateway."""
    return fm_mcp.McpGatewayClient(gateway['gateway_id'],
                                   url=gateway.get('gateway_url'))


def visible_tools(gateway: Dict[str, Any]) -> List[str]:
    """What the gateway will admit to having.

    Worth calling rather than assuming: under enforcement a tool no policy
    covers is **not listed at all**, so this is the clearest view of what an
    agent can actually reach.
    """
    client = mcp_client_for(gateway)
    return sorted(client.tool_names())


# ----------------------------------------------------------- policy lifecycle

def wait_policy(control, engine_id: str, policy_id: str,
                timeout: int = 120) -> Dict[str, Any]:
    """Wait out asynchronous Cedar validation."""
    deadline = time.time() + timeout
    last: Dict[str, Any] = {}
    while time.time() < deadline:
        last = control.get_policy(policyEngineId=engine_id,
                                  policyId=policy_id)
        last.pop('ResponseMetadata', None)
        if last.get('status') in ('ACTIVE', 'CREATE_FAILED', 'UPDATE_FAILED',
                                  'FAILED', 'INVALID'):
            return last
        time.sleep(2)
    return last


def install(control, engine_id: str, spec: Dict[str, Any],
            say=print) -> Dict[str, Any]:
    """Create one policy and report what the engine made of it.

    Returns a record whether or not creation succeeded: a refusal text is a
    result, and some specs are *expected* to be refused.
    """
    record = {'key': spec['name'], 'name': spec['name'],
              'kind': spec.get('kind'), 'plain': spec.get('plain'),
              'statement': spec['statement'],
              'enforcement_mode': spec.get('enforcement', 'ACTIVE'),
              'expect_status': spec.get('expect_status', 'ACTIVE')}
    try:
        response = control.create_policy(
            policyEngineId=engine_id,
            name=spec['name'],
            description=spec.get('description', ''),
            definition={'cedar': {'statement': spec['statement']}},
            enforcementMode=spec.get('enforcement', 'ACTIVE'))
    except botocore.exceptions.ClientError as exc:
        record.update({'status': 'REFUSED_AT_API', 'policy_id': None,
                       'status_reasons': [exc.response['Error']['Message']]})
        record['as_predicted'] = record['expect_status'] != 'ACTIVE'
        say(f"  policy          {spec['name']} -> REFUSED_AT_API")
        return record
    policy_id = response['policyId']
    detail = wait_policy(control, engine_id, policy_id)
    record.update({'policy_id': policy_id, 'status': detail.get('status'),
                   'status_reasons': detail.get('statusReasons') or []})
    record['as_predicted'] = record['status'] == record['expect_status']
    say(f"  policy          {spec['name']} -> {record['status']}"
        f"{'' if record['as_predicted'] else '  (NOT as predicted)'}")
    return record


def uninstall(control, engine_id: str, policy_id: str, say=print,
              label: str = '') -> None:
    """Delete one policy, waiting out the state it cannot be deleted in.

    A policy still `CREATING` refuses deletion with `ConflictException`, and
    the window is a few seconds wide - wide enough that an install-then-remove
    pass hits it most times.
    """
    deadline = time.time() + 90
    while time.time() < deadline:
        try:
            control.delete_policy(policyEngineId=engine_id,
                                  policyId=policy_id)
            say(f'  removed policy  {label or policy_id}')
            return
        except botocore.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] != 'ConflictException':
                say(f'  could not remove {label or policy_id}: '
                    f"{exc.response['Error']['Code']}")
                return
            time.sleep(3)
    say(f'  could not remove {label or policy_id}: still conflicting after 90s')


def set_enforcement(control, engine_id: str, policy_id: str, mode: str,
                    say=print) -> Dict[str, Any]:
    """Flip one policy between shadow (`LOG_ONLY`) and enforcing (`ACTIVE`).

    One field, one call, no statement rewrite - which is the point.
    """
    control.update_policy(policyEngineId=engine_id, policyId=policy_id,
                          enforcementMode=mode)
    detail = wait_policy(control, engine_id, policy_id)
    say(f'  enforcement     {policy_id} -> {mode} ({detail.get("status")})')
    return detail


def policies_with_prefix(control, engine_id: str,
                         prefix: str) -> Dict[str, Dict[str, Any]]:
    """Every policy on the engine whose name starts with `prefix`.

    Prefix-scoped because this engine is shared: each project removes only its
    own, in either direction.
    """
    found: Dict[str, Dict[str, Any]] = {}
    token = None
    while True:
        kwargs: Dict[str, Any] = {'policyEngineId': engine_id,
                                  'maxResults': 50}
        if token:
            kwargs['nextToken'] = token
        page = control.list_policies(**kwargs)
        # `list_policies` returns `policies`, not the `items` most of this
        # control plane uses.
        for item in page.get('policies', page.get('items', [])):
            if str(item.get('name', '')).startswith(prefix):
                found[item['name']] = item
        token = page.get('nextToken')
        if not token:
            return found
