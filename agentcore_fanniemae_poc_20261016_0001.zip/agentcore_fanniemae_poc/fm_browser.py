"""Read a price off a live retail page using the managed browser.

This is the step that justifies the browser's existence in this use case, and
it is worth being precise about why. Web search already returns extracted body
text, and sometimes a price is in it. But search text is a snapshot taken by
the connector, and retail prices are exactly the kind of thing that is
rendered client-side, localised, or changed after the crawl. If we are going to
move money based on a competitor's price, the agent should read the page as a
customer would see it *now*.

So the division of labour is:

    web search  ->  which pages are worth looking at   (through the gateway)
    browser     ->  what the page says right now       (NOT through the gateway)

The second half of that is the governance story. Browser is not a Gateway
target type - there is no browser option in `CreateGatewayTarget` - so these
calls go straight to the `bedrock-agentcore` data plane, authorised by IAM
alone. The Cedar policy that adjudicates the refund has no visibility of them.
That asymmetry is real and this POC shows it rather than hiding it.

Two access paths exist, and only one is useful:

    InvokeBrowser      mouseClick, keyType, screenshot, ... and no navigate
    automationStream   a CDP websocket - full Chrome, via Playwright

There is no navigation primitive in `InvokeBrowser`, so the SDK alone cannot
open a URL. Real work goes over the CDP endpoint, whose websocket upgrade must
be SigV4-signed by hand because no AWS SDK does it for you.
"""
# Ported into this project verbatim so that nothing in this folder
# imports another project. The ONLY change from the original is the
# `import fm_config as config` line below. The behaviour here was
# measured against live AgentCore - do not tidy it without
# re-measuring.


import json
import os
import re
import time
from typing import Any, Dict, List, Optional

import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest

import fm_config as config

# Prices as a customer sees them. Deliberately conservative: a currency symbol
# followed by a plausible amount. Matching bare numbers would happily pick up
# capacities ("24,000mAh"), review counts and model numbers.
PRICE_PATTERN = re.compile(r'[$£€]\s?([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?)')

# Pull every JSON-LD block and the price-bearing meta tags out of the DOM in
# one round trip. This is the whole reason the browser step uses CDP rather
# than the search connector's extracted text: structured data is in the
# document, not in the prose.
_EXTRACT_JS = '''() => ({
    title: document.title,
    url: document.location.href,
    text: document.body ? document.body.innerText : "",
    jsonld: [...document.querySelectorAll('script[type="application/ld+json"]')]
              .map(s => s.textContent),
    metas: [...document.querySelectorAll('meta')]
             .map(m => ({
                 key: m.getAttribute('property') || m.getAttribute('itemprop')
                      || m.getAttribute('name') || '',
                 value: m.getAttribute('content') || ''}))
             .filter(m => /price/i.test(m.key) && m.value),
    itemprops: [...document.querySelectorAll('[itemprop="price"]')]
                 .map(e => e.getAttribute('content') || e.innerText || '')
})'''

# Meta keys that carry a machine-readable price, best first.
_PRICE_META_KEYS = ('product:price:amount', 'og:price:amount', 'price',
                    'twitter:data1')


def _as_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    cleaned = re.sub(r'[^0-9.]', '', str(value))
    try:
        return float(cleaned) if cleaned else None
    except ValueError:
        return None


def _walk_jsonld(node: Any):
    """Yield every dict in a JSON-LD document, however it is nested.

    Real sites nest `Product` under `@graph`, inside arrays, or inside
    `mainEntity`, so a top-level type check misses most of them.
    """
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from _walk_jsonld(value)
    elif isinstance(node, list):
        for item in node:
            yield from _walk_jsonld(item)


def _price_from_jsonld(blocks: List[str]) -> Optional[Dict[str, Any]]:
    """The authoritative price, when the page publishes schema.org Product.

    Preferred over anything scraped from prose because it is the number the
    retailer declares to search engines - it is their own machine-readable
    answer to "what does this cost", not our inference from their layout.
    """
    for block in blocks:
        try:
            document = json.loads(block)
        except (json.JSONDecodeError, TypeError):
            continue
        for node in _walk_jsonld(document):
            types = node.get('@type')
            types = types if isinstance(types, list) else [types]
            if 'Product' not in types:
                continue
            offers = node.get('offers')
            for offer in (offers if isinstance(offers, list) else [offers]):
                if not isinstance(offer, dict):
                    continue
                # AggregateOffer publishes a range; the low end is the one a
                # price-match claim is about.
                for key in ('price', 'lowPrice'):
                    value = _as_float(offer.get(key))
                    if value:
                        return {'price': value,
                                'currency': offer.get('priceCurrency'),
                                'product': node.get('name'),
                                'source': f'json-ld Product.offers.{key}'}
    return None


def _price_from_meta(metas: List[Dict[str, str]],
                     itemprops: List[str]) -> Optional[Dict[str, Any]]:
    lookup = {m['key'].lower(): m['value'] for m in metas}
    for key in _PRICE_META_KEYS:
        if key in lookup:
            value = _as_float(lookup[key])
            if value:
                return {'price': value, 'source': f'meta[{key}]'}
    for raw in itemprops:
        value = _as_float(raw)
        if value:
            return {'price': value, 'source': 'itemprop=price'}
    return None


def _signed_cdp_headers(endpoint: str) -> Dict[str, str]:
    """SigV4 headers for the CDP websocket upgrade.

    botocore has no ws:// signer, but the signature is computed over the
    equivalent https GET, which is what the service validates. Only the
    auth-bearing headers are passed on; sending the rest confuses the upgrade.
    """
    request = AWSRequest(method='GET',
                         url=endpoint.replace('wss://', 'https://', 1))
    credentials = boto3.Session().get_credentials().get_frozen_credentials()
    SigV4Auth(credentials, 'bedrock-agentcore', config.REGION).add_auth(request)
    return {k: v for k, v in dict(request.headers).items()
            if k.lower() in ('authorization', 'x-amz-date',
                             'x-amz-security-token', 'x-amz-content-sha256')}


def _plausible_prices(text: str, floor: float, ceiling: float) -> List[float]:
    found = []
    for raw in PRICE_PATTERN.findall(text):
        try:
            value = float(raw.replace(',', ''))
        except ValueError:
            continue
        if floor <= value <= ceiling:
            found.append(value)
    return found


class ManagedBrowser:
    """One managed Chrome session, used as a context manager.

    Sessions bill until stopped and the timeout is a safety net rather than a
    billing strategy, so `__exit__` stops the session unconditionally.
    """

    def __init__(self, label: str = 'novacart-poc'):
        self.label = label
        self.data = boto3.client('bedrock-agentcore', region_name=config.REGION)
        self.session_id: Optional[str] = None
        self.automation_endpoint: Optional[str] = None
        self.live_view: Optional[str] = None
        self._pw = None
        self._browser = None
        self._page = None

    def __enter__(self) -> 'ManagedBrowser':
        response = self.data.start_browser_session(
            browserIdentifier=config.BROWSER_ID,
            name=f'{self.label}-{int(time.time())}',
            sessionTimeoutSeconds=config.BROWSER_SESSION_TIMEOUT,
            viewPort={'width': 1440, 'height': 900},
        )
        self.session_id = response['sessionId']
        streams = response.get('streams') or {}
        self.automation_endpoint = (
            (streams.get('automationStream') or {}).get('streamEndpoint'))
        # Worth surfacing in a demo: a human can watch the agent browse.
        self.live_view = (streams.get('liveViewStream') or {}).get('streamEndpoint')

        if not self.automation_endpoint:
            raise RuntimeError('session returned no automationStream endpoint')

        from playwright.sync_api import sync_playwright
        self._pw = sync_playwright().start()
        self._browser = self._pw.chromium.connect_over_cdp(
            self.automation_endpoint,
            headers=_signed_cdp_headers(self.automation_endpoint),
            timeout=60000)
        context = (self._browser.contexts[0] if self._browser.contexts
                   else self._browser.new_context())
        self._page = context.pages[0] if context.pages else context.new_page()
        return self

    def __exit__(self, *exc) -> None:
        for close in (lambda: self._browser and self._browser.close(),
                      lambda: self._pw and self._pw.stop()):
            try:
                close()
            except Exception:  # noqa: BLE001 - teardown must not mask errors
                pass
        if self.session_id:
            try:
                self.data.stop_browser_session(
                    browserIdentifier=config.BROWSER_ID,
                    sessionId=self.session_id)
            except Exception:  # noqa: BLE001
                pass

    @property
    def version(self) -> str:
        return self._browser.version if self._browser else 'unknown'

    def read_price(self, url: str, floor: float, ceiling: float,
                   screenshot_path: str = None) -> Dict[str, Any]:
        """Open a page and return what it says about price, and how we know.

        Extraction runs in three layers, best evidence first, and the layer
        that produced the answer is recorded as `price_source`. That matters
        more than it sounds: a refund traced to "the retailer's own
        schema.org Product offer" is defensible, and one traced to "the
        smallest dollar figure we saw in the page text" is not. The
        distinction is invisible unless you record it.

        The third layer is why this is needed at all. On a real product page
        the body text held eighteen plausible dollar amounts - accessories,
        bundle discounts, financing instalments, a strike-through was-price -
        and the lowest was $20.00 against a true price of $109.99. Reading
        prose gets you a number every time and the wrong number often.

        `floor`/`ceiling` bound what counts as plausible for the item in
        question, and apply to every layer.
        """
        record: Dict[str, Any] = {'url': url}
        try:
            self._page.goto(url, timeout=config.BROWSER_NAV_TIMEOUT_MS,
                            wait_until='domcontentloaded')
            # Retail pages render the price after first paint, so give the
            # network a moment - but do not insist on `networkidle`, which
            # never arrives on pages with analytics beacons or live chat.
            try:
                self._page.wait_for_load_state('load', timeout=8000)
            except Exception:  # noqa: BLE001
                pass
            time.sleep(1.5)

            # evaluate(), not a locator. A locator waits for its full timeout
            # when the selector is absent, which turns a page that simply looks
            # different into a misleading TimeoutError 30 seconds later.
            page_data = self._page.evaluate(_EXTRACT_JS)
        except Exception as e:  # noqa: BLE001 - one bad page must not end the run
            record.update({'ok': False, 'error': f'{type(e).__name__}: {e}'})
            return record

        text = page_data.get('text') or ''
        text_prices = _plausible_prices(text, floor, ceiling)
        record.update({
            'ok': True,
            'final_url': page_data.get('url'),
            'page_title': page_data.get('title'),
            'rendered_chars': len(text),
            'jsonld_blocks': len(page_data.get('jsonld') or []),
            'text_prices_found': sorted(set(text_prices)),
        })

        candidates = [
            _price_from_jsonld(page_data.get('jsonld') or []),
            _price_from_meta(page_data.get('metas') or [],
                             page_data.get('itemprops') or []),
            ({'price': min(text_prices),
              'source': 'page text (low confidence)'} if text_prices else None),
        ]
        for candidate in candidates:
            if candidate and floor <= candidate['price'] <= ceiling:
                record['price'] = candidate['price']
                record['price_source'] = candidate['source']
                record['currency'] = candidate.get('currency')
                record['product_name'] = candidate.get('product')
                break
        else:
            record['price'] = None
            record['price_source'] = None

        if screenshot_path:
            try:
                os.makedirs(os.path.dirname(screenshot_path), exist_ok=True)
                self._page.screenshot(path=screenshot_path, full_page=False)
                record['screenshot'] = screenshot_path
            except Exception as e:  # noqa: BLE001
                record['screenshot_error'] = str(e)
        return record


def find_competitor_price(urls: List[str], floor: float, ceiling: float,
                          artifact_prefix: str = None,
                          max_pages: int = 3,
                          say=print) -> Dict[str, Any]:
    """Visit candidate pages until one yields a plausible price.

    Returns the full visit log, not just the answer. A price-match refund that
    cannot be traced back to the page it came from is not auditable, and
    auditability is most of the point of doing this through governed
    infrastructure.
    """
    visits: List[Dict[str, Any]] = []
    outcome: Dict[str, Any] = {'price': None, 'source_url': None,
                               'visits': visits}

    with ManagedBrowser() as browser:
        outcome['browser_version'] = browser.version
        outcome['session_id'] = browser.session_id
        outcome['live_view_available'] = bool(browser.live_view)
        say(f'    managed Chrome {browser.version} '
            f'(session {browser.session_id[:24]}...)')

        for index, url in enumerate(urls[:max_pages]):
            shot = (f'{artifact_prefix}_page{index + 1}.png'
                    if artifact_prefix else None)
            visit = browser.read_price(url, floor, ceiling, screenshot_path=shot)
            visits.append(visit)

            if visit.get('ok'):
                say(f"    read {url[:68]}")
                say(f"         title={str(visit.get('page_title'))[:58]!r} "
                    f"rendered={visit.get('rendered_chars')} chars")
                if visit.get('price') is not None:
                    say(f"         price ${visit['price']:,.2f} "
                        f"{visit.get('currency') or ''} "
                        f"via {visit.get('price_source')}")
                else:
                    say('         no plausible price found on this page')
            else:
                say(f"    failed {url[:60]} -> {visit.get('error', '')[:70]}")

            if visit.get('price') is not None:
                outcome['price'] = visit['price']
                outcome['source_url'] = visit.get('final_url') or url
                outcome['screenshot'] = visit.get('screenshot')
                break

    outcome['pages_visited'] = len(visits)
    return outcome
