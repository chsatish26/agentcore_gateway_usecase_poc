"""One command line for the whole POC.

    python run_fm.py status                     what exists, what is missing
    python run_fm.py setup                      install this project's policies
    python run_fm.py research --mode with_gateway
    python run_fm.py research --mode without_gateway --hosted
    python run_fm.py security                   the nine identity/policy tests
    python run_fm.py testcases                  TC01-TC20
    python run_fm.py compare                    one prompt, both modes
    python run_fm.py teardown                   remove only what this project owns

`setup` is not a prerequisite for `research --mode without_gateway`, which
touches no policy at all. It *is* required for the gateway mode and for the
memory tests, so every command that needs it checks and says so rather than
failing at the point of use.
"""

import argparse
import json
import sys

import fm_config
import fm_policies
import fm_trace


def _say(message: str = '') -> None:
    print(message, flush=True)


def cmd_status() -> int:
    import fm_resources
    _say(f'Fannie Mae research POC — {fm_config.REGION}')
    _say(f'use case: {fm_config.USE_CASE}\n')

    _say('Shared AWS resources (discovered by name; not created here):')
    missing = []
    for name, info in fm_resources.resources(refresh=True).items():
        icon = 'ok ' if info['present'] else 'MISSING'
        _say(f"  {icon:<8} {name:<17} {info.get('id') or '-'}")
        if not info['present']:
            missing.append(name)

    _say('\nThis project owns:')
    try:
        import deploy_runtime
        runtime = deploy_runtime.status()
        _say(f"  {'ok ' if runtime['exists'] else 'MISSING':<8} "
             f"{'runtime':<17} {runtime.get('runtime_id') or '-'} "
             f"({runtime.get('status')})")
    except Exception as exc:                            # noqa: BLE001
        _say(f'  runtime check failed: {exc}')
    policies = fm_policies.status()
    _say(f"  {'ok ' if policies['ready_for_mode_b'] else 'MISSING':<8} "
         f"{'cedar policies':<17} "
         f"{', '.join(policies['fmpoc_policies']) or '-'}")

    if missing:
        _say(f'\nMissing borrowed resources: {missing}. Fix in '
             f'~/agentcore_gateway_usecase_poc:')
        _say('  python run_poc.py setup        # gateway, memory, identity')
        _say('  python memory_fgac.py run     # the memory FGAC gateway')
    if not policies['ready_for_mode_b']:
        _say('\nRun: python run_fm.py setup')
    return 0 if not missing else 1


def cmd_setup() -> int:
    result = fm_policies.ensure(_say)
    active = sum(1 for p in result['policies'].values()
                 if p.get('status') == 'ACTIVE')
    _say(f"\n{active}/{len(result['policies'])} policies ACTIVE on engine "
         f"{result['engine_id']}")
    return 0 if active == len(result['policies']) else 1


def cmd_research(mode: str, prompt: str, user: str, hosted: bool) -> int:
    if hosted:
        import invoke_runtime
        result = invoke_runtime.invoke(prompt, mode=mode, user=user, say=_say)
        if not result.get('ok'):
            _say(f"\nFAILED: {result.get('error')}")
            return 1
        _say(f"\nservices: {result.get('services_invoked')}")
        _say(f"\n{(result.get('answer') or {}).get('text', '')[:1200]}")
        path = fm_trace.write(result, f'research_hosted_{mode}')
    else:
        import research
        bundle = research.run(prompt, mode=mode, user=user, say=_say)
        _say(f"\n{bundle['answer']['text'][:1200]}")
        path = fm_trace.write(bundle, f'research_{mode}')
    _say(f'\nArtifact: {path}')
    _say('Open the app and pick "Ask the agent" to walk it.')
    return 0


def cmd_compare(prompt: str, user: str) -> int:
    import research
    bundles = {}
    for mode in fm_config.MODES:
        _say(f'\n=== {mode} ===')
        bundles[mode] = research.run(prompt, mode=mode, user=user, say=_say)
    import testcases
    rows = testcases.comparison_rows(bundles[fm_config.MODE_DIRECT],
                                     bundles[fm_config.MODE_GATEWAY])
    _say('\n' + '=' * 78)
    for row in rows:
        _say(f"\n{row['dimension']}")
        _say(f"  without gateway : {row['without_gateway']}")
        _say(f"  with gateway    : {row['with_gateway']}")
    path = fm_trace.write({'comparison': rows, 'runs': bundles}, 'compare')
    _say(f'\nArtifact: {path}')
    return 0


def cmd_security() -> int:
    import security_tests
    bundle = security_tests.run_all(_say)
    path = fm_trace.write(bundle, security_tests.ARTIFACT_PREFIX)
    _say(f'Artifact: {path}')
    return 0 if bundle['summary']['passed'] == bundle['summary']['total'] else 1


def cmd_testcases(include_hosted: bool, pdf: bool = True) -> int:
    import testcases
    bundle = testcases.run_all(include_hosted=include_hosted, say=_say)
    path = fm_trace.write(bundle, testcases.ARTIFACT_PREFIX)
    _say(f'\nArtifact: {path}')
    if pdf:
        import fm_report
        fm_report.build_all(bundle, say=_say)
    return 0 if bundle['summary']['failed'] == 0 else 1


def cmd_report(split: bool) -> int:
    """Render the newest test-case run as PDF(s) into artifacts/."""
    import fm_report
    import fm_trace
    bundle = fm_trace.latest('testcases')
    if not bundle:
        _say('No testcases_*.json in artifacts/. Run: '
             'python run_fm.py testcases')
        return 1
    _say(f"PDF [combined] : {fm_report.build(bundle)}")
    if split:
        for theme, where in fm_report.build_split(bundle).items():
            _say(f"PDF [{theme:<10}] : {where}")
    return 0


def cmd_teardown(yes: bool) -> int:
    """Remove only what this project created. Borrowed resources are left."""
    _say('This project owns two things: its Cedar policies (fmpoc_*) and its '
         'AgentCore Runtime.')
    _say('It will NOT touch the borrowed gateways, the policy engine, the '
         'memory resource, or the price-match POC\'s policies.')
    if not yes and input('Type "teardown" to confirm: ').strip() != 'teardown':
        _say('Cancelled.')
        return 1
    fm_policies.teardown(_say)
    import deploy_runtime
    deploy_runtime.destroy(yes=True)
    _say('\nDone. The memory events this POC wrote are left in place: they '
         'belong to the borrowed memory resource, which run_poc.py destroy '
         'owns.')
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description='AgentCore Gateway & Memory POC — Fannie Mae finance '
                    'use case')
    parser.add_argument('command',
                        choices=['status', 'setup', 'research', 'compare',
                                 'security', 'testcases', 'report',
                                 'teardown'])
    parser.add_argument('--mode', choices=list(fm_config.MODES),
                        default=fm_config.MODE_GATEWAY)
    parser.add_argument('--prompt', default=fm_config.DEFAULT_PROMPT)
    parser.add_argument('--user', default=fm_config.USER_PRIMARY)
    parser.add_argument('--hosted', action='store_true',
                        help='research: execute in AgentCore Runtime instead '
                             'of in this process')
    parser.add_argument('--no-hosted', action='store_true',
                        help='testcases: skip the Runtime invocations')
    parser.add_argument('--no-pdf', action='store_true',
                        help='testcases: skip rendering the PDF reports')
    parser.add_argument('--no-split', action='store_true',
                        help='report: write only the combined PDF, not the '
                             'three themed ones')
    parser.add_argument('--yes', action='store_true')
    args = parser.parse_args()

    if args.command == 'status':
        return cmd_status()
    if args.command == 'setup':
        return cmd_setup()
    if args.command == 'research':
        return cmd_research(args.mode, args.prompt, args.user, args.hosted)
    if args.command == 'compare':
        return cmd_compare(args.prompt, args.user)
    if args.command == 'security':
        return cmd_security()
    if args.command == 'testcases':
        return cmd_testcases(include_hosted=not args.no_hosted,
                             pdf=not args.no_pdf)
    if args.command == 'report':
        return cmd_report(split=not args.no_split)
    if args.command == 'teardown':
        return cmd_teardown(args.yes)
    # Every command is dispatched explicitly, and an unknown one is an error.
    # This used to fall through to `cmd_teardown`, which meant a newly added
    # command silently became "delete the runtime and the policies" - and with
    # `--yes` it would not even have asked. argparse `choices` makes this
    # branch unreachable today; it exists so the next command added here
    # cannot repeat that.
    _say(f'Unhandled command: {args.command!r}. Nothing was run.')
    return 2


if __name__ == '__main__':
    sys.exit(main())
