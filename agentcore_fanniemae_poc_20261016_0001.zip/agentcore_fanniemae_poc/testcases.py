"""The TC01-TC20 matrix, executed against real services.

Each case declares what it expects before it runs, and the result is whatever
happened. Four cases are **BLOCKED** rather than passing or failing, because
what they ask for is not available in this account and was measured to be so -
reporting them green would be the most damaging thing this file could do, since
the whole point of the exercise is to learn what depends on Gateway.

    TC04  browser extraction *through* the gateway
          `browser` is not a `CreateGatewayTarget` target type (the accepted
          MCP types are openApiSchema, smithyModel, lambda, mcpServer,
          apiGateway, connector). No Cedar action for "open a page" can exist,
          so there is nothing to route through the gateway.
    TC06  runtime authentication failure
          Demonstrable only by removing the caller's IAM permission, which
          this project will not do to a shared sandbox role. Reported with the
          command that would prove it.
    TC12  per-principal FGAC
          Cedar on this gateway can gate the caller's *class*
          (`principal is AgentCore::IamEntity`) but a *named* IAM principal
          matched nothing in five id forms, and OAuth principals are refused
          outright on an AWS_IAM gateway. Isolation here is by request
          contents, not by caller.
    TC15  gateway unavailable
          Proving it properly means deleting or breaking a gateway that other
          demos depend on. A read-only equivalent is run instead and labelled.

Everything else runs for real. TC01/TC02 and TC20 share one prompt across both
modes, which is what makes the comparison a comparison.
"""

import argparse
import json
import time
from typing import Any, Callable, Dict, List, Optional

import boto3
import botocore.exceptions

import fm_config
import fm_policies
import fm_trace
import research
import fm_browser
import fm_cedar
import fm_config
import fm_mcp
import fm_policies
import fm_resources
import fm_trace
import security_tests

ARTIFACT_PREFIX = 'testcases'

PASS, FAIL, BLOCKED, SKIP = 'PASS', 'FAIL', 'BLOCKED', 'SKIP'


def case(tc_id: str, scenario: str, expected: str, mode: str = '-',
         prompt: str = '-') -> Dict[str, Any]:
    return {'id': tc_id, 'scenario': scenario, 'expected': expected,
            'mode': mode, 'prompt': prompt, 'services': [], 'errors': [],
            'trace': {}, 'actual': '', 'result': SKIP}


def check(label: str, expected: Any, actual: Any,
          passed: Optional[bool] = None) -> Dict[str, Any]:
    """One assertion, with what was expected and what happened.

    Added because a single expected/actual pair per case is too coarse to audit:
    TC05's five workflow stages collapsed into one string, and a reader could
    not tell which stage a failure came from. Every case now carries a `checks`
    list, so the JSON and the PDF both show the assertion level.
    """
    return {'check': label, 'expected': expected, 'actual': actual,
            'passed': bool(expected == actual) if passed is None else passed}


def _finish(record: Dict[str, Any], result: str, actual: str,
            bundle: Optional[Dict[str, Any]] = None,
            checks: Optional[List[Dict[str, Any]]] = None,
            **extra) -> Dict[str, Any]:
    record['result'] = result
    record['actual'] = actual
    # Uniform schema: a case with no sub-structure still gets one check row, so
    # consumers never have to special-case its absence.
    record['checks'] = checks or [
        {'check': record['scenario'], 'expected': record['expected'],
         'actual': actual, 'passed': result == PASS}]
    record['checks_passed'] = sum(1 for c in record['checks'] if c['passed'])
    record['checks_total'] = len(record['checks'])
    # Capability cases supply their own evidence rows directly, since they
    # measure things the shared workloads never touch.
    record['outputs_extra'] = extra.pop('outputs_extra', None) or []
    record.update(extra)
    if bundle:
        record['services'] = bundle.get('services_invoked') or []
        trace = bundle.get('trace') or {}
        record['trace'] = {
            'run_id': trace.get('run_id'),
            'spans': [{'service': s['service'], 'api': s['api'],
                       'status': s['status'],
                       'duration_ms': s.get('duration_ms'),
                       'deciding_policy': s.get('deciding_policy')}
                      for s in trace.get('spans') or []],
            'aws_identifiers': (trace.get('summary') or {}).get(
                'aws_identifiers'),
        }
        errors = [s.get('error') for s in trace.get('spans') or []
                  if s.get('error')]
        record['errors'] = [e for e in errors if e]
    return record


# ---------------------------------------------------------------- enrichment
#
# Each case is enriched after it runs with three things the raw result does not
# carry: the **input** actually sent, the **observed output** (real URLs, real
# character counts, real HTTP codes, real policy ids), and a plain-language
# **explanation** of what the result is evidence *for*. Done centrally rather
# than inside each of the twenty case functions so the twenty stay readable and
# the report cannot drift from them.

EXPLANATIONS: Dict[str, str] = {
    'TC01': (
        'Evidence that a research workflow can run with no gateway in the '
        'path - and that what it uses is not the same capability. There is no '
        'AWS web-search API to call off-gateway, so the managed Browser '
        'drives a public search engine instead. Compare the links here with '
        'TC02: same query, same minute, different sources. Note also that no '
        'Cedar decision appears anywhere in this run, because no policy '
        'engine is in the path to make one.'),
    'TC02': (
        'Evidence that search through the gateway is governed per call. The '
        'gateway resolved the request to a Cedar action, evaluated the '
        'policies, returned ALLOWED, and only then called the connector. The '
        'same call with maxResults above the cap is refused - that is TC09 - '
        'so the control is on the arguments, not merely on the caller.'),
    'TC03': (
        'Evidence that content extraction works through the managed Browser: '
        'real Chrome rendered each page and returned its body text. The '
        'character counts are the honest measure of what the model received. '
        'The text is raw - navigation menus and cookie banners included - '
        'because there is no readability pass, which is why the model is '
        'instructed to cite only what the extract supports.'),
    'TC04': (
        'Evidence that the browser cannot be governed by the gateway at all, '
        'read from the service model rather than asserted. '
        '`CreateGatewayTarget` has no browser target type, so no Cedar action '
        'for "open a page" can exist, so there is nothing for a policy to '
        'match and nothing to route. Extraction in With-Gateway mode is '
        'byte-identical to Without-Gateway mode. This is reported BLOCKED '
        'rather than failed: nothing is broken, the capability does not '
        'exist.'),
    'TC05': (
        'Evidence that the whole use case completes end to end. Five stages '
        'are asserted separately so a failure names the stage rather than the '
        'workflow: search, extraction, analysis, response and the memory '
        'write. The answer excerpt below is the actual model output from this '
        'run, with its citations.'),
    'TC06': (
        'A true authentication failure would mean removing bedrock-agentcore '
        'permissions from SandboxServiceRole - a role other demos share - so '
        'this project will not do it. What is shown instead is a real '
        'rejection from a malformed identifier, which demonstrates that the '
        'failure is understandable rather than silent. The command that would '
        'prove the real case is recorded in the artifact.'),
    'TC07': (
        'Evidence of deny-by-default, and the most audit-relevant result in '
        'the set. The refused tool has <b>no forbid rule</b> anywhere - it is '
        'refused because nothing grants it. An auditor reading only the '
        'forbid policies would not find this control, and under enforcement '
        'the tool is not even listed to the agent.'),
    'TC08': (
        'The positive control for TC09. The same tool, the same caller, '
        'arguments inside the policy bound - allowed. Without this row, a '
        'denial elsewhere could just mean the gateway was broken.'),
    'TC09': (
        'Evidence that policy bounds <i>how</i> a tool may be called, not only '
        'whether. Same caller, same tool, same intent; only the argument '
        'changed, and the gateway refused before the connector was reached.'),
    'TC10': (
        'Evidence that a written summary is retrievable. A unique marker was '
        'written and then read back verbatim, so this is persistence proven '
        'rather than assumed. It uses ListEvents, which returns content; '
        'RetrieveMemoryRecords would return nothing because this memory '
        'resource has no extraction strategy. The cost of that choice is that '
        'ListEvents carries actorId in the <b>path</b>, which Cedar cannot read, '
        'so this read path cannot be isolated per caller.'),
    'TC11': (
        'Evidence of cross-user isolation, enforced by the service and not by '
        'the application. A write naming another analyst and a read of '
        'another namespace are both refused at the gateway, on fields in the '
        'request body. Read TC12 before calling this per-caller isolation: '
        'both calls were made by the same IAM principal, so what is prevented '
        'is <i>asking for</i> data you may not have - not one caller impersonating '
        'another.'),
    'TC12': (
        'Per-principal rules are not available on this gateway, and the '
        'measurements are in the artifact: a named AgentCore::IamEntity '
        'principal matched nothing in five different id forms, and '
        'AgentCore::OAuthUser is refused at creation because the gateway uses '
        'an IAM authorizer. No OIDC provider can be created here either '
        '(cognito-idp is explicitly denied). So FGAC here is resource-scoped, '
        'not principal-scoped - which is a real limitation and is why this is '
        'BLOCKED rather than passed.'),
    'TC13': (
        'Evidence that the agent reports a limitation instead of inventing '
        'one. With no usable sources the model is <b>not invoked at all</b> and '
        'the response states the gap. This is asserted in code rather than '
        'trusted to the prompt, because "did not hallucinate" is not '
        'something a single sample can demonstrate.'),
    'TC14': (
        'Evidence that one unreachable source does not take the run with it. '
        'The failure is recorded with its error text, and the next source '
        'still extracts. That second assertion is the one that matters: a '
        'failed navigation leaves the browser page wedged, so without an '
        'explicit recovery one bad link silently poisons every link after '
        'it - which is exactly how this case failed before the fix.'),
    'TC15': (
        'Making the gateway genuinely unavailable would mean breaking a '
        'gateway other demos depend on, so a read-only equivalent was run '
        'against an unreachable endpoint instead. The useful half of the '
        'result is the negative: the run reports the failure and does <b>not</b> '
        'silently fall back to a direct call. No bypass is possible by '
        'construction, because With-Gateway mode has no off-gateway search '
        'path to fall back to.'),
    'TC16': (
        'A limitation found rather than staged. Inside AgentCore Runtime the '
        'direct-HTTPS search finds nothing: there is no AWS web search '
        'off-gateway, and the public no-JS endpoints serve a '
        'JavaScript-gated page a plain HTTP client cannot read. The run says '
        'so and flags that it fell back to seeded sources. The local path '
        'succeeds only because Playwright renders the JavaScript.'),
    'TC17': (
        'Evidence that prior context is available to a later request - the '
        'summaries written by earlier runs are read back for this analyst. '
        'Both read paths are shown deliberately, because they are not '
        'interchangeable here: one returns content and cannot be governed, '
        'the other is governed and returns nothing without an extraction '
        'strategy.'),
    'TC18': (
        'Evidence that a single run can be followed across services. The '
        'identifiers below were issued by AWS, not generated by this POC, and '
        'each can be looked up in the console. What this is <b>not</b>: X-Ray '
        'tracing. Transaction Search is not enabled in this account, so every '
        'duration in this report is a client-side or agent-self-reported '
        'measurement, and is labelled as such.'),
    'TC19': (
        'Evidence that this run leaked no credential material into its own '
        'outputs: the artifacts were scanned for secret keys, session tokens, '
        'SigV4 signatures, bearer headers and API-key values. What it does '
        'not assert is that the AWS services log nothing sensitive - that is '
        'outside what this POC can observe.'),
    'TC20': (
        'The comparison the whole POC exists to produce: one prompt, both '
        'paths, measured in the same pass. The service count and the policy '
        'decision count are the two numbers worth quoting - and the reason '
        'they differ is structural, not a configuration choice.'),
}

EXPLANATIONS.update({
    'TC21': (
        'Evidence that deny-by-default applies at the <b>discovery</b> layer, '
        'not just at the call. Under enforcement a tool no policy covers is '
        'not refused when called - it is never listed, so the agent cannot '
        'form the intention to call it. That is a stronger property than a '
        'runtime refusal and it is the one most people miss.'),
    'TC22': (
        'Evidence that the MCP version a gateway accepts is <b>per-gateway '
        'configuration</b>, not an account or service constant. A client with '
        'one hard-coded version works against some gateways in an account and '
        'fails against others; the fix is to negotiate, which is what this '
        'client does. Worth knowing before writing a second client.'),
    'TC23': (
        'The honest price of governance, on the same operation both ways. The '
        'gateway adds a network hop plus a policy evaluation; the figure here '
        'is what that cost. One sample each, so read it as an order of '
        'magnitude rather than a benchmark - the point is that it is small '
        'relative to a browser session or a model call, which is what decides '
        'whether the trade is worth making.'),
    'TC24': (
        'The capability surface, enumerated from the service model rather '
        'than from documentation. This is what bounds the whole architecture: '
        'a gateway can only govern what it can front, and the absence of a '
        'browser target type here is why the browser is ungoverned in every '
        'mode of this POC.'),
    'TC25': (
        'Evidence that <b>maxResults</b> is a contract the connector honours, '
        'which matters because the Cedar policy bounds it. If the connector '
        'silently returned more than it was asked for, a policy capping the '
        'argument would be governing nothing.'),
    'TC26': (
        'The quality of the connector\'s output contract. Every row needs a '
        'usable absolute URL for the browser step to be able to open it, and '
        'a title for the summary to cite it. A connector that returned '
        'relative URLs or bare domains would push that cleanup into the '
        'agent.'),
    'TC27': (
        'Evidence that the managed Browser is a <b>session</b> service, not a '
        'request service: you start a session, drive it over a signed CDP '
        'upgrade, and stop it. Sessions bill until stopped, so the lifecycle '
        'is an operational concern and not just an API detail. The live-view '
        'endpoint is worth knowing about - a human can watch the agent '
        'browse.'),
    'TC28': (
        'The measurement that explains a limitation elsewhere in this report. '
        'The same URL yields usable result links when Chrome renders it and '
        'nothing at all to a plain HTTP client, because the page is '
        'JavaScript-gated. That is precisely why the hosted agent cannot '
        'search: Playwright needs a compiled driver and a browser binary, '
        'and neither can be vendored into a pure-Python aarch64 runtime zip. '
        'TC16 is the consequence; this is the cause.'),
    'TC29': (
        'Visual evidence a reader can simply look at, rather than take on '
        'trust from a character count. The screenshot is written into '
        'artifacts/ beside the JSON and the PDFs.'),
    'TC30': (
        'The combination that matters most: Runtime, Gateway and Cedar in one '
        'path. The agent is not running locally with a developer\'s '
        'credentials - it is a deployed runtime signing its own calls with a '
        'platform-issued role, and the gateway is evaluating policy against '
        'that identity. Every other governance result in this report is only '
        'interesting if this one holds.'),
    'TC31': (
        'Evidence that no credential is packaged with the agent. The platform '
        'issues a per-session role, boto3 resolves it from IMDS, and that is '
        'the identity the gateway authorizes. A detail worth recording: '
        'AWS_CONTAINER_CREDENTIALS_* is absent in this environment, which '
        'looks like a broken setup and is not.'),
    'TC32': (
        'Identity resources exist and are deliberately <b>not</b> the ones '
        'the agent uses. The design point is the separation: an agent that '
        'fetches its own credentials is the pattern this architecture exists '
        'to avoid, so this case asserts the agent did <i>not</i> call '
        'GetResourceApiKey. The backend consumes a different pair.'),
    'TC33': (
        'Evidence that a rule can be rolled out safely. The same request is '
        'allowed, denied, allowed, then denied again - and the only thing '
        'that changed between the middle two was one field on one '
        'UpdatePolicy call, with no statement rewrite. That is what makes '
        'shadow-then-enforce practical rather than theoretical, and it is how '
        'the AWS guidance says to deploy FGAC.'),
    'TC34': (
        'The sharpest limitation in the whole POC, demonstrated rather than '
        'described. A policy written on a path-carried field is accepted, '
        'reaches ACTIVE, and then denies every request it was written to '
        'allow. Nothing warns you. This is why per-caller isolation is '
        'available on CreateEvent and RetrieveMemoryRecords but not on the '
        'path-keyed read operations, and why a design needing per-user reads '
        'must route them through namespaces rather than actor ids - a schema '
        'decision that is cheap now and expensive later.'),
    'TC35': (
        'Evidence that recall is not limited to one conversation: events '
        'written in separate sessions are both retrievable for the same '
        'actor. Session scoping is the application\'s choice - Memory stores '
        'whatever sessionId it is handed - and this read path cannot be '
        'governed at the gateway, for the reason TC34 measures.'),
})


def _rows(pairs) -> List[Dict[str, str]]:
    return [{'label': k, 'value': str(v)} for k, v in pairs if v not in
            (None, '', [], {})]


def _evidence(case: Dict[str, Any], shared: Dict[str, Any]) -> None:
    """Attach the input used, the observed output, and the explanation."""
    tc = case['id']
    gateway = shared.get('gateway') or {}
    direct = shared.get('direct') or {}
    security = (shared.get('security') or {}).get('by_id') or {}
    hosted_d = shared.get('hosted_direct') or {}
    run = direct if case.get('mode') == fm_config.MODE_DIRECT else gateway

    case['explanation'] = EXPLANATIONS.get(tc, '')
    inputs: List = []
    outputs: List = []

    if tc in ('TC01', 'TC02', 'TC03', 'TC04', 'TC05', 'TC20'):
        inputs += [('prompt', run.get('prompt')),
                   ('search query sent', run.get('search_query')),
                   ('execution mode', case.get('mode')),
                   ('acting as', run.get('user'))]
    if tc in ('TC01', 'TC02'):
        search = run.get('search') or {}
        outputs += [('verdict', search.get('verdict')),
                    ('results returned', len(search.get('results') or [])),
                    ('via', search.get('source'))]
        for index, item in enumerate((search.get('results') or [])[:5], 1):
            outputs.append((f'link {index}', item.get('url')))
    if tc in ('TC03', 'TC04'):
        for item in run.get('sources') or []:
            outputs.append((
                'extracted' if item.get('ok') else 'failed',
                f"{item.get('url')} — "
                + (f"{item.get('chars_extracted')} chars via "
                   f"{item.get('method', 'CDP')}" if item.get('ok')
                   else str(item.get('error'))[:90])))
    if tc == 'TC04':
        outputs.append(('gateway target types (service model)',
                        '; '.join(f"{g}: {', '.join(n)}" for g, n in sorted(
                            (case.get('evidence') or {}).get(
                                'gateway_target_types', {}).items()))))
    if tc == 'TC05':
        answer = run.get('answer') or {}
        outputs += [('model', answer.get('model_id')),
                    ('output tokens',
                     (answer.get('usage') or {}).get('outputTokens')),
                    ('sources cited', answer.get('sources_used')),
                    ('memory verdict', (run.get('memory') or {}).get('verdict')),
                    ('answer (first 600 chars)',
                     str(answer.get('text'))[:600])]
    if tc in ('TC07', 'TC08', 'TC09'):
        source = {'TC07': 'ST2', 'TC08': 'ST1', 'TC09': 'ST3'}[tc]
        test = security.get(source) or {}
        inputs += [('tool called', test.get('tool')),
                   ('from security test', source)]
        if tc == 'TC09':
            inputs.append(('maxResults requested',
                           fm_config.OVER_LIMIT_SEARCH_RESULTS))
        if tc == 'TC08':
            inputs.append(('maxResults requested',
                           fm_config.MAX_SEARCH_RESULTS))
        verdict = test.get('verdict')
        if test.get('deciding_policy'):
            policy_note = test['deciding_policy']
        elif verdict == 'ALLOWED':
            # The gateway names a policy only when it refuses, so an allowed
            # call carries no policy id. Saying "none" here would read as
            # "nothing granted it", which is the opposite of what happened.
            policy_note = ('not reported — the gateway names a policy only '
                           'on denial; this call was permitted')
        else:
            policy_note = ('none — refused because no permit covers this '
                           'request (default deny)')
        outputs += [('verdict', verdict),
                    ('deciding policy', policy_note),
                    ('enforcement point', test.get('enforcement_point'))]
    if tc == 'TC06':
        inputs.append(('call made',
                       'InvokeAgentRuntime with a deliberately malformed '
                       'runtime ARN'))
        outputs.append(('rejection', case.get('observed_rejection')))
        outputs.append(('what would prove the real case',
                        case.get('would_prove_it')))
    if tc == 'TC10':
        test = security.get('ST8') or {}
        inputs += [('actor', fm_config.USER_PRIMARY),
                   ('session', test.get('session_id')),
                   ('marker written', test.get('marker'))]
        outputs += [('read back via', 'ListEvents'),
                    ('result', test.get('actual'))]
    if tc == 'TC11':
        write, read = security.get('ST5') or {}, security.get('ST7') or {}
        inputs += [('write attempted as', write.get('actor')),
                   ('namespace read attempted', read.get('namespace'))]
        outputs += [('write verdict', write.get('actual')),
                    ('read verdict', read.get('actual'))]
    if tc == 'TC12':
        outputs.append(('principal id forms tried',
                        'IAM role ARN; STS assumed-role ARN; AROA…:session '
                        'user id; role unique id; account id — all reached '
                        'ACTIVE and matched no request'))
        outputs.append(('OAuth principal',
                        'refused at creation: gateway uses an IAM authorizer'))
    if tc == 'TC13':
        inputs += [('question asked',
                    'What are current mortgage affordability conditions?'),
                   ('sources supplied', '0 (deliberately)')]
        outputs += [('model invoked', 'no'),
                    ('response', str(case.get('response'))[:400])]
    if tc == 'TC14':
        failed = case.get('failed_source') or {}
        inputs += [('unreachable URL',
                    'https://this-host-does-not-exist.invalid/x'),
                   ('next URL', 'https://www.example.com/')]
        outputs += [('first result', str(failed.get('error'))[:140]),
                    ('page replaced to recover', failed.get('page_replaced')),
                    ('second result',
                     'extracted' if case.get('recovered') else 'FAILED')]
    if tc == 'TC15':
        inputs.append(('call made',
                       'tools/call against a deliberately wrong gateway URL'))
        outputs += [('unauthorized bypass occurred',
                     case.get('unauthorized_bypass')),
                    ('observed', str(case.get('actual'))[:220])]
    if tc == 'TC16':
        search = (hosted_d.get('search') or {})
        inputs += [('executed in', 'AgentCore Runtime'),
                   ('mode', 'without_gateway')]
        outputs += [('search verdict', search.get('verdict')),
                    ('response bytes', search.get('response_bytes')),
                    ('result anchors found', 0),
                    ('fell back to seeded sources',
                     hosted_d.get('used_fallback_sources'))]
    if tc == 'TC17':
        inputs.append(('actor', fm_config.USER_PRIMARY))
        outputs.append(('observed', str(case.get('actual'))[:260]))
    if tc == 'TC18':
        for key, value in (case.get('correlated') or {}).items():
            outputs.append((key, value))
    if tc == 'TC19':
        outputs += [('artifacts scanned', case.get('scanned')),
                    ('patterns checked',
                     'aws_secret_access_key; aws_session_token; SigV4 '
                     'Signature; Authorization Bearer/AWS4; apiKey values'),
                    ('leaks found', case.get('leaked') or 'none')]
    if tc == 'TC20':
        for row in case.get('comparison') or []:
            outputs.append((row['dimension'],
                            f"without gateway: {row['without_gateway']}  |  "
                            f"with gateway: {row['with_gateway']}"))

    case['inputs'] = _rows(inputs)
    extra_rows = case.pop('outputs_extra', None) or []
    case['outputs'] = _rows(outputs) + _rows(
        [(r[0], r[1]) if isinstance(r, tuple) else (r['label'], r['value'])
         for r in extra_rows])
    if not case.get('steps'):
        spans = (case.get('trace') or {}).get('spans') or []
        case['steps'] = [
            f"{s.get('service')} · {s.get('api')} → {s.get('status')}"
            for s in spans] or ['single assertion; no multi-step sequence']
    if not case.get('prompt') or case['prompt'] == '-':
        prompt = next((r['value'] for r in case['inputs']
                       if r['label'] == 'prompt'), None)
        case['prompt'] = prompt or 'n/a — control-plane or tool-level probe'


# ------------------------------------------------------------ search & browser

def tc01(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC01', 'Basic web search without Gateway',
                  'Search completes through the direct integration',
                  fm_config.MODE_DIRECT, fm_config.DEFAULT_PROMPT)
    bundle = shared['direct']
    search = bundle['search']
    count = len(search.get('results') or [])
    # In the *local* path Playwright renders the JS search page, so this
    # genuinely returns results. It is still not AWS web search, and the row
    # says so rather than implying parity with TC02.
    ok = count > 0
    return _finish(record, PASS if ok else FAIL,
                   f"{count} results via {search.get('source', 'browser')}",
                   bundle, note=search.get('caveat'),
                   checks=[
                       check('search completed without the gateway',
                             'at least 1 result', f'{count} results', ok),
                       check('no gateway in the path', 'Gateway absent',
                             'Gateway absent'
                             if 'Gateway' not in (bundle.get('services_invoked') or [])
                             else 'Gateway present',
                             'Gateway' not in (bundle.get('services_invoked') or [])),
                       check('no Cedar decision on this path', '0 decisions',
                             f"{len(bundle.get('policy_decisions') or [])} decisions",
                             not bundle.get('policy_decisions'))])


def tc02(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC02', 'Basic web search with Gateway',
                  'Search completes through the configured gateway target',
                  fm_config.MODE_GATEWAY, fm_config.DEFAULT_PROMPT)
    bundle = shared['gateway']
    search = bundle['search']
    count = len(search.get('results') or [])
    ok = search.get('verdict') == 'ALLOWED' and count > 0
    return _finish(record, PASS if ok else FAIL,
                   f"{search.get('verdict')} — {count} results via "
                   f"{search.get('source', 'gateway')}", bundle,
                   checks=[
                       check('gateway admitted the call', 'ALLOWED',
                             search.get('verdict')),
                       check('search returned results', 'at least 1 result',
                             f'{count} results', count > 0),
                       check('call went through the gateway target',
                             fm_config.SEARCH_TOOL,
                             search.get('tool') or fm_config.SEARCH_TOOL)])


def tc03(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC03', 'Browser content extraction without Gateway',
                  'Relevant content is extracted through the direct browser '
                  'integration', fm_config.MODE_DIRECT)
    bundle = shared['direct']
    good = [s for s in bundle['sources'] if s.get('ok')]
    chars = sum(s.get('chars_extracted') or 0 for s in good)
    return _finish(record, PASS if good else FAIL,
                   f'{len(good)}/{len(bundle["sources"])} pages extracted, '
                   f'{chars} chars via managed Chrome (CDP)', bundle,
                   checks=[check(f"extract {s.get('url','')[:54]}",
                                 'text extracted',
                                 f"{s.get('chars_extracted')} chars"
                                 if s.get('ok')
                                 else f"FAILED: {str(s.get('error'))[:60]}",
                                 bool(s.get('ok')))
                           for s in bundle['sources']]
                   + [check('at least one source usable', 'yes',
                            'yes' if good else 'no', bool(good))])


def tc04(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC04', 'Browser content extraction with Gateway',
                  'Content is extracted through the configured gateway '
                  'integration', fm_config.MODE_GATEWAY)
    types = _gateway_target_types()
    has_browser = any('browser' in name.lower()
                      for group in types.values() for name in group)
    return _finish(
        record, BLOCKED,
        'No gateway integration for the browser exists. CreateGatewayTarget '
        'accepts ' + '; '.join(f"{group}: {', '.join(names)}"
                               for group, names in sorted(types.items()))
        + ' — no browser among them, so no Cedar action for "open a page" can '
          'be created and there is nothing to route. Extraction in Mode B is '
          'byte-identical to Mode A.',
        shared['gateway'],
        evidence={'gateway_target_types': types,
                  'browser_is_a_target_type': has_browser},
        blocked_reason='browser is not a gateway target type (service model)',
        checks=[
            check('a browser gateway target type exists',
                  'a target type containing "browser"',
                  'none of ' + ', '.join(sorted(
                      n for g in types.values() for n in g)),
                  has_browser),
            check('a Cedar action for opening a page can be created',
                  'yes', 'no — no target type to attach it to', False)])


def _gateway_target_types() -> Dict[str, List[str]]:
    control = boto3.client('bedrock-agentcore-control',
                           region_name=fm_config.REGION)
    shape = (control.meta.service_model
             .operation_model('CreateGatewayTarget')
             .input_shape.members['targetConfiguration'])
    return {group: sorted(member.members)
            for group, member in shape.members.items()}


def tc05(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC05', 'Full research workflow',
                  'Search, extraction, analysis and response generation '
                  'complete', fm_config.MODE_GATEWAY, fm_config.DEFAULT_PROMPT)
    bundle = shared['gateway']
    answer = bundle['answer']
    stages = {
        'search': bool(bundle['search'].get('results')),
        'extraction': any(s.get('ok') for s in bundle['sources']),
        'analysis': bool(answer.get('model_invoked')),
        'response': len(answer.get('text') or '') > 200,
        'memory': bool(bundle['memory'].get('written')),
    }
    ok = all(stages.values())
    return _finish(record, PASS if ok else FAIL,
                   ', '.join(f"{k}={'ok' if v else 'no'}"
                             for k, v in stages.items()),
                   bundle, stages=stages,
                   answer_chars=len(answer.get('text') or ''),
                   checks=[
                       check('search returned candidate sources',
                             'at least 1 result', 
                             f"{len(bundle['search'].get('results') or [])} results",
                             stages['search']),
                       check('at least one page extracted', 'yes',
                             f"{sum(1 for x in bundle['sources'] if x.get('ok'))}"
                             f"/{len(bundle['sources'])} extracted",
                             stages['extraction']),
                       check('model invoked for analysis', 'yes',
                             'yes' if stages['analysis'] else 'no',
                             stages['analysis']),
                       check('response is substantive', '> 200 chars',
                             f"{len(answer.get('text') or '')} chars",
                             stages['response']),
                       check('summary written to Memory', 'written',
                             bundle['memory'].get('verdict'),
                             stages['memory'])])


# ----------------------------------------------------------- auth & authority

def tc06(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC06', 'Runtime authentication failure',
                  'Request is rejected with an understandable error')
    # What an unauthenticated/unauthorised invoke actually returns is worth
    # knowing, so a bad ARN is used to show the shape of a rejection without
    # touching anybody's IAM.
    import deploy_runtime
    state = deploy_runtime.load_state() or {}
    arn = (state.get('agentRuntimeArn') or '') + 'XXXX'
    observed = 'no call made'
    try:
        boto3.client('bedrock-agentcore', region_name=fm_config.REGION
                     ).invoke_agent_runtime(
            agentRuntimeArn=arn, runtimeSessionId='x' * 36,
            payload=b'{}', contentType='application/json',
            accept='application/json')
        observed = 'accepted — unexpected'
    except botocore.exceptions.ClientError as exc:
        observed = (f"{exc.response['Error']['Code']}: "
                    f"{exc.response['Error']['Message'][:150]}")
    except botocore.exceptions.ParamValidationError as exc:
        observed = f'ParamValidationError: {str(exc)[:150]}'
    return _finish(
        record, BLOCKED,
        f'A malformed-identifier rejection is understandable and was '
        f'measured: {observed}. A true *authentication* failure is not '
        f'demonstrated: it would mean removing bedrock-agentcore permissions '
        f'from SandboxServiceRole, a role shared by other demos, which this '
        f'project will not do.',
        blocked_reason='would require modifying a shared IAM role',
        would_prove_it=('aws iam put-role-policy with an explicit Deny on '
                        'bedrock-agentcore:InvokeAgentRuntime, then invoke'),
        observed_rejection=observed)


def tc07(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC07', 'Unauthorized tool invocation',
                  'Access is denied at the designated enforcement point',
                  fm_config.MODE_GATEWAY)
    found = shared['security']['by_id'].get('ST2', {})
    return _finish(record, PASS if found.get('passed') else FAIL,
                   f"{found.get('actual')} — enforcement point: "
                   f"{found.get('enforcement_point')}",
                   security_source='ST2',
                   deciding_policy=found.get('deciding_policy'),
                   note=found.get('note'))


def tc08(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC08', 'Policy allows an operation',
                  'The authorized operation succeeds', fm_config.MODE_GATEWAY)
    found = shared['security']['by_id'].get('ST1', {})
    return _finish(record, PASS if found.get('passed') else FAIL,
                   str(found.get('actual')), security_source='ST1')


def tc09(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC09', 'Policy denies an operation',
                  'The restricted operation is blocked', fm_config.MODE_GATEWAY)
    found = shared['security']['by_id'].get('ST3', {})
    return _finish(record, PASS if found.get('passed') else FAIL,
                   f"{found.get('actual')} — asked for "
                   f"maxResults={fm_config.OVER_LIMIT_SEARCH_RESULTS} against "
                   f"a cap of {fm_config.GATEWAY_SEARCH_CAP}",
                   security_source='ST3', note=found.get('note'))


# ------------------------------------------------------------------- memory

def tc10(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC10', 'Memory write and subsequent retrieval',
                  'Persisted context is retrievable when supported by the '
                  'configured strategy')
    found = shared['security']['by_id'].get('ST8', {})
    return _finish(
        record, PASS if found.get('passed') else FAIL,
        f"{found.get('actual')} (via ListEvents)",
        security_source='ST8', note=found.get('note'),
        strategy_caveat=(
            'This memory resource has **no extraction strategy**, so '
            'RetrieveMemoryRecords returns zero rows however much is written. '
            'ListEvents returns the content immediately. The spec\'s "when '
            'supported by the configured strategy" is the operative clause.'))


def tc11(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC11', 'Memory access across users',
                  'Unauthorized cross-user access is prevented',
                  fm_config.MODE_GATEWAY)
    write = shared['security']['by_id'].get('ST5', {})
    read = shared['security']['by_id'].get('ST7', {})
    ok = write.get('passed') and read.get('passed')
    return _finish(
        record, PASS if ok else FAIL,
        f"write as another analyst: {write.get('actual')}; "
        f"read another namespace: {read.get('actual')}",
        security_source='ST5 + ST7',
        checks=[
            check(f"write as {fm_config.USER_OTHER} is refused",
                  'DENIED', write.get('verdict'), bool(write.get('passed'))),
            check(f"read {fm_config.namespace_for(fm_config.USER_OTHER)} "
                  f"is refused", 'DENIED', read.get('verdict'),
                  bool(read.get('passed')))],
        note=('Prevented at the gateway, on the **request contents** — the '
              'actorId in the body for the write, the namespace in the body '
              'for the read. Both calls were made by the same IAM principal, '
              'so this stops a caller asking for what it may not have; it '
              'does not distinguish two callers. See TC12.'))


def tc12(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC12', 'Memory access with different principals',
                  'Results reflect the configured FGAC rules',
                  fm_config.MODE_GATEWAY)
    return _finish(
        record, BLOCKED,
        'Per-principal rules are not available on this gateway. '
        '`principal is AgentCore::IamEntity` (the caller\'s class) matches, '
        'but a *named* principal matched nothing in five id forms — the IAM '
        'role ARN, the STS assumed-role ARN, the AROA…:session user id, the '
        'role unique id and the account id all reached ACTIVE and then '
        'matched no request. `AgentCore::OAuthUser` is refused at creation '
        'on an AWS_IAM gateway ("requires \'AgentCore::IamEntity\' principal '
        'type"), and no OIDC provider can be created here because '
        'cognito-idp is explicitDeny. So FGAC here is resource-scoped, not '
        'principal-scoped.',
        blocked_reason='named IamEntity principals do not match; OAuth '
                       'unavailable in this account',
        what_does_work='TC11 — isolation on the request body')


def tc17(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC17', 'Repeated request using prior context',
                  'Relevant permitted memory is retrieved',
                  fm_config.MODE_GATEWAY)
    trace = fm_trace.Trace(fm_config.MODE_GATEWAY, 'recall prior context',
                           fm_config.USER_PRIMARY)
    events = research.recall_events(fm_config.USER_PRIMARY, trace, limit=5)
    governed = research.recall(fm_config.USER_PRIMARY,
                               fm_config.MODE_GATEWAY, trace)
    count = len(events.get('events') or [])
    ok = count > 0
    return _finish(
        record, PASS if ok else FAIL,
        f"{count} prior summary event(s) retrieved for "
        f"{fm_config.USER_PRIMARY}; the governed read path returned "
        f"{governed.get('verdict')} with "
        f"{len(governed.get('records') or [])} records",
        {'services_invoked': trace.services(), 'trace': trace.to_dict()},
        note=('Two paths, deliberately both shown: ListEvents returns the '
              'content and cannot be governed per caller; '
              'RetrieveMemoryRecords is governed and returns nothing here '
              'because no extraction strategy is configured.'))


# ------------------------------------------------------- failure & resilience

def tc13(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC13', 'Search returns no results',
                  'The agent reports the limitation without fabricating '
                  'sources', fm_config.MODE_GATEWAY)
    trace = fm_trace.Trace(fm_config.MODE_GATEWAY, 'no-results probe',
                           fm_config.USER_PRIMARY)
    # A query that cannot match anything, then summarise with no sources.
    answer = research.summarise(
        'What are current mortgage affordability conditions?', [], trace)
    text = (answer.get('text') or '').lower()
    honest = (not answer.get('model_invoked')
              and ('nothing to summarise' in text or 'no sources' in text))
    return _finish(
        record, PASS if honest else FAIL,
        f"model_invoked={answer.get('model_invoked')}, "
        f"sources_used={answer.get('sources_used')}; response states the "
        f"limitation: {honest}",
        {'services_invoked': trace.services(), 'trace': trace.to_dict()},
        response=answer.get('text'))


def tc14(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC14', 'Browser cannot access a source',
                  'The failure is displayed and handled gracefully',
                  fm_config.MODE_DIRECT)
    # A host that cannot resolve. The run must record the failure and carry on.
    trace = fm_trace.Trace(fm_config.MODE_DIRECT, 'unreachable source',
                           fm_config.USER_PRIMARY)
    with fm_browser.ManagedBrowser(label='fm-tc14') as browser:
        bad = research.extract('https://this-host-does-not-exist.invalid/x',
                               trace, browser)
        good = research.extract('https://www.example.com/', trace, browser)
    ok = (not bad.get('ok')) and bool(bad.get('error')) and good.get('ok')
    return _finish(
        record, PASS if ok else FAIL,
        f"unreachable source recorded as {str(bad.get('error'))[:60]}; "
        f"the next source still extracted ({good.get('chars_extracted')} "
        f"chars)",
        {'services_invoked': trace.services(), 'trace': trace.to_dict()},
        failed_source=bad, recovered=good.get('ok'),
        checks=[
            check('unreachable source does not raise', 'recorded as failure',
                  'recorded' if not bad.get('ok') else 'unexpectedly ok',
                  not bad.get('ok')),
            check('the error is captured', 'error text present',
                  str(bad.get('error'))[:70] or 'none',
                  bool(bad.get('error'))),
            check('the next source still extracts', 'text extracted',
                  f"{good.get('chars_extracted')} chars" if good.get('ok')
                  else 'FAILED — one bad source poisoned the next',
                  bool(good.get('ok')))])


def tc15(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC15', 'Gateway unavailable',
                  'A clear failure is displayed; no unauthorized bypass '
                  'occurs', fm_config.MODE_GATEWAY)
    # Read-only equivalent: point the MCP client at a gateway id that does not
    # exist and confirm the failure is reported rather than silently falling
    # back to a direct path.
    trace = fm_trace.Trace(fm_config.MODE_GATEWAY, 'gateway unavailable',
                           fm_config.USER_PRIMARY)
    stack = fm_resources.mcp_stack()
    observed, bypassed = 'not attempted', None
    if stack:
        broken_url = stack.gateway_url.replace(
            stack.gateway_id, stack.gateway_id[:-4] + 'zzzz')
        client = fm_mcp.McpGatewayClient(stack.gateway_id,
                                                   url=broken_url)
        with trace.span('Gateway', 'tools/call',
                        'deliberately wrong gateway URL') as span:
            decision = fm_cedar.call_through_gateway(
                client, fm_config.SEARCH_TOOL,
                {'query': 'x', 'maxResults': 3})
            observed = decision.verdict
            span.note(verdict=observed)
            if decision.verdict != 'ALLOWED':
                span.failed(str(decision.to_dict().get('policy_message'))[:200])
        # The important half: a failed gateway must not silently become a
        # direct call. Mode B has no direct search path to fall through to.
        bypassed = decision.verdict == 'ALLOWED'
    return _finish(
        record, BLOCKED,
        f'A read-only equivalent was run: an unreachable gateway endpoint '
        f'returns {observed} and the run reports it rather than bypassing. '
        f'Truly making the gateway unavailable means deleting or breaking a '
        f'gateway other demos depend on, which this project will not do.',
        {'services_invoked': trace.services(), 'trace': trace.to_dict()},
        blocked_reason='would require breaking a shared gateway',
        unauthorized_bypass=bool(bypassed),
        note=('No bypass is possible by construction: Mode B has no direct '
              'web-search path to fall back to, because web search does not '
              'exist off-gateway.'))


def tc16(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC16', 'Direct integration unavailable',
                  'The direct-mode failure is displayed accurately',
                  fm_config.MODE_DIRECT)
    # This one is real and was found rather than staged: the hosted agent's
    # direct-HTTPS search finds nothing, because the public no-JS endpoints
    # are JavaScript-gated.
    hosted = shared.get('hosted_direct') or {}
    search = hosted.get('search') or {}
    reported = search.get('verdict') in ('UNAVAILABLE', 'ERROR')
    fell_back = hosted.get('used_fallback_sources')
    ok = bool(reported and fell_back)
    return _finish(
        record, PASS if ok else (SKIP if not hosted else FAIL),
        f"in Runtime the direct search reports {search.get('verdict')} "
        f"({search.get('response_bytes')} bytes, 0 result anchors) and the "
        f"run flags used_fallback_sources={fell_back}"
        if hosted else 'hosted run unavailable',
        note=('Genuinely measured, not staged: there is no AWS web search '
              'off-gateway, and the public no-JS endpoints serve a '
              'JavaScript-gated page that a plain HTTPS client cannot read. '
              'The app\'s local mode succeeds only because Playwright '
              'renders it.'))


# -------------------------------------------------------------- traces & data

def tc18(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC18', 'Trace correlation',
                  'Available runtime, gateway, tool and memory traces are '
                  'correlated', fm_config.MODE_GATEWAY)
    hosted = shared.get('hosted_gateway') or {}
    local = shared['gateway']
    hosted_services = hosted.get('services_invoked') or []
    local_ids = (local['trace'].get('summary') or {}).get(
        'aws_identifiers') or {}
    invocation = hosted.get('_invocation') or {}
    correlated = {
        'runtime_session_id': invocation.get('session_id'),
        'runtime_id': invocation.get('runtime_id'),
        'log_group': invocation.get('log_group'),
        'gateway_ids': local_ids.get('gateway_id'),
        'policy_ids': local_ids.get('policy_id'),
        'memory_ids': local_ids.get('memory_id'),
        'event_ids': local_ids.get('event_id'),
        'browser_session_ids': local_ids.get('browser_session_id'),
    }
    have = [k for k, v in correlated.items() if v]
    ok = len(have) >= 5
    return _finish(
        record, PASS if ok else FAIL,
        f'{len(have)} of {len(correlated)} identifier kinds collected and '
        f'correlated by run: {", ".join(have)}',
        local, correlated=correlated,
        hosted_steps=len(hosted.get('steps') or []),
        hosted_services=hosted_services,
        note=('Spans are client-side and agent-self-reported measurements. '
              'They are not X-Ray traces: Transaction Search is not enabled '
              'in this account, which is also why the reused POC reports its '
              'observability row as PARTIAL. The identifiers above are '
              'service-issued and can be looked up in the console.'))


def tc19(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC19', 'Sensitive information handling',
                  'Secrets and protected data are not exposed in logs or '
                  'unauthorized responses')
    # Scan this run's own artifacts for things that must never appear.
    import glob
    import os
    leaked: List[str] = []
    checked = 0
    # Each pattern requires a key name **followed by a plausible value**. An
    # earlier version matched the bare names, which meant this case's own
    # evidence row - which lists what it scans for - was picked up as a leak
    # by the next run. A scanner that finds its own documentation fails
    # forever and gets worse every run, so the detector now needs a value.
    patterns = {
        'aws_secret_key':
            r'(?i)aws_secret_access_key["\']?\s*[:=]\s*["\']?[A-Za-z0-9/+=]{20,}',
        'session_token':
            r'(?i)aws_session_token["\']?\s*[:=]\s*["\']?[A-Za-z0-9/+=]{40,}',
        'sigv4_signature': r'Signature=[0-9a-f]{64}',
        'bearer_token':
            r'(?i)authorization["\']?\s*[:=]\s*["\']?(Bearer |AWS4-HMAC)',
        'api_key_value': r'(?i)"apiKey"\s*:\s*"[^"*]{8,}"',
    }
    import re
    for path in glob.glob(os.path.join(fm_trace.artifact_dir(), '*.json')):
        checked += 1
        text = open(path).read()
        for name, pattern in patterns.items():
            if re.search(pattern, text):
                leaked.append(f'{name} in {os.path.basename(path)}')
    ok = not leaked
    return _finish(
        record, PASS if ok else FAIL,
        f'{checked} artifact(s) scanned, {len(leaked)} leak(s) found'
        + (f': {leaked}' if leaked else ''),
        scanned=checked, leaked=leaked,
        note=('Scans this project\'s own artifacts for credential material. '
              'What it does not assert: that the services log nothing '
              'sensitive. It also does not cover the reused POC\'s synthetic '
              'API key, which is generated locally and never printed by this '
              'project.'))


def tc20(shared: Dict[str, Any], say) -> Dict[str, Any]:
    record = case('TC20', 'Gateway versus direct comparison',
                  'Both execution paths can be evaluated against the same '
                  'test prompt', 'both', fm_config.DEFAULT_PROMPT)
    direct, gateway = shared['direct'], shared['gateway']
    same_prompt = direct['prompt'] == gateway['prompt']
    rows = comparison_rows(direct, gateway)
    ok = same_prompt and bool(direct.get('answer')) and bool(
        gateway.get('answer'))
    return _finish(
        record, PASS if ok else FAIL,
        f"same prompt run both ways; "
        f"{len(direct['services_invoked'])} services direct vs "
        f"{len(gateway['services_invoked'])} via gateway; "
        f"{len(gateway.get('policy_decisions') or [])} policy decisions vs "
        f"{len(direct.get('policy_decisions') or [])}",
        gateway, comparison=rows, same_prompt=same_prompt)


def comparison_rows(direct: Dict[str, Any],
                    gateway: Dict[str, Any]) -> List[Dict[str, Any]]:
    """The after-execution comparison the spec asks for, from real runs."""
    def srch(bundle):
        return bundle.get('search') or {}
    return [
        {'dimension': 'Services invoked',
         'without_gateway': ', '.join(direct['services_invoked']),
         'with_gateway': ', '.join(gateway['services_invoked'])},
        {'dimension': 'Web search',
         'without_gateway': f"{srch(direct).get('source', 'n/a')} — "
                            f"{len(srch(direct).get('results') or [])} results",
         'with_gateway': f"gateway connector — "
                         f"{len(srch(gateway).get('results') or [])} results, "
                         f"verdict {srch(gateway).get('verdict')}"},
        {'dimension': 'Policy decisions in the path',
         'without_gateway': str(len(direct.get('policy_decisions') or [])),
         'with_gateway': str(len(gateway.get('policy_decisions') or []))},
        {'dimension': 'Browser extraction',
         'without_gateway': 'managed Browser, IAM only',
         'with_gateway': 'managed Browser, IAM only — identical'},
        {'dimension': 'Memory write',
         'without_gateway': f"{(direct.get('memory') or {}).get('path')} — "
                            f"{(direct.get('memory') or {}).get('verdict')}",
         'with_gateway': f"{(gateway.get('memory') or {}).get('path')} — "
                         f"{(gateway.get('memory') or {}).get('verdict')}"},
        {'dimension': 'Total spans',
         'without_gateway': str(len(direct['trace']['spans'])),
         'with_gateway': str(len(gateway['trace']['spans']))},
    ]


CASES: List[Callable] = [
    tc01, tc02, tc03, tc04, tc05, tc06, tc07, tc08, tc09, tc10,
    tc11, tc12, tc13, tc14, tc15, tc16, tc17, tc18, tc19, tc20,
]


def run_all(include_hosted: bool = True, say=print) -> Dict[str, Any]:
    """Run the shared workloads once, then evaluate every case against them.

    The two research runs and the security suite are executed **once** and
    shared: twenty cases each starting their own browser session and gateway
    search would take far longer and measure the same thing twenty times.
    """
    say('Preparing shared workloads (this is most of the runtime)…')
    policies = fm_policies.status()
    if not policies['ready_for_mode_b']:
        say('  installing this project\'s Cedar policies first')
        fm_policies.ensure(say)

    say('  [1/4] research run — with gateway')
    gateway_run = research.run(mode=fm_config.MODE_GATEWAY, say=None)
    say('  [2/4] research run — without gateway')
    direct_run = research.run(mode=fm_config.MODE_DIRECT, say=None)
    say('  [3/4] security tests')
    security = security_tests.run_all(say=lambda *_: None)
    security['by_id'] = {t['id']: t for t in security['tests']}

    hosted_gateway: Dict[str, Any] = {}
    hosted_direct: Dict[str, Any] = {}
    if include_hosted:
        say('  [4/4] hosted runs in AgentCore Runtime')
        try:
            import invoke_runtime
            hosted_gateway = invoke_runtime.invoke(
                mode=fm_config.MODE_GATEWAY, say=lambda *_: None)
            hosted_direct = invoke_runtime.invoke(
                mode=fm_config.MODE_DIRECT, say=lambda *_: None)
        except Exception as exc:                        # noqa: BLE001
            say(f'  hosted runs unavailable: {type(exc).__name__}: {exc}')
    else:
        say('  [4/4] hosted runs skipped (--no-hosted)')

    shared = {'gateway': gateway_run, 'direct': direct_run,
              'security': security, 'hosted_gateway': hosted_gateway,
              'hosted_direct': hosted_direct}

    say('')
    results: List[Dict[str, Any]] = []
    import testcases_capability
    runners = list(CASES) + [
        # The capability cases take the shared helpers as arguments so they
        # live in their own module without importing this one back.
        (lambda fn: lambda shared, say_: fn(shared, say_, case, check,
                                            _finish))(f)
        for f in testcases_capability.CASES]
    for runner in runners:
        try:
            record = runner(shared, say)
        except Exception as exc:                        # noqa: BLE001
            record = case(getattr(runner, '__name__', 'TC??').upper(),
                          'unexpected failure', '-')
            record.update({'result': FAIL,
                           'actual': f'{type(exc).__name__}: {exc}',
                           'errors': [f'{type(exc).__name__}: {exc}']})
        try:
            _evidence(record, shared)
        except Exception as exc:                        # noqa: BLE001
            # Enrichment is presentation: never let it lose a test result.
            record['explanation'] = EXPLANATIONS.get(record['id'], '')
            record['inputs'], record['outputs'] = [], []
            record['enrichment_error'] = f'{type(exc).__name__}: {exc}'
        results.append(record)
        say(f"  {record['id']:<6} {record['scenario'][:46]:<48} "
            f"{record['result']:<8} {str(record['actual'])[:60]}")

    counts: Dict[str, int] = {}
    for record in results:
        counts[record['result']] = counts.get(record['result'], 0) + 1
    say(f"\n{counts.get(PASS, 0)} passed, {counts.get(FAIL, 0)} failed, "
        f"{counts.get(BLOCKED, 0)} blocked, {counts.get(SKIP, 0)} skipped")

    return {
        'generated_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'use_case': fm_config.USE_CASE,
        'disclaimer': fm_config.DISCLAIMER,
        'prompt': fm_config.DEFAULT_PROMPT,
        'cases': results,
        'counts': counts,
        'comparison': comparison_rows(direct_run, gateway_run),
        'runs': {'with_gateway': gateway_run, 'without_gateway': direct_run,
                 'hosted_with_gateway': hosted_gateway,
                 'hosted_without_gateway': hosted_direct},
        'security': security,
        'policies': policies,
        'summary': {
            'total': len(results),
            'passed': counts.get(PASS, 0),
            'failed': counts.get(FAIL, 0),
            'blocked': counts.get(BLOCKED, 0),
            'blocked_ids': [r['id'] for r in results
                            if r['result'] == BLOCKED],
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description='Run the TC01-TC20 matrix')
    parser.add_argument('--no-hosted', action='store_true',
                        help='skip the two AgentCore Runtime invocations')
    parser.add_argument('--no-pdf', action='store_true',
                        help='skip rendering the four PDF reports')
    args = parser.parse_args()
    bundle = run_all(include_hosted=not args.no_hosted)
    path = fm_trace.write(bundle, ARTIFACT_PREFIX)
    print(f'\nArtifact: {path}')
    if not args.no_pdf:
        import fm_report
        fm_report.build_all(bundle, say=print)
    return 0 if bundle['summary']['failed'] == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
