"""Execution traces for one research run.

What this is and is not. These are **client-side spans**: this process records
what it called, when, for how long, and what came back. They are real
measurements of real calls, and they are *not* AWS X-Ray traces - Transaction
Search is not enabled in this account, which the price-match POC measured and
recorded as the reason its observability row is PARTIAL. So every span here
carries `source: 'client'`, and where AWS itself returned an identifier (a
browser session id, a policy id, a Memory event id, a Runtime request id) it is
attached to the span as `aws_ids` and marked as service-issued.

That distinction is the whole reason this module exists rather than printing
timings: a reader who is shown "traces" and later discovers they were stopwatch
readings in the app has been misled. A reader who is shown stopwatch readings
labelled as such, with the service-issued ids called out separately, can tell
exactly how much to trust.
"""

import json
import os
import time
import uuid
from typing import Any, Dict, List, Optional

import fm_config


class Span:
    """One timed call to one service."""

    def __init__(self, trace: 'Trace', service: str, api: str,
                 detail: str = '', **extra):
        self.trace = trace
        self.record: Dict[str, Any] = {
            'span_id': uuid.uuid4().hex[:12],
            'service': service,
            'api': api,
            'detail': detail,
            'mode': trace.mode,
            'source': 'client',
            'started_at': None,
            'duration_ms': None,
            'status': 'PENDING',
            'aws_ids': {},
            **extra,
        }
        self._t0 = 0.0

    def __enter__(self) -> 'Span':
        self._t0 = time.time()
        self.record['started_at'] = time.strftime('%Y-%m-%dT%H:%M:%S',
                                                  time.localtime(self._t0))
        self.record['started_epoch'] = round(self._t0, 3)
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        self.record['duration_ms'] = round((time.time() - self._t0) * 1000, 1)
        if exc is not None:
            self.record['status'] = 'ERROR'
            self.record['error'] = f'{exc_type.__name__}: {exc}'
        elif self.record['status'] == 'PENDING':
            self.record['status'] = 'OK'
        self.trace.spans.append(self.record)
        # Exceptions propagate: a span is a recorder, not a handler. The caller
        # decides whether a failed tool call is fatal to the run, and several
        # test cases depend on a failure being visible rather than swallowed.
        return False

    def ok(self, **fields) -> 'Span':
        self.record['status'] = 'OK'
        self.record.update(fields)
        return self

    def denied(self, policy: Optional[str] = None, message: str = '') -> 'Span':
        """A policy refusal is not an error - it is the control working."""
        self.record['status'] = 'DENIED'
        self.record['deciding_policy'] = policy
        self.record['policy_message'] = message[:400]
        if policy:
            self.record['aws_ids']['policy_id'] = policy
        return self

    def failed(self, message: str) -> 'Span':
        self.record['status'] = 'FAILED'
        self.record['error'] = str(message)[:400]
        return self

    def skipped(self, why: str) -> 'Span':
        self.record['status'] = 'SKIPPED'
        self.record['detail'] = (self.record.get('detail') or '') + f' — {why}'
        return self

    def aws_id(self, **ids) -> 'Span':
        """Attach an identifier the *service* issued, not one we made up."""
        self.record['aws_ids'].update({k: v for k, v in ids.items() if v})
        return self

    def note(self, **fields) -> 'Span':
        self.record.update(fields)
        return self


class Trace:
    """All spans for one run, in the order they happened."""

    def __init__(self, mode: str, prompt: str, user: str):
        self.run_id = f"fm-{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6]}"
        self.mode = mode
        self.prompt = prompt
        self.user = user
        self.spans: List[Dict[str, Any]] = []
        self.started_epoch = time.time()
        self.log: List[str] = []

    def span(self, service: str, api: str, detail: str = '', **extra) -> Span:
        return Span(self, service, api, detail, **extra)

    def say(self, message: str = '') -> None:
        """Human-readable running commentary, kept alongside the spans."""
        self.log.append(str(message))

    # -- reporting ---------------------------------------------------------

    def services(self) -> List[str]:
        """Which services this run actually touched, in first-use order.

        Only spans that ran: a SKIPPED span means the service was *not*
        invoked, and listing it would overstate what the run demonstrated.
        """
        seen: List[str] = []
        for span in self.spans:
            if span['status'] == 'SKIPPED':
                continue
            if span['service'] not in seen:
                seen.append(span['service'])
        return seen

    def policy_decisions(self) -> List[Dict[str, Any]]:
        return [s for s in self.spans
                if s['status'] == 'DENIED' or s.get('verdict')
                or s.get('deciding_policy')]

    def aws_identifiers(self) -> Dict[str, Any]:
        """Every service-issued id this run collected, by kind."""
        out: Dict[str, Any] = {}
        for span in self.spans:
            for key, value in (span.get('aws_ids') or {}).items():
                out.setdefault(key, [])
                if value not in out[key]:
                    out[key].append(value)
        return out

    def summary(self) -> Dict[str, Any]:
        statuses: Dict[str, int] = {}
        for span in self.spans:
            statuses[span['status']] = statuses.get(span['status'], 0) + 1
        return {
            'run_id': self.run_id,
            'mode': self.mode,
            'user': self.user,
            'spans': len(self.spans),
            'statuses': statuses,
            'total_ms': round((time.time() - self.started_epoch) * 1000, 1),
            'services': self.services(),
            'aws_identifiers': self.aws_identifiers(),
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            'run_id': self.run_id,
            'mode': self.mode,
            'prompt': self.prompt,
            'user': self.user,
            'generated_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'trace_note': (
                'Spans are client-side measurements made by this process. '
                'They are not AWS X-Ray traces: Transaction Search is not '
                'enabled in this account. Identifiers under aws_ids were '
                'issued by the service and can be looked up in the console.'),
            'spans': self.spans,
            'summary': self.summary(),
            'log': self.log,
        }


def artifact_dir() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    path = (fm_config.ARTIFACT_DIR if os.path.isabs(fm_config.ARTIFACT_DIR)
            else os.path.join(here, fm_config.ARTIFACT_DIR))
    os.makedirs(path, exist_ok=True)
    return path


def write(bundle: Dict[str, Any], prefix: str) -> str:
    """Persist one run. Appends a random suffix for the reason the price-match
    POC learned the hard way: timestamp alone collides for runs started in the
    same second and silently overwrites the earlier one."""
    name = (f"{prefix}_{time.strftime('%Y%m%d_%H%M%S')}_"
            f"{uuid.uuid4().hex[:4]}.json")
    path = os.path.join(artifact_dir(), name)
    with open(path, 'w') as handle:
        json.dump(bundle, handle, indent=2, default=str)
    return path


def latest(prefix: str) -> Optional[Dict[str, Any]]:
    directory = artifact_dir()
    names = sorted(f for f in os.listdir(directory)
                   if f.startswith(prefix) and f.endswith('.json'))
    if not names:
        return None
    with open(os.path.join(directory, names[-1])) as handle:
        bundle = json.load(handle)
    bundle['_artifact'] = names[-1]
    return bundle


def all_runs(prefix: str) -> List[str]:
    directory = artifact_dir()
    if not os.path.isdir(directory):
        return []
    return sorted((os.path.join(directory, f) for f in os.listdir(directory)
                   if f.startswith(prefix) and f.endswith('.json')),
                  reverse=True)
