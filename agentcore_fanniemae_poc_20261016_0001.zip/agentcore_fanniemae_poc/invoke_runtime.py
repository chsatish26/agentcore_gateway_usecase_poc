"""Invoke the deployed mortgage-research agent.

Two measured platform behaviours shape this file, and both cost real debugging
time in the price-match work before they were understood:

1. **`runtimeSessionId` has a minimum length of 33.** `uuid4().hex` is 32 and
   is rejected client-side by botocore's validator, which looks like a service
   error and is not. `str(uuid4())` is 36.

2. **About one fresh session in three is accepted and then never routed.** No
   instance starts, no log stream exists for that session, and the call hangs
   until the client read timeout. A *new session id* works immediately. So the
   read timeout is bounded well under the default and one retry on a fresh
   session is attempted - which is safe here only because the agent never
   received the request, so nothing ran and nothing can be duplicated.

   `retries={'total_max_attempts': 1}` rather than `max_attempts`: the two
   count differently in standard versus legacy mode, and one observed "single
   attempt" spent two full 180-second timeouts.

A healthy turn is 4-12 seconds for the probe and up to ~90 for a full research
run, so the timeout is set from the work being asked for rather than fixed.
"""

import argparse
import json
import time
import uuid
from typing import Any, Dict, Optional

import boto3
import botocore.config
import botocore.exceptions

import deploy_runtime
import fm_config
import fm_config
import fm_resources


def _client(read_timeout: int):
    return boto3.client(
        'bedrock-agentcore', region_name=fm_config.REGION,
        config=botocore.config.Config(
            read_timeout=read_timeout, connect_timeout=15,
            # See the module docstring: total_max_attempts, not max_attempts.
            retries={'total_max_attempts': 1}))


def runtime_context() -> Dict[str, Any]:
    """Resolve the borrowed resource ids the agent needs, here rather than there.

    The agent is given the memory gateway URL and memory id in its payload
    instead of rediscovering them: this process already has the state files,
    and an agent that resolves them again is a second place for them to be
    wrong - or to need IAM it would not otherwise need.
    """
    memory = fm_resources.memory_stack()
    return {
        'memory_gateway_url': getattr(memory, 'gateway_url', None),
        'memory_gateway_id': getattr(memory, 'gateway_id', None),
        'memory_target': fm_config.MEMFGAC_TARGET_NAME,
        'memory_id': getattr(memory, 'memory_id', None),
    }


def invoke(prompt: Optional[str] = None,
           mode: str = fm_config.MODE_GATEWAY,
           user: Optional[str] = None,
           probe_browser: bool = True,
           max_results: Optional[int] = None,
           read_timeout: int = 120,
           retry_on_unrouted: bool = True,
           say=print) -> Dict[str, Any]:
    """Call the hosted agent once, retrying once if the session is never routed."""
    state = deploy_runtime.load_state()
    if not state:
        raise RuntimeError(
            'No runtime state. Deploy first: python deploy_runtime.py deploy')
    runtime_arn = state['agentRuntimeArn']

    payload = {
        'prompt': prompt or fm_config.DEFAULT_PROMPT,
        'mode': mode,
        'user': user or fm_config.USER_PRIMARY,
        'probe_browser': probe_browser,
        'max_results': max_results or fm_config.MAX_SEARCH_RESULTS,
        'context': runtime_context(),
    }
    # The agent's own query extraction is deliberately crude; give it the same
    # query the local path would use so the two are comparable.
    import research
    payload['query'] = research._query_from(payload['prompt'])

    attempts = []
    for attempt in range(2 if retry_on_unrouted else 1):
        # A fresh session id per attempt: that is the whole remedy for an
        # unrouted session, and reusing the id would reproduce the hang.
        session_id = str(uuid.uuid4())
        if len(session_id) < 33:                      # cannot happen; asserted
            raise RuntimeError('runtimeSessionId must be at least 33 chars')
        started = time.time()
        say(f'  invoking {state["agentRuntimeId"]} '
            f'(session {session_id[:8]}…, attempt {attempt + 1})')
        try:
            response = _client(read_timeout).invoke_agent_runtime(
                agentRuntimeArn=runtime_arn,
                runtimeSessionId=session_id,
                payload=json.dumps(payload).encode(),
                contentType='application/json',
                accept='application/json')
            raw = response['response'].read()
            elapsed = round(time.time() - started, 1)
            result = json.loads(raw)
            result['_invocation'] = {
                'runtime_id': state['agentRuntimeId'],
                'runtime_arn': runtime_arn,
                'runtime_version': state.get('agentRuntimeVersion'),
                'session_id': session_id,
                'elapsed_s': elapsed,
                'attempt': attempt + 1,
                'log_group': state.get('log_group'),
                'log_stream_hint': (
                    f"YYYY/MM/DD/[runtime-logs-{session_id}]…"),
            }
            say(f'  returned in {elapsed}s')
            return result
        except botocore.exceptions.ReadTimeoutError:
            elapsed = round(time.time() - started, 1)
            attempts.append({'session_id': session_id, 'elapsed_s': elapsed,
                             'outcome': 'read timeout — session never routed'})
            say(f'  timed out after {elapsed}s — this is the unrouted-session '
                f'behaviour, not the agent being slow. '
                f"{'Retrying on a fresh session.' if attempt == 0 else ''}")
            continue
        except botocore.exceptions.ClientError as exc:
            # A service-side rejection is a different thing from an unrouted
            # session and must not be retried as one.
            return {'ok': False,
                    'error': f"{exc.response['Error']['Code']}: "
                             f"{exc.response['Error']['Message']}",
                    '_invocation': {'session_id': session_id,
                                    'attempt': attempt + 1,
                                    'runtime_id': state['agentRuntimeId']}}
    return {
        'ok': False,
        'error': ('The runtime accepted every session and never routed one. '
                  'No instance started and no log stream exists for these '
                  'session ids. This is a platform-side behaviour measured at '
                  'roughly one fresh session in three; invoking again usually '
                  'succeeds.'),
        '_invocation': {'attempts': attempts,
                        'runtime_id': state['agentRuntimeId']},
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description='Invoke the deployed mortgage-research agent')
    parser.add_argument('prompt', nargs='?', default=None)
    parser.add_argument('--mode', choices=list(fm_config.MODES),
                        default=fm_config.MODE_GATEWAY)
    parser.add_argument('--user', default=None)
    parser.add_argument('--no-browser-probe', action='store_true')
    parser.add_argument('--timeout', type=int, default=120)
    parser.add_argument('--json', action='store_true',
                        help='print the whole response')
    args = parser.parse_args()

    result = invoke(args.prompt, mode=args.mode, user=args.user,
                    probe_browser=not args.no_browser_probe,
                    read_timeout=args.timeout)
    if args.json:
        print(json.dumps(result, indent=2, default=str))
        return 0 if result.get('ok') else 1

    if not result.get('ok'):
        print(f"\nFAILED: {result.get('error')}")
        return 1
    print(f"\nmode              {result.get('mode')}")
    print(f"executed in       {result.get('executed_in')}")
    print(f"identity          {(result.get('identity') or {}).get('arn')}")
    print(f"services invoked  {result.get('services_invoked')}")
    search = result.get('search') or {}
    print(f"search            {search.get('verdict')} "
          f"({len(search.get('results') or [])} results)")
    if result.get('used_fallback_sources'):
        print('                  fell back to seeded public sources')
    memory = result.get('memory') or {}
    print(f"memory            {memory.get('verdict')} "
          f"written={memory.get('written')}")
    print(f"\n{(result.get('answer') or {}).get('text', '')[:900]}\n")
    for step in result.get('steps') or []:
        print(f"  {step['service']:<22} {step['api']:<34} "
              f"{step['status']:<12} {step['duration_ms']:>8} ms")
    invocation = result.get('_invocation') or {}
    print(f"\nlog group  {invocation.get('log_group')}")
    print(f"session    {invocation.get('session_id')}")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
