"""This project's Cedar policies, on the borrowed Memory FGAC gateway.

Two policies, both narrow, both named `fmpoc_*` so that teardown here can find
exactly its own work and nothing else. They are installed on the *engine the
FGAC lab created* rather than on a new one, because a second policy engine
fronting the same Memory would prove nothing the first does not - and because
reusing it is what the spec asked for.

Co-tenancy rules this file obeys, since two projects now write to one engine:

* **Name prefix.** The lab removes only `labmemfgac_*`; this project removes
  only `fmpoc_*`. Neither clears the other, in either direction.
* **Namespace root.** The lab leaves a standing permit for `namespace like
  "/actors/*"`. Anything this project put under `/actors/` would inherit that
  permit and its cross-user isolation test would pass for the wrong reason, so
  this project's namespaces are rooted at `/fmpoc/`. See
  `fm_config.namespace_for`.
* **Actor ids.** `fm-analyst-*`, not `labmem-*`, so a denial here is never the
  lab's policy talking.

What the two policies demonstrate, and the one they cannot:

    write   CreateEvent, actorId == fm-analyst-alice   body field  -> binds
    read    RetrieveMemoryRecords, namespace == ...    body field  -> binds
    read    ListEvents, actorId == fm-analyst-alice    path param  -> inert

The third is not installed. It was measured in the FGAC lab: a policy on a
path-carried `actorId` reaches ACTIVE and then denies every request, so
installing one here would add a rule that silently blocks the functional
read-back path. That is reported as a limitation, not worked around.
"""

import argparse
from typing import Any, Dict, List, Optional

import botocore.exceptions

import fm_config
import fm_cedar
import fm_config
import fm_memory
import fm_resources

PREFIX = 'fmpoc_'


def _control():
    import boto3
    return boto3.client('bedrock-agentcore-control',
                        region_name=fm_config.REGION)


def specs(gateway_arn: str) -> Dict[str, Dict[str, Any]]:
    """The policies, as submitted. `principal is AgentCore::IamEntity` because
    the borrowed gateway is AWS_IAM inbound: an `AgentCore::OAuthUser` policy
    is refused at creation there, with both principal types named in the error.
    """
    write = fm_memory.action('CreateEvent')
    read = fm_memory.action('RetrieveMemoryRecords')
    namespace = fm_config.namespace_for(fm_config.USER_PRIMARY)

    def head(effect: str, action: str) -> str:
        return (f'{effect} (\n'
                f'    principal is AgentCore::IamEntity,\n'
                f'    action == AgentCore::Action::"{action}",\n'
                f'    resource == AgentCore::Gateway::"{gateway_arn}"\n')

    return {
        'write_own_actor': {
            'name': f'{PREFIX}permit_write_own_actor',
            'kind': 'permit, per-identity write isolation',
            'description': (f'Fannie Mae POC: only {fm_config.USER_PRIMARY} '
                            f'may write their own research summaries.'),
            'enforcement': 'ACTIVE',
            'expect_status': 'ACTIVE',
            'plain': (f'A research summary may be saved only for actor '
                      f'{fm_config.USER_PRIMARY}. A write naming any other '
                      f'actor is denied, so one analyst cannot file findings '
                      f'under another analyst\'s name.'),
            'statement': head('permit', write) + f''') when {{
    context has input &&
    context.input has actorId &&
    context.input.actorId == "{fm_config.USER_PRIMARY}"
}};''',
        },
        'read_own_namespace': {
            'name': f'{PREFIX}permit_read_own_namespace',
            'kind': 'permit, per-namespace read isolation',
            'description': (f'Fannie Mae POC: reads restricted to '
                            f'{namespace}.'),
            'enforcement': 'ACTIVE',
            'expect_status': 'ACTIVE',
            'plain': (f'Memory records may be retrieved only from '
                      f'{namespace}. A retrieve naming another analyst\'s '
                      f'namespace is denied before it reaches Memory.'),
            'statement': head('permit', read) + f''') when {{
    context has input &&
    context.input has namespace &&
    context.input.namespace == "{namespace}"
}};''',
        },
    }


def installed(control=None) -> Dict[str, Dict[str, Any]]:
    """Which of this project's policies are on the engine right now."""
    stack = fm_resources.memory_stack()
    if stack is None:
        return {}
    control = control or _control()
    found: Dict[str, Dict[str, Any]] = {}
    token = None
    while True:
        kwargs: Dict[str, Any] = {'policyEngineId': stack.engine_id,
                                  'maxResults': 50}
        if token:
            kwargs['nextToken'] = token
        page = control.list_policies(**kwargs)
        # `list_policies` returns `policies` here, not the `items` most of this
        # control plane uses; both are tried so a normalisation does not break it.
        for item in page.get('policies', page.get('items', [])):
            if str(item.get('name', '')).startswith(PREFIX):
                found[item['name']] = item
        token = page.get('nextToken')
        if not token:
            return found


def ensure(say=print) -> Dict[str, Any]:
    """Install this project's policies, idempotently.

    An existing policy of the same name is left alone rather than replaced:
    re-creating it would mean a delete, and deletion lags behind the call that
    requested it, so a re-create races its own teardown.
    """
    stack = fm_resources.memory_stack()
    if stack is None:
        raise RuntimeError(
            'The Memory FGAC gateway does not exist. This project reuses it '
            'rather than creating one. Fix: run `python memory_fgac.py run` '
            'in agentcore_gateway_usecase_poc.')
    control = _control()
    present = installed(control)
    results: Dict[str, Any] = {}
    for key, spec in specs(stack.gateway_arn).items():
        if spec['name'] in present:
            say(f"  policy          {spec['name']} (existing)")
            results[key] = {'name': spec['name'], 'status': 'ACTIVE',
                            'policy_id': present[spec['name']]['policyId'],
                            'existing': True, 'statement': spec['statement'],
                            'plain': spec['plain'], 'kind': spec['kind']}
            continue
        results[key] = fm_cedar.install(control, stack.engine_id,
                                                  spec, say)
    return {'engine_id': stack.engine_id, 'gateway_id': stack.gateway_id,
            'policies': results}


def teardown(say=print) -> List[str]:
    """Remove only this project's policies. The lab's are left untouched."""
    stack = fm_resources.memory_stack()
    if stack is None:
        say('No Memory FGAC gateway; nothing to remove.')
        return []
    control = _control()
    removed = []
    for name, item in installed(control).items():
        fm_cedar.uninstall(control, stack.engine_id,
                                     item['policyId'], say, name)
        removed.append(name)
    if not removed:
        say('No fmpoc_* policies were installed.')
    return removed


def status() -> Dict[str, Any]:
    stack = fm_resources.memory_stack()
    present = sorted(installed())
    return {
        'memory_gateway_present': stack is not None,
        'gateway_id': getattr(stack, 'gateway_id', None),
        'engine_id': getattr(stack, 'engine_id', None),
        'fmpoc_policies': present,
        'ready_for_mode_b': len(present) == 2,
        'expected': [s['name'] for s in specs('x').values()],
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="This project's Cedar policies on the borrowed Memory "
                    "FGAC gateway")
    parser.add_argument('command', choices=['ensure', 'status', 'teardown'])
    args = parser.parse_args()

    if args.command == 'ensure':
        result = ensure()
        ok = sum(1 for p in result['policies'].values()
                 if p.get('status') == 'ACTIVE')
        print(f"\n{ok}/{len(result['policies'])} policies ACTIVE on engine "
              f"{result['engine_id']}")
        return 0 if ok == len(result['policies']) else 1

    if args.command == 'teardown':
        teardown()
        return 0

    import json
    print(json.dumps(status(), indent=2, default=str))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
