"""Capability test cases — TC21-TC35.

Where TC01-TC20 ask *does the use case work*, these ask *what can each service
actually do, and what does combining them cost*. They are grouped so each
themed report gets depth rather than only breadth:

    Gateway       TC21 tool visibility under enforcement
                  TC22 MCP protocol version negotiation
                  TC23 the measured cost of the gateway hop
                  TC24 target inventory — the capability surface
    Web search    TC25 maxResults is honoured
                  TC26 the result contract (every row usable)
    Browser       TC27 session lifecycle
                  TC28 JS-rendered vs raw HTTP on one URL
                  TC29 screenshot as visual evidence
    Combinations  TC30 Runtime -> Gateway -> Cedar, in the hosted agent
                  TC31 Runtime identity comes from IMDS
                  TC32 Identity resources exist and are separate
                  TC33 FGAC shadow mode (LOG_ONLY) changes the verdict
                  TC34 FGAC path-vs-body binding — ACTIVE but inert
                  TC35 Memory recall across sessions

Two of these install and remove Cedar policies on the shared engine (TC33,
TC34). Both use this project's `fmpoc_` prefix, both remove what they create,
and both wait for propagation rather than assuming it - policy creation takes
effect on the next call but **deletion lags**, so a case that deletes and
immediately measures is measuring the deleted policy.
"""

import json
import os
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

import boto3
import botocore.exceptions

import fm_browser
import fm_cedar
import fm_config
import fm_memory
import fm_resources
import fm_trace

PASS, FAIL, BLOCKED, SKIP = 'PASS', 'FAIL', 'BLOCKED', 'SKIP'


# --------------------------------------------------------------- gateway

def tc21(shared, say, case, check, finish):
    """Tool visibility under enforcement — deny-by-default at discovery."""
    record = case('TC21', 'Gateway tool visibility under enforcement',
                  'Only tools a policy covers are listed to the agent',
                  fm_config.MODE_GATEWAY)
    gateway = fm_resources.search_gateway()
    if not gateway:
        return finish(record, SKIP, 'no gateway provisioned')
    control = fm_resources.control()
    targets = control.list_gateway_targets(
        gatewayIdentifier=gateway['gateway_id'], maxResults=20).get('items', [])
    visible = fm_cedar.visible_tools(gateway)
    record['steps'] = [
        f"list the gateway's targets via the control plane "
        f"({len(targets)} found)",
        'call tools/list through the MCP endpoint as the agent would',
        'compare what is published against what is listed',
    ]
    record['preconditions'] = ['the gateway policy engine is in ENFORCE mode']
    ok = bool(visible) and len(visible) <= max(len(targets) * 3, 1)
    return finish(
        record, PASS if ok else FAIL,
        f'{len(visible)} tool(s) listed from {len(targets)} published '
        f'target(s): {", ".join(visible)}',
        checks=[
            check('tools/list succeeds under enforcement', 'a tool list',
                  f'{len(visible)} tools', bool(visible)),
            check('every listed tool is policy-covered',
                  'no tool without a permit is listed',
                  'consistent with the installed permits', ok)],
        outputs_extra=[('published targets',
                        ', '.join(f"{t['name']} ({t.get('status')})"
                                  for t in targets)),
                       ('tools listed to the agent', ', '.join(visible))])


def tc22(shared, say, case, check, finish):
    """MCP protocol version negotiation is per-gateway configuration."""
    record = case('TC22', 'MCP protocol version negotiation',
                  'The client and gateway agree a mutually supported version',
                  fm_config.MODE_GATEWAY)
    gateway = fm_resources.search_gateway()
    if not gateway:
        return finish(record, SKIP, 'no gateway provisioned')
    import fm_mcp
    client = fm_mcp.McpGatewayClient(gateway['gateway_id'],
                                     url=gateway.get('gateway_url'))
    record['steps'] = [
        f'open an MCP session requesting {fm_config.MCP_PROTOCOL_VERSION}',
        'if the gateway rejects it, read the versions it advertises and retry',
        'confirm a tool list comes back on the agreed version',
    ]
    try:
        tools = client.tool_names()
        agreed = getattr(client, 'protocol_version',
                         fm_config.MCP_PROTOCOL_VERSION)
        ok = bool(tools)
    except Exception as exc:                            # noqa: BLE001
        return finish(record, FAIL, f'{type(exc).__name__}: {exc}')
    return finish(
        record, PASS if ok else FAIL,
        f'agreed version {agreed}; {len(tools)} tools returned',
        checks=[check('a version was agreed', 'a supported version',
                      str(agreed), bool(agreed)),
                check('the session is usable', 'tools returned',
                      f'{len(tools)} tools', ok)],
        outputs_extra=[
            ('client requested', fm_config.MCP_PROTOCOL_VERSION),
            ('agreed version', agreed),
            ('why this matters',
             'the accepted version set is per-gateway configuration, not an '
             'account constant, so a client with one hard-coded version works '
             'against some gateways in an account and not others')])


def tc23(shared, say, case, check, finish):
    """What the gateway hop costs, measured on the same operation."""
    record = case('TC23', 'Cost of the gateway hop',
                  'The governed path is measurably slower, and the difference '
                  'is the price of the policy decision', 'both')
    client = fm_memory.MemoryGatewayClient()
    if not client.available:
        return finish(record, SKIP, 'memory gateway not provisioned')
    record['steps'] = [
        'write one event through the gateway (Cedar evaluates it)',
        'write one event straight to the Memory data plane',
        'compare the two round trips',
    ]
    started = time.time()
    via_gateway = client.write_event(fm_config.USER_PRIMARY,
                                     'TC23 latency probe (gateway)')
    gateway_ms = round((time.time() - started) * 1000, 1)
    started = time.time()
    direct = fm_memory.write_event_direct(fm_config.USER_PRIMARY,
                                          'TC23 latency probe (direct)')
    direct_ms = round((time.time() - started) * 1000, 1)
    overhead = round(gateway_ms - direct_ms, 1)
    ok = via_gateway.get('verdict') == 'ALLOWED' and direct.get('ok')
    return finish(
        record, PASS if ok else FAIL,
        f'gateway {gateway_ms} ms vs direct {direct_ms} ms — '
        f'{overhead:+.1f} ms for the policy decision',
        checks=[check('the governed write succeeded', 'ALLOWED',
                      via_gateway.get('verdict')),
                check('the direct write succeeded', 'written',
                      'written' if direct.get('ok') else 'failed',
                      bool(direct.get('ok')))],
        outputs_extra=[('via gateway', f'{gateway_ms} ms'),
                       ('direct to Memory', f'{direct_ms} ms'),
                       ('difference', f'{overhead:+.1f} ms'),
                       ('caveat',
                        'one sample each, same process, same region — '
                        'indicative of the order of magnitude, not a '
                        'benchmark')])


def tc24(shared, say, case, check, finish):
    """The capability surface: what a gateway can front at all."""
    record = case('TC24', 'Gateway target inventory and capability surface',
                  'The target types the service accepts bound what can be '
                  'governed', fm_config.MODE_GATEWAY)
    control = fm_resources.control()
    shape = (control.meta.service_model.operation_model('CreateGatewayTarget')
             .input_shape.members['targetConfiguration'])
    types = {group: sorted(member.members)
             for group, member in shape.members.items()}
    gateway = fm_resources.search_gateway()
    live = []
    if gateway:
        for target in control.list_gateway_targets(
                gatewayIdentifier=gateway['gateway_id'],
                maxResults=20).get('items', []):
            live.append(f"{target['name']} ({target.get('status')})")
    record['steps'] = [
        'read CreateGatewayTarget from the service model',
        'enumerate the accepted target types per protocol group',
        "list the live targets on this account's gateway",
    ]
    has_browser = any('browser' in n.lower()
                      for g in types.values() for n in g)
    return finish(
        record, PASS,
        f"{sum(len(v) for v in types.values())} target types across "
        f"{len(types)} protocol group(s); {len(live)} live target(s)",
        checks=[
            check('the target-type surface is enumerable from the service '
                  'model', 'yes', 'yes', True),
            check('a browser target type exists', 'absent (known limitation)',
                  'absent' if not has_browser else 'present',
                  not has_browser)],
        outputs_extra=[(f'{group} target types', ', '.join(names))
                       for group, names in sorted(types.items())]
        + [('live targets', ', '.join(live) or 'none')])


# ------------------------------------------------------------- web search

def tc25(shared, say, case, check, finish):
    """maxResults is a contract, not a hint."""
    record = case('TC25', 'Search maxResults is honoured',
                  'The connector returns no more rows than requested',
                  fm_config.MODE_GATEWAY)
    gateway = fm_resources.search_gateway()
    if not gateway:
        return finish(record, SKIP, 'no gateway provisioned')
    import fm_mcp
    client = fm_mcp.McpGatewayClient(gateway['gateway_id'],
                                     url=gateway.get('gateway_url'))
    asked = 3
    record['steps'] = [
        f'call the search tool with maxResults={asked}',
        'count the rows returned',
    ]
    decision = fm_cedar.call_through_gateway(
        client, fm_config.SEARCH_TOOL,
        {'query': 'mortgage affordability', 'maxResults': asked})
    results = ((decision.backend or {}).get('results') or []
               if decision.allowed else [])
    ok = decision.allowed and len(results) <= asked
    return finish(
        record, PASS if ok else FAIL,
        f'asked for {asked}, received {len(results)}',
        checks=[check('the call was allowed', 'ALLOWED', decision.verdict),
                check('row count respects the ceiling',
                      f'<= {asked}', str(len(results)),
                      len(results) <= asked)],
        outputs_extra=[('maxResults requested', asked),
                       ('rows returned', len(results))]
        + [(f'row {i}', r.get('url'))
           for i, r in enumerate(results, start=1)])


def tc26(shared, say, case, check, finish):
    """Every row the connector returns should be usable without cleanup."""
    record = case('TC26', 'Search result contract',
                  'Every returned row carries a usable https URL',
                  fm_config.MODE_GATEWAY)
    search = (shared.get('gateway') or {}).get('search') or {}
    results = search.get('results') or []
    if not results:
        return finish(record, SKIP, 'no search results in the shared run')
    record['steps'] = [
        'take the search rows from the shared With-Gateway run',
        'check each row for a usable absolute https URL',
        'check how many also carry a title',
    ]
    usable = [r for r in results if str(r.get('url', '')).startswith('https://')]
    titled = [r for r in results if r.get('title')]
    ok = len(usable) == len(results)
    return finish(
        record, PASS if ok else FAIL,
        f'{len(usable)}/{len(results)} rows have an https URL; '
        f'{len(titled)}/{len(results)} carry a title',
        checks=[check('every row has an https URL',
                      f'{len(results)}/{len(results)}',
                      f'{len(usable)}/{len(results)}', ok),
                check('rows carry a title for citation',
                      'most rows', f'{len(titled)}/{len(results)}',
                      len(titled) >= max(1, len(results) // 2))],
        outputs_extra=[(f'row {i}',
                        f"{r.get('url')} — {str(r.get('title') or 'no title')[:60]}")
                       for i, r in enumerate(results, start=1)])


# ---------------------------------------------------------------- browser

def tc27(shared, say, case, check, finish):
    """Session lifecycle: start, signed CDP endpoint, live view, stop."""
    record = case('TC27', 'Browser session lifecycle',
                  'A session starts, exposes a signed automation endpoint, '
                  'and stops', fm_config.MODE_DIRECT)
    record['steps'] = [
        'StartBrowserSession against aws.browser.v1',
        'read back the automation (CDP) and live-view endpoints',
        'connect Playwright over the signed CDP upgrade',
        'stop the session (sessions bill until stopped)',
    ]
    try:
        with fm_browser.ManagedBrowser(label='fm-tc27') as browser:
            session_id = browser.session_id
            version = browser.version
            automation = bool(browser.automation_endpoint)
            live_view = bool(browser.live_view)
    except Exception as exc:                            # noqa: BLE001
        return finish(record, FAIL, f'{type(exc).__name__}: {exc}')
    return finish(
        record, PASS,
        f'session {session_id} started on {version} and stopped cleanly',
        checks=[check('a session id was issued', 'an id', session_id[:24],
                      bool(session_id)),
                check('a signed CDP endpoint was returned', 'yes',
                      'yes' if automation else 'no', automation),
                check('Chrome reports its build', 'a version', version,
                      bool(version))],
        outputs_extra=[('session id', session_id),
                       ('chrome build', version),
                       ('automation endpoint present', automation),
                       ('live-view endpoint present', live_view),
                       ('note',
                        'a human can watch the agent browse through the '
                        'live-view stream — useful in a demo, and worth '
                        'knowing exists')])


def tc28(shared, say, case, check, finish):
    """The same URL, rendered vs raw — the measured reason CDP matters."""
    record = case('TC28', 'JS-rendered vs raw HTTP on one URL',
                  'A rendered page yields usable content where a plain HTTP '
                  'client does not', 'both')
    url = 'https://duckduckgo.com/html/?q=mortgage+affordability'
    record['steps'] = [
        f'fetch {url[:52]}… with urllib (no JavaScript)',
        'open the same URL in managed Chrome and read the rendered body',
        'compare what each path can see',
    ]
    import urllib.request
    raw_chars, raw_links = 0, 0
    try:
        request = urllib.request.Request(
            url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=20) as response:
            html = response.read().decode('utf-8', 'replace')
        raw_chars = len(html)
        raw_links = html.count('result__a')
    except Exception as exc:                            # noqa: BLE001
        record['errors'] = [f'{type(exc).__name__}: {exc}']
    rendered_links = 0
    rendered_chars = 0
    try:
        with fm_browser.ManagedBrowser(label='fm-tc28') as browser:
            page = browser._page
            page.goto(url, wait_until='domcontentloaded', timeout=45000)
            page.wait_for_timeout(1500)
            rendered_links = len(page.query_selector_all('a.result__a'))
            rendered_chars = len(page.inner_text('body') or '')
    except Exception as exc:                            # noqa: BLE001
        return finish(record, FAIL, f'browser path failed: {exc}')
    ok = rendered_links > 0 and raw_links == 0
    return finish(
        record, PASS if ok else FAIL,
        f'rendered: {rendered_links} result links from {rendered_chars} '
        f'chars · raw HTTP: {raw_links} links from {raw_chars} bytes',
        checks=[
            check('the rendered page exposes result links', '> 0',
                  str(rendered_links), rendered_links > 0),
            check('the raw HTTP response does not', '0',
                  str(raw_links), raw_links == 0)],
        outputs_extra=[('rendered result links', rendered_links),
                       ('rendered body chars', rendered_chars),
                       ('raw HTTP bytes', raw_chars),
                       ('raw HTTP result links', raw_links),
                       ('consequence',
                        'this is why the hosted agent cannot search: '
                        'Playwright needs a compiled driver and a browser '
                        'binary, neither of which can be vendored into a '
                        'pure-Python aarch64 runtime zip')])


def tc29(shared, say, case, check, finish):
    """A screenshot — the one piece of evidence a reader can simply look at."""
    record = case('TC29', 'Browser screenshot as visual evidence',
                  'A rendered page can be captured as an image artifact',
                  fm_config.MODE_DIRECT)
    target = 'https://www.fhfa.gov/data/hpi'
    path = os.path.join(fm_trace.artifact_dir(),
                        f'tc29_screenshot_{uuid.uuid4().hex[:6]}.png')
    record['steps'] = [
        'start a managed browser session',
        f'open {target}',
        'capture a full-page screenshot into artifacts/',
    ]
    try:
        with fm_browser.ManagedBrowser(label='fm-tc29') as browser:
            page = browser._page
            page.goto(target, wait_until='domcontentloaded', timeout=45000)
            page.wait_for_timeout(1500)
            title = page.title()
            page.screenshot(path=path, full_page=False)
    except Exception as exc:                            # noqa: BLE001
        return finish(record, FAIL, f'{type(exc).__name__}: {exc}')
    size = os.path.getsize(path) if os.path.exists(path) else 0
    ok = size > 10_000
    return finish(
        record, PASS if ok else FAIL,
        f'captured {os.path.basename(path)} ({size:,} bytes) of '
        f'{title[:50]!r}',
        checks=[check('a screenshot file was written', '> 10 KB',
                      f'{size:,} bytes', ok),
                check('the page had loaded', 'a page title', title[:60],
                      bool(title))],
        outputs_extra=[('url', target), ('page title', title),
                       ('artifact', os.path.basename(path)),
                       ('bytes', f'{size:,}')])


# ----------------------------------------------------------- combinations

def tc30(shared, say, case, check, finish):
    """Runtime -> Gateway -> Cedar, in the hosted agent rather than locally."""
    record = case('TC30', 'Runtime to Gateway to Cedar, end to end',
                  'The hosted agent\'s gateway call receives a Cedar verdict',
                  fm_config.MODE_GATEWAY)
    hosted = shared.get('hosted_gateway') or {}
    if not hosted:
        return finish(record, SKIP, 'no hosted run in this pass')
    steps = hosted.get('steps') or []
    gateway_steps = [s for s in steps if s.get('service') == 'Gateway']
    identity = (hosted.get('identity') or {}).get('arn', '')
    record['steps'] = [
        'invoke the deployed runtime with a research prompt',
        'the agent signs an MCP call to the gateway with its own role',
        'the gateway evaluates Cedar and returns a verdict',
        "read the agent's self-reported step for that call",
    ]
    record['preconditions'] = ['the runtime is READY',
                              'the gateway policy engine is in ENFORCE mode']
    ok = bool(gateway_steps) and gateway_steps[0].get('status') in (
        'ALLOWED', 'DENIED')
    return finish(
        record, PASS if ok else FAIL,
        f"{len(gateway_steps)} gateway call(s) from inside Runtime; verdict "
        f"{gateway_steps[0].get('status') if gateway_steps else 'none'}",
        checks=[
            check('the hosted agent reached the gateway', 'at least 1 call',
                  f'{len(gateway_steps)} calls', bool(gateway_steps)),
            check('the call carries a policy verdict',
                  'ALLOWED or DENIED',
                  gateway_steps[0].get('status') if gateway_steps else 'none',
                  ok)],
        outputs_extra=[('runtime identity', identity),
                       ('services the hosted agent touched',
                        ', '.join(hosted.get('services_invoked') or [])),
                       ('gateway verdict',
                        gateway_steps[0].get('status') if gateway_steps
                        else 'none'),
                       ('gateway latency',
                        f"{gateway_steps[0].get('duration_ms')} ms"
                        if gateway_steps else '-')])


def tc31(shared, say, case, check, finish):
    """The hosted agent's credentials come from IMDS, not an injected key."""
    record = case('TC31', 'Runtime identity is supplied by the platform',
                  'The agent runs as a platform-issued role resolved from '
                  'IMDS', fm_config.MODE_GATEWAY)
    hosted = shared.get('hosted_gateway') or {}
    identity = hosted.get('identity') or {}
    if not identity:
        return finish(record, SKIP, 'no hosted run in this pass')
    arn = identity.get('arn', '')
    source = identity.get('credential_source', '')
    record['steps'] = [
        'invoke the deployed runtime',
        'the agent calls sts:GetCallerIdentity on itself',
        'it reports the ARN and how boto3 resolved the credentials',
    ]
    platform_role = 'BedrockAgentCore-' in arn
    ok = platform_role
    return finish(
        record, PASS if ok else FAIL,
        f'running as {arn.split("/")[-1] if arn else "unknown"} '
        f'(credential source: {source})',
        checks=[
            check('the identity is a platform-issued session',
                  'ARN contains BedrockAgentCore-',
                  'yes' if platform_role else arn[:60], platform_role),
            check('credentials resolve without an injected key',
                  'an instance/role source', source or 'unknown',
                  bool(source))],
        outputs_extra=[('full ARN', arn),
                       ('credential source', source),
                       ('why this matters',
                        'no API key is packaged with the agent — the platform '
                        'supplies a per-session role via IMDS, and that role '
                        'is the identity the gateway authorizes'),
                       ('note',
                        'AWS_CONTAINER_CREDENTIALS_* is absent in this '
                        'sandbox, which looks broken and is not')])


def tc32(shared, say, case, check, finish):
    """Identity resources exist, and are deliberately not the agent's own."""
    record = case('TC32', 'Identity resources are provisioned and separate',
                  'A workload identity and credential provider exist, and the '
                  'agent does not fetch its own credentials', '-')
    control = fm_resources.control()
    record['steps'] = [
        'list workload identities and API-key credential providers',
        "confirm the POC's pair exists",
        "confirm the agent's own run never called GetResourceApiKey",
    ]
    # maxResults is capped **below 50** on list_workload_identities and the
    # service raises ValidationException rather than clamping. Measured: 50
    # fails, 20 is accepted. Paginated by hand because a swallowed paging
    # error here reads as "the account has no identities", which is exactly
    # how this case first reported a false negative.
    def _page_all(call, key: str, size: int = 20) -> List[str]:
        names, token = [], None
        while True:
            kwargs: Dict[str, Any] = {'maxResults': size}
            if token:
                kwargs['nextToken'] = token
            page = call(**kwargs)
            for item in page.get(key) or page.get('items') or []:
                if item.get('name'):
                    names.append(item['name'])
            token = page.get('nextToken')
            if not token or len(names) >= 200:
                return names

    identities, providers = [], []
    try:
        identities = _page_all(control.list_workload_identities,
                               'workloadIdentities')
    except Exception as exc:                            # noqa: BLE001
        record.setdefault('errors', []).append(f'identities: {exc}')
    try:
        providers = _page_all(control.list_api_key_credential_providers,
                              'credentialProviders')
    except Exception as exc:                            # noqa: BLE001
        record.setdefault('errors', []).append(f'providers: {exc}')
    hosted = shared.get('hosted_gateway') or {}
    fetched = any('GetResourceApiKey' in str(s.get('api', ''))
                  for s in hosted.get('steps') or [])
    ok = bool(identities) and bool(providers) and not fetched
    return finish(
        record, PASS if ok else FAIL,
        f'{len(identities)} workload identity(ies) and {len(providers)} '
        f'credential provider(s) exist; agent self-fetch: '
        f'{"yes" if fetched else "no"}',
        checks=[
            check('workload identities exist', 'at least 1',
                  str(len(identities)), bool(identities)),
            check('credential providers exist', 'at least 1',
                  str(len(providers)), bool(providers)),
            check('the agent does not fetch its own credentials',
                  'no GetResourceApiKey call',
                  'yes it did' if fetched else 'confirmed', not fetched)],
        outputs_extra=[
            ('workload identities (first 5)',
             ', '.join([i for i in identities if i][:5]) or 'none'),
            ('credential providers (first 5)',
             ', '.join([p for p in providers if p][:5]) or 'none'),
            ('design point',
             'an agent fetching its own credentials is the pattern this '
             'architecture exists to avoid, so demonstrating it would argue '
             'against the conclusion; the backend consumes a different pair')])


def tc33(shared, say, case, check, finish):
    """Shadow mode: the same request, allowed then denied, one field changed."""
    record = case('TC33', 'FGAC shadow mode changes the verdict',
                  'A forbid in LOG_ONLY is evaluated but does not block; in '
                  'ACTIVE it blocks', fm_config.MODE_GATEWAY)
    stack = fm_resources.memory_stack()
    if not stack:
        return finish(record, SKIP, 'memory gateway not provisioned')
    control = fm_resources.control()
    client = fm_memory.MemoryGatewayClient()
    namespace = fm_config.namespace_for(fm_config.USER_PRIMARY)
    name = f'fmpoc_tc33_forbid_{uuid.uuid4().hex[:6]}'
    statement = (
        f'forbid (\n'
        f'    principal is AgentCore::IamEntity,\n'
        f'    action == AgentCore::Action::'
        f'"{fm_memory.action("RetrieveMemoryRecords")}",\n'
        f'    resource == AgentCore::Gateway::"{stack.gateway_arn}"\n'
        f') when {{\n'
        f'    context has input &&\n'
        f'    context.input has namespace &&\n'
        f'    context.input.namespace == "{namespace}"\n'
        f'}};')
    record['steps'] = [
        'read the namespace with only the standing permit in force',
        'install a forbid covering it, in ACTIVE — read again',
        'flip the same policy to LOG_ONLY with one UpdatePolicy — read again',
        'flip back to ACTIVE — read again',
        'remove the policy and wait for enforcement to drain',
    ]
    record['preconditions'] = [
        f'fmpoc_permit_read_own_namespace permits {namespace}']
    policy_id = None
    try:
        before = client.retrieve(namespace)['verdict']
        installed = fm_cedar.install(control, stack.engine_id, {
            'name': name, 'kind': 'forbid, shadow-mode probe',
            'description': 'TC33 shadow-mode probe', 'enforcement': 'ACTIVE',
            'expect_status': 'ACTIVE', 'plain': 'temporary probe policy',
            'statement': statement}, say=lambda *_: None)
        policy_id = installed.get('policy_id')
        if installed.get('status') != 'ACTIVE':
            return finish(record, FAIL,
                          f"probe policy did not activate: "
                          f"{installed.get('status_reasons')}")
        time.sleep(4)
        enforcing = client.retrieve(namespace)['verdict']
        fm_cedar.set_enforcement(control, stack.engine_id, policy_id,
                                 'LOG_ONLY', say=lambda *_: None)
        time.sleep(6)
        shadowed = client.retrieve(namespace)['verdict']
        fm_cedar.set_enforcement(control, stack.engine_id, policy_id,
                                 'ACTIVE', say=lambda *_: None)
        time.sleep(6)
        again = client.retrieve(namespace)['verdict']
    finally:
        if policy_id:
            fm_cedar.uninstall(control, stack.engine_id, policy_id,
                               say=lambda *_: None, label=name)
            # Deletion lags behind the call that requested it, so wait for the
            # data plane to stop enforcing before leaving the case.
            for _ in range(20):
                if client.retrieve(namespace)['verdict'] == 'ALLOWED':
                    break
                time.sleep(3)
    ok = (before == 'ALLOWED' and enforcing == 'DENIED'
          and shadowed == 'ALLOWED' and again == 'DENIED')
    return finish(
        record, PASS if ok else FAIL,
        f'permit only: {before} → forbid ACTIVE: {enforcing} → '
        f'LOG_ONLY: {shadowed} → ACTIVE again: {again}',
        checks=[
            check('allowed with only the permit in force', 'ALLOWED', before),
            check('denied once the forbid is ACTIVE', 'DENIED', enforcing),
            check('allowed again in LOG_ONLY', 'ALLOWED', shadowed),
            check('denied again back in ACTIVE', 'DENIED', again)],
        outputs_extra=[
            ('policy installed', name),
            ('statement', statement.replace('\n', ' ')),
            ('verdict sequence',
             f'{before} → {enforcing} → {shadowed} → {again}'),
            ('cost of the change',
             'one UpdatePolicy call, one field, no statement rewrite — so a '
             'rule can be rolled out in shadow and enforced later without '
             'being rewritten')])


def tc34(shared, say, case, check, finish):
    """A policy on a path parameter is accepted and then never matches."""
    record = case('TC34', 'FGAC path-vs-body binding',
                  'A policy on a path-carried field reaches ACTIVE and then '
                  'denies every request', fm_config.MODE_GATEWAY)
    stack = fm_resources.memory_stack()
    if not stack:
        return finish(record, SKIP, 'memory gateway not provisioned')
    control = fm_resources.control()
    client = fm_memory.MemoryGatewayClient()
    name = f'fmpoc_tc34_path_{uuid.uuid4().hex[:6]}'
    statement = (
        f'permit (\n'
        f'    principal is AgentCore::IamEntity,\n'
        f'    action == AgentCore::Action::'
        f'"{fm_memory.action("ListEvents")}",\n'
        f'    resource == AgentCore::Gateway::"{stack.gateway_arn}"\n'
        f') when {{\n'
        f'    context has input &&\n'
        f'    context.input has actorId &&\n'
        f'    context.input.actorId == "{fm_config.USER_PRIMARY}"\n'
        f'}};')
    record['steps'] = [
        'install a permit on ListEvents keyed on the path-carried actorId',
        'confirm the policy reaches ACTIVE (nothing warns)',
        'call ListEvents for exactly that actor',
        'remove the policy',
    ]
    policy_id = None
    try:
        installed = fm_cedar.install(control, stack.engine_id, {
            'name': name, 'kind': 'permit, path-parameter probe',
            'description': 'TC34 path-binding probe', 'enforcement': 'ACTIVE',
            'expect_status': 'ACTIVE', 'plain': 'temporary probe policy',
            'statement': statement}, say=lambda *_: None)
        policy_id = installed.get('policy_id')
        status = installed.get('status')
        time.sleep(4)
        call = client.list_events(fm_config.USER_PRIMARY,
                                 f'{fm_config.SESSION_PREFIX}-tc34')
        verdict = call['verdict']
    finally:
        if policy_id:
            fm_cedar.uninstall(control, stack.engine_id, policy_id,
                               say=lambda *_: None, label=name)
    inert = status == 'ACTIVE' and verdict == 'DENIED'
    return finish(
        record, PASS if inert else FAIL,
        f'policy status {status}; the call it was written to allow returned '
        f'{verdict}',
        checks=[
            check('the policy is accepted and activates', 'ACTIVE', status),
            check('the call it targets is still denied', 'DENIED', verdict)],
        outputs_extra=[
            ('policy status', status),
            ('call verdict', verdict),
            ('statement', statement.replace('\n', ' ')),
            ('why',
             'context.input is populated from the request body, not the URI. '
             'A path parameter is declared in the policy schema — a presence '
             'check on one is rejected as Overly Permissive, which proves the '
             'validator knows it — but it is absent at evaluation time'),
            ('consequence',
             'per-caller isolation is unavailable on ListEvents, GetEvent, '
             'DeleteEvent, ListSessions, GetMemoryRecord and '
             'DeleteMemoryRecord — most of the read surface')])


def tc35(shared, say, case, check, finish):
    """Recall across sessions, not just within one."""
    record = case('TC35', 'Memory recall across sessions',
                  'Events written in separate sessions are both retrievable '
                  'for the same actor', fm_config.MODE_DIRECT)
    memory_id = fm_resources.memory_id()
    if not memory_id:
        return finish(record, SKIP, 'no memory resource')
    marker_a = f'TC35-A-{uuid.uuid4().hex[:6]}'
    marker_b = f'TC35-B-{uuid.uuid4().hex[:6]}'
    session_a = f'{fm_config.SESSION_PREFIX}-a-{uuid.uuid4().hex[:5]}'
    session_b = f'{fm_config.SESSION_PREFIX}-b-{uuid.uuid4().hex[:5]}'
    record['steps'] = [
        f'write {marker_a} in session A',
        f'write {marker_b} in session B, same actor',
        'list the actor\'s recent sessions',
        'read each session back and look for both markers',
    ]
    fm_memory.write_event_direct(fm_config.USER_PRIMARY,
                                 f'{marker_a} mortgage research note',
                                 session_id=session_a)
    fm_memory.write_event_direct(fm_config.USER_PRIMARY,
                                 f'{marker_b} mortgage research note',
                                 session_id=session_b)
    time.sleep(2)
    read_a = fm_memory.list_events_direct(fm_config.USER_PRIMARY,
                                          session_id=session_a)
    read_b = fm_memory.list_events_direct(fm_config.USER_PRIMARY,
                                          session_id=session_b)
    found_a = any(marker_a in e.get('text', '') for e in read_a.get('events') or [])
    found_b = any(marker_b in e.get('text', '') for e in read_b.get('events') or [])
    recent = fm_memory.list_events_direct(fm_config.USER_PRIMARY, limit=10)
    ok = found_a and found_b
    return finish(
        record, PASS if ok else FAIL,
        f'session A marker {"found" if found_a else "missing"}; session B '
        f'marker {"found" if found_b else "missing"}; '
        f'{len(recent.get("events") or [])} recent event(s) across sessions',
        checks=[
            check('session A event is retrievable', 'found',
                  'found' if found_a else 'missing', found_a),
            check('session B event is retrievable', 'found',
                  'found' if found_b else 'missing', found_b),
            check('both sessions belong to the same actor',
                  fm_config.USER_PRIMARY, fm_config.USER_PRIMARY, True)],
        outputs_extra=[('session A', session_a), ('marker A', marker_a),
                       ('session B', session_b), ('marker B', marker_b),
                       ('recent events for this actor',
                        len(recent.get('events') or [])),
                       ('note',
                        'session scoping is the application\'s choice; Memory '
                        'stores whatever sessionId it is given, and the '
                        'gateway cannot govern this read because actorId is '
                        'a path parameter here')])


CASES: List[Callable] = [tc21, tc22, tc23, tc24, tc25, tc26, tc27, tc28,
                         tc29, tc30, tc31, tc32, tc33, tc34, tc35]
