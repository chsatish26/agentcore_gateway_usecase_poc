"""Settings the hosted agent reads, inside the Runtime sandbox.

Separate from `fm_config.py` on purpose: this file is the only config that
ships in the zip, and it must import nothing but the standard library. The
runtime sandbox has no boto3 until `agent.py` puts `vendor/` on `sys.path`, and
`fm_config` pulls in nothing heavy today but would be an easy thing to break
later.

Values arrive as **environment variables** where they vary, and the gateway and
memory identifiers arrive in the **invocation payload** instead - the caller
already resolved them, and an agent that rediscovers them is a second place for
them to be wrong, needing IAM it would not otherwise need.
"""

import os

REGION = os.getenv('AWS_REGION', 'us-east-1')

# Gateway. GATEWAY_ID is overridden per-deployment; the default is the shared
# search gateway this POC reuses.
GATEWAY_ID = os.getenv('GATEWAY_ID', 'novacart-price-match-poc-qdnpxdyr1x')
SEARCH_TOOL = os.getenv('SEARCH_TOOL', 'research___WebSearch')
MCP_PROTOCOL_VERSION = os.getenv('MCP_PROTOCOL_VERSION', '2025-11-25')
MCP_SERVICE = 'bedrock-agentcore'

# Model. Claude needs the `us.` inference-profile prefix in this account, and
# 4.5+ rejects temperature and topP in the same request - send one.
MODEL_ID = os.getenv('MODEL_ID',
                     'us.anthropic.claude-haiku-4-5-20251001-v1:0')
MAX_TOKENS = int(os.getenv('MAX_TOKENS', '1200'))

MEMORY_NAME = os.getenv('MEMORY_NAME', 'novacart_price_match_poc_memory')
BROWSER_ID = os.getenv('BROWSER_ID', 'aws.browser.v1')


def gateway_url(gateway_id: str = None, region: str = None) -> str:
    return (f"https://{gateway_id or GATEWAY_ID}.gateway.bedrock-agentcore."
            f"{region or REGION}.amazonaws.com/mcp")
