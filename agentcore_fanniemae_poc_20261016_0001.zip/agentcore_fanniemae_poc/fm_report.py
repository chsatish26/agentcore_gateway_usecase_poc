"""Render a test-result run as a visual PDF, into `artifacts/`.

Design decisions here follow the project's data-viz procedure - form first,
colour last, and the palette was put through the validator rather than eyeballed:

* **No pie chart for the status split.** A proportion across three states is read
  faster as a row of hero numbers plus one stacked bar; a pie makes the reader
  compare angles for no gain.
* **Status colours are the fixed reserved set** - good `#0ca30c`, warning
  `#fab219`, critical `#d03b3b` - never reused for a series. The validator
  reports CVD separation PASS (worst adjacent dE 11.3, target >= 8) and
  normal-vision PASS (27.6, floor 15), and flags `#fab219` at 1.79:1 contrast on
  the light surface. That sub-3:1 is documented as by-design for status, and the
  stated mitigation is **icon + label**: every status in this PDF carries a glyph
  and the word, so colour never carries meaning alone. This matters more in print
  than on screen - a greyscaled page keeps all of its meaning.
* **Timing bars are one series**, so one sequential hue (blue step 450) and no
  legend box - the title names the series. Values are direct-labelled rather than
  read off a grid.
* Grid and axes recessive, text in ink tokens and never in a series colour.

reportlab lays out the document; matplotlib renders the two figures as images.
"""

import io
import json
import json
import os
import textwrap
import time
from typing import Any, Dict, List, Optional, Tuple

import matplotlib
matplotlib.use('Agg')                 # no display in SageMaker; must precede pyplot
import matplotlib.pyplot as plt
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

import fm_trace

# ---- tokens, from the validated reference palette -------------------------
SURFACE = '#fcfcfb'
PAGE = '#f9f9f7'
INK = '#0b0b0b'
INK_2 = '#52514e'
MUTED = '#898781'
GRID = '#e1e0d9'
BASELINE = '#c3c2b7'
SERIES_1 = '#2a78d6'          # sequential blue, step 450 - single series
STATUS = {'PASS': '#0ca30c', 'BLOCKED': '#fab219', 'FAIL': '#d03b3b',
          'SKIP': '#898781'}
# The relief for status colour: a glyph plus the word, always both.
# Restricted to marks the base PDF font actually carries - U+25D0 rendered as a
# missing-glyph box in the first build, which is worse than no glyph at all.
GLYPH = {'PASS': '\u2713', 'BLOCKED': '!', 'FAIL': '\u2717', 'SKIP': '-'}

ORDER = ['PASS', 'BLOCKED', 'FAIL', 'SKIP']

# ---- themed reports ------------------------------------------------------
#
# Three audiences read these results differently: someone evaluating Gateway,
# someone evaluating web search, someone evaluating the browser. So the matrix
# is published three ways rather than once.
#
# A case appears in a theme when it exercises that capability, which means
# several appear more than once - and that is correct rather than duplication.
# TC01 is the clearest example: "web search without Gateway" is a *web search*
# case, and it is also a *browser* case, because with no gateway in the path
# the managed Browser is what performs the search.
#
# COMMON cases exercise all three at once and are included in every report, so
# each PDF stands alone without the reader needing the other two.
COMMON = ['TC05', 'TC18', 'TC19', 'TC20']

THEMES: Dict[str, Dict[str, Any]] = {
    'gateway': {
        'title': 'Gateway test cases',
        'blurb': ('Everything that depends on an AgentCore Gateway being in '
                  'the path: the Cedar enforcement points on search and on '
                  'memory, deny-by-default, authentication, and what is lost '
                  'when the gateway is unavailable.'),
        'cases': ['TC02', 'TC04', 'TC06', 'TC07', 'TC08', 'TC09', 'TC10',
                  'TC11', 'TC12', 'TC15', 'TC17',
                  # capability cases
                  'TC21', 'TC22', 'TC23', 'TC24', 'TC25', 'TC30', 'TC31',
                  'TC32', 'TC33', 'TC34'],
    },
    'websearch': {
        'title': 'Web search test cases',
        'blurb': ('Search in both modes. The finding these cases exist to '
                  'record: web search is not a standalone AgentCore API - it '
                  'exists only as the gateway web-search connector - so the '
                  'two modes are different capabilities, not one wrapped in '
                  'the other.'),
        'cases': ['TC01', 'TC02', 'TC07', 'TC08', 'TC09', 'TC13', 'TC15',
                  'TC16',
                  # capability cases
                  'TC21', 'TC22', 'TC25', 'TC26', 'TC28'],
    },
    'combination': {
        'title': 'Combined capability test cases',
        'blurb': ('Cases that only mean something when several services are '
                  'in one path: Runtime signing its own gateway calls, '
                  'Identity supplying that signature, Cedar deciding on it, '
                  'and Memory recording the outcome. Includes the two '
                  'fine-grained access control cases that measure what the '
                  'policy layer can and cannot see.'),
        'cases': ['TC05', 'TC10', 'TC11', 'TC12', 'TC17', 'TC23', 'TC30',
                  'TC31', 'TC32', 'TC33', 'TC34', 'TC35'],
    },
    'browser': {
        'title': 'Browser test cases',
        'blurb': ('Content extraction through the managed Browser, and why it '
                  'is identical in both modes: <b>browser</b> is not a '
                  'CreateGatewayTarget target type, so no Cedar action for '
                  '&quot;open a page&quot; can exist.'),
        'cases': ['TC01', 'TC03', 'TC04', 'TC14', 'TC16',
                  # capability cases
                  'TC27', 'TC28', 'TC29'],
    },
}


def theme_cases(bundle: Dict[str, Any], theme: str) -> List[Dict[str, Any]]:
    """The cases for one theme, plus the common ones, in TC order."""
    wanted = set(THEMES[theme]['cases']) | set(COMMON)
    return [c for c in bundle.get('cases') or [] if c['id'] in wanted]


def _rich(text: Any) -> str:
    """Make free text safe and expressive for reportlab's mini-HTML.

    Two jobs. Escape the characters that would otherwise be read as markup -
    an unescaped `&` or `<` from a URL or an error message raises at build
    time. And convert markdown emphasis to tags, because `**not**` renders as
    literal asterisks otherwise; artifacts written before this existed still
    render correctly, which is why the conversion lives in the renderer rather
    than in the data.
    """
    import re as _re
    out = (str(text or '').replace('&', '&amp;').replace('<', '&lt;')
           .replace('>', '&gt;'))
    out = _re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', out)
    out = _re.sub(r'(?<![\w*])\*([^*\n]+)\*(?![\w*])', r'<i>\1</i>', out)
    out = _re.sub(r'`([^`]+)`', r'<i>\1</i>', out)
    # Restore the small tag subset reportlab accepts. Escaping has to happen
    # first (an unescaped `&` in a URL raises at build time), which means any
    # tags already present in the source text get escaped too - and then
    # render as literal "<b>not</b>". Un-escaping just these puts them back.
    for tag in ('b', 'i', 'u', 'br/'):
        out = (out.replace(f'&lt;{tag}&gt;', f'<{tag}>')
                  .replace(f'&lt;/{tag}&gt;', f'</{tag}>'))
    return out


def _styles() -> Dict[str, ParagraphStyle]:
    base = getSampleStyleSheet()
    return {
        'title': ParagraphStyle('t', parent=base['Title'], fontSize=19,
                                leading=23, textColor=colors.HexColor(INK),
                                alignment=TA_LEFT, spaceAfter=2),
        'sub': ParagraphStyle('s', parent=base['Normal'], fontSize=9.5,
                              leading=13, textColor=colors.HexColor(INK_2)),
        'h2': ParagraphStyle('h2', parent=base['Heading2'], fontSize=13,
                             leading=16, textColor=colors.HexColor(INK),
                             spaceBefore=10, spaceAfter=4),
        'h3': ParagraphStyle('h3', parent=base['Heading3'], fontSize=10.5,
                             leading=13, textColor=colors.HexColor(INK),
                             spaceBefore=7, spaceAfter=2),
        'body': ParagraphStyle('b', parent=base['Normal'], fontSize=8.6,
                               leading=11.6, textColor=colors.HexColor(INK)),
        'cell': ParagraphStyle('c', parent=base['Normal'], fontSize=7.6,
                               leading=9.8, textColor=colors.HexColor(INK)),
        'muted': ParagraphStyle('m', parent=base['Normal'], fontSize=7.6,
                                leading=10, textColor=colors.HexColor(MUTED)),
    }


# ----------------------------------------------------------------- figures

def _status_figure(counts: Dict[str, int], total: int) -> io.BytesIO:
    """Hero numbers plus one stacked proportion bar. Deliberately not a pie."""
    present = [s for s in ORDER if counts.get(s)]
    fig, (tiles, bar) = plt.subplots(
        2, 1, figsize=(10.6, 2.5), height_ratios=[1.25, 1],
        facecolor=SURFACE)
    fig.subplots_adjust(hspace=0.55, left=0.02, right=0.98, top=0.95,
                        bottom=0.22)

    # --- stat tiles: the number is the headline, the label carries meaning
    tiles.set_facecolor(SURFACE)
    tiles.axis('off')
    for index, status in enumerate(present):
        x = index / max(len(present), 1)
        tiles.text(x, 0.52, str(counts[status]), fontsize=31, fontweight='bold',
                   color=STATUS[status], ha='left', va='center',
                   transform=tiles.transAxes)
        tiles.text(x, 0.06, f'{GLYPH[status]}  {status}', fontsize=9.5,
                   color=INK_2, ha='left', va='center',
                   transform=tiles.transAxes)
    tiles.text(0.985, 0.52, f'{total}', fontsize=22, color=MUTED,
               ha='right', va='center', transform=tiles.transAxes)
    tiles.text(0.985, 0.06, 'TOTAL CASES', fontsize=8, color=MUTED,
               ha='right', va='center', transform=tiles.transAxes)

    # --- one stacked bar, 2px surface gap between segments, rounded ends
    bar.set_facecolor(SURFACE)
    left = 0.0
    for status in present:
        width = counts[status] / total * 100
        bar.barh([0], [width], left=[left], height=0.44,
                 color=STATUS[status], edgecolor=SURFACE, linewidth=1.6)
        if width >= 7:                    # label only where it fits
            bar.text(left + width / 2, 0, f'{counts[status]}  {status}',
                     ha='center', va='center', fontsize=8.5, color='white',
                     fontweight='bold')
        left += width
    bar.set_xlim(0, 100)
    bar.set_ylim(-0.5, 0.5)
    bar.set_yticks([])
    bar.set_xticks([0, 25, 50, 75, 100])
    bar.set_xticklabels(['0%', '25%', '50%', '75%', '100%'], fontsize=7.5,
                        color=MUTED)
    bar.grid(axis='x', color=GRID, linewidth=0.6, alpha=0.9)
    bar.set_axisbelow(True)
    for side in ('top', 'right', 'left'):
        bar.spines[side].set_visible(False)
    bar.spines['bottom'].set_color(BASELINE)
    bar.spines['bottom'].set_linewidth(0.8)

    return _png(fig)


def _timing_figure(spans: List[Dict[str, Any]]) -> Optional[io.BytesIO]:
    """Per-service time for one run. One series, so one hue and no legend."""
    totals: Dict[str, float] = {}
    for span in spans:
        service = span.get('service')
        ms = span.get('duration_ms')
        if service and isinstance(ms, (int, float)):
            totals[service] = totals.get(service, 0.0) + float(ms)
    if not totals:
        return None
    rows = sorted(totals.items(), key=lambda kv: kv[1])
    labels = [r[0] for r in rows]
    values = [r[1] for r in rows]

    height = max(1.9, 0.42 * len(rows) + 0.9)
    fig, axis = plt.subplots(figsize=(10.6, height), facecolor=SURFACE)
    axis.set_facecolor(SURFACE)
    axis.barh(labels, values, height=0.52, color=SERIES_1, edgecolor=SURFACE,
              linewidth=1.4)
    span_max = max(values)
    for y, value in enumerate(values):
        axis.text(value + span_max * 0.015, y, f'{value:,.0f} ms',
                  va='center', fontsize=8, color=INK_2)
    axis.set_xlim(0, span_max * 1.16)
    axis.tick_params(axis='y', labelsize=8.4, colors=INK, length=0)
    axis.tick_params(axis='x', labelsize=7.5, colors=MUTED, length=0)
    axis.grid(axis='x', color=GRID, linewidth=0.6)
    axis.set_axisbelow(True)
    for side in ('top', 'right', 'left'):
        axis.spines[side].set_visible(False)
    axis.spines['bottom'].set_color(BASELINE)
    axis.spines['bottom'].set_linewidth(0.8)
    axis.set_xlabel('milliseconds (client-measured)', fontsize=7.8,
                    color=MUTED)
    fig.tight_layout()
    return _png(fig)


def _png(fig) -> io.BytesIO:
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png', dpi=190, facecolor=SURFACE,
                bbox_inches='tight', pad_inches=0.08)
    plt.close(fig)
    buffer.seek(0)
    return buffer


# ------------------------------------------------------------------ tables

def _status_cell(status: str, style) -> Paragraph:
    """Glyph + word + colour. Never colour alone — this is the relief rule."""
    return Paragraph(
        f'<font color="{STATUS.get(status, MUTED)}"><b>{GLYPH.get(status, "")} '
        f'{status}</b></font>', style)


def _summary_table(cases: List[Dict[str, Any]], styles) -> Table:
    head = ['ID', 'Scenario', 'Mode', 'Result', 'Checks', 'Actual']
    rows = [[Paragraph(f'<b>{h}</b>', styles['cell']) for h in head]]
    for case in cases:
        rows.append([
            Paragraph(f"<b>{case['id']}</b>", styles['cell']),
            Paragraph(case['scenario'], styles['cell']),
            Paragraph(str(case.get('mode', '-')).replace('_', ' '),
                      styles['cell']),
            _status_cell(case['result'], styles['cell']),
            Paragraph(f"{case.get('checks_passed', 0)}/"
                      f"{case.get('checks_total', 0)}", styles['cell']),
            Paragraph(_rich(str(case.get('actual', ''))[:210]),
                      styles['cell']),
        ])
    table = Table(rows, repeatRows=1,
                  colWidths=[14 * mm, 52 * mm, 24 * mm, 22 * mm, 14 * mm,
                             130 * mm])
    style = [
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(PAGE)),
        ('LINEBELOW', (0, 0), (-1, 0), 0.7, colors.HexColor(BASELINE)),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('TOPPADDING', (0, 0), (-1, -1), 3.2),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3.2),
        ('LEFTPADDING', (0, 0), (-1, -1), 4),
        ('RIGHTPADDING', (0, 0), (-1, -1), 4),
        ('INNERGRID', (0, 1), (-1, -1), 0.3, colors.HexColor(GRID)),
        ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor(BASELINE)),
    ]
    for index, case in enumerate(cases, start=1):
        if index % 2 == 0:
            style.append(('BACKGROUND', (0, index), (-1, index),
                          colors.HexColor('#fdfdfc')))
    table.setStyle(TableStyle(style))
    return table


def _checks_table(case: Dict[str, Any], styles) -> Table:
    """The assertion level: what was expected, what happened, and whether it held."""
    head = ['', 'Check', 'Expected', 'Actual']
    rows = [[Paragraph(f'<b>{h}</b>', styles['cell']) for h in head]]
    for item in case.get('checks') or []:
        mark = 'PASS' if item.get('passed') else 'FAIL'
        rows.append([
            Paragraph(f'<font color="{STATUS[mark]}"><b>{GLYPH[mark]}</b>'
                      f'</font>', styles['cell']),
            Paragraph(_rich(str(item.get('check', ''))[:110]),
                      styles['cell']),
            Paragraph(_rich(str(item.get('expected', ''))[:110]),
                      styles['cell']),
            Paragraph(_rich(str(item.get('actual', ''))[:140]),
                      styles['cell']),
        ])
    table = Table(rows, repeatRows=1,
                  colWidths=[7 * mm, 72 * mm, 72 * mm, 105 * mm])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(PAGE)),
        ('LINEBELOW', (0, 0), (-1, 0), 0.6, colors.HexColor(BASELINE)),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('TOPPADDING', (0, 0), (-1, -1), 2.6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2.6),
        ('INNERGRID', (0, 1), (-1, -1), 0.3, colors.HexColor(GRID)),
        ('BOX', (0, 0), (-1, -1), 0.4, colors.HexColor(BASELINE)),
    ]))
    return table


def _kv_table(rows: List[Dict[str, str]], styles, head: str,
              value_width: float = 196) -> Optional[Table]:
    """A label/value table for the inputs and the observed outputs."""
    if not rows:
        return None
    data = [[Paragraph(f'<b>{head}</b>', styles['cell']),
             Paragraph('<b>Value</b>', styles['cell'])]]
    for row in rows:
        data.append([
            Paragraph(_rich(str(row.get('label', ''))[:60]),
                      styles['cell']),
            Paragraph(_rich(str(row.get('value', ''))[:700]),
                      styles['cell']),
        ])
    table = Table(data, repeatRows=1,
                  colWidths=[60 * mm, value_width * mm])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(PAGE)),
        ('LINEBELOW', (0, 0), (-1, 0), 0.6, colors.HexColor(BASELINE)),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('TOPPADDING', (0, 0), (-1, -1), 2.4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2.4),
        ('INNERGRID', (0, 1), (-1, -1), 0.3, colors.HexColor(GRID)),
        ('BOX', (0, 0), (-1, -1), 0.4, colors.HexColor(BASELINE)),
    ]))
    return table


def _flow_table(run: Dict[str, Any], styles) -> Optional[Table]:
    spans = ((run.get('trace') or {}).get('spans') or run.get('steps') or [])
    if not spans:
        return None
    head = ['#', 'Service', 'API', 'Status', 'ms', 'Enforced at',
            'Deciding policy']
    rows = [[Paragraph(f'<b>{h}</b>', styles['cell']) for h in head]]
    for index, span in enumerate(spans, start=1):
        status = span.get('status', '')
        tint = {'OK': '#0ca30c', 'ALLOWED': '#0ca30c', 'DENIED': '#d03b3b',
                'FAILED': '#d03b3b', 'ERROR': '#d03b3b',
                'UNAVAILABLE': '#fab219', 'SKIPPED': MUTED}.get(status, INK)
        rows.append([
            Paragraph(str(index), styles['cell']),
            Paragraph(str(span.get('service', '')), styles['cell']),
            Paragraph(str(span.get('api', ''))[:40], styles['cell']),
            Paragraph(f'<font color="{tint}"><b>{status}</b></font>',
                      styles['cell']),
            Paragraph(str(span.get('duration_ms', '')), styles['cell']),
            Paragraph(str(span.get('enforcement_point', '-'))[:60],
                      styles['cell']),
            Paragraph(str(span.get('deciding_policy') or '-')[:44],
                      styles['cell']),
        ])
    table = Table(rows, repeatRows=1,
                  colWidths=[8 * mm, 34 * mm, 48 * mm, 20 * mm, 16 * mm,
                             76 * mm, 54 * mm])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(PAGE)),
        ('LINEBELOW', (0, 0), (-1, 0), 0.6, colors.HexColor(BASELINE)),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('TOPPADDING', (0, 0), (-1, -1), 2.6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2.6),
        ('INNERGRID', (0, 1), (-1, -1), 0.3, colors.HexColor(GRID)),
        ('BOX', (0, 0), (-1, -1), 0.4, colors.HexColor(BASELINE)),
    ]))
    return table


# ------------------------------------------------------------------- render

def build(bundle: Dict[str, Any], path: str = None,
          theme: str = None) -> str:
    """Render a test-case bundle to PDF. Returns the path written.

    `theme` selects one of THEMES and filters the cases to it (plus the common
    ones). Counts are recomputed from the filtered set, so each themed report's
    headline is about its own cases and not the whole matrix.
    """
    styles = _styles()
    if theme:
        cases = theme_cases(bundle, theme)
    else:
        cases = bundle.get('cases') or []
    counts: Dict[str, int] = {}
    for case in cases:
        counts[case['result']] = counts.get(case['result'], 0) + 1
    total = len(cases) or 1
    summary = {'blocked_ids': [c['id'] for c in cases
                               if c['result'] == 'BLOCKED']}

    if path is None:
        stamp = (bundle.get('generated_at') or time.strftime('%Y%m%d_%H%M%S')
                 ).replace(':', '').replace('-', '').replace('T', '_')
        name = (f'test_report_{theme}_{stamp}.pdf' if theme
                else f'test_report_{stamp}.pdf')
        path = os.path.join(fm_trace.artifact_dir(), name)

    document = SimpleDocTemplate(
        path, pagesize=landscape(A4),
        leftMargin=12 * mm, rightMargin=12 * mm,
        topMargin=11 * mm, bottomMargin=11 * mm,
        title='AgentCore Gateway & Memory POC — test results',
        author='Fannie Mae finance use-case POC')

    story: List[Any] = []
    heading = (THEMES[theme]['title'] if theme
               else 'AgentCore Gateway &amp; Memory — test results')
    story.append(Paragraph(heading, styles['title']))
    story.append(Paragraph(
        f"{bundle.get('use_case', '')} &nbsp;·&nbsp; run "
        f"{bundle.get('generated_at', '')}", styles['sub']))
    if theme:
        story.append(Spacer(1, 2 * mm))
        story.append(Paragraph(_rich(THEMES[theme]['blurb']),
                               styles['body']))
        shared = [c['id'] for c in cases if c['id'] in COMMON]
        story.append(Spacer(1, 1.5 * mm))
        story.append(Paragraph(
            f"This is one of three themed reports (gateway, web search, "
            f"browser) from the same run. "
            f"{', '.join(shared)} exercise all three capabilities and appear "
            f"in every report, so this one stands alone; a few other cases "
            f"appear in two reports because they genuinely exercise both.",
            styles['muted']))
    story.append(Spacer(1, 3 * mm))
    story.append(Paragraph(
        f"<i>{bundle.get('disclaimer', '')}</i>", styles['muted']))
    story.append(Spacer(1, 4 * mm))

    # --- the headline
    story.append(Image(_status_figure(counts, total),
                       width=263 * mm, height=62 * mm))
    story.append(Spacer(1, 2 * mm))
    blocked = summary.get('blocked_ids') or []
    if blocked:
        story.append(Paragraph(
            f"<b>Blocked:</b> {', '.join(blocked)}. These are not failures and "
            f"not passes — each is a capability this account cannot provide, "
            f"reported with the measurement that blocks it. A green row for "
            f"one of them would defeat the purpose of the exercise.",
            styles['body']))
    story.append(Spacer(1, 3 * mm))

    # --- the matrix
    story.append(Paragraph('Every case', styles['h2']))
    story.append(_summary_table(cases, styles))

    # --- the flow, then the per-case assertions
    runs = {k: v for k, v in (bundle.get('runs') or {}).items() if v}
    labels = {'with_gateway': 'With Gateway (local)',
              'without_gateway': 'Without Gateway (local)',
              'hosted_with_gateway': 'With Gateway (AgentCore Runtime)',
              'hosted_without_gateway': 'Without Gateway (AgentCore Runtime)'}
    for key, run in runs.items():
        story.append(PageBreak())
        story.append(Paragraph(f'Flow — {labels.get(key, key)}',
                               styles['h2']))
        story.append(Paragraph(
            'services: ' + ', '.join(run.get('services_invoked') or []),
            styles['sub']))
        story.append(Spacer(1, 2 * mm))
        spans = ((run.get('trace') or {}).get('spans')
                 or run.get('steps') or [])
        figure = _timing_figure(spans)
        if figure:
            rows = len({s.get('service') for s in spans if s.get('service')})
            story.append(Image(figure, width=250 * mm,
                               height=min(70, 11 * rows + 22) * mm))
            story.append(Spacer(1, 2 * mm))
        table = _flow_table(run, styles)
        if table:
            story.append(table)
        note = (run.get('trace') or {}).get('trace_note')
        if note:
            story.append(Spacer(1, 1.5 * mm))
            story.append(Paragraph(note, styles['muted']))

    story.append(PageBreak())
    story.append(Paragraph('Checks, expected vs actual', styles['h2']))
    story.append(Paragraph(
        'Each case below lists its individual assertions. A case passes only '
        'if every assertion holds; a blocked case lists the assertion that '
        'could not be made and why.', styles['sub']))
    for index, case in enumerate(cases):
        # Page-break between cases, not before the first - otherwise the
        # section intro sits alone on an otherwise blank page.
        if index:
            story.append(PageBreak())
        else:
            story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"{case['id']} — {case['scenario']} "
            f"<font color=\"{STATUS.get(case['result'], MUTED)}\">"
            f"<b>{GLYPH.get(case['result'], '')} "
            f"{case['result']}</b></font>", styles['h2']))
        story.append(Paragraph(
            f"<b>Execution mode:</b> {case.get('mode', '-')} &nbsp;·&nbsp; "
            f"<b>Checks passed:</b> {case.get('checks_passed', 0)}/"
            f"{case.get('checks_total', 0)}", styles['sub']))
        story.append(Spacer(1, 2 * mm))

        if case.get('preconditions'):
            story.append(Paragraph('Preconditions', styles['h3']))
            for item in case['preconditions']:
                story.append(Paragraph(f'• {_rich(item)}', styles['body']))

        story.append(Paragraph('Input given', styles['h3']))
        story.append(Paragraph(
            f"<b>Prompt / input:</b> {_rich(case.get('prompt', '-'))}",
            styles['body']))
        inputs = _kv_table(case.get('inputs') or [], styles, 'Input')
        if inputs:
            story.append(Spacer(1, 1.4 * mm))
            story.append(inputs)

        if case.get('steps'):
            story.append(Paragraph('What the test did', styles['h3']))
            for number, item in enumerate(case['steps'], start=1):
                story.append(Paragraph(f'{number}. {_rich(item)}',
                                       styles['body']))
            story.append(Spacer(1, 1.2 * mm))

        story.append(Paragraph('Expected vs actual', styles['h3']))
        story.append(Paragraph(f"<b>Expected:</b> "
                               f"{_rich(case.get('expected', ''))}",
                               styles['body']))
        story.append(Paragraph(f"<b>Actual:</b> "
                               f"{_rich(case.get('actual', ''))}",
                               styles['body']))
        if case.get('blocked_reason'):
            story.append(Paragraph(
                f"<b>Blocked because:</b> {_rich(case['blocked_reason'])}",
                styles['body']))
        story.append(Spacer(1, 1.4 * mm))
        story.append(_checks_table(case, styles))

        outputs = _kv_table(case.get('outputs') or [], styles,
                            'Observed output')
        if outputs:
            story.append(Paragraph('Observed output (evidence)',
                                   styles['h3']))
            story.append(outputs)

        if case.get('explanation'):
            story.append(Paragraph('What this is evidence for',
                                   styles['h3']))
            story.append(Paragraph(_rich(case['explanation']),
                                   styles['body']))
        if case.get('note'):
            story.append(Spacer(1, 1.2 * mm))
            story.append(Paragraph(_rich(case['note']), styles['muted']))
        for error in (case.get('errors') or [])[:2]:
            story.append(Spacer(1, 1 * mm))
            story.append(Paragraph(
                f"<font color=\"{STATUS['FAIL']}\">error:</font> "
                f"{str(error)[:400]}", styles['muted']))

    story.append(PageBreak())
    story.append(Paragraph('How to read this report', styles['h2']))
    for line in [
        '<b>PASS</b> — every assertion in the case held, measured against live '
        'AWS services.',
        '<b>BLOCKED</b> — the capability does not exist in this account. The '
        'case records the measurement that blocks it rather than a verdict.',
        '<b>FAIL</b> — an assertion did not hold. The checks table names which.',
        '<b>Timings are client-measured or agent-self-reported.</b> They are '
        'not AWS X-Ray traces: Transaction Search is not enabled in this '
        'account. Service-issued identifiers (runtime session, gateway, '
        'policy, memory, event, browser session) are recorded in the JSON '
        'artifact alongside this PDF and can be looked up in the console.',
        '<b>Status is never colour alone.</b> Every verdict carries a glyph '
        'and the word, so the report survives greyscale printing and '
        'colour-vision deficiency.',
    ]:
        story.append(Paragraph(line, styles['body']))
        story.append(Spacer(1, 1.4 * mm))

    document.build(story)
    return path


def build_latest(path: str = None) -> Optional[str]:
    """Render the most recent test-case artifact as one combined PDF."""
    bundle = fm_trace.latest('testcases')
    if not bundle:
        return None
    return build(bundle, path)


def build_all(bundle: Dict[str, Any] = None,
              say=None) -> Dict[str, str]:
    """The combined report plus the three themed ones.

    Called automatically at the end of every test run - from the CLI, from
    `testcases.py` directly, and from the Streamlit button - so a run always
    leaves its PDFs beside its JSON. Rendering failures are reported and do
    **not** fail the run: the JSON artifact is the evidence, and losing a test
    result because a chart could not be drawn would be the wrong trade.
    """
    bundle = bundle or fm_trace.latest('testcases')
    if not bundle:
        return {}
    written: Dict[str, str] = {}
    try:
        written['combined'] = build(bundle)
        written.update(build_split(bundle))
    except Exception as exc:                            # noqa: BLE001
        if say:
            say(f'  PDF rendering failed ({type(exc).__name__}: {exc}). '
                f'The JSON artifact is unaffected.')
        return written
    if say:
        for theme, where in written.items():
            say(f"  PDF [{theme:<10}] {os.path.basename(where)}")
    return written


def build_split(bundle: Dict[str, Any] = None) -> Dict[str, str]:
    """Render the three themed PDFs. Returns {theme: path}."""
    bundle = bundle or fm_trace.latest('testcases')
    if not bundle:
        return {}
    return {theme: build(bundle, theme=theme) for theme in THEMES}


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(
        description='Render a test-case run as a visual PDF')
    parser.add_argument('--artifact', help='path to a testcases_*.json '
                                           '(default: the newest)')
    parser.add_argument('--out', help='output path (default: artifacts/)')
    parser.add_argument('--split', action='store_true',
                        help='write three themed PDFs (gateway, web search, '
                             'browser) instead of one combined report')
    parser.add_argument('--theme', choices=sorted(THEMES),
                        help='write just one themed PDF')
    args = parser.parse_args()

    bundle = None
    if args.artifact:
        with open(args.artifact) as handle:
            bundle = json.load(handle)

    if args.split:
        written = build_split(bundle)
        if not written:
            print('No testcases_*.json in artifacts/. Run: '
                  'python run_fm.py testcases')
            return 1
        for theme, where in written.items():
            print(f'PDF [{theme}]: {where}')
        return 0

    if args.theme:
        bundle = bundle or fm_trace.latest('testcases')
        path = build(bundle, args.out, theme=args.theme) if bundle else None
    elif bundle:
        path = build(bundle, args.out)
    else:
        path = build_latest(args.out)
    if not path:
        print('No testcases_*.json in artifacts/. Run: '
              'python run_fm.py testcases')
        return 1
    print(f'PDF: {path}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
