"""Deploy the mortgage-research agent into its own AgentCore Runtime.

Self-contained: the zip is built only from files in this folder, and the
packaging, vendoring and network selection live in `fm_deploy.py`.

The zip carries three files, all from here:

    agent.py          this project's fm_agent.py, renamed
    agent_config.py   settings the hosted agent reads
    agent_gateway.py  signed MCP over urllib

Known traps this respects, each of which cost a deploy cycle when first met:

* runtime names are `[a-zA-Z][a-zA-Z0-9_]{0,47}` - **no hyphens**, unlike
  gateways. Same console, different grammar.
* a subnet whose only default route is an **internet gateway** is not egress:
  the runtime reaches READY, passes its health check, then every outbound call
  fails and the log group has no stream at all. `fm_deploy.pick_network()`
  ranks NAT and transit gateways above it for exactly this reason.
* `UpdateAgentRuntime` must **not** echo back the `networkConfiguration` that
  `GetAgentRuntime` returns: it carries `requireServiceS3Endpoint`, which
  runtimes created after 2026-06-11 may not modify even to the same value.
* `runtimeSessionId` has a minimum length of 33, so `uuid4().hex` (32) is
  rejected client-side. See `invoke_runtime.py`.
"""

import argparse
import json
import os
import pathlib
import sys
import time
from typing import Any, Dict, List, Optional

import boto3

import fm_config
import fm_deploy

HERE = pathlib.Path(__file__).resolve().parent
BUILD = HERE / 'build'
STATE = HERE / 'runtime_state.json'

# What goes in the zip: (source path, name inside the archive). Every source
# file lives in this folder - the zip is built only from this project.
AGENT_FILES = [
    (HERE / 'fm_agent.py', 'agent.py'),
    (HERE / 'agent_config.py', 'agent_config.py'),
    (HERE / 'agent_gateway.py', 'agent_gateway.py'),
]


def say(message: str = '') -> None:
    print(message, flush=True)




def _control():
    return boto3.client('bedrock-agentcore-control',
                        region_name=fm_config.REGION)


def package() -> pathlib.Path:
    """Build the zip from this project's files plus a pruned vendor tree."""
    return fm_deploy.package(AGENT_FILES, BUILD / 'agent.zip')


def push(archive: pathlib.Path) -> Dict[str, Any]:
    """Upload the zip and return the `agentRuntimeArtifact` for it."""
    return fm_deploy.push(archive, f'{fm_config.RUNTIME_NAME}/agent.zip')


def find_runtime() -> Optional[Dict[str, Any]]:
    """There is no GetAgentRuntimeByName; the id is name + service suffix."""
    control = _control()
    token = None
    while True:
        kwargs: Dict[str, Any] = {'maxResults': 50}
        if token:
            kwargs['nextToken'] = token
        page = control.list_agent_runtimes(**kwargs)
        for item in page.get('agentRuntimes', page.get('items', [])):
            if item.get('agentRuntimeName') == fm_config.RUNTIME_NAME:
                return item
        token = page.get('nextToken')
        if not token:
            return None


def deploy(wait: bool = True) -> int:
    if not fm_config.RUNTIME_NAME.replace('_', '').isalnum():
        raise SystemExit(
            f'Runtime names must match [a-zA-Z][a-zA-Z0-9_]{{0,47}} - no '
            f'hyphens. Got {fm_config.RUNTIME_NAME!r}.')

    say(f'Deploying {fm_config.RUNTIME_NAME} to AgentCore Runtime '
        f'({fm_config.REGION})')
    problems = fm_deploy.check_bucket()
    if problems:
        say('\n'.join(f'  - {p}' for p in problems))
        return 1

    artifact = push(package())
    network = fm_deploy.pick_network()
    say(f'  network            {json.dumps(network)[:160]}')

    existing = find_runtime()
    control = _control()
    if existing:
        runtime_id = existing['agentRuntimeId']
        say(f"  updating           {runtime_id} "
            f"(v{existing.get('agentRuntimeVersion')})")
        # Do not echo back the networkConfiguration GetAgentRuntime returns:
        # it carries `requireServiceS3Endpoint`, which runtimes created after
        # 2026-06-11 may not modify even to the same value.
        result = control.update_agent_runtime(
            agentRuntimeId=runtime_id,
            agentRuntimeArtifact=artifact,
            roleArn=fm_deploy.RUNTIME_ROLE_ARN,
            networkConfiguration=network,
            protocolConfiguration={'serverProtocol': 'HTTP'})
    else:
        say(f'  creating           {fm_config.RUNTIME_NAME}')
        result = control.create_agent_runtime(
            agentRuntimeName=fm_config.RUNTIME_NAME,
            description='Fannie Mae POC: mortgage-research agent calling '
                        'AgentCore Gateway, Browser, Bedrock and Memory',
            agentRuntimeArtifact=artifact,
            roleArn=fm_deploy.RUNTIME_ROLE_ARN,
            networkConfiguration=network,
            protocolConfiguration={'serverProtocol': 'HTTP'})
        runtime_id = result['agentRuntimeId']

    state = {
        'agentRuntimeId': runtime_id,
        'agentRuntimeArn': result['agentRuntimeArn'],
        'agentRuntimeVersion': result.get('agentRuntimeVersion'),
        'workloadIdentityArn': (result.get('workloadIdentityDetails') or {})
                               .get('workloadIdentityArn'),
        'runtime_name': fm_config.RUNTIME_NAME,
        'region': fm_config.REGION,
        'log_group': f'/aws/bedrock-agentcore/runtimes/{runtime_id}-DEFAULT',
        'deployed': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    STATE.write_text(json.dumps(state, indent=2) + '\n')
    say(f"  arn                {state['agentRuntimeArn']}")
    say(f'  state written to   {STATE.name}')

    if not wait:
        return 0
    final = wait_for(runtime_id)
    if final['status'] != 'READY':
        say(f"\n{final['status']}. Nothing is serving. "
            f"reason: {final.get('failureReason')}")
        return 1
    say('\nREADY. Try it:\n'
        '  python invoke_runtime.py --mode with_gateway')
    return 0


def wait_for(runtime_id: str, timeout: int = 600) -> Dict[str, Any]:
    """Poll until the runtime settles. `failureReason` is the whole story.

    Implemented here rather than borrowed because it is four lines and because
    the borrowed one would need another subprocess per poll.
    """
    control = _control()
    deadline = time.time() + timeout
    detail: Dict[str, Any] = {}
    last = None
    while time.time() < deadline:
        detail = control.get_agent_runtime(agentRuntimeId=runtime_id)
        status_now = detail.get('status')
        if status_now != last:
            say(f'  status             {status_now}')
            last = status_now
        if status_now in ('READY', 'CREATE_FAILED', 'UPDATE_FAILED',
                          'DELETE_FAILED', 'FAILED'):
            return detail
        time.sleep(5)
    return detail or {'status': 'TIMEOUT'}


def load_state() -> Optional[Dict[str, Any]]:
    if not STATE.exists():
        return None
    return json.loads(STATE.read_text())


def status() -> Dict[str, Any]:
    state = load_state()
    live = find_runtime()
    detail: Dict[str, Any] = {}
    if live:
        detail = _control().get_agent_runtime(
            agentRuntimeId=live['agentRuntimeId'])
    return {
        'state_file': str(STATE) if state else None,
        'runtime_name': fm_config.RUNTIME_NAME,
        'exists': live is not None,
        'runtime_id': (live or {}).get('agentRuntimeId'),
        'status': detail.get('status'),
        'version': detail.get('agentRuntimeVersion'),
        'log_group': (f"/aws/bedrock-agentcore/runtimes/"
                      f"{(live or {}).get('agentRuntimeId')}-DEFAULT"
                      if live else None),
    }


def destroy(yes: bool = False) -> int:
    live = find_runtime()
    if not live:
        say(f'No runtime named {fm_config.RUNTIME_NAME}; nothing to delete.')
        return 0
    if not yes:
        say(f"About to delete runtime {live['agentRuntimeId']}.")
        if input('Type "delete" to confirm: ').strip() != 'delete':
            say('Cancelled.')
            return 1
    _control().delete_agent_runtime(agentRuntimeId=live['agentRuntimeId'])
    say(f"  deleted            {live['agentRuntimeId']}")
    if STATE.exists():
        STATE.unlink()
        say(f'  removed            {STATE.name}')
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description='Deploy the Fannie Mae mortgage-research agent into its '
                    'own AgentCore Runtime')
    parser.add_argument('command',
                        choices=['deploy', 'package', 'status', 'destroy'])
    parser.add_argument('--no-wait', action='store_true',
                        help='deploy: return as soon as the API accepts it')
    parser.add_argument('--yes', action='store_true',
                        help='destroy: skip the confirmation prompt')
    args = parser.parse_args()

    if args.command == 'package':
        package()
        return 0
    if args.command == 'status':
        print(json.dumps(status(), indent=2, default=str))
        return 0
    if args.command == 'destroy':
        return destroy(args.yes)
    return deploy(wait=not args.no_wait)


if __name__ == '__main__':
    raise SystemExit(main())
