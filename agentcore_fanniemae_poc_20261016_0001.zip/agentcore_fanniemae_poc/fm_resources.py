"""Find the AWS resources this POC uses, by name, from AWS.

This project is self-contained in *code*. It still **shares AWS resources** with
the price-match POC - the same gateway, policy engine, memory and browser - and
that is deliberate: a second gateway fronting the same memory would prove
nothing, and the spec asked to reuse what exists. What changed is how they are
found. Nothing here reads another project's state files; everything is
discovered live from the control plane by name and cached in this project's own
`fm_state.json`.

Discovery rather than configuration, for a measured reason: resource ids carry
a random suffix assigned at creation (`novacart-price-match-poc-qdnpxdyr1x`),
`GetGateway` takes an id and not a name, and the same is true of memories and
policy engines. So the only stable handle is the name, and finding the id means
listing and matching.

Missing is a **legitimate state**, not an error. `run_poc.py destroy` in the
other project removes the gateway; `memory_fgac.py teardown` removes the memory
gateway. When one is gone this module reports it and the caller decides -
which is what lets Mode A keep working when Mode B cannot, and what TC15 and
TC16 depend on.
"""

import json
import os
import time
from typing import Any, Dict, List, Optional

import boto3
import botocore.exceptions

import fm_config

STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          'fm_state.json')

# Response keys are not consistent across this control plane: `list_gateways`
# and `list_gateway_targets` return `items`, `list_policy_engines` returns
# `policyEngines`, `list_policies` returns `policies`, `list_memories` returns
# `memories`. Every plausible key is tried rather than hard-coding one per call.
_RESULT_KEYS = ('items', 'policyEngines', 'policies', 'memories', 'gateways',
                'targets', 'agentRuntimes')


def control():
    return boto3.client('bedrock-agentcore-control',
                        region_name=fm_config.REGION)


def data_plane():
    return boto3.client('bedrock-agentcore', region_name=fm_config.REGION)


def find_by_name(list_call, name: str, name_field: str = 'name',
                 **kwargs) -> Optional[Dict[str, Any]]:
    """Page through a list operation and return the first match on name.

    Paginated by hand: this account holds ~30 gateways and ~25 memories that
    are not ours, so a match can sit behind a page boundary. Note that boto3
    paginators are *not* used anywhere in this project - they are unavailable
    inside the deployed Runtime, where vendoring prunes botocore's
    `paginators-1.json` away, and keeping one code path avoids a helper that
    works locally and fails hosted.
    """
    token = None
    while True:
        page = list_call(maxResults=50,
                         **({'nextToken': token} if token else {}), **kwargs)
        for key in _RESULT_KEYS:
            for item in page.get(key) or []:
                candidate = item.get(name_field)
                if candidate is None and item.get('id'):
                    # ListMemories returns `id` and older shapes had no name;
                    # the name is the id minus its random suffix.
                    candidate = str(item['id']).rsplit('-', 1)[0]
                if candidate == name:
                    return item
        token = page.get('nextToken')
        if not token:
            return None


# ------------------------------------------------------------------ discovery

def find_gateway(name: str) -> Optional[Dict[str, Any]]:
    found = find_by_name(control().list_gateways, name)
    if not found:
        return None
    detail = control().get_gateway(gatewayIdentifier=found['gatewayId'])
    return {
        'gateway_id': detail['gatewayId'],
        'gateway_arn': detail['gatewayArn'],
        # A non-MCP gateway (protocolType null) has no /mcp suffix and is
        # addressed as a plain HTTPS base URL; an MCP gateway keeps it.
        'gateway_url': detail.get('gatewayUrl'),
        'protocol_type': detail.get('protocolType'),
        'status': detail.get('status'),
        'policy_engine': (detail.get('policyEngineConfiguration') or {}),
    }


def find_policy_engine(name: str) -> Optional[Dict[str, Any]]:
    found = find_by_name(control().list_policy_engines, name)
    if not found:
        return None
    return {'engine_id': found['policyEngineId'],
            'engine_arn': control().get_policy_engine(
                policyEngineId=found['policyEngineId'])['policyEngineArn']}


def find_memory(name: str = None) -> Optional[Dict[str, Any]]:
    name = name or fm_config.MEMORY_NAME
    found = find_by_name(control().list_memories, name)
    if not found:
        return None
    resolved = found.get('id') or found.get('memoryId')
    # Both keys on purpose: callers ported from the other project read `id`.
    return {'memory_id': resolved, 'id': resolved,
            'status': found.get('status')}


def find_target(gateway_id: str, name: str) -> Optional[str]:
    found = find_by_name(control().list_gateway_targets, name,
                         gatewayIdentifier=gateway_id)
    return found['targetId'] if found else None


# -------------------------------------------------------------------- the view

def discover(refresh: bool = False) -> Dict[str, Any]:
    """Resolve everything, caching to `fm_state.json`.

    Cached because the app renders this in a sidebar and five list-and-match
    sweeps on every rerun is both slow and rude to the API. `refresh=True`
    re-probes, which is what the app's button does.
    """
    if not refresh:
        cached = load_state()
        if cached and cached.get('discovered_at'):
            return cached

    search_gw = find_gateway(fm_config.GATEWAY_NAME)
    memory_gw = find_gateway(fm_config.MEMFGAC_GATEWAY_NAME)
    memory = find_memory()
    state: Dict[str, Any] = {
        'discovered_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'region': fm_config.REGION,
        'search_gateway': search_gw,
        'memory_gateway': memory_gw,
        'memory': memory,
        'search_tool': fm_config.SEARCH_TOOL,
        'memory_target': fm_config.MEMFGAC_TARGET_NAME,
        'browser_id': fm_config.BROWSER_ID,
    }
    if memory_gw:
        state['memory_target_id'] = find_target(
            memory_gw['gateway_id'], fm_config.MEMFGAC_TARGET_NAME)
    save_state(state)
    return state


def save_state(state: Dict[str, Any]) -> None:
    with open(STATE_FILE, 'w') as handle:
        json.dump(state, handle, indent=2, default=str)


def load_state() -> Optional[Dict[str, Any]]:
    if not os.path.exists(STATE_FILE):
        return None
    try:
        with open(STATE_FILE) as handle:
            return json.load(handle)
    except (json.JSONDecodeError, OSError):
        return None


# -------------------------------------------------------------- what callers use

def search_gateway(refresh: bool = False) -> Optional[Dict[str, Any]]:
    """The MCP gateway that carries the web-search connector, or None."""
    return (discover(refresh) or {}).get('search_gateway')


def memory_gateway(refresh: bool = False) -> Optional[Dict[str, Any]]:
    """The non-MCP gateway fronting Memory under Cedar, or None."""
    return (discover(refresh) or {}).get('memory_gateway')


def memory_id(refresh: bool = False) -> Optional[str]:
    return ((discover(refresh) or {}).get('memory') or {}).get('memory_id')


def memory_base_url(refresh: bool = False) -> Optional[str]:
    """`<gatewayUrl>/<target>` - the gateway routes on the first path segment.

    Omit the target segment and the gateway answers
    `404 No Target found for Target name: memories`, which is a confusing
    error for what is really a missing prefix.
    """
    gateway = memory_gateway(refresh)
    if not gateway or not gateway.get('gateway_url'):
        return None
    return (gateway['gateway_url'].rstrip('/') + '/'
            + fm_config.MEMFGAC_TARGET_NAME)


def summary(refresh: bool = False) -> Dict[str, Any]:
    """Every resource with whether it is present and who owns it.

    Ownership is stated because it decides what teardown may touch: this
    project owns its runtime and its `fmpoc_*` policies, and nothing else.
    """
    state = discover(refresh)
    search_gw = state.get('search_gateway') or {}
    memory_gw = state.get('memory_gateway') or {}
    memory = state.get('memory') or {}
    return {
        'search_gateway': {
            'purpose': 'Mode B web search — the only path to AWS web search',
            'id': search_gw.get('gateway_id'),
            'url': search_gw.get('gateway_url'),
            'protocol_type': search_gw.get('protocol_type') or 'MCP',
            'policy_engine': (search_gw.get('policy_engine') or {}).get('arn'),
            'present': bool(search_gw),
            'owned_by': 'shared — created by run_poc.py setup',
        },
        'memory_gateway': {
            'purpose': 'Mode B memory access under Cedar (FGAC)',
            'id': memory_gw.get('gateway_id'),
            'url': memory_gw.get('gateway_url'),
            'protocol_type': memory_gw.get('protocol_type'),
            'target': state.get('memory_target'),
            'present': bool(memory_gw),
            'owned_by': 'shared — created by memory_fgac.py run',
        },
        'memory': {
            'purpose': 'where research summaries are written, in both modes',
            'id': memory.get('memory_id'),
            'name': fm_config.MEMORY_NAME,
            'present': bool(memory),
            'owned_by': 'shared — created by run_poc.py setup',
        },
        'browser': {
            'purpose': 'search in Mode A, content extraction in both modes',
            'id': state.get('browser_id'),
            'present': True,
            'owned_by': 'AWS managed',
        },
        'discovered_at': state.get('discovered_at'),
    }


def resources(refresh: bool = False) -> Dict[str, Dict[str, Any]]:
    """Just the resource entries from `summary()`, nothing else.

    `summary()` also carries `discovered_at`, which is a string. A caller that
    iterates `summary().items()` and treats every value as a resource dict
    raises `TypeError: string indices must be integers` - which is exactly how
    the app's sidebar broke. This accessor exists so that cannot happen again.
    """
    return {name: entry for name, entry in summary(refresh).items()
            if isinstance(entry, dict)}


def require_search_gateway() -> Dict[str, Any]:
    gateway = search_gateway()
    if not gateway:
        raise RuntimeError(
            f'No gateway named {fm_config.GATEWAY_NAME}. Mode B search needs '
            f'it. Create it with: cd ~/agentcore_gateway_usecase_poc && '
            f'python run_poc.py setup')
    return gateway


def require_memory_gateway() -> Dict[str, Any]:
    gateway = memory_gateway()
    if not gateway:
        raise RuntimeError(
            f'No gateway named {fm_config.MEMFGAC_GATEWAY_NAME}. Mode B '
            f'memory needs it. Create it with: '
            f'cd ~/agentcore_gateway_usecase_poc && python memory_fgac.py run')
    return gateway


# ------------------------------------------------- attribute-style accessors

class _Gateway:
    """A discovered gateway, with attribute access.

    Exists so callers read `stack.gateway_id` rather than indexing a dict in
    twenty places. Thin on purpose: the dicts above are the source of truth and
    this only renames.
    """

    def __init__(self, found: Dict[str, Any], engine: Dict[str, Any] = None,
                 memory: str = None, search_tool: str = None):
        self.gateway_id = found.get('gateway_id')
        self.gateway_arn = found.get('gateway_arn')
        self.gateway_url = found.get('gateway_url')
        self.protocol_type = found.get('protocol_type')
        self.status = found.get('status')
        # The engine attached to the gateway, as the gateway reports it.
        attached = found.get('policy_engine') or {}
        self.policy_engine_arn = attached.get('arn')
        self.policy_engine_mode = attached.get('mode')
        self.policy_engine_id = (
            attached.get('arn', '').rsplit('/', 1)[-1] or None)
        # For the memory gateway, the engine this project writes policies to.
        self.engine_id = (engine or {}).get('engine_id') or self.policy_engine_id
        self.engine_arn = (engine or {}).get('engine_arn') or self.policy_engine_arn
        self.memory_id = memory
        self.search_tool = search_tool

    @property
    def base_url(self) -> Optional[str]:
        if not self.gateway_url:
            return None
        return (self.gateway_url.rstrip('/') + '/'
                + fm_config.MEMFGAC_TARGET_NAME)


def mcp_stack(refresh: bool = False) -> Optional['_Gateway']:
    """The MCP gateway carrying the web-search connector, or None if gone."""
    found = search_gateway(refresh)
    if not found:
        return None
    return _Gateway(found, search_tool=fm_config.SEARCH_TOOL)


def memory_stack(refresh: bool = False) -> Optional['_Gateway']:
    """The non-MCP gateway fronting Memory, or None if gone."""
    found = memory_gateway(refresh)
    if not found:
        return None
    return _Gateway(found, engine=find_policy_engine(
        fm_config.MEMFGAC_ENGINE_NAME), memory=memory_id(refresh))
