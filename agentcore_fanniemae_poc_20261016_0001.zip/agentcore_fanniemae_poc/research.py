"""The mortgage-research workflow, in both execution modes.

One prompt, two paths, and the honest finding that they are not symmetric:

    Mode A (without gateway)
        search     managed Browser drives a public search engine
        extract    managed Browser                       <- same as Mode B
        summarise  Bedrock Converse                      <- same as Mode B
        memory     Memory data plane, SigV4, no policy
        policy     none. No Cedar action exists on this path at all.

    Mode B (with gateway)
        search     gateway -> web-search connector, Cedar on every call
        extract    managed Browser                       <- same as Mode A
        summarise  Bedrock Converse                      <- same as Mode A
        memory     gateway -> agentcore-memory connector, Cedar on every call
        policy     two enforcement points: search, and memory

Three measured facts shape that, and none of them is a choice this module made:

* **Web search is not a standalone AgentCore API.** There is no `WebSearch`
  operation. It exists only as the `web-search` gateway connector, so Mode A
  cannot use AWS web search at all and substitutes a browser-driven search.
  This is the clearest answer in the whole POC to "what depends on Gateway".
* **Browser is not a gateway target type.** `CreateGatewayTarget` accepts
  openApiSchema, smithyModel, lambda, mcpServer, apiGateway and connector -
  there is no browser among them. So no Cedar action can exist for "open a
  page", and Mode B does not govern browsing. Both modes call it identically.
* **Memory is reachable both ways**, and this is the one capability where the
  modes differ by *policy* rather than by plumbing.

Everything here runs in-process so it can be exercised from a terminal, from
the Streamlit app, or from inside the deployed Runtime agent - `agent.py`
imports this module and calls `run()`, so the hosted path and the local path
execute the same code rather than two drifting copies.
"""

import json
import re
import time
import uuid
from typing import Any, Dict, List, Optional

import boto3

import fm_config
import fm_trace
import fm_browser
import fm_cedar
import fm_config
import fm_mcp
import fm_memory
import fm_resources
import fm_trace

SEARCH_ENGINE = 'https://duckduckgo.com/html/?q='

# Seeded sources for the fallback path. Public, stable, and on-topic for
# mortgage affordability - used only when search returns nothing, and every row
# that uses them says so, because a summary built from a hard-coded URL list is
# not evidence that search worked.
FALLBACK_SOURCES = [
    'https://www.consumerfinance.gov/owning-a-home/',
    'https://www.fhfa.gov/data/hpi',
]


# --------------------------------------------------------------------- search

def search_gateway(query: str, trace: fm_trace.Trace,
                   max_results: Optional[int] = None) -> Dict[str, Any]:
    """Mode B search: through the gateway, so Cedar sees every call.

    `maxResults` is always sent. Not politeness - the standing gateway's
    `novacart_allow_bounded_research` policy *requires* it present and within
    the cap, so a call that omits it is denied. Policy here shapes how the tool
    must be called, not only whether it may be.
    """
    stack = fm_resources.mcp_stack()
    requested = (fm_config.MAX_SEARCH_RESULTS if max_results is None
                 else max_results)
    with trace.span('Gateway', 'tools/call',
                    f'web search via {fm_config.SEARCH_TOOL}',
                    enforcement_point='AgentCore Gateway + Cedar') as span:
        if stack is None:
            span.failed('The standing MCP gateway is not provisioned. Mode B '
                        'search is unavailable. Fix: run `python run_poc.py '
                        'setup` in agentcore_gateway_usecase_poc.')
            return {'results': [], 'available': False,
                    'verdict': 'UNAVAILABLE'}
        span.aws_id(gateway_id=stack.gateway_id,
                    policy_engine_id=stack.policy_engine_id)
        tool = fm_config.SEARCH_TOOL
        client = fm_mcp.McpGatewayClient(stack.gateway_id,
                                                   url=stack.gateway_url)
        decision = fm_cedar.call_through_gateway(
            client, tool, {'query': query, 'maxResults': requested})
        record = decision.to_dict()
        span.note(verdict=decision.verdict, tool=tool,
                  requested_max_results=requested)
        if not decision.allowed:
            span.denied(record.get('deciding_policy'),
                        record.get('policy_message') or '')
            return {'results': [], 'available': True,
                    'verdict': decision.verdict, 'decision': record}
        payload = decision.backend if 'results' in decision.backend else {}
        results = [{'url': r.get('url'), 'title': r.get('title'),
                    'snippet': r.get('snippet') or r.get('description')}
                   for r in payload.get('results', []) if r.get('url')]
        span.ok(results=len(results), gateway_latency_ms=decision.latency_ms)
        trace.say(f'  search (gateway): {len(results)} results via {tool}')
        return {'results': results, 'available': True, 'verdict': 'ALLOWED',
                'decision': record, 'source': f'gateway tool {tool}'}


def search_direct(query: str, trace: fm_trace.Trace, browser=None,
                  max_results: Optional[int] = None) -> Dict[str, Any]:
    """Mode A search: no gateway, therefore no AWS web search either.

    The managed Browser drives a public search engine and the result links are
    parsed out of the rendered page. This is a genuine AWS-service path (the
    Browser is an AgentCore service) and it is *not* the same capability as the
    connector - it has no `maxResults` contract, no domain filters and no
    policy. Saying so is the point of the comparison.
    """
    requested = (fm_config.MAX_SEARCH_RESULTS if max_results is None
                 else max_results)
    with trace.span('Browser', 'CDP navigate + extract',
                    'search engine results page (no gateway in path)',
                    enforcement_point='IAM only — no Cedar action exists') as span:
        if browser is None:
            span.failed('no browser session supplied')
            return {'results': [], 'available': False, 'verdict': 'ERROR'}
        span.aws_id(browser_session_id=browser.session_id,
                    browser_identifier=fm_config.BROWSER_ID)
        # Reaching for the private `_page` deliberately: `ManagedBrowser`
        # exposes only `read_price`, which is price-extraction specific, and
        # `browser_price.py` belongs to a finished deliverable this project
        # does not edit. The Playwright page is the stable thing underneath.
        page = browser._page
        page.goto(SEARCH_ENGINE + query.replace(' ', '+'),
                  wait_until='domcontentloaded',
                  timeout=fm_config.SEARCH_TIMEOUT * 1000)
        page.wait_for_timeout(1500)
        results: List[Dict[str, Any]] = []
        for anchor in page.query_selector_all('a.result__a')[:requested * 2]:
            href = anchor.get_attribute('href') or ''
            title = (anchor.inner_text() or '').strip()
            url = _unwrap_redirect(href)
            if url and url.startswith('http') and len(results) < requested:
                results.append({'url': url, 'title': title, 'snippet': ''})
        span.ok(results=len(results), requested_max_results=requested,
                engine=SEARCH_ENGINE)
        trace.say(f'  search (browser, direct): {len(results)} results')
        return {'results': results, 'available': True, 'verdict': 'N/A',
                'source': 'managed Browser driving a public search engine',
                'caveat': ('Not AWS web search. Web search has no standalone '
                           'AgentCore API - it exists only as the gateway '
                           'web-search connector, so this path substitutes a '
                           'browser-driven search.')}


def _fresh_page(browser) -> bool:
    """Replace a wedged Playwright page with a new one from the same context.

    Writes to `browser._page` deliberately: `ManagedBrowser` holds the page as
    private state and lives in a finished deliverable this project does not
    edit, so the replacement is made from here. The browser *session* is
    untouched - only the tab is swapped, which keeps the AgentCore session id
    (and therefore the trace) stable across the recovery.
    """
    try:
        old = browser._page
        context = old.context
        try:
            old.close()
        except Exception:                           # noqa: BLE001
            pass
        browser._page = context.new_page()
        return True
    except Exception:                               # noqa: BLE001
        return False


def _unwrap_redirect(href: str) -> str:
    """Pull the real URL out of a search engine's redirect wrapper."""
    if href.startswith('//'):
        href = 'https:' + href
    match = re.search(r'[?&]uddg=([^&]+)', href)
    if match:
        from urllib.parse import unquote
        return unquote(match.group(1))
    return href


# -------------------------------------------------------------------- extract

def extract(url: str, trace: fm_trace.Trace, browser) -> Dict[str, Any]:
    """Open one page in managed Chrome and take its readable text.

    Identical in both modes, and that is a result rather than an oversight:
    there is no gateway target type for a browser, so there is no governed
    version of this call to compare against.
    """
    with trace.span('Browser', 'CDP navigate + extract', url[:70],
                    enforcement_point='IAM only — no Cedar action exists') as span:
        span.aws_id(browser_session_id=browser.session_id)
        page = browser._page
        try:
            page.goto(url, wait_until='domcontentloaded',
                      timeout=fm_config.SEARCH_TIMEOUT * 1000)
            page.wait_for_timeout(1200)
            title = page.title()
            text = page.inner_text('body')
        except Exception as exc:                    # noqa: BLE001 - recorded
            # A source that will not load is an expected outcome, not a crash:
            # TC14 asserts exactly this, so it is recorded and returned.
            #
            # The recovery matters more than the record. A failed navigation
            # leaves the page wedged, and the *next* goto on it is rejected
            # with "interrupted by another navigation to chrome-error://..." -
            # so one unreachable source silently poisons every source after
            # it. Measured: TC14 failed for this reason, and the main workflow
            # only looked healthy because its failures happened to come last.
            #
            # Measured recovery, in the order tried: `goto('about:blank')`
            # does **not** clear it, and retrying the same page fails twice
            # more. Only a **new page from the same context** works, so the
            # wedged page is discarded and `_page` repointed at a fresh one.
            recovered = _fresh_page(browser)
            span.failed(f'{type(exc).__name__}: {exc}')
            trace.say(f'  extract FAILED {url[:60]}: {type(exc).__name__} '
                      f'(page reset so the next source is unaffected)')
            return {'url': url, 'ok': False,
                    'error': f'{type(exc).__name__}: {exc}',
                    'page_replaced': recovered}
        clean = re.sub(r'\n{3,}', '\n\n', (text or '')).strip()
        span.ok(chars=len(clean), title=title[:120])
        trace.say(f'  extract OK {url[:56]} — {len(clean)} chars')
        return {'url': url, 'ok': True, 'title': title,
                'text': clean[:fm_config.EXTRACT_CHARS],
                'chars_extracted': len(clean),
                # Recorded rather than inferred by the viewer: the hosted
                # agent reports `urllib` here, and the difference between the
                # two paths is a result, not a presentation detail.
                'method': 'CDP inner_text'}


# ------------------------------------------------------------------ summarise

def summarise(question: str, sources: List[Dict[str, Any]],
              trace: fm_trace.Trace) -> Dict[str, Any]:
    """Compress the extracts into an answer that cites them by number."""
    usable = [s for s in sources if s.get('ok') and s.get('text')]
    with trace.span('Bedrock', 'Converse', fm_config.MODEL_ID,
                    enforcement_point='IAM (model invocation)') as span:
        if not usable:
            # TC13: no sources must produce a stated limitation, not an
            # invented answer. Cheaper and more reliable to assert that here
            # than to ask the model to be honest about an empty context.
            span.skipped('no usable source extracts')
            trace.say('  summarise: skipped, no sources')
            return {
                'ok': True, 'model_invoked': False,
                'text': ('No sources could be retrieved for this question, so '
                         'there is nothing to summarise. No findings are '
                         'reported, because reporting any would mean inventing '
                         'them.\n\n' + fm_config.DISCLAIMER),
                'sources_used': 0}
        blocks = []
        for index, source in enumerate(usable, start=1):
            blocks.append(f"[{index}] {source.get('title') or source['url']}\n"
                          f"URL: {source['url']}\n"
                          f"{source['text'][:fm_config.EXTRACT_CHARS]}")
        prompt = (f'Question: {question}\n\n'
                  f'Source extracts:\n\n' + '\n\n---\n\n'.join(blocks) +
                  '\n\nWrite a short research summary: the key factors, each '
                  'attributed to a source by its number, then a one-line '
                  'statement of what these sources do not cover. Be concise.')
        client = boto3.client('bedrock-runtime', region_name=fm_config.REGION)
        response = client.converse(
            modelId=fm_config.MODEL_ID,
            system=[{'text': fm_config.SYSTEM_PROMPT}],
            messages=[{'role': 'user', 'content': [{'text': prompt}]}],
            # temperature only - Claude 4.5+ rejects temperature and topP
            # together in this account.
            inferenceConfig={'maxTokens': fm_config.MAX_SUMMARY_TOKENS,
                             'temperature': 0.2})
        text = response['output']['message']['content'][0]['text']
        usage = response.get('usage') or {}
        span.ok(input_tokens=usage.get('inputTokens'),
                output_tokens=usage.get('outputTokens'),
                sources_used=len(usable))
        trace.say(f'  summarise: {usage.get("outputTokens")} output tokens '
                  f'from {len(usable)} sources')
        return {'ok': True, 'model_invoked': True, 'text': text,
                'sources_used': len(usable), 'usage': usage,
                'model_id': fm_config.MODEL_ID}


# --------------------------------------------------------------------- memory

def remember(summary: str, user: str, mode: str,
             trace: fm_trace.Trace) -> Dict[str, Any]:
    """Write the research summary to Memory, by the path the mode implies.

    Mode B goes through the `agentcore-memory` connector, so a Cedar policy
    decides whether this caller may write for this actor. Mode A writes
    straight to the Memory data plane, where the only control is the IAM
    permission of the process - which is the asymmetry the whole POC is about.
    """
    if mode == fm_config.MODE_GATEWAY:
        return _remember_gateway(summary, user, trace)
    return _remember_direct(summary, user, trace)


def _remember_gateway(summary: str, user: str,
                      trace: fm_trace.Trace) -> Dict[str, Any]:
    stack = fm_resources.memory_stack()
    with trace.span('Memory (via Gateway)', 'CreateEvent',
                    f'actor {user}, Cedar-governed',
                    enforcement_point='AgentCore Gateway + Cedar') as span:
        if stack is None:
            span.failed('The Memory FGAC gateway is not provisioned. Fix: run '
                        '`python memory_fgac.py run` in '
                        'agentcore_gateway_usecase_poc.')
            return {'ok': False, 'available': False, 'verdict': 'UNAVAILABLE'}
        span.aws_id(gateway_id=stack.gateway_id, engine_id=stack.engine_id,
                    memory_id=stack.memory_id)
        client = fm_memory.MemoryGatewayClient()
        record = client.call('CreateEvent', {}, {
            'actorId': user,
            'sessionId': f'{fm_config.SESSION_PREFIX}-{uuid.uuid4().hex[:6]}',
            'eventTimestamp': int(time.time()),
            'clientToken': str(uuid.uuid4()),
            'payload': [{'conversational': {
                'role': 'ASSISTANT',
                'content': {'text': summary[:8000]}}}]})
        span.note(verdict=record['verdict'], http_status=record['http_status'])
        if record['verdict'] != 'ALLOWED':
            span.denied(record.get('deciding_policy'),
                        str(record.get('body'))[:400])
            trace.say(f'  memory write DENIED for actor {user}')
            return {'ok': False, 'available': True, 'written': False,
                    'verdict': record['verdict'],
                    'deciding_policy': record.get('deciding_policy'),
                    'path': 'gateway'}
        event_id = _event_id(record.get('body'))
        span.ok(event_id=event_id).aws_id(event_id=event_id)
        trace.say(f'  memory write ALLOWED for actor {user} '
                  f'(event {str(event_id)[:24]})')
        return {'ok': True, 'available': True, 'written': True,
                'verdict': 'ALLOWED', 'event_id': event_id,
                'actor': user, 'path': 'gateway',
                'memory_id': stack.memory_id}


def _remember_direct(summary: str, user: str,
                     trace: fm_trace.Trace) -> Dict[str, Any]:
    with trace.span('Memory (direct)', 'CreateEvent',
                    f'actor {user}, SigV4, no policy in path',
                    enforcement_point='IAM only — no Cedar in this path') as span:
        memory = fm_resources.find_memory()
        if not memory:
            span.failed(f'No memory named {fm_config.MEMORY_NAME}')
            return {'ok': False, 'available': False}
        memory_id = memory.get('id') or memory.get('memoryId')
        span.aws_id(memory_id=memory_id)
        data = boto3.client('bedrock-agentcore', region_name=fm_config.REGION)
        response = data.create_event(
            memoryId=memory_id,
            actorId=user,
            sessionId=f'{fm_config.SESSION_PREFIX}-{uuid.uuid4().hex[:6]}',
            eventTimestamp=time.time(),
            payload=[{'conversational': {
                'role': 'ASSISTANT',
                'content': {'text': summary[:8000]}}}])
        event = response.get('event') or {}
        span.ok(event_id=event.get('eventId')).aws_id(
            event_id=event.get('eventId'))
        trace.say(f'  memory write OK (direct) for actor {user}')
        return {'ok': True, 'available': True, 'written': True,
                'verdict': 'N/A (no policy in this path)',
                'event_id': event.get('eventId'), 'actor': user,
                'path': 'direct', 'memory_id': memory_id}


def recall(user: str, mode: str, trace: fm_trace.Trace,
           query: str = 'mortgage affordability research') -> Dict[str, Any]:
    """Retrieve what this user has stored, by the path the mode implies.

    Uses `RetrieveMemoryRecords` rather than `ListEvents` on purpose: retrieve
    carries `namespace` in the request *body*, where Cedar can read it, while
    ListEvents carries `actorId` in the path, where it cannot. Designing the
    read path around that measurement is the practical consequence of the FGAC
    finding, and it is why per-user namespaces exist in this project.
    """
    namespace = fm_config.namespace_for(user)
    if mode == fm_config.MODE_GATEWAY:
        stack = fm_resources.memory_stack()
        with trace.span('Memory (via Gateway)', 'RetrieveMemoryRecords',
                        f'namespace {namespace}',
                        enforcement_point='AgentCore Gateway + Cedar') as span:
            if stack is None:
                span.failed('Memory FGAC gateway not provisioned')
                return {'ok': False, 'available': False}
            span.aws_id(gateway_id=stack.gateway_id,
                        memory_id=stack.memory_id)
            client = fm_memory.MemoryGatewayClient()
            record = client.retrieve(namespace)
            span.note(verdict=record['verdict'],
                      http_status=record['http_status'])
            if record['verdict'] != 'ALLOWED':
                span.denied(record.get('deciding_policy'),
                            str(record.get('body'))[:400])
                return {'ok': False, 'available': True,
                        'verdict': record['verdict'], 'records': [],
                        'deciding_policy': record.get('deciding_policy'),
                        'namespace': namespace, 'path': 'gateway'}
            records = _records(record.get('body'))
            span.ok(records=len(records))
            return {'ok': True, 'available': True, 'verdict': 'ALLOWED',
                    'records': records, 'namespace': namespace,
                    'path': 'gateway'}

    with trace.span('Memory (direct)', 'RetrieveMemoryRecords',
                    f'namespace {namespace}, SigV4',
                    enforcement_point='IAM only — no Cedar in this path') as span:
        memory = fm_resources.find_memory()
        if not memory:
            span.failed('no memory resource')
            return {'ok': False, 'available': False}
        memory_id = memory.get('id') or memory.get('memoryId')
        span.aws_id(memory_id=memory_id)
        data = boto3.client('bedrock-agentcore', region_name=fm_config.REGION)
        response = data.retrieve_memory_records(
            memoryId=memory_id, namespace=namespace,
            searchCriteria={'searchQuery': query})
        records = response.get('memoryRecordSummaries') or []
        span.ok(records=len(records))
        return {'ok': True, 'available': True,
                'verdict': 'N/A (no policy in this path)',
                'records': [{'content': str(r.get('content'))[:300]}
                            for r in records],
                'namespace': namespace, 'path': 'direct'}


def recall_events(user: str, trace: fm_trace.Trace, session_id: str = None,
                  limit: int = 5) -> Dict[str, Any]:
    """Read back what was actually written - the path that returns content.

    Deliberately separate from `recall()`, and the separation is a finding
    rather than a design preference. The POC's memory resource has **no
    strategies configured**, so nothing is ever extracted into long-term
    records and `RetrieveMemoryRecords` returns zero rows however much is
    written. `ListEvents` returns the events immediately, with their text.

    The cost is that `ListEvents` carries `actorId` in the **path**, where
    Cedar cannot read it, so this path cannot be isolated per caller at the
    gateway. Hence: this function proves *persistence*, `recall()` proves
    *authorization*, and neither is asked to do the other's job.
    """
    with trace.span('Memory (direct)', 'ListEvents',
                    f'actor {user} — functional read-back',
                    enforcement_point=(
                        'IAM only — actorId is a path parameter, so no Cedar '
                        'policy can isolate this call per caller')) as span:
        memory = fm_resources.find_memory()
        if not memory:
            span.failed('no memory resource')
            return {'ok': False, 'events': []}
        memory_id = memory.get('id') or memory.get('memoryId')
        span.aws_id(memory_id=memory_id)
        data = boto3.client('bedrock-agentcore', region_name=fm_config.REGION)
        sessions = ([session_id] if session_id else
                    _recent_sessions(data, memory_id, user, limit))
        events: List[Dict[str, Any]] = []
        for session in sessions:
            page = data.list_events(memoryId=memory_id, actorId=user,
                                    sessionId=session, maxResults=limit)
            for event in page.get('events') or []:
                events.append({
                    'event_id': event.get('eventId'),
                    'session_id': session,
                    'text': _event_text(event)})
        span.ok(events=len(events), sessions=len(sessions))
        trace.say(f'  read back {len(events)} event(s) for {user}')
        return {'ok': True, 'events': events[:limit], 'actor': user,
                'memory_id': memory_id,
                'note': ('ListEvents returns content; RetrieveMemoryRecords '
                         'returns none because this memory has no extraction '
                         'strategy configured.')}


def _recent_sessions(data, memory_id: str, user: str,
                     limit: int) -> List[str]:
    try:
        page = data.list_sessions(memoryId=memory_id, actorId=user,
                                  maxResults=limit)
    except Exception:                                 # noqa: BLE001
        return []
    return [s.get('sessionId') for s in page.get('sessionSummaries')
            or page.get('sessions') or [] if s.get('sessionId')]


def _event_text(event: Dict[str, Any]) -> str:
    for part in event.get('payload') or []:
        content = (part.get('conversational') or {}).get('content') or {}
        if content.get('text'):
            return content['text']
    return ''


def _event_id(body: Any) -> Optional[str]:
    try:
        return (json.loads(body) or {}).get('event', {}).get('eventId')
    except Exception:                                 # noqa: BLE001
        return None


def _records(body: Any) -> List[Dict[str, Any]]:
    try:
        parsed = json.loads(body) or {}
    except Exception:                                 # noqa: BLE001
        return []
    return [{'content': str(r.get('content'))[:300]}
            for r in parsed.get('memoryRecordSummaries') or []]


# ------------------------------------------------------------------- the run

def run(prompt: str = None, mode: str = fm_config.MODE_GATEWAY,
        user: str = None, max_results: Optional[int] = None,
        say=None) -> Dict[str, Any]:
    """One research run, end to end, in one mode.

    The browser session is opened once and reused for the search and every
    extraction: sessions bill until stopped, and one session per page would be
    both slower and more expensive for no benefit.
    """
    prompt = prompt or fm_config.DEFAULT_PROMPT
    user = user or fm_config.USER_PRIMARY
    trace = fm_trace.Trace(mode, prompt, user)
    if say:
        original_say = trace.say

        def tee(message: str = '') -> None:
            original_say(message)
            say(message)
        trace.say = tee                                    # type: ignore

    trace.say(f'[{mode}] {prompt[:90]}')
    query = _query_from(prompt)
    trace.say(f'  search query: {query}')

    sources: List[Dict[str, Any]] = []
    search: Dict[str, Any] = {}
    # One browser session covers Mode A's search plus extraction in both modes.
    with fm_browser.ManagedBrowser(label='fanniemae-research') as browser:
        trace.say(f'  browser session {browser.session_id}')
        if mode == fm_config.MODE_GATEWAY:
            search = search_gateway(query, trace, max_results)
        else:
            search = search_direct(query, trace, browser, max_results)

        urls = [r['url'] for r in search.get('results') or [] if r.get('url')]
        used_fallback = False
        if not urls:
            trace.say('  no search results — falling back to seeded public '
                      'sources, which is recorded as such')
            urls = FALLBACK_SOURCES[:fm_config.MAX_PAGES_TO_EXTRACT]
            used_fallback = True
        for url in urls[:fm_config.MAX_PAGES_TO_EXTRACT]:
            sources.append(extract(url, trace, browser))

    answer = summarise(prompt, sources, trace)
    memory = remember(answer['text'], user, mode, trace)
    # Read back only what was actually stored. A read-back after a denied
    # write would be reporting someone else's events as this run's output.
    readback = (recall_events(user, trace) if memory.get('written')
                else {'ok': False, 'events': [],
                      'skipped': 'nothing was written to read back'})

    bundle = {
        'use_case': fm_config.USE_CASE,
        'disclaimer': fm_config.DISCLAIMER,
        'prompt': prompt,
        'mode': mode,
        'user': user,
        'search_query': query,
        'search': search,
        'used_fallback_sources': used_fallback,
        'sources': sources,
        'answer': answer,
        'memory': memory,
        'memory_readback': readback,
        'services_invoked': trace.services(),
        'policy_decisions': trace.policy_decisions(),
        'enforcement_points': _enforcement_points(mode),
        'trace': trace.to_dict(),
    }
    trace.say(f"  done: {len(trace.services())} services, "
              f"{len(trace.spans)} spans")
    return bundle


def _enforcement_points(mode: str) -> List[Dict[str, str]]:
    """Where a decision could have been made, per mode. Shown in the app."""
    if mode == fm_config.MODE_GATEWAY:
        return [
            {'step': 'web search', 'control': 'Cedar on the gateway',
             'grain': 'query and maxResults, per call'},
            {'step': 'content extraction', 'control': 'IAM only',
             'grain': 'may this principal browse at all — no Cedar action '
                      'exists, because browser is not a gateway target type'},
            {'step': 'memory write/read', 'control': 'Cedar on the gateway',
             'grain': 'actorId (body) and namespace (body), per call'},
        ]
    return [
        {'step': 'web search', 'control': 'IAM only',
         'grain': 'no AWS web search on this path at all; the browser '
                  'substitutes, governed only by IAM'},
        {'step': 'content extraction', 'control': 'IAM only',
         'grain': 'identical to Mode B'},
        {'step': 'memory write/read', 'control': 'IAM only',
         'grain': 'the process may write any actor and read any namespace'},
    ]


def _query_from(prompt: str) -> str:
    """Turn the user's sentence into a search query.

    Deliberately crude - strip the instruction verbs and keep the subject. A
    model call here would be a second thing that can fail before the demo
    reaches the part it is meant to show.
    """
    text = prompt.strip()
    for phrase in ('research publicly available information about',
                   'research public information about',
                   'find relevant sources, summarise the key factors, and '
                   'save a short research summary in my authorized memory',
                   'save a short research summary in my authorized memory',
                   'find relevant sources', 'summarise the key factors',
                   'summarize the key factors', 'research'):
        text = re.sub(phrase, ' ', text, flags=re.I)
    text = re.sub(r'[.,;]+', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip(' .,and')
    return (text or 'mortgage affordability housing market conditions')[:160]
