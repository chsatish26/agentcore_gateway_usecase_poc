"""Identity, policy and Memory FGAC tests, with the enforcement point named.

The spec asks to "clearly distinguish native service-enforced FGAC from
application-level checks". That distinction is the most important thing on this
page, so every test declares which of three kinds it is:

``service-resource``
    AgentCore Gateway evaluates Cedar and refuses before the backend is
    reached. The rule is about **what is being asked for** - a tool, an
    `actorId` in the request body, a `namespace` in the request body. Measured,
    these work.

``service-principal``
    A rule about **who is asking**, enforced by the service. Available only in
    the weak form here: `principal is AgentCore::IamEntity` (the caller's
    *class*) matches, but pinning a *named* IAM principal did not match in any
    of five id forms, and the OAuth principal type is refused outright on an
    AWS_IAM gateway. So "user A cannot read user B's memory" is enforced at the
    gateway **by the namespace in the request**, not by the caller's identity.
    Pretending otherwise would be the single most misleading claim this POC
    could make, because it would imply a confused-deputy protection that is not
    there: any caller holding the IAM permission can ask for any namespace, and
    is refused only because the *namespace* is not permitted.

``application``
    This code checks something before calling AWS. Honest, useful, and worth
    nothing against a caller who bypasses this code. Labelled so nobody counts
    it as a service guarantee.

Every test states expected and actual, and a test that fails is reported as a
failure rather than re-explained until it looks like a pass.
"""

import argparse
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

import boto3

import fm_config
import fm_policies
import fm_trace
import fm_cedar
import fm_config
import fm_mcp
import fm_memory
import fm_policies
import fm_resources
import fm_trace

ARTIFACT_PREFIX = 'security_tests'

KINDS = {
    'service-resource': 'Service-enforced (Cedar, on the request contents)',
    'service-principal': 'Service-enforced (on the caller) — limited here',
    'application': 'Application-level check (not a service guarantee)',
}


def _result(test_id: str, name: str, kind: str, expected: str, actual: str,
            passed: bool, **extra) -> Dict[str, Any]:
    return {'id': test_id, 'name': name, 'kind': kind,
            'kind_label': KINDS[kind], 'expected': expected, 'actual': actual,
            'passed': passed, **extra}


# ------------------------------------------------------------- tool authority

def allowed_tool(trace: fm_trace.Trace) -> Dict[str, Any]:
    """ST1: an authorised caller invokes a permitted tool within its bounds."""
    stack = fm_resources.mcp_stack()
    if stack is None:
        return _result('ST1', 'Authorised user invokes an allowed tool',
                       'service-resource',
                       'ALLOWED by novacart_allow_bounded_research',
                       'SKIPPED — the standing MCP gateway is not provisioned',
                       False, skipped=True)
    tool = fm_config.SEARCH_TOOL
    client = fm_mcp.McpGatewayClient(stack.gateway_id,
                                               url=stack.gateway_url)
    with trace.span('Gateway', 'tools/call', f'{tool} within the cap') as span:
        decision = fm_cedar.call_through_gateway(
            client, tool, {'query': 'mortgage affordability',
                           'maxResults': fm_config.MAX_SEARCH_RESULTS})
        span.note(verdict=decision.verdict).aws_id(
            gateway_id=stack.gateway_id)
        if not decision.allowed:
            span.denied(decision.to_dict().get('deciding_policy'),
                        decision.to_dict().get('policy_message') or '')
    return _result(
        'ST1', 'Authorised user invokes an allowed tool', 'service-resource',
        f'ALLOWED — maxResults {fm_config.MAX_SEARCH_RESULTS} is within the '
        f'policy cap of {fm_config.GATEWAY_SEARCH_CAP}',
        f'{decision.verdict}', decision.allowed,
        tool=tool, verdict=decision.verdict,
        enforcement_point='AgentCore Gateway (Cedar)')


def denied_tool(trace: fm_trace.Trace) -> Dict[str, Any]:
    """ST2: a tool nothing grants is refused, by default rather than by a rule.

    `issue_store_credit` is published on the standing gateway and no policy
    covers it. That is the interesting denial: there is no `forbid` to find in
    an audit, and the call still fails. Deny-by-default is the control.
    """
    stack = fm_resources.mcp_stack()
    if stack is None:
        return _result('ST2', 'Unauthorised tool invocation is denied',
                       'service-resource', 'DENIED', 'SKIPPED — no gateway',
                       False, skipped=True)
    tool = fm_cedar.action(fm_config.TARGET_REFUNDS,
                                       'issue_store_credit')
    client = fm_mcp.McpGatewayClient(stack.gateway_id,
                                               url=stack.gateway_url)
    with trace.span('Gateway', 'tools/call',
                    f'{tool} — no policy covers this tool') as span:
        decision = fm_cedar.call_through_gateway(
            client, tool, {'amount': 25, 'reason': 'fm poc security test'})
        span.note(verdict=decision.verdict)
        if not decision.allowed:
            span.denied(decision.to_dict().get('deciding_policy'),
                        decision.to_dict().get('policy_message') or '')
    denied = decision.verdict != 'ALLOWED'
    return _result(
        'ST2', 'Unauthorised tool invocation is denied', 'service-resource',
        'DENIED — no policy grants this tool, so default deny applies',
        decision.verdict, denied, tool=tool, verdict=decision.verdict,
        deciding_policy=decision.to_dict().get('deciding_policy'),
        note=('Denied by the absence of a permit rather than by a forbid, '
              'which is why an auditor reading only the forbid rules would '
              'not find this control.'),
        enforcement_point='AgentCore Gateway (Cedar, deny-by-default)')


def policy_bound_exceeded(trace: fm_trace.Trace) -> Dict[str, Any]:
    """ST3: the same permitted tool, asked for more than the policy allows."""
    stack = fm_resources.mcp_stack()
    if stack is None:
        return _result('ST3', 'Policy denies an out-of-bounds request',
                       'service-resource', 'DENIED', 'SKIPPED — no gateway',
                       False, skipped=True)
    tool = fm_config.SEARCH_TOOL
    client = fm_mcp.McpGatewayClient(stack.gateway_id,
                                               url=stack.gateway_url)
    over = fm_config.OVER_LIMIT_SEARCH_RESULTS
    with trace.span('Gateway', 'tools/call',
                    f'{tool} with maxResults={over}') as span:
        decision = fm_cedar.call_through_gateway(
            client, tool, {'query': 'mortgage affordability',
                           'maxResults': over})
        span.note(verdict=decision.verdict)
        if not decision.allowed:
            span.denied(decision.to_dict().get('deciding_policy'),
                        decision.to_dict().get('policy_message') or '')
    denied = decision.verdict != 'ALLOWED'
    return _result(
        'ST3', 'Policy denies an out-of-bounds request', 'service-resource',
        f'DENIED — maxResults {over} exceeds the policy cap of '
        f'{fm_config.GATEWAY_SEARCH_CAP}',
        decision.verdict, denied, tool=tool, verdict=decision.verdict,
        note=('Same caller, same tool, same intent — only the argument '
              'changed. Policy bounds *how* a tool may be called, not only '
              'whether it may be.'),
        enforcement_point='AgentCore Gateway (Cedar)')


# ----------------------------------------------------------------- memory FGAC

def memory_write_own(trace: fm_trace.Trace) -> Dict[str, Any]:
    """ST4: the permitted analyst writes to their own actor."""
    stack = fm_resources.memory_stack()
    if stack is None:
        return _result('ST4', 'Analyst writes their own memory',
                       'service-resource', 'ALLOWED',
                       'SKIPPED — Memory FGAC gateway not provisioned', False,
                       skipped=True)
    client = fm_memory.MemoryGatewayClient()
    with trace.span('Memory (via Gateway)', 'CreateEvent',
                    f'actorId={fm_config.USER_PRIMARY} (body field)') as span:
        record = _write(client, fm_config.USER_PRIMARY)
        span.note(verdict=record['verdict'],
                  http_status=record['http_status']).aws_id(
            gateway_id=stack.gateway_id)
        if record['verdict'] != 'ALLOWED':
            span.denied(record.get('deciding_policy'))
    ok = record['verdict'] == 'ALLOWED'
    return _result(
        'ST4', 'Analyst writes their own memory', 'service-resource',
        f'ALLOWED — fmpoc_permit_write_own_actor permits actorId == '
        f'{fm_config.USER_PRIMARY}',
        f"{record['verdict']} (HTTP {record['http_status']})", ok,
        actor=fm_config.USER_PRIMARY, verdict=record['verdict'],
        enforcement_point='AgentCore Gateway (Cedar, on the request body)')


def memory_write_other(trace: fm_trace.Trace) -> Dict[str, Any]:
    """ST5: the same caller tries to file findings under another analyst.

    This is genuine per-identity isolation and the strongest FGAC result in the
    POC - `actorId` is a body field on CreateEvent, so Cedar can read it.
    """
    stack = fm_resources.memory_stack()
    if stack is None:
        return _result('ST5', 'Writing as another analyst is denied',
                       'service-resource', 'DENIED', 'SKIPPED', False,
                       skipped=True)
    client = fm_memory.MemoryGatewayClient()
    with trace.span('Memory (via Gateway)', 'CreateEvent',
                    f'actorId={fm_config.USER_OTHER} (not permitted)') as span:
        record = _write(client, fm_config.USER_OTHER)
        span.note(verdict=record['verdict'],
                  http_status=record['http_status'])
        if record['verdict'] != 'ALLOWED':
            span.denied(record.get('deciding_policy'))
    denied = record['verdict'] == 'DENIED'
    return _result(
        'ST5', 'Writing as another analyst is denied', 'service-resource',
        f'DENIED — no policy permits actorId == {fm_config.USER_OTHER}',
        f"{record['verdict']} (HTTP {record['http_status']})", denied,
        actor=fm_config.USER_OTHER, verdict=record['verdict'],
        note=('The request body decided this. One analyst cannot file research '
              'under another analyst\'s name, and the application was not '
              'consulted.'),
        enforcement_point='AgentCore Gateway (Cedar, on the request body)')


def memory_read_own(trace: fm_trace.Trace) -> Dict[str, Any]:
    """ST6: a read of the permitted namespace is allowed."""
    stack = fm_resources.memory_stack()
    if stack is None:
        return _result('ST6', 'Analyst reads their own namespace',
                       'service-resource', 'ALLOWED', 'SKIPPED', False,
                       skipped=True)
    namespace = fm_config.namespace_for(fm_config.USER_PRIMARY)
    client = fm_memory.MemoryGatewayClient()
    with trace.span('Memory (via Gateway)', 'RetrieveMemoryRecords',
                    f'namespace={namespace} (body field)') as span:
        record = client.retrieve(namespace)
        span.note(verdict=record['verdict'],
                  http_status=record['http_status'])
        if record['verdict'] != 'ALLOWED':
            span.denied(record.get('deciding_policy'))
    ok = record['verdict'] == 'ALLOWED'
    return _result(
        'ST6', 'Analyst reads their own namespace', 'service-resource',
        f'ALLOWED — fmpoc_permit_read_own_namespace permits {namespace}',
        f"{record['verdict']} (HTTP {record['http_status']})", ok,
        namespace=namespace, verdict=record['verdict'],
        note=('ALLOWED, and zero records returned — this memory resource has '
              'no extraction strategy, so no long-term records exist to '
              'retrieve. The authorization is what this test measures; '
              'persistence is ST8.'),
        enforcement_point='AgentCore Gateway (Cedar, on the request body)')


def memory_read_other(trace: fm_trace.Trace) -> Dict[str, Any]:
    """ST7: a read of another analyst's namespace is refused.

    Read the `actual` field carefully before reusing this as a confused-deputy
    control. The caller is the *same* IAM principal in ST6 and ST7; what
    changed is the namespace in the body. The gateway is enforcing a rule about
    the resource requested, not about who requested it.
    """
    stack = fm_resources.memory_stack()
    if stack is None:
        return _result("ST7", "Reading another analyst's namespace is denied",
                       'service-resource', 'DENIED', 'SKIPPED', False,
                       skipped=True)
    namespace = fm_config.namespace_for(fm_config.USER_OTHER)
    client = fm_memory.MemoryGatewayClient()
    with trace.span('Memory (via Gateway)', 'RetrieveMemoryRecords',
                    f'namespace={namespace} (not permitted)') as span:
        record = client.retrieve(namespace)
        span.note(verdict=record['verdict'],
                  http_status=record['http_status'])
        if record['verdict'] != 'ALLOWED':
            span.denied(record.get('deciding_policy'))
    denied = record['verdict'] == 'DENIED'
    return _result(
        'ST7', "Reading another analyst's namespace is denied",
        'service-principal',
        f'DENIED — no policy permits {namespace}',
        f"{record['verdict']} (HTTP {record['http_status']})", denied,
        namespace=namespace, verdict=record['verdict'],
        note=('Enforced on the **namespace in the request**, not on the '
              'caller: ST6 and ST7 are the same IAM principal. A named '
              'AgentCore::IamEntity principal did not match in any of five id '
              'forms, and OAuth principals are refused on an AWS_IAM gateway, '
              'so per-caller identity rules are not available here. This '
              'prevents a caller from *asking for* an unpermitted namespace; '
              'it does not distinguish two callers.'),
        enforcement_point='AgentCore Gateway (Cedar, on the request body)')


def memory_roundtrip(trace: fm_trace.Trace) -> Dict[str, Any]:
    """ST8: write, then read the same content back."""
    marker = f'FM-POC-ROUNDTRIP-{uuid.uuid4().hex[:8]}'
    memory = fm_resources.find_memory()
    if not memory:
        return _result('ST8', 'Memory write then retrieval', 'service-resource',
                       'the written text is returned', 'SKIPPED — no memory',
                       False, skipped=True)
    memory_id = memory.get('id') or memory.get('memoryId')
    session = f'{fm_config.SESSION_PREFIX}-rt-{uuid.uuid4().hex[:6]}'
    data = boto3.client('bedrock-agentcore', region_name=fm_config.REGION)
    with trace.span('Memory (direct)', 'CreateEvent',
                    f'roundtrip marker in {session}') as span:
        written = data.create_event(
            memoryId=memory_id, actorId=fm_config.USER_PRIMARY,
            sessionId=session, eventTimestamp=time.time(),
            payload=[{'conversational': {'role': 'ASSISTANT',
                      'content': {'text': marker}}}])
        span.aws_id(event_id=written['event']['eventId'], memory_id=memory_id)
    with trace.span('Memory (direct)', 'ListEvents',
                    f'read back {session}') as span:
        page = data.list_events(memoryId=memory_id,
                                actorId=fm_config.USER_PRIMARY,
                                sessionId=session, maxResults=5)
        texts = []
        for event in page.get('events') or []:
            for part in event.get('payload') or []:
                text = ((part.get('conversational') or {})
                        .get('content') or {}).get('text')
                if text:
                    texts.append(text)
        span.ok(events=len(texts))
    found = any(marker in t for t in texts)
    return _result(
        'ST8', 'Memory write then retrieval', 'service-resource',
        f'the exact written marker {marker} is returned by ListEvents',
        f"{'marker found' if found else 'marker NOT found'} in "
        f"{len(texts)} event(s)", found,
        marker=marker, session_id=session,
        note=('Uses ListEvents, which returns content. '
              'RetrieveMemoryRecords would return nothing because this '
              'memory has no extraction strategy — and ListEvents carries '
              'actorId in the path, so this read path cannot be governed by '
              'Cedar. Persistence and authorization are provable here on '
              'different calls.'),
        enforcement_point='IAM only — path-carried actorId is invisible to Cedar')


def application_level_check(trace: fm_trace.Trace) -> Dict[str, Any]:
    """ST9: an application-level guard, labelled as exactly that.

    Included to make the contrast concrete rather than theoretical: this check
    is real and it protects nothing from a caller who does not run this code.
    """
    requested = fm_config.USER_OTHER
    session_user = fm_config.USER_PRIMARY
    with trace.span('Application', 'in-process check',
                    'requested actor != session user') as span:
        blocked = requested != session_user
        span.ok(blocked=blocked)
    return _result(
        'ST9', 'Application-level actor check', 'application',
        'the app refuses to build a request for another analyst',
        f'refused (requested {requested}, session user {session_user})',
        blocked, note=('A service guarantee this is not: anything calling the '
                       'Memory data plane directly, with the same IAM role and '
                       'without this code, is unaffected. Compare ST5, which '
                       'the gateway enforced.'),
        enforcement_point='this process only')


def _write(client, actor: str) -> Dict[str, Any]:
    return client.call('CreateEvent', {}, {
        'actorId': actor,
        'sessionId': f'{fm_config.SESSION_PREFIX}-st-{uuid.uuid4().hex[:6]}',
        'eventTimestamp': int(time.time()),
        'clientToken': str(uuid.uuid4()),
        'payload': [{'conversational': {
            'role': 'ASSISTANT',
            'content': {'text': 'Security test write from the Fannie Mae '
                                'research POC.'}}}]})


TESTS: List[Callable] = [
    allowed_tool, denied_tool, policy_bound_exceeded,
    memory_write_own, memory_write_other, memory_read_own, memory_read_other,
    memory_roundtrip, application_level_check,
]


def run_all(say=print) -> Dict[str, Any]:
    trace = fm_trace.Trace('security', 'identity / policy / memory FGAC',
                           fm_config.USER_PRIMARY)
    policies = fm_policies.status()
    if not policies['ready_for_mode_b']:
        say('WARNING: this project\'s Cedar policies are not installed, so '
            'the memory tests will not measure what they claim. '
            'Fix: python fm_policies.py ensure')
    results: List[Dict[str, Any]] = []
    for test in TESTS:
        record = test(trace)
        results.append(record)
        flag = 'PASS' if record['passed'] else (
            'SKIP' if record.get('skipped') else 'FAIL')
        say(f"  {record['id']:<5} {record['name']:<44} {flag}   "
            f"{record['actual'][:46]}")
    passed = sum(1 for r in results if r['passed'])
    say(f'\n{passed}/{len(results)} security tests passed')
    return {
        'generated_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'kinds': KINDS,
        'policies': policies,
        'tests': results,
        'summary': {'passed': passed, 'total': len(results),
                    'by_kind': {k: sum(1 for r in results if r['kind'] == k)
                                for k in KINDS}},
        'trace': trace.to_dict(),
    }


def main() -> int:
    argparse.ArgumentParser(
        description='Identity, policy and Memory FGAC tests').parse_args()
    bundle = run_all()
    path = fm_trace.write(bundle, ARTIFACT_PREFIX)
    print(f'Artifact: {path}')
    return 0 if bundle['summary']['passed'] == bundle['summary']['total'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
