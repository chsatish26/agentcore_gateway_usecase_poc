"""Configuration for the Fannie Mae mortgage-research POC.

**Self-contained.** Every module this project runs lives in this folder. The
AgentCore helpers that were originally borrowed from the price-match POC are
ported here as `fm_mcp.py`, `fm_browser.py`, `fm_cedar.py`, `fm_memory.py` and
`fm_deploy.py`; nothing imports another project.

It still **shares AWS resources** with that POC - the same gateway, policy
engine, memory and browser - which is deliberate: a second gateway fronting the
same memory would prove nothing. Those are discovered live by name
(`fm_resources.py`), never read from another project's state files, and this
project creates or deletes none of them.

Owned and created here: one AgentCore Runtime, two Cedar policies prefixed
`fmpoc_`, and the artifacts under `artifacts/`.

The two modes, and why they are not symmetric
---------------------------------------------
The spec asks for "with Gateway" and "without Gateway" over the same prompt.
Measured, the three tools do not line up the way that framing suggests, and
pretending otherwise would be the one thing that makes the comparison useless:

* **Web search is gateway-only.** It is not a standalone AgentCore API - there
  is no `WebSearch` operation. It exists solely as the `web-search` gateway
  connector. So Mode A cannot use AWS web search, and substitutes a search
  driven through the managed Browser. That difference is the single clearest
  answer to "what depends on Gateway".
* **Browser is direct-only.** `browser` is not a `CreateGatewayTarget` target
  type, so there is no Cedar action for "open a page" and both modes reach it
  the same way. Mode B does not improve it.
* **Memory is reachable both ways.** Directly (SigV4, no policy) or through the
  `agentcore-memory` connector on a non-MCP gateway, where Cedar applies. This
  is the one capability where the two modes differ by policy rather than by
  plumbing.
"""

import os

REGION = os.getenv('AWS_REGION', 'us-east-1')
ACCOUNT_ID = os.getenv('ACCOUNT_ID', '196856463470')

# ---------------------------------------------------------------- this project

RUNTIME_NAME = os.getenv('FM_RUNTIME_NAME', 'fanniemae_research_agent')
ARTIFACT_DIR = os.getenv('FM_ARTIFACT_DIR', 'artifacts')
STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          'fanniemae_state.json')

# Haiku for the summariser: the job is to compress extracted page text, not to
# reason, and the runtime deployment next door already runs on this id. Claude
# needs the `us.` inference-profile prefix in this account, and 4.5+ rejects
# temperature and topP in the same request - send one.
MODEL_ID = os.getenv('FM_MODEL_ID',
                     'us.anthropic.claude-haiku-4-5-20251001-v1:0')
MAX_SUMMARY_TOKENS = int(os.getenv('FM_MAX_SUMMARY_TOKENS', '1200'))

# ------------------------------------------------------------------- the modes

MODE_DIRECT = 'without_gateway'
MODE_GATEWAY = 'with_gateway'
MODES = (MODE_DIRECT, MODE_GATEWAY)

# ------------------------------------------------------- borrowed identifiers


# Search behaviour. MAX_SEARCH_RESULTS is deliberately <= the ceiling the
# standing gateway's Cedar policy enforces (`maxResults <= 10` in
# `novacart_allow_bounded_research`); asking for more is denied, which is a
# demonstration in its own right and TC09 uses it.
MAX_SEARCH_RESULTS = int(os.getenv('FM_MAX_SEARCH_RESULTS', '5'))
OVER_LIMIT_SEARCH_RESULTS = int(os.getenv('FM_OVER_LIMIT_RESULTS', '50'))
SEARCH_TIMEOUT = int(os.getenv('FM_SEARCH_TIMEOUT', '60'))

# Pages to actually open and extract. Browser sessions bill until stopped, so
# one session is reused for every extraction in a run.
MAX_PAGES_TO_EXTRACT = int(os.getenv('FM_MAX_PAGES', '2'))
EXTRACT_CHARS = int(os.getenv('FM_EXTRACT_CHARS', '6000'))

# ------------------------------------------------------------------- principals

# Two demonstration users. The memory FGAC lab proved that per-caller isolation
# binds on a *body* field (CreateEvent.actorId) and never on a path parameter,
# so these ids are used where they are carried in the body and the limitation is
# reported where they are not.
USER_PRIMARY = os.getenv('FM_USER_PRIMARY', 'fm-analyst-alice')
USER_OTHER = os.getenv('FM_USER_OTHER', 'fm-analyst-bob')
SESSION_PREFIX = os.getenv('FM_SESSION_PREFIX', 'fm-research')


def namespace_for(user: str) -> str:
    """The memory namespace a user's research summaries live under.

    Per-user namespaces rather than per-user actor ids on reads, because the
    FGAC measurement showed `RetrieveMemoryRecords` carries `namespace` in the
    body (so Cedar can see it) while `ListEvents` carries `actorId` in the path
    (so Cedar cannot). Designing around that is the whole point.

    Rooted at `/fmpoc/` and **not** `/actors/` on purpose: the borrowed FGAC
    lab leaves a standing permit for `namespace like "/actors/*"`, which would
    cover both demo users and quietly destroy the cross-user isolation test.
    Under `/fmpoc/` this project's own policies are the only ones in play, so
    TC11 measures this project's rules rather than a leftover from next door.
    """
    return f'/fmpoc/{user}/'


# Two read paths, and they are not the same path - measured, see
# docs/FINDINGS.md. The POC's memory resource has **no strategies**, so no
# long-term records are ever extracted and `RetrieveMemoryRecords` returns zero
# rows no matter what is written. `ListEvents` returns the events immediately.
#
#   functional read-back -> ListEvents            works, returns the text,
#                                                 ungoverned (actorId is a
#                                                 path parameter)
#   governed read        -> RetrieveMemoryRecords Cedar decides on the body
#                                                 namespace, always 0 rows here
#
# So this POC uses the first to prove persistence and the second to prove
# authorization, and says which is which everywhere it shows them.
MEMORY_HAS_STRATEGIES = False


# ------------------------------------------------------------- the use case

USE_CASE = 'Mortgage affordability and housing-market research assistant'

DEFAULT_PROMPT = (
    'Research publicly available information about mortgage affordability and '
    'housing-market conditions. Find relevant sources, summarise the key '
    'factors, and save a short research summary in my authorized memory.')

# Shown in the app and prepended to the model's system prompt. The POC is a
# demonstration against public sources; saying so in the agent's own
# instructions is cheaper than hoping nobody asks.
DISCLAIMER = (
    'This is a demonstration POC using public information only. It is not an '
    'official Fannie Mae application, has no access to Fannie Mae internal '
    'systems or borrower records, and makes no mortgage approval decisions.')

SYSTEM_PROMPT = (
    'You are a mortgage-market research assistant for a demonstration POC. '
    'You summarise only what the supplied source extracts actually say. '
    'Every factual claim must be attributable to one of the supplied sources; '
    'cite them by number. If the extracts do not support an answer, say so '
    'plainly rather than filling the gap from memory - a stated gap is a '
    'correct answer here and an invented figure is not. Never infer anything '
    'about an individual borrower. ' + DISCLAIMER)


# ---------------------------------------------------------------------------
# Settings the ported AgentCore helpers need.
#
# This project is **self-contained**: `fm_mcp.py`, `fm_browser.py`,
# `fm_memory.py` and `fm_cedar.py` are ports of the price-match POC's measured
# helpers, living here so nothing in this folder imports another project. They
# were written against a module called `config`, so they are copied with
# `import fm_config as config` and read the names below. Defaults are the
# measured ones - changing them changes behaviour that was verified.
# ---------------------------------------------------------------------------

# Shared AWS resources. This project does not create or delete these; it
# discovers them by name (see fm_resources.py). Sharing the *resources* is
# deliberate - a second gateway fronting the same memory would prove nothing -
# and is separate from sharing *code*, which this project no longer does.
GATEWAY_NAME = os.getenv('FM_GATEWAY_NAME', 'novacart-price-match-poc')
POLICY_ENGINE_NAME = os.getenv('FM_POLICY_ENGINE_NAME',
                               'novacart_poc_policies')
TARGET_RESEARCH = os.getenv('FM_TARGET_RESEARCH', 'research')
TARGET_REFUNDS = os.getenv('FM_TARGET_REFUNDS', 'novacart')
SEARCH_TOOL = os.getenv('FM_SEARCH_TOOL', 'research___WebSearch')

# The memory FGAC gateway: non-MCP (protocolType null), fronting Memory through
# the `agentcore-memory` connector. Mode B's memory path.
MEMFGAC_GATEWAY_NAME = os.getenv('FM_MEMFGAC_GATEWAY_NAME',
                                 'novacart-memfgac-poc')
MEMFGAC_ENGINE_NAME = os.getenv('FM_MEMFGAC_ENGINE_NAME',
                                'novacart_memfgac_policies')
MEMFGAC_TARGET_NAME = os.getenv('FM_MEMFGAC_TARGET_NAME', 'memfgac')

MEMORY_NAME = os.getenv('FM_MEMORY_NAME', 'novacart_price_match_poc_memory')
MEMORY_ACTOR_ID = os.getenv('FM_MEMORY_ACTOR_ID', 'fm-analyst-alice')
MEMORY_EVENT_EXPIRY_DAYS = int(os.getenv('FM_MEMORY_EVENT_EXPIRY_DAYS', '7'))

GATEWAY_ROLE_ARN = os.getenv(
    'FM_GATEWAY_ROLE_ARN',
    f'arn:aws:iam::{ACCOUNT_ID}:role/SandboxServiceRole')

# Browser. Sessions bill until stopped, so the timeout is a safety net rather
# than a billing strategy.
BROWSER_ID = os.getenv('FM_BROWSER_ID', 'aws.browser.v1')
BROWSER_SESSION_TIMEOUT = int(os.getenv('FM_BROWSER_SESSION_TIMEOUT', '300'))
BROWSER_NAV_TIMEOUT_MS = int(os.getenv('FM_BROWSER_NAV_TIMEOUT_MS', '45000'))

# MCP. The accepted version set is **per-gateway configuration**, not an
# account constant, so the client negotiates - see fm_mcp.py.
MCP_PROTOCOL_VERSION = os.getenv('FM_MCP_PROTOCOL_VERSION', '2025-11-25')
MCP_SERVICE = 'bedrock-agentcore'

# The ceiling the standing gateway's Cedar policy enforces on the search tool.
# Not ours to change: it is what `novacart_allow_bounded_research` says, and
# TC09 exceeds it on purpose.
GATEWAY_SEARCH_CAP = int(os.getenv('FM_GATEWAY_SEARCH_CAP', '10'))


def gateway_url(gateway_id: str, region: str = None) -> str:
    """The MCP endpoint for a gateway id."""
    return (f'https://{gateway_id}.gateway.bedrock-agentcore.'
            f'{region or REGION}.amazonaws.com/mcp')
