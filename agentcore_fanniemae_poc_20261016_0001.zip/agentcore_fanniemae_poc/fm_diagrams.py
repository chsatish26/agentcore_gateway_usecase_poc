"""Architecture diagrams for the two execution modes.

Drawn from the **measured** invocation paths, not from the idealised ones. The
spec's sketch has both modes reaching "Web Search and Browser Tools" with the
only difference being a Gateway box in the middle; that is not what this
account does, and a diagram that showed it would mislead every reader who
later looked at a trace.

Three corrections the drawings carry:

* Mode A has **no web search**. Web search is not a standalone AgentCore API;
  it exists only as the gateway's `web-search` connector. In Runtime, Mode A's
  direct-HTTPS substitute is JavaScript-gated and returns nothing, so the
  diagram shows that edge as blocked and the run falls back to seeded sources.
  The app's local mode renders JS with Playwright and does get results.
* The **Browser is identical in both modes** and ungoverned in both, because
  `browser` is not a `CreateGatewayTarget` target type, so no Cedar action for
  "open a page" can exist.
* Only **Memory** differs by policy rather than by plumbing.

Conventions, carried over from the reused POC so the two read the same way:
blue is governed (through the gateway, subject to Cedar), amber is ungoverned,
red is a measured blocker, dashed is not deployed.

    python -c "import fm_diagrams; print(fm_diagrams.mode_b())" | dot -Tpng -o b.png
"""

GOVERNED = '#31527a'
UNGOVERNED = '#b8860b'
ALLOW = '#1e7f3f'
DENY = '#c5221f'
MUTED = '#80868b'

_HEAD = ('digraph G {\n'
         '  rankdir=%s; bgcolor="transparent";\n'
         '  node [fontname="Helvetica", fontsize=10, shape=box, '
         'style="rounded,filled", color="#cfd8e3", fillcolor="white"];\n'
         '  edge [fontname="Helvetica", fontsize=9, color="%s"];\n')


def mode_a() -> str:
    """Without Gateway: nothing in the path can refuse a call."""
    return (_HEAD % ('LR', MUTED)) + f'''
  user [label="analyst", color="{MUTED}"];
  app [label="Streamlit", fillcolor="#f1f6fb", color="{GOVERNED}"];
  rt [label="AgentCore Runtime\\nfanniemae_research_agent", color="{GOVERNED}", fillcolor="#e8f0fa"];
  agent [label="research agent", color="{GOVERNED}", fillcolor="#e8f0fa"];

  search [label="direct HTTPS search\\nJS-gated: 0 results", color="{DENY}", fillcolor="#fdecea"];
  seed [label="seeded public sources\\n(flagged in the result)", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
  extract [label="page extract\\nurllib in Runtime /\\nmanaged Browser locally", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
  model [label="Bedrock Converse\\nClaude Haiku 4.5", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
  mem [label="AgentCore Memory\\nSigV4, data plane", color="{UNGOVERNED}", fillcolor="#fdf6e3"];

  user -> app -> rt -> agent;
  agent -> search [label=" no AWS web search\\n exists off-gateway ", color="{DENY}"];
  search -> seed [label=" falls back ", style=dashed, color="{UNGOVERNED}"];
  seed -> extract;
  agent -> extract [label=" IAM only "];
  extract -> model -> mem;

  note [label="No Cedar action exists anywhere on this path.\\nThe only control is the IAM permission of the\\nrole the agent runs as: it may write any actor\\nand read any namespace.", shape=note, color="{DENY}", fillcolor="#fdecea"];
  mem -> note [style=dotted, arrowhead=none, color="{DENY}"];
}}
'''


def mode_b() -> str:
    """With Gateway: two enforcement points, and one capability that only exists here."""
    return (_HEAD % ('LR', MUTED)) + f'''
  user [label="analyst", color="{MUTED}"];
  app [label="Streamlit", fillcolor="#f1f6fb", color="{GOVERNED}"];
  rt [label="AgentCore Runtime\\nfanniemae_research_agent", color="{GOVERNED}", fillcolor="#e8f0fa"];
  agent [label="research agent", color="{GOVERNED}", fillcolor="#e8f0fa"];

  gw [label="AgentCore Gateway (MCP)\\nnovacart-price-match-poc\\nCedar on every call", color="{GOVERNED}", fillcolor="#e8f0fa"];
  ws [label="web-search connector\\nresearch___WebSearch", color="{ALLOW}", fillcolor="#eaf5ec"];
  mgw [label="AgentCore Gateway (non-MCP)\\nnovacart-memfgac-poc\\nCedar on every call", color="{GOVERNED}", fillcolor="#e8f0fa"];
  mcon [label="agentcore-memory\\nconnector", color="{ALLOW}", fillcolor="#eaf5ec"];
  mem [label="AgentCore Memory", color="{ALLOW}", fillcolor="#eaf5ec"];

  extract [label="page extract\\nmanaged Browser / urllib", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
  model [label="Bedrock Converse\\nClaude Haiku 4.5", color="{UNGOVERNED}", fillcolor="#fdf6e3"];

  user -> app -> rt -> agent;
  agent -> gw [label=" MCP, SigV4 "] ;
  gw -> ws [label=" allowed only ", color="{ALLOW}"];
  ws -> extract;
  agent -> extract [label=" IAM only — identical\\n to Mode A ", color="{UNGOVERNED}"];
  extract -> model;
  model -> mgw [label=" HTTPS, SigV4 "];
  mgw -> mcon [label=" allowed only ", color="{ALLOW}"];
  mcon -> mem;

  pol1 [label="permit maxResults <= 10\\nforbid over-limit queries", shape=note, color="{ALLOW}", fillcolor="#eaf5ec"];
  gw -> pol1 [style=dotted, arrowhead=none, color="{ALLOW}"];
  pol2 [label="permit actorId == own (body)\\npermit namespace == own (body)", shape=note, color="{ALLOW}", fillcolor="#eaf5ec"];
  mgw -> pol2 [style=dotted, arrowhead=none, color="{ALLOW}"];
  gap [label="Browser is not a gateway target type,\\nso no Cedar action for 'open a page'\\ncan exist in either mode.", shape=note, color="{DENY}", fillcolor="#fdecea"];
  extract -> gap [style=dotted, arrowhead=none, color="{DENY}"];
}}
'''


def capability_matrix() -> str:
    """Which capability is reachable which way. The core of the comparison."""
    return (_HEAD % ('LR', MUTED)) + f'''
  node [shape=box];
  subgraph cluster_gwonly {{
    label="Gateway only"; fontname="Helvetica"; fontsize=10;
    color="{GOVERNED}"; style=dashed;
    ws [label="Web search\\nno standalone API exists", color="{GOVERNED}", fillcolor="#e8f0fa"];
  }}
  subgraph cluster_both {{
    label="Either way"; fontname="Helvetica"; fontsize=10;
    color="{ALLOW}"; style=dashed;
    mm [label="Memory\\ndirect = no policy\\ngateway = Cedar", color="{ALLOW}", fillcolor="#eaf5ec"];
    bb [label="Bedrock\\nIAM either way", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
  }}
  subgraph cluster_direct {{
    label="Direct only"; fontname="Helvetica"; fontsize=10;
    color="{UNGOVERNED}"; style=dashed;
    br [label="Browser\\nnot a gateway target type", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
    rr [label="Runtime\\ninvoked by the client", color="{UNGOVERNED}", fillcolor="#fdf6e3"];
  }}
}}
'''
