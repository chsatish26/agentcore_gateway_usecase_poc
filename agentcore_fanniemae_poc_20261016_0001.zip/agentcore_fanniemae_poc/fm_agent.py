"""The mortgage-research agent, as it runs inside AgentCore Runtime.

Shipped into the zip as `agent.py`. Deployed alongside two files copied
verbatim from the price-match runtime module - its `config.py` and
`gateway_mcp.py` - so the signed-MCP path into the gateway is the one that was
already measured rather than a second implementation of it.

The Runtime contract, which is unforgiving and mostly undocumented by error
message:

* listen on `0.0.0.0:8080`; `GET /ping` must return exactly
  `{"status": "Healthy"}`; `POST /invocations` must return 200 with any JSON.
* **a non-2xx body is discarded** and replaced with a generic
  `RuntimeClientError ... (502)`, so every failure here returns 200 with an
  `error` key. Returning 500 with a traceback means losing the traceback.
* the sandbox has **no boto3** - site-packages holds no SDKs - so deps are
  vendored into `vendor/` and put on `sys.path` before anything imports them.
* credentials come from **IMDS**, not `AWS_CONTAINER_CREDENTIALS_*`, which are
  absent. `boto3.Session()` resolves them anyway.
* aarch64, so vendored packages must be pure Python.

What this agent deliberately does **not** do, and why it is not a shortcut
-------------------------------------------------------------------------
It does not drive the managed Browser over CDP. Playwright needs a compiled
driver plus a browser binary; neither can be vendored into a pure-Python
aarch64 zip. So the hosted path:

* **probes** the Browser service (starts a session, reads the signed CDP
  endpoint, stops it) to prove Runtime can reach it and hold a session, and
* **fetches page text with `urllib`** for the extraction itself.

The Streamlit app's local mode does drive real CDP through the managed Browser.
Both paths are offered and each says which one it is, because "the agent used
the Browser" means two measurably different things here and collapsing them
would misrepresent the deployment.
"""

import json
import os
import sys
import time
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Dict, List, Optional

# Vendored dependencies first: there is no boto3 in the runtime's site-packages
# and an `import boto3` before this line fails with a bare ImportError in a log
# nobody is watching yet.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'vendor'))

import urllib.error                                    # noqa: E402
import urllib.parse                                    # noqa: E402
import urllib.request                                  # noqa: E402

import boto3                                            # noqa: E402
import botocore.exceptions                              # noqa: E402
from botocore.auth import SigV4Auth                     # noqa: E402
from botocore.awsrequest import AWSRequest              # noqa: E402

import agent_config as config          # noqa: E402  this project
import agent_gateway as gateway_mcp     # noqa: E402  this project

SEARCH_ENGINE = 'https://duckduckgo.com/html/?q='
# Public, stable, on-topic. Used only when search finds nothing, and every
# response that uses them sets `used_fallback_sources`.
FALLBACK_SOURCES = [
    'https://www.consumerfinance.gov/owning-a-home/',
    'https://www.fhfa.gov/data/hpi',
]
USER_AGENT = 'Mozilla/5.0 (compatible; AgentCoreFannieMaePOC/1.0)'
DEFAULT_USER = os.getenv('FM_USER_PRIMARY', 'fm-analyst-alice')
MAX_PAGES = int(os.getenv('FM_MAX_PAGES', '2'))
EXTRACT_CHARS = int(os.getenv('FM_EXTRACT_CHARS', '6000'))
MAX_RESULTS = int(os.getenv('FM_MAX_SEARCH_RESULTS', '5'))

SYSTEM_PROMPT = (
    'You are a mortgage-market research assistant for a demonstration POC. '
    'You summarise only what the supplied source extracts actually say. '
    'Every factual claim must be attributable to a supplied source; cite them '
    'by number. If the extracts do not support an answer, say so plainly '
    'rather than filling the gap. Never infer anything about an individual '
    'borrower. This is a demonstration POC using public information only; it '
    'is not an official Fannie Mae application and makes no mortgage '
    'approval decisions.')


def _now() -> float:
    return time.time()


class Steps:
    """Per-service trace, built as the turn runs.

    The agent reports its own steps because the alternative - inferring what it
    did from the outside - is guesswork, and because X-Ray is unavailable in
    this account (Transaction Search is not enabled).
    """

    def __init__(self) -> None:
        self.rows: List[Dict[str, Any]] = []

    def add(self, service: str, api: str, status: str, started: float,
            **extra) -> Dict[str, Any]:
        row = {
            'service': service, 'api': api, 'status': status,
            'duration_ms': round((_now() - started) * 1000, 1),
            'at': time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime(started)),
            'source': 'agent (in-runtime, self-reported)',
            **extra,
        }
        self.rows.append(row)
        return row

    def services(self) -> List[str]:
        out: List[str] = []
        for row in self.rows:
            if row['status'] != 'SKIPPED' and row['service'] not in out:
                out.append(row['service'])
        return out


# ------------------------------------------------------------------ identity

def whoami(steps: Steps) -> Dict[str, Any]:
    """What the runtime is running as. Cheap, and the first thing to check."""
    started = _now()
    try:
        identity = boto3.client('sts', region_name=config.REGION
                                ).get_caller_identity()
        session = boto3.Session()
        credentials = session.get_credentials()
        record = {
            'arn': identity['Arn'],
            'account': identity['Account'],
            'credential_source': getattr(credentials, 'method', 'unknown'),
            'otel_resource': os.getenv('OTEL_RESOURCE_ATTRIBUTES', '')[:300],
        }
        steps.add('Identity (STS)', 'GetCallerIdentity', 'OK', started,
                  **record)
        return record
    except Exception as exc:                            # noqa: BLE001
        steps.add('Identity (STS)', 'GetCallerIdentity', 'FAILED', started,
                  error=f'{type(exc).__name__}: {exc}')
        return {}


# -------------------------------------------------------------------- search

def search_via_gateway(query: str, steps: Steps,
                       max_results: int = MAX_RESULTS) -> Dict[str, Any]:
    """Mode B: the gateway's web-search connector, so Cedar sees the call."""
    started = _now()
    tool = config.SEARCH_TOOL
    try:
        client = gateway_mcp.GatewayClient()
        # `call_tool` already normalises: it returns a verdict and an
        # unwrapped `backend`, and it does **not** raise on a policy denial
        # (a refusal is an answer, not an exception). Passing its return value
        # through `_tool_payload` again finds nothing - that helper expects the
        # raw MCP result, not this envelope. Measured: a working gateway search
        # reported ALLOWED with 0 results until this was corrected.
        outcome = client.call_tool(tool, {'query': query,
                                          'maxResults': max_results})
        verdict = outcome.get('verdict')
        if verdict != 'ALLOWED':
            steps.add('Gateway', 'tools/call', verdict or 'ERROR', started,
                      tool=tool, gateway_id=config.GATEWAY_ID,
                      deciding_policy=outcome.get('deciding_policy'),
                      policy_message=str(outcome.get('message'))[:300],
                      enforcement_point='AgentCore Gateway (Cedar)')
            return {'results': [], 'verdict': verdict or 'ERROR',
                    'tool': tool, 'path': 'gateway',
                    'deciding_policy': outcome.get('deciding_policy'),
                    'policy_message': str(outcome.get('message'))[:300]}
        payload = outcome.get('backend') or {}
        if isinstance(payload, str):
            payload = gateway_mcp._unwrap(payload)
        results = [{'url': r.get('url'), 'title': r.get('title'),
                    'snippet': r.get('snippet') or r.get('description')}
                   for r in (payload or {}).get('results', [])
                   if r.get('url')]
        steps.add('Gateway', 'tools/call', 'ALLOWED', started, tool=tool,
                  results=len(results), gateway_id=config.GATEWAY_ID,
                  gateway_latency_ms=outcome.get('latency_ms'),
                  enforcement_point='AgentCore Gateway (Cedar)')
        return {'results': results[:max_results], 'verdict': 'ALLOWED',
                'tool': tool, 'path': 'gateway', 'available': True}
    except Exception as exc:                            # noqa: BLE001
        steps.add('Gateway', 'tools/call', 'FAILED', started, tool=tool,
                  error=f'{type(exc).__name__}: {exc}')
        return {'results': [], 'verdict': 'ERROR', 'tool': tool,
                'error': f'{type(exc).__name__}: {exc}', 'path': 'gateway'}


def search_direct(query: str, steps: Steps,
                  max_results: int = MAX_RESULTS) -> Dict[str, Any]:
    """Mode A: no gateway, so no AWS web search either.

    Web search is not a standalone AgentCore API - it exists only as the
    gateway connector - so this path queries a public engine over HTTPS. It is
    a different capability with no policy, no maxResults contract and no domain
    filters, and the response says so.
    """
    started = _now()
    try:
        html = _fetch(SEARCH_ENGINE + urllib.parse.quote_plus(query))
        results = _links_from(html, max_results)
        # Measured 2026-10-15: the public no-JS search endpoints return a
        # JS-gated shell (~14 KB, no result anchors) to a plain HTTPS client.
        # So this path finds nothing from inside Runtime, where there is no
        # browser to render it. Reported as unavailable rather than as an empty
        # result set - "search returned no results" and "search could not run"
        # are different findings and only one of them is true here.
        if not results:
            steps.add('Direct HTTPS', 'GET (public search engine)',
                      'UNAVAILABLE', started, engine=SEARCH_ENGINE,
                      response_bytes=len(html), results=0,
                      enforcement_point='none — no AWS service in this path',
                      reason=('The endpoint served a JavaScript-gated page '
                              'with no result anchors. A plain HTTPS client '
                              'cannot render it, and there is no AWS web '
                              'search outside the gateway connector.'))
            return {'results': [], 'verdict': 'UNAVAILABLE', 'path': 'direct',
                    'available': False, 'response_bytes': len(html),
                    'caveat': ('No usable web search on this path from inside '
                               'Runtime. Web search has no standalone '
                               'AgentCore API, and the public no-JS endpoints '
                               'are JavaScript-gated. The app\'s local mode '
                               'succeeds here only because Playwright renders '
                               'the page.')}
        steps.add('Direct HTTPS', 'GET (public search engine)', 'OK', started,
                  results=len(results), engine=SEARCH_ENGINE,
                  enforcement_point='none — no AWS service in this path')
        return {'results': results, 'verdict': 'N/A', 'path': 'direct',
                'available': True,
                'caveat': ('Not AWS web search. Web search has no standalone '
                           'AgentCore API; it exists only as the gateway '
                           'web-search connector.')}
    except Exception as exc:                            # noqa: BLE001
        steps.add('Direct HTTPS', 'GET (public search engine)', 'FAILED',
                  started, error=f'{type(exc).__name__}: {exc}')
        return {'results': [], 'verdict': 'ERROR', 'path': 'direct',
                'error': f'{type(exc).__name__}: {exc}'}


def _links_from(html: str, limit: int) -> List[Dict[str, Any]]:
    """Pull result links out of a no-JS results page.

    Several patterns because the attribute order is not stable and the class
    names change: an anchor may carry href before class or after it.
    """
    import re
    patterns = [
        r'<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"',
        r'<a[^>]*href="([^"]+)"[^>]*class="[^"]*result__a[^"]*"',
        r'<a[^>]*class="[^"]*result-link[^"]*"[^>]*href="([^"]+)"',
    ]
    out: List[Dict[str, Any]] = []
    for match in re.finditer('|'.join(patterns), html):
        url = next((g for g in match.groups() if g), '')
        if url.startswith('//'):
            url = 'https:' + url
        inner = re.search(r'[?&]uddg=([^&]+)', url)
        if inner:
            url = urllib.parse.unquote(inner.group(1))
        if url.startswith('http') and len(out) < limit:
            out.append({'url': url, 'title': '', 'snippet': ''})
    return out


# ------------------------------------------------------------------- browser

def browser_probe(steps: Steps) -> Dict[str, Any]:
    """Prove Runtime can reach the Browser service and hold a session.

    Not extraction. Starting a session and reading back its signed automation
    endpoint is the most this environment can demonstrate, because driving it
    needs Playwright and Playwright cannot be vendored into a pure-Python
    aarch64 zip. Reported as a probe, never as a page read.
    """
    started = _now()
    data = boto3.client('bedrock-agentcore', region_name=config.REGION)
    session_id = None
    try:
        response = data.start_browser_session(
            browserIdentifier=os.getenv('BROWSER_ID', 'aws.browser.v1'),
            name=f'fm-runtime-probe-{int(_now())}',
            sessionTimeoutSeconds=120,
            viewPort={'width': 1280, 'height': 800})
        session_id = response['sessionId']
        streams = response.get('streams') or {}
        automation = bool((streams.get('automationStream') or {})
                          .get('streamEndpoint'))
        steps.add('Browser', 'StartBrowserSession', 'OK', started,
                  browser_session_id=session_id,
                  automation_endpoint_present=automation,
                  enforcement_point='IAM only — browser is not a gateway '
                                    'target type, so no Cedar action exists',
                  limitation=('Session proven reachable from Runtime. CDP '
                              'extraction not performed here: Playwright '
                              'cannot be vendored into the zip.'))
        return {'ok': True, 'session_id': session_id,
                'automation_endpoint_present': automation,
                'extraction_performed': False}
    except Exception as exc:                            # noqa: BLE001
        steps.add('Browser', 'StartBrowserSession', 'FAILED', started,
                  error=f'{type(exc).__name__}: {exc}')
        return {'ok': False, 'error': f'{type(exc).__name__}: {exc}'}
    finally:
        if session_id:
            try:
                data.stop_browser_session(
                    browserIdentifier=os.getenv('BROWSER_ID',
                                                'aws.browser.v1'),
                    sessionId=session_id)
            except Exception:                           # noqa: BLE001
                pass


def extract(url: str, steps: Steps) -> Dict[str, Any]:
    """Fetch one page and reduce it to readable text, with urllib."""
    started = _now()
    try:
        html = _fetch(url)
        text = _text_from(html)
        steps.add('Direct HTTPS', 'GET (page extract)', 'OK', started,
                  url=url[:120], chars=len(text),
                  method='urllib + tag strip (not CDP)')
        return {'url': url, 'ok': True, 'text': text[:EXTRACT_CHARS],
                'chars_extracted': len(text), 'method': 'urllib'}
    except Exception as exc:                            # noqa: BLE001
        steps.add('Direct HTTPS', 'GET (page extract)', 'FAILED', started,
                  url=url[:120], error=f'{type(exc).__name__}: {exc}')
        return {'url': url, 'ok': False,
                'error': f'{type(exc).__name__}: {exc}'}


def _fetch(url: str, timeout: int = 25) -> str:
    request = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read()
    for encoding in ('utf-8', 'latin-1'):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode('utf-8', errors='replace')


def _text_from(html: str) -> str:
    import re
    body = re.sub(r'(?is)<(script|style|noscript|svg)[^>]*>.*?</\1>', ' ', html)
    body = re.sub(r'(?s)<[^>]+>', ' ', body)
    body = (body.replace('&nbsp;', ' ').replace('&amp;', '&')
            .replace('&quot;', '"').replace('&#39;', "'")
            .replace('&lt;', '<').replace('&gt;', '>'))
    return re.sub(r'\s{2,}', ' ', body).strip()


# ----------------------------------------------------------------- summarise

def summarise(prompt: str, sources: List[Dict[str, Any]],
              steps: Steps) -> Dict[str, Any]:
    usable = [s for s in sources if s.get('ok') and s.get('text')]
    started = _now()
    if not usable:
        steps.add('Bedrock', 'Converse', 'SKIPPED', started,
                  reason='no usable source extracts')
        return {'text': ('No sources could be retrieved, so there is nothing '
                         'to summarise. No findings are reported, because '
                         'reporting any would mean inventing them.'),
                'model_invoked': False, 'sources_used': 0}
    blocks = []
    for index, source in enumerate(usable, start=1):
        blocks.append(f"[{index}] {source['url']}\n{source['text']}")
    message = (f'Question: {prompt}\n\nSource extracts:\n\n'
               + '\n\n---\n\n'.join(blocks)
               + '\n\nWrite a short research summary: the key factors, each '
                 'attributed to a source by number, then one line on what '
                 'these sources do not cover.')
    try:
        client = boto3.client('bedrock-runtime', region_name=config.REGION,
                              config=__import__('botocore.config',
                                                fromlist=['Config'])
                              .Config(read_timeout=90, retries={'max_attempts': 2}))
        response = client.converse(
            modelId=config.MODEL_ID,
            system=[{'text': SYSTEM_PROMPT}],
            messages=[{'role': 'user', 'content': [{'text': message}]}],
            # temperature only: Claude 4.5+ rejects temperature and topP
            # together.
            inferenceConfig={'maxTokens': 1200, 'temperature': 0.2})
        text = response['output']['message']['content'][0]['text']
        usage = response.get('usage') or {}
        steps.add('Bedrock', 'Converse', 'OK', started,
                  model_id=config.MODEL_ID,
                  input_tokens=usage.get('inputTokens'),
                  output_tokens=usage.get('outputTokens'),
                  sources_used=len(usable))
        return {'text': text, 'model_invoked': True,
                'sources_used': len(usable), 'usage': usage,
                'model_id': config.MODEL_ID}
    except Exception as exc:                            # noqa: BLE001
        steps.add('Bedrock', 'Converse', 'FAILED', started,
                  error=f'{type(exc).__name__}: {exc}')
        return {'text': f'Summarisation failed: {type(exc).__name__}',
                'model_invoked': False, 'sources_used': len(usable),
                'error': f'{type(exc).__name__}: {exc}'}


# -------------------------------------------------------------------- memory

def remember(summary: str, user: str, mode: str, context: Dict[str, Any],
             steps: Steps) -> Dict[str, Any]:
    """Write the summary to Memory, by the path the mode implies.

    Mode B signs an HTTPS request to the Memory connector on the non-MCP
    gateway, so Cedar decides. Mode A calls the Memory data plane directly,
    where the only control is this runtime role's IAM permission.

    The gateway URL and memory id arrive in the payload rather than from
    config: they belong to resources this project borrows, and the caller
    already resolved them. An agent that rediscovers them would be a second
    place for them to be wrong.
    """
    started = _now()
    text = summary[:8000]
    if mode == 'with_gateway' and context.get('memory_gateway_url'):
        base = context['memory_gateway_url'].rstrip('/')
        target = context.get('memory_target', 'memfgac')
        memory_id = context.get('memory_id')
        url = f'{base}/{target}/memories/{memory_id}/events'
        body = json.dumps({
            'actorId': user,
            'sessionId': f"fm-research-{uuid.uuid4().hex[:8]}",
            'eventTimestamp': int(_now()),
            'clientToken': str(uuid.uuid4()),
            'payload': [{'conversational': {
                'role': 'ASSISTANT', 'content': {'text': text}}}],
        }).encode()
        status, response_body = _signed_post(url, body)
        allowed = 200 <= status < 300
        denied = status == 403
        steps.add('Memory (via Gateway)', 'CreateEvent',
                  'ALLOWED' if allowed else ('DENIED' if denied else 'FAILED'),
                  started, actor=user, http_status=status,
                  gateway_id=context.get('memory_gateway_id'),
                  deciding_policy=_policy_from_body(response_body),
                  enforcement_point='AgentCore Gateway (Cedar, request body)')
        return {'written': allowed, 'path': 'gateway', 'actor': user,
                'http_status': status,
                'verdict': 'ALLOWED' if allowed else
                           ('DENIED' if denied else 'ERROR'),
                'deciding_policy': _policy_from_body(response_body),
                'event_id': _event_id(response_body)}

    try:
        memory_id = context.get('memory_id') or _resolve_memory()
        data = boto3.client('bedrock-agentcore', region_name=config.REGION)
        response = data.create_event(
            memoryId=memory_id, actorId=user,
            sessionId=f"fm-research-{uuid.uuid4().hex[:8]}",
            eventTimestamp=_now(),
            payload=[{'conversational': {
                'role': 'ASSISTANT', 'content': {'text': text}}}])
        event_id = (response.get('event') or {}).get('eventId')
        steps.add('Memory (direct)', 'CreateEvent', 'OK', started,
                  actor=user, event_id=event_id, memory_id=memory_id,
                  enforcement_point='IAM only — no Cedar in this path')
        return {'written': True, 'path': 'direct', 'actor': user,
                'verdict': 'N/A (no policy in this path)',
                'event_id': event_id, 'memory_id': memory_id}
    except Exception as exc:                            # noqa: BLE001
        steps.add('Memory (direct)', 'CreateEvent', 'FAILED', started,
                  actor=user, error=f'{type(exc).__name__}: {exc}')
        return {'written': False, 'path': 'direct', 'actor': user,
                'verdict': 'ERROR', 'error': f'{type(exc).__name__}: {exc}'}


def _signed_post(url: str, body: bytes) -> tuple:
    session = boto3.Session()
    credentials = session.get_credentials().get_frozen_credentials()
    signed = AWSRequest(method='POST', url=url, data=body,
                        headers={'Content-Type': 'application/json'})
    SigV4Auth(credentials, 'bedrock-agentcore',
              config.REGION).add_auth(signed)
    request = urllib.request.Request(url, data=body, method='POST',
                                     headers=dict(signed.headers.items()))
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            return response.status, response.read().decode()[:600]
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode()[:600]
    except Exception as exc:                            # noqa: BLE001
        return 0, f'{type(exc).__name__}: {exc}'


def _resolve_memory() -> Optional[str]:
    """Find the memory by name, without a paginator.

    `get_paginator('list_memories')` raises `OperationNotPageableError` in the
    runtime and not on a development host: vendoring prunes botocore to
    `service-2.json` per service, which drops `paginators-1.json`. So anything
    that works locally via a paginator fails here. Measured, and the reason
    this loop is written out by hand.
    """
    control = boto3.client('bedrock-agentcore-control',
                           region_name=config.REGION)
    token = None
    while True:
        kwargs: Dict[str, Any] = {'maxResults': 100}
        if token:
            kwargs['nextToken'] = token
        page = control.list_memories(**kwargs)
        for item in page.get('memories', []):
            name = item.get('name') or str(item.get('id', '')).rsplit('-', 1)[0]
            if name == config.MEMORY_NAME:
                return item.get('id')
        token = page.get('nextToken')
        if not token:
            return None


def _policy_from_body(body: Any) -> Optional[str]:
    text = str(body or '')
    if 'denied due to' in text:
        return text.split('denied due to')[1].strip(' ].}"\'')
    return None


def _event_id(body: Any) -> Optional[str]:
    try:
        return (json.loads(body) or {}).get('event', {}).get('eventId')
    except Exception:                                   # noqa: BLE001
        return None


# ---------------------------------------------------------------- the handler

def handle(payload: Dict[str, Any]) -> Dict[str, Any]:
    """One research turn. Never raises: the caller gets 200 and a report."""
    started = _now()
    steps = Steps()
    prompt = (payload.get('prompt') or '').strip() or (
        'Research publicly available information about mortgage affordability '
        'and housing-market conditions.')
    mode = payload.get('mode') or 'with_gateway'
    user = payload.get('user') or DEFAULT_USER
    context = payload.get('context') or {}
    query = payload.get('query') or prompt[:160]
    max_results = int(payload.get('max_results') or MAX_RESULTS)

    identity = whoami(steps)
    search = (search_via_gateway(query, steps, max_results)
              if mode == 'with_gateway'
              else search_direct(query, steps, max_results))
    browser = browser_probe(steps) if payload.get('probe_browser', True) else {
        'ok': False, 'skipped': True}

    sources: List[Dict[str, Any]] = []
    urls = [i['url'] for i in (search.get('results') or []) if i.get('url')]
    used_fallback = False
    if not urls:
        # No search results: fall back to seeded public sources so the rest of
        # the workflow can still be demonstrated, and flag it loudly. A summary
        # built from a hard-coded URL list is not evidence that search worked.
        urls = FALLBACK_SOURCES
        used_fallback = True
    for url in urls[:MAX_PAGES]:
        sources.append(extract(url, steps))

    answer = summarise(prompt, sources, steps)
    memory = remember(answer['text'], user, mode, context, steps)

    return {
        'ok': True,
        'use_case': 'Mortgage affordability and housing-market research',
        'prompt': prompt,
        'mode': mode,
        'user': user,
        'search_query': query,
        'executed_in': 'AgentCore Runtime',
        'identity': identity,
        'search': search,
        'used_fallback_sources': used_fallback,
        'browser_probe': browser,
        'sources': [{k: v for k, v in s.items() if k != 'text'}
                    for s in sources],
        'answer': answer,
        'memory': memory,
        'services_invoked': steps.services(),
        'steps': steps.rows,
        'total_ms': round((_now() - started) * 1000, 1),
        'notes': [
            'Web search has no standalone AgentCore API; it exists only as '
            'the gateway web-search connector. Mode A therefore substitutes a '
            'direct HTTPS search, which is a different capability.',
            'Browser is not a gateway target type, so no Cedar action exists '
            'for opening a page in either mode.',
            'This agent probes the Browser service but extracts page text '
            'with urllib: Playwright cannot be vendored into a pure-Python '
            'aarch64 zip. The Streamlit app\'s local mode drives real CDP.',
            'Steps are self-reported by the agent. X-Ray traces are not '
            'available: Transaction Search is not enabled in this account.',
        ],
    }


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, format: str, *args: Any) -> None:
        # Default logging writes to stderr in a shape that is noise in
        # CloudWatch; the handler prints what matters itself.
        return

    def _send(self, status: int, body: Dict[str, Any]) -> None:
        raw = json.dumps(body, default=str).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:                           # noqa: N802
        if self.path.rstrip('/') == '/ping':
            # Exactly this body. The health check is string-compared.
            self._send(200, {'status': 'Healthy'})
            return
        self._send(404, {'error': 'not found'})

    def do_POST(self) -> None:                          # noqa: N802
        if self.path.rstrip('/') != '/invocations':
            self._send(404, {'error': 'not found'})
            return
        session = self.headers.get(
            'x-amzn-bedrock-agentcore-runtime-session-id', '')
        length = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(length) if length else b'{}'
        try:
            payload = json.loads(raw or b'{}')
        except json.JSONDecodeError as exc:
            self._send(200, {'ok': False, 'error': f'invalid JSON: {exc}'})
            return
        print(f'[invocation] session={session[:36]} '
              f'mode={payload.get("mode")} prompt={str(payload.get("prompt"))[:60]!r}',
              flush=True)
        try:
            result = handle(payload)
        except Exception as exc:                        # noqa: BLE001
            import traceback
            # 200 on purpose: a non-2xx body is discarded by the runtime and
            # replaced with a generic 502, which loses the traceback.
            self._send(200, {'ok': False,
                             'error': f'{type(exc).__name__}: {exc}',
                             'traceback': traceback.format_exc()[-2000:]})
            return
        result['runtime_session_id'] = session
        print(f'[invocation] done services={result.get("services_invoked")} '
              f'ms={result.get("total_ms")}', flush=True)
        self._send(200, result)


def serve(port: int = 8080) -> None:
    print(f'fanniemae research agent listening on 0.0.0.0:{port}', flush=True)
    HTTPServer(('0.0.0.0', port), Handler).serve_forever()


# Started at module level, not under a `__name__` guard. The entry file *is*
# run as `__main__` so a guard would work - but when nothing binds 8080 the
# failure is a 30s init timeout with empty logs, and that is an expensive thing
# to debug for no benefit.
serve(int(os.getenv('PORT', '8080')))
