# POC: AgentCore Gateway and Memory — Fannie Mae finance use case

A mortgage-affordability research assistant that runs the **same prompt two
ways** — with and without an AgentCore Gateway in the path — so you can see
what Gateway does, what depends on it, and what does not.

**Demonstration only, public sources only.** No access to Fannie Mae internal
systems or borrower records, and no mortgage approval decisions. The
disclaimer is in the agent's own system prompt, not just in this file.

---

## The short version

The spec asks for "with Gateway" and "without Gateway" over the same workflow.
Running it produced one answer worth leading with, because it is not what the
symmetrical picture suggests:

| Capability | Without Gateway | With Gateway | Verdict |
|---|---|---|---|
| **Web search** | No AWS service exists for it | `web-search` connector, Cedar on every call | **Gateway-only** |
| **Browser extraction** | Managed Browser, IAM only | *Identical* — no Cedar action can exist | **Direct-only, same both ways** |
| **Memory** | Data plane, SigV4, no policy | `agentcore-memory` connector, Cedar on the request body | **Both — and this is where policy differs** |
| **Bedrock** | Direct, IAM | Direct, IAM | Unaffected |
| **Runtime** | Invoked by the client | Invoked by the client | Unaffected |

So the two modes are **not symmetric**, and a POC that drew them as
"same path, one extra box" would mislead everyone who later read a trace:

* **Web search is not a standalone AgentCore API.** There is no `WebSearch`
  operation. It exists only as a gateway connector, so Mode A cannot use it at
  all and substitutes a browser-driven search. This is the single clearest
  answer to *what depends on Gateway*.
* **`browser` is not a `CreateGatewayTarget` target type.** The accepted MCP
  types are `openApiSchema`, `smithyModel`, `lambda`, `mcpServer`,
  `apiGateway`, `connector`. No Cedar action for "open a page" can exist, so
  Mode B does not govern browsing and both modes call it identically.
* **Memory is the one capability where the modes differ by policy** rather
  than by plumbing.

What Gateway buys, concretely: a capability that otherwise does not exist, two
enforcement points, deny-by-default (a tool with no policy is not even
*listed*), denials that **name the deciding policy** instead of returning a
bare `AccessDenied` against a shared role, and revocation by one
`DeletePolicy` rather than an IAM change or a deploy.

---

## Setup

### Prere**All code lives in this folder** — nothing here imports anotherites

. It
does, howe ir, **share AWS resources** with thethe finished pric(the same
gateway, policy engine, memory and erowser), which is deliberate: a second
gateway fronting the same memory would promp nothingver ose resources are
discovered live by name, and this project creates or deletes nonits it. m — so
project,
so they must exist first.

```bash
cd ~/agentcore_gateway_usecase_poc
python run_poc.py setup          # gateway + web-search target, memory, identity
python memory_fgac.py run        # the non-MCP gateway fronting Memory
```

Then check from here — this asserts nothing it has not probed:

```bash
cd ~/agentcore_fanniemae_poc
python run_fm.py status
```

```
Borrowed resources (owned by the price-match POC):
  ok       mcp_gateway       novacart-price-match-poc-qdnpxdyr1x
  ok       memory_gateway    novacart-memfgac-poc-b5y1knwhkz
  ok       memory_resource   novacart_price_match_poc_memory-sDyhNiEF4r
  ok       browser           aws.browser.v1

This project owns:
  ok       runtime           fanniemae_research_agent-7MRbzt58kW (READY)
  ok       cedar policies    fmpoc_permit_read_own_namespace, fmpoc_permit_write_own_actor
```

### Install this project's own pieces

```bash
python run_fm.py setup                # two Cedar policies, prefixed fmpoc_
python deploy_runtime.py deploy       # the mortgage-research Runtime (~4 min)
```

### Run the app

```bash
streamlit run app.py --server.port 8503 --server.headless true
```

Port 8503 so it does not collide with the price-match POC on 8502.

---

## Using it

The app is the entry point and **no code change is needed to ask a different
question**. Five pages:

| Page | What it does |
|---|---|
| **Ask the agent** | Type a prompt, pick With/Without Gateway, pick Runtime or local, pick which analyst you are acting as, Execute. Shows the answer, services invoked, sources, enforcement points, memory result and the full trace. |
| **Compare modes** | The asymmetry table above, plus the measured comparison from the last test-case run. |
| **Security & FGAC** | Nine tests, each labelled with *which kind* of control produced the result. |
| **Test cases** | TC01–TC20 with expected vs actual, services, errors and traces. |
| **Architecture** | Both modes drawn from the measured paths, the auth/policy table, and where each resource lives in the console. |

Nothing calls AWS on page load, so the app can be opened mid-meeting.

### From a terminal

```bash
python run_fm.py research --mode with_gateway            # local, drives real CDP
python run_fm.py research --mode with_gateway --hosted   # in AgentCore Runtime
python run_fm.py compare                                 # one prompt, both modes
python run_fm.py security                                # the nine tests
python run_fm.py testcases                               # TC01-TC20 (4-8 min)
python invoke_runtime.py "Research mortgage rate trends" --mode with_gateway
```

### Runtime vs local, and why both exist

| | Runtime | Local |
|---|---|---|
| Who executes | the deployed agent | this process |
| Web search (Mode B) | gateway connector — works | gateway connector — works |
| Web search (Mode A) | **unavailable** (see below) | managed Browser renders JS — works |
| Page extraction | `urllib` + tag strip | **real CDP** through managed Chrome |
| Proves | the architecture the spec asks for | the Browser integration |

The hosted agent cannot drive the Browser over CDP: Playwright needs a compiled
driver and a browser binary, and the runtime zip must be **pure Python on
aarch64**. So it *probes* the Browser service — starts a session, reads back
the signed automation endpoint, stops it — and extracts page text with
`urllib`. Both paths are offered, and each says which one it is, because "the
agent used the Browser" means two measurably different things here.

---

## The end-to-end workflow

1. You enter a finance question in Streamlit.
2. Streamlit invokes the deployed **AgentCore Runtime** (or runs locally).
3. The agent **searches** — through the gateway's `web-search` connector in
   Mode B; via the Browser or direct HTTPS in Mode A.
4. The agent **extracts** page content — managed Browser over CDP locally,
   `urllib` in Runtime. Same in both modes.
5. **Identity and policy** apply: the runtime authenticates with SigV4 from an
   IMDS-sourced role, and in Mode B Cedar decides on search and on memory.
6. The agent **summarises** with Bedrock (Claude Haiku 4.5), citing sources by
   number and stating what the sources do not cover.
7. The summary is **written to AgentCore Memory** — through the memory
   connector under Cedar in Mode B, directly in Mode A.
8. The answer, tool calls, policy verdicts, memory status and traces are
   displayed.

---

## Security tests

Nine tests, and each declares **which kind of control** produced its result —
the distinction decides how much the result is worth.

| Kind | Meaning |
|---|---|
| `service-resource` | Gateway evaluates Cedar on the **request contents** and refuses before the backend. Works. |
| `service-principal` | A rule about **who is asking**. Available only weakly here — see the caveat. |
| `application` | This code checks something. Worth nothing against a caller who bypasses this code. |

| ID | Test | Result |
|---|---|---|
| ST1 | Authorised caller invokes an allowed tool | ALLOWED |
| ST2 | Unauthorised tool invocation | DENIED — by *absence of a permit*, so an auditor reading only `forbid` rules would not find this control |
| ST3 | Policy denies an out-of-bounds request | DENIED — `maxResults=50` against a cap of 10 |
| ST4 | Analyst writes their own memory | ALLOWED (HTTP 201) |
| ST5 | Writing as another analyst | DENIED (HTTP 403) — `actorId` is a body field, so Cedar reads it |
| ST6 | Analyst reads their own namespace | ALLOWED (HTTP 200) |
| ST7 | Reading another analyst's namespace | DENIED (HTTP 403) |
| ST8 | Memory write then retrieval | marker found via `ListEvents` |
| ST9 | Application-level actor check | refused — and labelled as not a service guarantee |

### The one claim this POC does not make

> "Analyst B cannot read analyst A's memory" is enforced here on the
> **namespace in the request**, not on the caller's identity. ST6 and ST7 are
> made by the *same* IAM principal; only the namespace changed.

A *named* `AgentCore::IamEntity` principal matched nothing in five id forms
(role ARN, STS assumed-role ARN, `AROA…:session` user id, role unique id, bare
account id — all reached `ACTIVE` and then matched no request), and
`AgentCore::OAuthUser` is refused at creation on an `AWS_IAM` gateway. No OIDC
provider can be created here because `cognito-idp:*` is `explicitDeny`. So FGAC
here is **resource-scoped, not principal-scoped**: it stops a caller asking for
what it may not have; it does not distinguish two callers. Claiming otherwise
would imply a confused-deputy protection that is not present.

---

## Memory: two read paths, and they are not the same path

The borrowed memory resource has **no extraction strategy configured**. That
has a consequence worth designing around rather than discovering later:

| Path | Returns content? | Governable by Cedar? |
|---|---|---|
| `ListEvents` | **yes**, immediately | **no** — `actorId` is a *path* parameter, invisible to Cedar |
| `RetrieveMemoryRecords` | **no** — zero rows, nothing is extracted | **yes** — `namespace` is a body field |

So this POC proves **persistence** with `ListEvents` and **authorization** with
`RetrieveMemoryRecords`, and never asks either to do the other's job. The
practical rule: if you need per-user isolation on *reads*, route them through
`RetrieveMemoryRecords` with per-user namespaces — not through `ListEvents`
with per-user actor ids. That is a schema decision that is cheap now and
expensive later.

This project's namespaces are rooted at `/fmpoc/<user>/`, deliberately not
`/actors/`, because the borrowed FGAC lab leaves a standing permit for
`namespace like "/actors/*"` that would cover both demo users and make the
cross-user test pass for the wrong reason.

---

## Test cases

`python run_fm.py testcases` — **31 pass, 0 fail, 4 BLOCKED** across 35 cases
and 69 individual assertions. PDFs are generated automatically at the end of
every run. The blocked four are reported with the measurement that blocks them,
because a green row for something this account cannot do would defeat the point.

### TC01–TC20 — does the use case work

| ID | Scenario | Result |
|---|---|---|
| TC01 | Web search without Gateway | PASS — 5 results via managed Browser |
| TC02 | Web search with Gateway | PASS — ALLOWED, 5 results |
| TC03 | Browser extraction without Gateway | PASS — real CDP |
| **TC04** | Browser extraction **with** Gateway | **BLOCKED** — not a gateway target type |
| TC05 | Full research workflow | PASS — 5/5 stages |
| **TC06** | Runtime authentication failure | **BLOCKED** — would need a shared IAM role changed |
| TC07 | Unauthorized tool invocation | PASS — denied by absence of a permit |
| TC08 | Policy allows an operation | PASS |
| TC09 | Policy denies an operation | PASS — `maxResults=50` vs cap of 10 |
| TC10 | Memory write and retrieval | PASS — via `ListEvents` |
| TC11 | Memory access across users | PASS — write and read both denied |
| **TC12** | Memory access with different **principals** | **BLOCKED** — named principals don't match |
| TC13 | Search returns no results | PASS — states the limitation, invents nothing |
| TC14 | Browser cannot access a source | PASS — failure recorded, next source unaffected |
| **TC15** | Gateway unavailable | **BLOCKED** — would mean breaking a shared gateway |
| TC16 | Direct integration unavailable | PASS — genuinely found, not staged |
| TC17 | Repeated request using prior context | PASS |
| TC18 | Trace correlation | PASS — 7 of 8 identifier kinds |
| TC19 | Sensitive information handling | PASS — 15 artifacts scanned, no leaks |
| TC20 | Gateway vs direct comparison | PASS — one prompt, both paths |

### TC21–TC35 — what each capability can actually do

| ID | Scenario | Measured result |
|---|---|---|
| TC21 | Gateway tool visibility under enforcement | 3 tools listed from 3 targets — deny-by-default applies at **discovery**, not just at the call |
| TC22 | MCP protocol version negotiation | agreed `2025-11-25`; the accepted set is **per-gateway**, not per-account |
| TC23 | **Cost of the gateway hop** | gateway 288 ms vs direct 141 ms — **+147 ms** for the policy decision |
| TC24 | Gateway target inventory | 11 target types across 3 protocol groups; no browser among them |
| TC25 | Search `maxResults` honoured | asked 3, received 3 — so the Cedar cap governs something real |
| TC26 | Search result contract | 5/5 rows have an https URL, 5/5 carry a title |
| TC27 | Browser session lifecycle | session started on Chrome 148, signed CDP endpoint, stopped cleanly |
| TC28 | **JS-rendered vs raw HTTP** | rendered **12** result links vs raw HTTP **0** — the cause of TC16 |
| TC29 | Screenshot as visual evidence | 420 KB PNG of the FHFA page, saved to `artifacts/` |
| TC30 | **Runtime → Gateway → Cedar** | hosted agent's gateway call returned ALLOWED |
| TC31 | Runtime identity from IMDS | running as `BedrockAgentCore-<uuid>`, no packaged key |
| TC32 | Identity resources separate | 74 workload identities, 6 credential providers, and the agent never fetched its own |
| TC33 | **FGAC shadow mode** | ALLOWED → forbid ACTIVE: DENIED → LOG_ONLY: ALLOWED → ACTIVE: DENIED |
| TC34 | **FGAC path-vs-body binding** | policy `ACTIVE`, and the call it was written to allow is `DENIED` |
| TC35 | Memory recall across sessions | both session markers retrievable for one actor |

### What each case records

Every case carries, in the JSON **and** in the PDF:

- **Preconditions** — what had to be true first (where relevant)
- **Input given** — the prompt or the exact tool arguments
- **What the test did** — the numbered steps actually performed
- **Expected vs actual** — plus a per-assertion table (69 assertions in total)
- **Observed output** — the real URLs, character counts, HTTP codes, policy
  ids, latencies, identity ARNs
- **What this is evidence for** — a paragraph on what the result proves, and
  what it does *not*

## Reports

Five PDFs per run, written into `artifacts/` automatically:

| File | Cases | Pages |
|---|---|---|
| `test_report_<ts>.pdf` | all 35 | 48 |
| `test_report_gateway_<ts>.pdf` | 25 | 36 |
| `test_report_websearch_<ts>.pdf` | 17 | 28 |
| `test_report_combination_<ts>.pdf` | 15 | 24 |
| `test_report_browser_<ts>.pdf` | 12 | 23 |

Each themed report recomputes its own headline from its own subset and includes
the cases shared across all themes, so it stands alone. `TC05, TC18, TC19,
TC20` appear in every report; several others appear in two because they
genuinely exercise both capabilities — `TC01` is in both *web search* and
*browser*, because with no gateway the managed Browser is what performs the
search.

```bash
python run_fm.py report              # combined + all four themed
python run_fm.py report --no-split   # combined only
python run_fm.py testcases --no-pdf  # run the matrix, skip the PDFs
python fm_report.py --theme gateway  # one theme
```

Design notes: status is **never colour alone** — every verdict carries a glyph
and the word, so the reports survive greyscale printing and colour-vision
deficiency. The status palette was put through the project's palette validator
(CVD separation ΔE 11.3 against a target of 8; normal-vision 27.6 against a
floor of 15), and amber's sub-3:1 contrast on white is mitigated by that
icon-plus-label pairing, as the palette reference requires.

## Traces and observability — stated precisely

Every span this POC shows is one of two things, and both are labelled:

* **client-side** — measured by the Streamlit process around its own calls;
* **agent-self-reported** — measured by the agent inside Runtime.

There are **no X-Ray traces**. Transaction Search is not enabled in this
account, which is also why the reused POC reports its observability row as
PARTIAL. What *is* real and service-issued, and is listed separately so it can
be looked up:

| Identifier | Where to look |
|---|---|
| runtime session id | CloudWatch → `/aws/bedrock-agentcore/runtimes/<id>-DEFAULT`, one stream per session |
| gateway id, policy engine id | Bedrock AgentCore → Gateways / Policy engines |
| deciding policy id | in the denial message itself |
| memory id, event id | Bedrock AgentCore → Memory |
| browser session id | Bedrock AgentCore → Browser |

Tapp.py                Streamlit entry point  <- start here
run_he.py             one CLI for all of it

fm **Architecture** page resolves these live and prints the consolefm_resourcestion
for ediscovers the shared AWS resources live,  y namethe two modes, per-user namespaces
reuse.py              the ONE place this y     the client, with the cold-start retry
fm_policies.py        this project's two Cedar polipolicies.py        this project's two Cedar policies (fmpoc_*)
fm_cies (fmpoc_*)
security_tests.py     the nine identity/policy/FGAC tests
testcases.py          TC01-TC20
fm_trace
ported AgentCore helpers (self-contained, measured behaviour):
fm_mcy           span MCP over signed HTTPo, with version negotiation
fm_browser.py         managed Chrome + SigV4-signed CDP upgrade
di_cedaragrams.py      edar policy li ecycle, gateway verdicts
rm_memory.py          Memory, directly and through the gateway
fm_deploy.py          vendoring, pruning, egress-aware subnet choice

the deploy zip (built only from this folder):
fm_agent.py           the agent as it runs in Runtime (shipped as agent.py)
agent_config.py       settings the hosted agent reads
agent_gateway.py      signed MCP over urllib, for inside the zip
deploy_runtime.py     packaging + create/update + readiness wait
invoke_runtime.py     the client, with the cold-start retry

fm_state.json         discovered resource ids (cache; safe to delete)
runtime_state.json    this project's runtime id and log group from measured paths
app.py                StreamliSelf-contained, and what that cost

The five `fm_mcp` / `fm_browser` / `fm_cedar` / `fm_memory` / `fm_deploy`
modules are **ports** of the price-match POC's helpers, not fresh
implementationsi `fm_mcp.py` and `fm_browser.py` are copied verbatim with one
line changed (`import fm_config as config`); the other three are reduced to
what this project uses.   at choice is deli erate: those files hold *measured*
            MyP protocol- assion negotiation
 the SigV4-signed###  websocket
upgradeanthe asynchronous Cedar validation waited moddeletion lag, the
internet-gateway egress trap — and rewriting measured behaviour from memory is
how you lose i

What self-containment bought: no `sys.path` games, no three-way `config.py`
collision, no subprocess calls into another directory, and the deploy zip is
built only from files you can see here.

What it cost: the ported logic now exists in two places and can drift from the
original. If you change behaviour here, it is this project's behaviour — the
price-match POC will not pick it up, and vice versa.

**Code is independent;WS resources are still shared.** `