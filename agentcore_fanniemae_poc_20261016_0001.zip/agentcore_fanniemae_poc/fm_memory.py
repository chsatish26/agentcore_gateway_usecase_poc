"""AgentCore Memory, both ways: directly, and through the gateway under Cedar.

Ported from the price-match POC's `memory_fgac.py` and `memory_store.py`,
reduced to what this project uses.

The asymmetry this module exists to expose:

    direct   boto3 -> Memory data plane, SigV4. The only control is the IAM
             permission of the calling role: it may write any actor and read
             any namespace.
    gateway  signed HTTPS -> the `agentcore-memory` connector on a non-MCP
             gateway, where Cedar evaluates the request **body** before it is
             forwarded.

Two measured facts that shape every caller:

* **`context.input` is populated from the request body, not the URI.** A path
  parameter is declared in the policy schema - a presence check on one is
  rejected as "Overly Permissive", which proves the validator knows it - but it
  is absent at evaluation time, so an equality check on a path-carried value
  reaches `ACTIVE` and then denies every request. So per-caller isolation works
  on `CreateEvent` (body `actorId`) and `RetrieveMemoryRecords` (body
  `namespace`), and is unavailable on `ListEvents`, `GetEvent`, `DeleteEvent`,
  `ListSessions`, `GetMemoryRecord` and `DeleteMemoryRecord`.
* **The shared memory resource has no extraction strategy**, so no long-term
  records are ever created and `RetrieveMemoryRecords` returns zero rows
  however much is written. `ListEvents` returns the events immediately.

Which leaves the governable read path and the working read path as *different
calls*, so this module offers both and never pretends one is the other.
"""

import json
import time
import urllib.error
import urllib.request
import uuid
from typing import Any, Dict, List, Optional

import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest

import fm_config
import fm_resources

# The Memory operations the connector exposes as Cedar actions, with where each
# one carries its caller identifier. `identifier_in` is the column that decides
# whether a per-caller policy is possible at all.
OPERATIONS: Dict[str, Dict[str, str]] = {
    'ListEvents': {
        'method': 'POST',
        'uri': '/memories/{memoryId}/actor/{actorId}/sessions/{sessionId}',
        'identifier_in': 'path'},
    'CreateEvent': {
        'method': 'POST', 'uri': '/memories/{memoryId}/events',
        'identifier_in': 'body'},
    'GetEvent': {
        'method': 'GET',
        'uri': '/memories/{memoryId}/actor/{actorId}/sessions/{sessionId}'
               '/events/{eventId}',
        'identifier_in': 'path'},
    'DeleteEvent': {
        'method': 'DELETE',
        'uri': '/memories/{memoryId}/actor/{actorId}/sessions/{sessionId}'
               '/events/{eventId}',
        'identifier_in': 'path'},
    'ListSessions': {
        'method': 'POST',
        'uri': '/memories/{memoryId}/actor/{actorId}/sessions',
        'identifier_in': 'path'},
    'ListActors': {
        'method': 'POST', 'uri': '/memories/{memoryId}/actors',
        'identifier_in': 'none'},
    'RetrieveMemoryRecords': {
        'method': 'POST', 'uri': '/memories/{memoryId}/retrieve',
        'identifier_in': 'body'},
    'ListMemoryRecords': {
        'method': 'POST', 'uri': '/memories/{memoryId}/memoryRecords',
        'identifier_in': 'body'},
    'GetMemoryRecord': {
        'method': 'GET',
        'uri': '/memories/{memoryId}/memoryRecord/{memoryRecordId}',
        'identifier_in': 'path'},
    'DeleteMemoryRecord': {
        'method': 'DELETE',
        'uri': '/memories/{memoryId}/memoryRecords/{memoryRecordId}',
        'identifier_in': 'path'},
    'ListMemoryExtractionJobs': {
        'method': 'POST', 'uri': '/memories/{memoryId}/extractionJobs',
        'identifier_in': 'none'},
    'StartMemoryExtractionJob': {
        'method': 'POST', 'uri': '/memories/{memoryId}/extractionJobs/start',
        'identifier_in': 'body'},
}

# Documented as unavailable as Cedar actions: each carries many records in one
# request, which the engine cannot evaluate per record. They cannot be
# permitted through the gateway at all.
UNGOVERNABLE = ['BatchCreateMemoryRecords', 'BatchUpdateMemoryRecords',
                'BatchDeleteMemoryRecords']


def action(operation: str, target: str = None) -> str:
    """The Cedar action id: `<target>___<METHOD>:<uri-template>`.

    The template keeps its `{...}` placeholders - they are *not* substituted
    with concrete values, so the action id is identical for every actor and
    session. That is exactly why isolation has to come from a condition on
    `context.input` and cannot come from the action id.
    """
    spec = OPERATIONS[operation]
    target = target or fm_config.MEMFGAC_TARGET_NAME
    return f"{target}___{spec['method']}:{spec['uri']}"


# --------------------------------------------------------------- via a gateway

class MemoryGatewayClient:
    """Signed HTTPS to the Memory connector, with the verdict extracted.

    Deliberately not boto3: boto3 would sign for the Memory data plane and send
    the request straight there, which is the path this class exists to contrast
    with. The gateway is a different endpoint with the target name in front of
    Memory's own URI, so the request is built and signed by hand.
    """

    def __init__(self, base_url: str = None, memory_id: str = None,
                 service: str = 'bedrock-agentcore'):
        self.base_url = (base_url or fm_resources.memory_base_url() or '')
        self.memory_id = memory_id or fm_resources.memory_id()
        self.service = service
        self.credentials = (boto3.Session().get_credentials()
                            .get_frozen_credentials())

    @property
    def available(self) -> bool:
        return bool(self.base_url and self.memory_id)

    def call(self, operation: str, path_values: Dict[str, str] = None,
             body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        spec = OPERATIONS[operation]
        record: Dict[str, Any] = {'operation': operation,
                                  'action': action(operation),
                                  'method': spec['method']}
        if not self.available:
            record.update({'http_status': None, 'verdict': 'UNAVAILABLE',
                           'reached_memory': False,
                           'error': 'the Memory FGAC gateway is not '
                                    'provisioned'})
            return record
        uri = spec['uri'].format(memoryId=self.memory_id,
                                 **(path_values or {}))
        url = self.base_url + uri
        record['uri'] = uri
        data = json.dumps(body).encode() if body is not None else None
        signed = AWSRequest(method=spec['method'], url=url, data=data,
                            headers={'Content-Type': 'application/json'})
        SigV4Auth(self.credentials, self.service,
                  fm_config.REGION).add_auth(signed)
        request = urllib.request.Request(
            url, data=data, method=spec['method'],
            headers=dict(signed.headers.items()))
        started = time.time()
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                record.update({'http_status': response.status,
                               'body': response.read().decode()[:600]})
        except urllib.error.HTTPError as exc:
            record.update({'http_status': exc.code,
                           'body': exc.read().decode()[:600]})
        except Exception as exc:                      # noqa: BLE001 recorded
            record.update({'http_status': None,
                           'error': f'{type(exc).__name__}: {exc}'})
        record['latency_ms'] = round((time.time() - started) * 1000, 1)
        record.update(_verdict(record))
        return record

    # -- the calls this project makes ------------------------------------

    def write_event(self, actor: str, text: str,
                    session_id: str = None) -> Dict[str, Any]:
        # clientToken and a *numeric* eventTimestamp are both required by
        # Memory and neither is mentioned by the FGAC guide; an ISO-8601
        # string is refused ("STRING_VALUE cannot be converted to Date").
        return self.call('CreateEvent', {}, {
            'actorId': actor,
            'sessionId': session_id or f'{fm_config.SESSION_PREFIX}-'
                                       f'{uuid.uuid4().hex[:8]}',
            'eventTimestamp': int(time.time()),
            'clientToken': str(uuid.uuid4()),
            'payload': [{'conversational': {
                'role': 'ASSISTANT', 'content': {'text': text[:8000]}}}]})

    def retrieve(self, namespace: str,
                 query: str = 'mortgage affordability research'
                 ) -> Dict[str, Any]:
        return self.call('RetrieveMemoryRecords', {}, {
            'namespace': namespace,
            'searchCriteria': {'searchQuery': query}})

    def list_events(self, actor: str, session_id: str,
                    limit: int = 5) -> Dict[str, Any]:
        return self.call('ListEvents',
                         {'actorId': actor, 'sessionId': session_id},
                         {'maxResults': limit})


def _verdict(record: Dict[str, Any]) -> Dict[str, Any]:
    """Separate the gateway's decision from Memory's own answer.

    A 403 with a policy message is the engine. A 2xx means the request was
    forwarded and Memory answered. A non-403 4xx means policy **allowed** it
    and Memory rejected it on its own terms - that third case is an ALLOWED
    verdict, and reading it as a failure would understate what the policy did.
    """
    status = record.get('http_status')
    body = record.get('body') or ''
    if status == 403 and 'policy enforcement' in body:
        policy = None
        if 'denied due to' in body:
            policy = body.split('denied due to')[1].strip(' ].}"\'')
        return {'verdict': 'DENIED', 'deciding_policy': policy,
                'denied_by_default': 'denied by default' in body,
                'reached_memory': False}
    if status is not None and 200 <= status < 300:
        return {'verdict': 'ALLOWED', 'deciding_policy': None,
                'reached_memory': True}
    if status is not None and 400 <= status < 500:
        return {'verdict': 'ALLOWED', 'deciding_policy': None,
                'reached_memory': True,
                'note': 'policy allowed it; Memory itself rejected the body'}
    return {'verdict': 'ERROR', 'deciding_policy': None,
            'reached_memory': False}


# ---------------------------------------------------------------- direct, boto3

def write_event_direct(actor: str, text: str,
                       session_id: str = None) -> Dict[str, Any]:
    """Write straight to the Memory data plane. No policy is in this path."""
    memory_id = fm_resources.memory_id()
    if not memory_id:
        return {'ok': False, 'error': f'no memory named '
                                      f'{fm_config.MEMORY_NAME}'}
    session_id = session_id or (f'{fm_config.SESSION_PREFIX}-'
                                f'{uuid.uuid4().hex[:8]}')
    response = fm_resources.data_plane().create_event(
        memoryId=memory_id, actorId=actor, sessionId=session_id,
        eventTimestamp=time.time(),
        payload=[{'conversational': {
            'role': 'ASSISTANT', 'content': {'text': text[:8000]}}}])
    event = response.get('event') or {}
    return {'ok': True, 'event_id': event.get('eventId'),
            'memory_id': memory_id, 'session_id': session_id, 'actor': actor}


def retrieve_direct(namespace: str,
                    query: str = 'mortgage affordability research'
                    ) -> Dict[str, Any]:
    memory_id = fm_resources.memory_id()
    if not memory_id:
        return {'ok': False, 'records': []}
    response = fm_resources.data_plane().retrieve_memory_records(
        memoryId=memory_id, namespace=namespace,
        searchCriteria={'searchQuery': query})
    return {'ok': True, 'memory_id': memory_id,
            'records': [{'content': str(r.get('content'))[:300]}
                        for r in response.get('memoryRecordSummaries') or []]}


def list_events_direct(actor: str, session_id: str = None,
                       limit: int = 5) -> Dict[str, Any]:
    """Read back what was written. The path that returns content.

    `ListEvents` needs a session id, so when none is given the actor's recent
    sessions are listed first.
    """
    memory_id = fm_resources.memory_id()
    if not memory_id:
        return {'ok': False, 'events': []}
    data = fm_resources.data_plane()
    sessions = ([session_id] if session_id
                else _recent_sessions(data, memory_id, actor, limit))
    events: List[Dict[str, Any]] = []
    for session in sessions:
        page = data.list_events(memoryId=memory_id, actorId=actor,
                               sessionId=session, maxResults=limit)
        for event in page.get('events') or []:
            events.append({'event_id': event.get('eventId'),
                           'session_id': session,
                           'text': _event_text(event)})
    return {'ok': True, 'events': events[:limit], 'actor': actor,
            'memory_id': memory_id,
            'note': ('ListEvents returns content; RetrieveMemoryRecords '
                     'returns none because this memory has no extraction '
                     'strategy configured.')}


def _recent_sessions(data, memory_id: str, actor: str,
                     limit: int) -> List[str]:
    try:
        page = data.list_sessions(memoryId=memory_id, actorId=actor,
                                  maxResults=limit)
    except Exception:                                 # noqa: BLE001
        return []
    return [s.get('sessionId') for s in
            page.get('sessionSummaries') or page.get('sessions') or []
            if s.get('sessionId')]


def _event_text(event: Dict[str, Any]) -> str:
    for part in event.get('payload') or []:
        content = (part.get('conversational') or {}).get('content') or {}
        if content.get('text'):
            return content['text']
    return ''


def has_strategies() -> bool:
    """Whether this memory extracts long-term records at all.

    If False, `RetrieveMemoryRecords` can only ever return zero rows - which is
    the state of the shared resource, and the reason this project proves
    persistence and authorization on different calls.
    """
    memory_id = fm_resources.memory_id()
    if not memory_id:
        return False
    detail = fm_resources.control().get_memory(memoryId=memory_id)
    return bool((detail.get('memory') or {}).get('strategies'))
