"""Packaging and network selection for the Runtime zip — self-contained.

Ported from the price-match runtime module so that nothing in this folder
depends on another project. Every comment below records something that cost a
deploy cycle to learn; none of it is defensive padding.

The zip, and why it is shaped this way:

    agent.py              this project's fm_agent.py, renamed
    agent_config.py       settings the hosted agent reads
    agent_gateway.py      signed MCP over urllib
    vendor/               boto3, pinned and pruned

The runtime sandbox has **no boto3** - site-packages holds no SDKs - so
dependencies are vendored in and `sys.path`-inserted before anything imports
them. It is **aarch64** and your build host almost certainly is not, so
everything vendored must be pure Python; a wheel with a compiled extension
ships the wrong architecture and surfaces as an import error in a log you have
to go hunting for. `_check_pure` fails the build instead.
"""

import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import zipfile
from typing import Any, Dict, List, Tuple

import boto3
from botocore.exceptions import ClientError

import fm_config

HERE = pathlib.Path(__file__).resolve().parent

# Deploy-time settings. Defaults are the measured ones.
CODE_BUCKET = os.getenv('FM_CODE_BUCKET',
                        f'agentcore-runtime-deploy-{fm_config.ACCOUNT_ID}')
PYTHON_RUNTIME = os.getenv('FM_PYTHON_RUNTIME', 'PYTHON_3_12')
VENDOR_DIR = os.getenv('FM_VENDOR_DIR', 'vendor')
RUNTIME_ROLE_ARN = os.getenv(
    'FM_RUNTIME_ROLE_ARN',
    f'arn:aws:iam::{fm_config.ACCOUNT_ID}:role/SandboxServiceRole')
NETWORK_MODE = os.getenv('FM_NETWORK_MODE', 'VPC')
SUBNET_IDS = [s for s in os.getenv('FM_SUBNET_IDS', '').split(',') if s]
SECURITY_GROUP_IDS = [s for s in
                      os.getenv('FM_SECURITY_GROUP_IDS', '').split(',') if s]

# Only these zones run AgentCore Runtime here. A subnet in an unsupported zone
# **passes validation** and then fails the runtime asynchronously ~8s later,
# visible only in `failureReason`.
SUPPORTED_AZ_IDS = set(os.getenv('FM_SUPPORTED_AZ_IDS',
                                 'use1-az1,use1-az2,use1-az4').split(','))

# botocore ships ~400 service models and the agent calls five. Pruning takes
# boto3 from 32 MB to a ~1.5 MB artifact.
KEEP_BOTOCORE_SERVICES = set(os.getenv(
    'FM_KEEP_BOTOCORE_SERVICES',
    'sts,bedrock,bedrock-runtime,bedrock-agentcore,bedrock-agentcore-control'
).split(','))

REQUIREMENTS = ['boto3>=1.43.0']


def say(message: str = '') -> None:
    print(message, flush=True)


# ------------------------------------------------------------------ vendoring

def vendor_into(target: pathlib.Path) -> int:
    """Install the pinned requirements, prune them, and refuse impure builds."""
    target.mkdir(parents=True, exist_ok=True)
    requirements = target.parent / 'requirements.txt'
    requirements.write_text('\n'.join(REQUIREMENTS) + '\n')
    # --no-warn-conflicts because pip otherwise reports conflicts against
    # whatever is installed in the *host* environment, which is irrelevant:
    # nothing here is installed into it.
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--quiet',
                    '--no-warn-conflicts', '--no-compile',
                    '--target', str(target), '-r', str(requirements)],
                   check=True, stdout=subprocess.DEVNULL)

    data = target / 'botocore' / 'data'
    if data.is_dir():
        for entry in sorted(data.iterdir()):
            if entry.is_dir() and entry.name not in KEEP_BOTOCORE_SERVICES:
                shutil.rmtree(entry)
        for service in (p for p in data.iterdir() if p.is_dir()):
            for version in (p for p in service.iterdir() if p.is_dir()):
                for leaf in version.iterdir():
                    # Keeping only service-2.json is what drops
                    # paginators-1.json - which is why nothing in this project
                    # uses a boto3 paginator: `get_paginator` raises
                    # OperationNotPageableError in the runtime and works fine
                    # on a development host.
                    if leaf.name not in ('service-2.json',
                                         'service-2.json.gz'):
                        leaf.unlink()
    shutil.rmtree(target / 'boto3' / 'data', ignore_errors=True)
    for junk in target.rglob('__pycache__'):
        shutil.rmtree(junk, ignore_errors=True)
    for info in list(target.glob('*.dist-info')) + list(target.glob('bin')):
        shutil.rmtree(info, ignore_errors=True)

    _check_pure(target)
    return sum(1 for f in target.rglob('*') if f.is_file())


def _check_pure(target: pathlib.Path) -> None:
    native = [str(f.relative_to(target)) for f in target.rglob('*.so')][:5]
    if native:
        raise SystemExit(
            'Vendored dependencies contain compiled extensions, built for '
            f'this host and not for the runtime (aarch64): {native}. Drop the '
            'dependency or switch to a container build.')


def package(agent_files: List[Tuple[pathlib.Path, str]],
            out: pathlib.Path) -> pathlib.Path:
    """Build the zip from this project's files plus a pruned vendor tree."""
    out.parent.mkdir(parents=True, exist_ok=True)
    missing = [str(src) for src, _ in agent_files if not src.is_file()]
    if missing:
        raise SystemExit(f'Cannot package, missing source files: {missing}')
    with tempfile.TemporaryDirectory() as tmp:
        vendor = pathlib.Path(tmp) / VENDOR_DIR
        count = vendor_into(vendor)
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as archive:
            for source, name in agent_files:
                archive.write(source, name)
            for found in vendor.rglob('*'):
                if found.is_file():
                    archive.write(found, str(pathlib.Path(VENDOR_DIR)
                                             / found.relative_to(vendor)))
    say(f'  packaged           {out.name} {out.stat().st_size / 1e6:.1f} MB '
        f'({len(agent_files)} agent files + {count} vendored)')
    return out


# -------------------------------------------------------------------- the s3

def check_bucket() -> List[str]:
    s3 = boto3.client('s3', region_name=fm_config.REGION)
    try:
        s3.head_bucket(Bucket=CODE_BUCKET)
        say(f'  code bucket        s3://{CODE_BUCKET} exists')
        return []
    except ClientError as exc:
        if exc.response['Error']['Code'] not in ('404', '403', 'NoSuchBucket'):
            return [f's3: {exc}']
    try:
        kwargs: Dict[str, Any] = {'Bucket': CODE_BUCKET}
        if fm_config.REGION != 'us-east-1':
            kwargs['CreateBucketConfiguration'] = {
                'LocationConstraint': fm_config.REGION}
        s3.create_bucket(**kwargs)
        say(f'  code bucket        created s3://{CODE_BUCKET}')
        return []
    except ClientError as exc:
        return [f'cannot create s3://{CODE_BUCKET}: '
                f"{exc.response['Error']['Code']}"]


def push(archive: pathlib.Path, prefix: str) -> Dict[str, Any]:
    boto3.client('s3', region_name=fm_config.REGION).upload_file(
        str(archive), CODE_BUCKET, prefix)
    say(f'  uploaded           s3://{CODE_BUCKET}/{prefix}')
    return {'codeConfiguration': {
        'code': {'s3': {'bucket': CODE_BUCKET, 'prefix': prefix}},
        'runtime': PYTHON_RUNTIME,
        'entryPoint': ['agent.py']}}


# ---------------------------------------------------------------- networking

EGRESS_RANK = {'nat': 0, 'tgw': 0, 'igw': 1, 'none': 2}


def egress_kind(ec2, subnet: Dict[str, Any],
                tables: List[Dict[str, Any]]) -> str:
    """How — and whether — traffic from this subnet reaches the internet.

    This distinction is the whole reason the function exists. A subnet whose
    default route is an **internet gateway** looks connected and is not: the
    ENI AgentCore places in your subnet has no public IP, and an IGW route only
    works for instances that have one. The agent then starts fine, passes its
    health check, and every outbound call hangs until it fails — and the log
    group has no session stream at all, because log delivery needs the same
    egress. An empty log group is the diagnosis.

    NAT or transit gateway does work. So: rank, do not merely check.
    """
    explicit = next((t for t in tables for a in t['Associations']
                     if a.get('SubnetId') == subnet['SubnetId']), None)
    table = explicit or next(
        (t for t in tables if t['VpcId'] == subnet['VpcId']
         and any(a.get('Main') for a in t['Associations'])), None)
    if table is None:
        return 'none'
    for route in table['Routes']:
        if route.get('DestinationCidrBlock') != '0.0.0.0/0':
            continue
        if route.get('NatGatewayId'):
            return 'nat'
        if route.get('TransitGatewayId'):
            return 'tgw'
        if route.get('GatewayId', '').startswith('igw-'):
            return 'igw'
    return 'none'


def pick_network() -> Dict[str, Any]:
    """Build `networkConfiguration`, discovering subnets if none are set.

    Two filters, both learned the hard way:

    * Availability zone, on `AvailabilityZoneId` and **never** on
      `AvailabilityZone`. Zone names are per-account aliases, so a name-based
      filter is the kind of bug that passes review and then fails only in
      someone else's account.
    * Egress, per `egress_kind` above.
    """
    if NETWORK_MODE.upper() == 'PUBLIC':
        return {'networkMode': 'PUBLIC'}
    if SUBNET_IDS and SECURITY_GROUP_IDS:
        return {'networkMode': 'VPC',
                'networkModeConfig': {'subnets': SUBNET_IDS,
                                      'securityGroups': SECURITY_GROUP_IDS}}

    ec2 = boto3.client('ec2', region_name=fm_config.REGION)
    tables = ec2.describe_route_tables()['RouteTables']
    usable: Dict[str, List[Tuple[str, str]]] = {}
    for subnet in ec2.describe_subnets()['Subnets']:
        if subnet['AvailabilityZoneId'] in SUPPORTED_AZ_IDS:
            usable.setdefault(subnet['VpcId'], []).append(
                (subnet['SubnetId'], egress_kind(ec2, subnet, tables)))
    if not usable:
        raise SystemExit(
            'No subnet in a zone AgentCore Runtime supports '
            f'({sorted(SUPPORTED_AZ_IDS)}). Create one, or set '
            'FM_NETWORK_MODE=PUBLIC if this account permits it.')

    # Best egress first, then most zones — in that order, because a second
    # zone is worth less than working outbound traffic.
    def score(vpc_id: str) -> Tuple[int, int]:
        kinds = [kind for _, kind in usable[vpc_id]]
        return (min(EGRESS_RANK[kind] for kind in kinds), -len(kinds))

    vpc = min(usable, key=score)
    best = min(EGRESS_RANK[kind] for _, kind in usable[vpc])
    chosen = [(sid, kind) for sid, kind in usable[vpc]
              if EGRESS_RANK[kind] == best]
    kinds = sorted({kind for _, kind in chosen})
    if best == 1:
        say('  WARNING            the only usable subnets route 0.0.0.0/0 to '
            'an internet gateway. AgentCore ENIs have no public IP, so the '
            'runtime will reach READY and then fail every outbound call, with '
            'an empty log group as the only symptom.')
    say(f"  egress             via {', '.join(kinds)}")

    groups = SECURITY_GROUP_IDS or [
        group['GroupId'] for group in ec2.describe_security_groups(
            Filters=[{'Name': 'vpc-id', 'Values': [vpc]},
                     {'Name': 'group-name', 'Values': ['default']}]
        )['SecurityGroups']]
    subnets = [sid for sid, _ in chosen]
    say(f'  network            VPC {vpc}, subnets {subnets}, sg {groups}')
    return {'networkMode': 'VPC',
            'networkModeConfig': {'subnets': subnets,
                                  'securityGroups': groups}}
