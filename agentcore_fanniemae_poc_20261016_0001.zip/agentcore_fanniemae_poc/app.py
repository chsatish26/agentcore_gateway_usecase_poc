"""The Streamlit entry point for the Fannie Mae mortgage-research POC.

Five pages, in the order a reader needs them:

    Ask            type a prompt, pick a mode, execute, read the answer
    Compare        the same prompt both ways, side by side
    Security       identity / policy / Memory FGAC tests
    Test cases     the full matrix, with a Run button
    Architecture   the two modes drawn, what Gateway does, where things live

Design rules carried over from the reused POC, each for a measured reason:

* **No AWS call on load.** Every page renders from artifacts on disk until a
  button is pressed, so a presenter can open this mid-meeting.
* **Figures are read back from artifacts**, not typed into the page. A number
  on screen that nobody can trace to a run is worth nothing in this context.
* **Nothing claims a resource exists without checking.** The sidebar probes
  the borrowed resources and says plainly which are missing, because three of
  the five belong to another project and can be torn down independently.
"""

import json
import os
import time
from typing import Any, Dict, List, Optional

import streamlit as st

import fm_config
import fm_diagrams
import fm_policies
import fm_trace
import fm_config
import fm_diagrams
import fm_policies
import fm_resources
import fm_trace

st.set_page_config(page_title='AgentCore Gateway & Memory — Fannie Mae POC',
                   page_icon='🏠', layout='wide')

HERE = os.path.dirname(os.path.abspath(__file__))
RUNNING = 'fm_run_in_flight'


# ------------------------------------------------------------------- loading

@st.cache_data(show_spinner=False)
def _case_total() -> int:
    """How many cases the matrix actually has.

    Read from the case lists rather than written in the heading - the labels
    said "TC01-TC20" for a while after fifteen capability cases were added,
    which told the reader the wrong thing about what the button would run.
    Cached because importing the case modules pulls in boto3.
    """
    import testcases
    import testcases_capability
    return len(testcases.CASES) + len(testcases_capability.CASES)


@st.cache_data(show_spinner=False)
def _load(path: str, mtime: float) -> Dict[str, Any]:
    with open(path) as handle:
        return json.load(handle)


def _runs(prefix: str) -> Dict[str, str]:
    return {os.path.basename(p): p for p in fm_trace.all_runs(prefix)}


def _pick(prefix: str, label: str) -> Optional[Dict[str, Any]]:
    options = _runs(prefix)
    if not options:
        return None
    chosen = st.selectbox(label, list(options), key=f'pick_{prefix}',
                          help='Newest first. Everything below is read from '
                               'the selected run.')
    path = options[chosen]
    return _load(path, os.path.getmtime(path))


# -------------------------------------------------------------------- sidebar

def sidebar() -> None:
    st.sidebar.title('🏠 Fannie Mae research POC')
    st.sidebar.caption(fm_config.USE_CASE)
    st.sidebar.warning(fm_config.DISCLAIMER)

    with st.sidebar.expander('Resources this POC uses', expanded=False):
        st.caption('Probed live when you expand this. Three of these belong '
                   'to the price-match POC next door and can be torn down '
                   'independently of this project.')
        if st.button('Check resources', key='check_res'):
            resources = fm_resources.resources(refresh=True)
            for name, info in resources.items():
                icon = '✅' if info['present'] else '🛑'
                st.markdown(f"{icon} **{name}** — {info['purpose']}")
                st.caption(f"`{info.get('id') or 'missing'}` · owned by "
                           f"{info['owned_by']}")
            try:
                import deploy_runtime
                runtime = deploy_runtime.status()
                icon = '✅' if runtime['exists'] else '🛑'
                st.markdown(f"{icon} **runtime** — this project's own")
                st.caption(f"`{runtime.get('runtime_id') or 'not deployed'}` "
                           f"· {runtime.get('status')}")
            except Exception as exc:                    # noqa: BLE001
                st.caption(f'runtime check failed: {exc}')
            policies = fm_policies.status()
            icon = '✅' if policies['ready_for_mode_b'] else '⚠️'
            st.markdown(f"{icon} **this project's Cedar policies**")
            for name in policies['fmpoc_policies'] or ['none installed']:
                st.caption(f'`{name}`')

    st.sidebar.markdown('---')
    st.sidebar.caption(
        'Run from a terminal:\n\n'
        '`python run_fm.py research --mode with_gateway`\n\n'
        '`python run_fm.py security`\n\n'
        '`python run_fm.py testcases`')


# ----------------------------------------------------------------- page: ask

def page_ask() -> None:
    st.title('Ask the mortgage-research agent')
    st.caption('Type a prompt, choose whether the gateway is in the path, and '
               'execute. Nothing here is hard-coded to one question.')

    with st.form('ask'):
        prompt = st.text_area(
            'Prompt', value=fm_config.DEFAULT_PROMPT, height=100,
            help='Any finance-research question. The agent searches public '
                 'sources, extracts them, summarises with citations and '
                 'saves the summary to Memory.')
        columns = st.columns([2, 2, 2, 3])
        mode_label = columns[0].radio(
            'Execution mode', ['With Gateway', 'Without Gateway'],
            help='With Gateway: web search goes through the gateway connector '
                 'and Cedar decides; memory writes go through the memory '
                 'connector. Without Gateway: neither, and no policy is in '
                 'the path at all.')
        where = columns[1].radio(
            'Run where', ['AgentCore Runtime', 'Locally (managed Browser)'],
            help='Runtime: the deployed agent executes it, which is the '
                 'architecture the spec asks for. Local: this process does, '
                 'which is the only way to drive the Browser over CDP — '
                 'Playwright cannot be vendored into the runtime zip.')
        user = columns[2].selectbox(
            'Acting as', [fm_config.USER_PRIMARY, fm_config.USER_OTHER],
            help=f'{fm_config.USER_PRIMARY} is permitted to write by this '
                 f'project\'s Cedar policy; {fm_config.USER_OTHER} is not, '
                 f'so a write as that analyst is denied at the gateway.')
        columns[3].caption(
            'A full run takes 20-60s: a browser session, a search, two page '
            'extracts, one model call and a memory write. Every number shown '
            'afterwards comes from that run.')
        submitted = st.form_submit_button('Execute', type='primary')

    if submitted:
        mode = (fm_config.MODE_GATEWAY if mode_label == 'With Gateway'
                else fm_config.MODE_DIRECT)
        hosted = where == 'AgentCore Runtime'
        _execute(prompt, mode, user, hosted)

    bundle = _pick('research_', 'Recorded run')
    if bundle:
        _show_run(bundle)
    else:
        st.info('No run recorded yet. Press Execute above.')


def _execute(prompt: str, mode: str, user: str, hosted: bool) -> None:
    log: List[str] = []
    stream = st.empty()

    def say(message: str = '') -> None:
        log.append(str(message))
        stream.code('\n'.join(log[-18:]), language='text')

    with st.spinner('Executing…'):
        try:
            if hosted:
                import invoke_runtime
                result = invoke_runtime.invoke(prompt, mode=mode, user=user,
                                               say=say)
                if not result.get('ok'):
                    st.error(result.get('error'))
                    return
                bundle = _from_hosted(result, prompt, mode, user)
            else:
                import research
                bundle = research.run(prompt, mode=mode, user=user, say=say)
            path = fm_trace.write(bundle, 'research_')
        except Exception as exc:                        # noqa: BLE001
            st.error(f'{type(exc).__name__}: {exc}')
            return
    st.success(f'Done — written to `{os.path.basename(path)}`')
    st.cache_data.clear()
    st.rerun()


def _from_hosted(result: Dict[str, Any], prompt: str, mode: str,
                 user: str) -> Dict[str, Any]:
    """Normalise a hosted response into the same shape a local run produces.

    One shape, so the display code and the comparison do not need to know
    where the run happened - but `executed_in` is carried through, because the
    difference is real and shown.
    """
    invocation = result.get('_invocation') or {}
    steps = result.get('steps') or []
    return {
        'use_case': fm_config.USE_CASE,
        'disclaimer': fm_config.DISCLAIMER,
        'prompt': prompt, 'mode': mode, 'user': user,
        'executed_in': 'AgentCore Runtime',
        'search_query': result.get('search_query'),
        'search': result.get('search') or {},
        'used_fallback_sources': result.get('used_fallback_sources'),
        'sources': result.get('sources') or [],
        'answer': result.get('answer') or {},
        'memory': result.get('memory') or {},
        'memory_readback': {'ok': False, 'events': [],
                            'skipped': 'hosted run does not read back'},
        'browser_probe': result.get('browser_probe') or {},
        'identity': result.get('identity') or {},
        'services_invoked': result.get('services_invoked') or [],
        'policy_decisions': [s for s in steps
                             if s.get('status') == 'DENIED'
                             or s.get('deciding_policy')],
        'enforcement_points': [
            {'step': s.get('api'), 'control': s.get('enforcement_point', '—'),
             'grain': s.get('limitation') or s.get('reason') or '—'}
            for s in steps if s.get('enforcement_point')],
        'notes': result.get('notes') or [],
        'trace': {
            'run_id': invocation.get('session_id'),
            'mode': mode,
            'spans': [{**s, 'aws_ids': {
                k: v for k, v in s.items()
                if k in ('browser_session_id', 'gateway_id', 'event_id',
                         'memory_id')}} for s in steps],
            'summary': {'spans': len(steps), 'services':
                        result.get('services_invoked') or [],
                        'total_ms': result.get('total_ms'),
                        'aws_identifiers': {
                            'runtime_session_id': [invocation.get(
                                'session_id')],
                            'runtime_id': [invocation.get('runtime_id')]}},
            'log': [],
            'trace_note': ('Steps are self-reported by the agent running '
                           'inside AgentCore Runtime. Not X-Ray traces: '
                           'Transaction Search is not enabled here.'),
        },
        '_invocation': invocation,
    }


def _show_run(bundle: Dict[str, Any]) -> None:
    mode = bundle.get('mode')
    where = bundle.get('executed_in', 'locally')
    st.markdown(f"### Answer — *{mode}*, executed in **{where}**")
    st.caption(f"prompt: {bundle.get('prompt')}")

    if bundle.get('used_fallback_sources'):
        st.warning(
            '**No search results, so seeded public sources were used.** The '
            'summary below is built from a hard-coded URL list, which is not '
            'evidence that search worked. This is flagged in the artifact as '
            '`used_fallback_sources`.')

    answer = bundle.get('answer') or {}
    if not answer.get('model_invoked'):
        st.info('The model was not invoked — there was nothing to summarise. '
                'The response states the limitation rather than inventing '
                'findings.')
    st.markdown(answer.get('text') or '_no answer_')

    columns = st.columns(4)
    columns[0].metric('Services invoked',
                      len(bundle.get('services_invoked') or []))
    columns[1].metric('Policy decisions',
                      len(bundle.get('policy_decisions') or []))
    search = bundle.get('search') or {}
    columns[2].metric('Search results', len(search.get('results') or []),
                      help=f"verdict: {search.get('verdict')}")
    memory = bundle.get('memory') or {}
    columns[3].metric('Memory write',
                      'written' if memory.get('written') else 'denied',
                      help=f"verdict: {memory.get('verdict')}")

    st.caption('services: ' + ', '.join(f'`{s}`' for s in
                                        bundle.get('services_invoked') or []))

    _show_search(bundle)
    _show_sources(bundle)

    with st.expander('Where a decision could have been made', expanded=False):
        points = bundle.get('enforcement_points') or []
        if points:
            st.dataframe([{'Step': p.get('step'), 'Control': p.get('control'),
                           'Grain': p.get('grain')} for p in points],
                         width='stretch', hide_index=True)
        st.caption(
            'In *without_gateway* there is no Cedar action anywhere in the '
            'path: the only control is the IAM permission of the role the '
            'agent runs as.')

    _show_memory(bundle)
    _show_trace(bundle)


def _show_search(bundle: Dict[str, Any]) -> None:
    """Every link the search returned, not just how many.

    The count alone is the least useful part: which links came back is what
    distinguishes the gateway connector from a browser-driven search, and the
    two return genuinely different sets for the same query.
    """
    search = bundle.get('search') or {}
    results = search.get('results') or []
    opened = {s.get('url') for s in bundle.get('sources') or []}
    label = (f"Web search — {len(results)} result(s), verdict "
             f"{search.get('verdict')}")
    with st.expander(label, expanded=True):
        st.caption(f"query sent: `{bundle.get('search_query')}`  ·  via "
                   f"{search.get('source') or search.get('path') or '—'}")
        if search.get('deciding_policy'):
            st.error(f"DENIED by `{search['deciding_policy']}` — "
                     f"{str(search.get('policy_message'))[:200]}")
        if search.get('caveat'):
            st.warning(search['caveat'])
        if not results:
            st.caption('No links returned. See the caveat above, or the '
                       'fallback-sources warning at the top of the page.')
            return
        st.dataframe(
            [{'#': i,
              'opened?': '📄 extracted' if r.get('url') in opened else '—',
              'URL': r.get('url'),
              'Title': str(r.get('title') or '')[:80]}
             for i, r in enumerate(results, start=1)],
            width='stretch', hide_index=True)
        st.caption(
            f'Only the first {fm_config.MAX_PAGES_TO_EXTRACT} link(s) are '
            f'opened — a browser session costs time and money per page, and '
            f'the point is to show the path, not to crawl.')


def _show_sources(bundle: Dict[str, Any]) -> None:
    """What the browser actually got back, including the raw text."""
    sources = bundle.get('sources') or []
    with st.expander('Extracted content — what the answer is built from',
                     expanded=True):
        if not sources:
            st.caption('none')
            return
        st.dataframe(
            [{'extracted': '✅' if s.get('ok') else '🛑',
              'URL': s.get('url'),
              'Title': str(s.get('title') or '—')[:70],
              'chars': s.get('chars_extracted'),
              'method': s.get('method') or 'CDP inner_text',
              'error': str(s.get('error') or '')[:70]}
             for s in sources],
            width='stretch', hide_index=True)
        st.caption(
            '`CDP inner_text` is the managed Browser rendering the page and '
            'returning the body text. `urllib` is the hosted agent, which '
            'cannot drive CDP — Playwright needs a compiled driver and a '
            'browser binary, and the runtime zip must be pure-Python aarch64. '
            'Same URL, different character counts, and no page title on the '
            'urllib path because it has no DOM.')
        for index, source in enumerate(sources, start=1):
            if not source.get('text'):
                continue
            with st.expander(f"[{index}] raw extracted text — "
                             f"{str(source.get('url'))[:70]}"):
                st.caption(
                    f"{source.get('chars_extracted')} characters extracted; "
                    f"the first {fm_config.EXTRACT_CHARS} are passed to the "
                    f"model. This is **raw page text** — no readability pass, "
                    f"so navigation menus and cookie banners are included and "
                    f"the model is instructed to cite only what the extract "
                    f"supports.")
                st.text_area('extract', value=source['text'], height=220,
                             key=f"extract_{bundle.get('trace', {}).get('run_id')}_{index}",
                             label_visibility='collapsed')


def _show_memory(bundle: Dict[str, Any]) -> None:
    memory = bundle.get('memory') or {}
    readback = bundle.get('memory_readback') or {}
    with st.expander('Memory — what was written, and what came back',
                     expanded=False):
        columns = st.columns(2)
        columns[0].markdown('**Write**')
        columns[0].caption(f"path: `{memory.get('path')}` · verdict: "
                           f"`{memory.get('verdict')}` · actor: "
                           f"`{memory.get('actor')}`")
        if memory.get('deciding_policy'):
            columns[0].error(f"denied by `{memory['deciding_policy']}`")
        if memory.get('event_id'):
            columns[0].caption(f"event id: `{memory['event_id']}`")
        columns[1].markdown('**Read back**')
        events = readback.get('events') or []
        if events:
            for event in events[:3]:
                columns[1].caption(f"`{event.get('event_id')}` — "
                                   f"{str(event.get('text'))[:110]}…")
        else:
            columns[1].caption(readback.get('skipped')
                               or 'nothing read back')
        st.info(
            '**Two read paths, and they are not the same path.** This memory '
            'resource has no extraction strategy, so '
            '`RetrieveMemoryRecords` returns zero rows however much is '
            'written — but it *is* governable, because `namespace` is a body '
            'field Cedar can read. `ListEvents` returns the content '
            'immediately but carries `actorId` in the **path**, which Cedar '
            'cannot read, so it cannot be isolated per caller. Persistence '
            'and authorization are therefore provable on different calls.')


def _show_trace(bundle: Dict[str, Any]) -> None:
    trace = bundle.get('trace') or {}
    with st.expander('Execution trace', expanded=False):
        st.caption(trace.get('trace_note', ''))
        spans = trace.get('spans') or []
        st.dataframe(
            [{'at': s.get('started_at') or s.get('at'),
              'service': s.get('service'), 'api': s.get('api'),
              'status': s.get('status'),
              'ms': s.get('duration_ms'),
              'enforcement point': s.get('enforcement_point', '—'),
              'deciding policy': s.get('deciding_policy') or '—'}
             for s in spans],
            width='stretch', hide_index=True)
        identifiers = (trace.get('summary') or {}).get('aws_identifiers') or {}
        if identifiers:
            st.markdown('**Service-issued identifiers from this run**')
            st.json(identifiers, expanded=True)
        if trace.get('log'):
            st.code('\n'.join(trace['log']), language='text')
        st.download_button(
            'Download this run (JSON)',
            json.dumps(bundle, indent=2, default=str),
            file_name=f"run_{trace.get('run_id', 'research')}.json",
            mime='application/json', key=f"dl_{trace.get('run_id')}",
            help='The whole run: search links, extracted text, every span, '
                 'the policy verdicts and the service-issued identifiers.')
        invocation = bundle.get('_invocation') or {}
        if invocation:
            st.markdown('**Runtime invocation**')
            st.caption(f"runtime `{invocation.get('runtime_id')}` v"
                       f"{invocation.get('runtime_version')} · session "
                       f"`{invocation.get('session_id')}` · "
                       f"{invocation.get('elapsed_s')}s")
            st.caption(f"CloudWatch log group: "
                       f"`{invocation.get('log_group')}`")


# ------------------------------------------------------------- page: compare

def page_compare() -> None:
    st.title('With Gateway vs Without Gateway')
    st.markdown('''
Both modes answer the same prompt. What differs is **who can refuse**, and the
honest answer is that the three tools do not line up symmetrically — which is
the most useful thing in this POC.
''')
    st.dataframe([
        {'Capability': 'Web search',
         'Without Gateway': 'Not available as an AWS service at all. There is '
                            'no WebSearch API; it exists only as the gateway '
                            'connector. A browser-driven or HTTPS search is '
                            'substituted.',
         'With Gateway': 'The web-search connector, with Cedar on every call '
                         '(query and maxResults).',
         'Verdict': 'Gateway-only'},
        {'Capability': 'Browser extraction',
         'Without Gateway': 'Managed Browser over CDP, IAM only.',
         'With Gateway': 'Identical — `browser` is not a gateway target type, '
                         'so no Cedar action for "open a page" can exist.',
         'Verdict': 'Direct-only, same both ways'},
        {'Capability': 'Memory',
         'Without Gateway': 'Data plane, SigV4. The role may write any actor '
                            'and read any namespace.',
         'With Gateway': 'The agentcore-memory connector, with Cedar on the '
                         'request body (actorId, namespace).',
         'Verdict': 'Both, and this is where policy differs'},
        {'Capability': 'Bedrock (the model)',
         'Without Gateway': 'Direct, IAM.',
         'With Gateway': 'Direct, IAM — unchanged.',
         'Verdict': 'Unaffected'},
        {'Capability': 'Runtime',
         'Without Gateway': 'Invoked by the client.',
         'With Gateway': 'Invoked by the client — the gateway does not front '
                         'the runtime here.',
         'Verdict': 'Unaffected'},
    ], width='stretch', hide_index=True)

    st.markdown('### What changes when Gateway is enabled')
    st.markdown('''
1. **A capability appears.** Web search becomes possible at all.
2. **Two enforcement points appear**, on search and on memory. Every call gets
   a verdict, and a denial names the policy that caused it instead of
   returning a bare `AccessDenied` against a shared role.
3. **The default inverts.** Off-gateway, the agent can do whatever its IAM role
   allows. On-gateway, nothing is permitted until a policy says so — a tool
   with no policy is not even listed.
4. **Revoking becomes cheap.** One `DeletePolicy`, not an IAM change on a
   shared role or an application deploy.
5. **Nothing else changes.** Browser and Bedrock are byte-identical, and the
   agent code is the same code.
''')

    st.markdown('### Measured, from the two most recent runs')
    bundle = _pick('testcases_', 'Test-case run to read the comparison from')
    if not bundle:
        st.info('Run `python run_fm.py testcases` to populate this.')
        return
    st.dataframe([{'Dimension': row['dimension'],
                   'Without Gateway': row['without_gateway'],
                   'With Gateway': row['with_gateway']}
                  for row in bundle.get('comparison') or []],
                 width='stretch', hide_index=True)
    st.caption(f"from {bundle.get('generated_at')}")

    # The sharpest single piece of evidence in the whole POC: the same query,
    # at the same moment, returning two different sets of links.
    runs = bundle.get('runs') or {}
    direct = (runs.get('without_gateway') or {})
    gateway = (runs.get('with_gateway') or {})
    if direct.get('search') or gateway.get('search'):
        st.markdown('### The same query returned different links')
        st.caption(
            f"query: `{gateway.get('search_query') or direct.get('search_query')}`"
            f" — run both ways in the same test pass")
        left, right = st.columns(2)
        for column, run, title in ((left, direct, 'Without Gateway'),
                                   (right, gateway, 'With Gateway')):
            search = run.get('search') or {}
            results = search.get('results') or []
            column.markdown(f"**{title}** — {len(results)} result(s), "
                            f"verdict `{search.get('verdict')}`")
            column.caption(f"via {search.get('source') or '—'}")
            for index, item in enumerate(results, start=1):
                column.caption(f"{index}. {item.get('url')}")
            if not results:
                column.caption('_no links returned_')
        st.info(
            'Neither set is "better". The point is that these are **different '
            'capabilities**, not one wrapped inside the other: the gateway '
            'path is the `web-search` connector under Cedar, and the direct '
            'path is a browser driving a public search engine with no policy '
            'and no `maxResults` contract. Web search has no standalone '
            'AgentCore API, so there is nothing for Mode A to call.')


# ------------------------------------------------------------ page: security

def page_security() -> None:
    st.title('Identity, policy and Memory FGAC')
    st.markdown('''
Every test below says **which kind of control** produced its result, because
the difference decides how much the result is worth.
''')
    bundle = _pick('security_tests', 'Security test run')
    if st.button('Run the security tests now', type='primary'):
        import security_tests
        log: List[str] = []
        stream = st.empty()

        def say(message: str = '') -> None:
            log.append(str(message))
            stream.code('\n'.join(log[-14:]), language='text')
        with st.spinner('Running nine tests against live services…'):
            result = security_tests.run_all(say=say)
            fm_trace.write(result, security_tests.ARTIFACT_PREFIX)
        st.cache_data.clear()
        st.rerun()
    if not bundle:
        st.info('No security run recorded yet.')
        return

    summary = bundle['summary']
    if summary['passed'] == summary['total']:
        st.success(f"{summary['passed']}/{summary['total']} tests passed.")
    else:
        st.warning(f"{summary['passed']}/{summary['total']} tests passed.")
    st.download_button(
        'Download security results (JSON)',
        json.dumps(bundle, indent=2, default=str),
        file_name=f"security_{bundle.get('generated_at', 'run')}.json",
        mime='application/json',
        help='Every test with its expected value, actual value, enforcement '
             'point and the spans behind it.')

    for kind, label in (bundle.get('kinds') or {}).items():
        tests = [t for t in bundle['tests'] if t['kind'] == kind]
        if not tests:
            continue
        st.markdown(f'#### {label}')
        st.dataframe(
            [{'': '✅' if t['passed'] else '🛑', 'ID': t['id'],
              'Test': t['name'], 'Expected': t['expected'],
              'Actual': t['actual'],
              'Enforced at': t.get('enforcement_point', '—')}
             for t in tests], width='stretch', hide_index=True)
        for test in tests:
            if test.get('note'):
                with st.expander(f"{test['id']} — why this result means what "
                                 f"it means"):
                    st.caption(test['note'])

    st.error('''
**The one claim this page does not make.** "Analyst B cannot read analyst A's
memory" is enforced here on the **namespace in the request**, not on the
caller's identity: both calls are made by the same IAM principal. A *named*
`AgentCore::IamEntity` principal matched nothing in five id forms, and
`AgentCore::OAuthUser` is refused outright on an AWS_IAM gateway. So this
stops a caller asking for what it may not have; it does not distinguish two
callers. Per-principal FGAC would need OAuth inbound, and no OIDC provider can
be created in this account.
''')


# ----------------------------------------------------------- page: test cases

def _testcase_options() -> Dict[str, bool]:
    st.caption(f'{_case_total()} cases: TC01–TC20 cover the use case, '
               f'TC21–TC35 probe each capability and the combinations.')
    hosted = st.checkbox(
        'Include the two AgentCore Runtime invocations', value=True,
        help='On: TC16 and TC18 get hosted evidence. Off: ~2 minutes faster, '
             'and those two rows fall back to local evidence.')
    st.caption(
        'Runs the shared workloads once (two research runs, the nine security '
        'tests, optionally two hosted runs) and then evaluates every case '
        'against them. **8–14 minutes** for the full matrix. Every call is '
        'real: browser sessions, gateway calls, Bedrock, memory writes, and '
        'two cases install and remove Cedar policies.')
    return {'hosted': hosted}


def _run_testcases(hosted: bool) -> None:
    import testcases
    log: List[str] = []
    stream = st.empty()

    def say(message: str = '') -> None:
        log.append(str(message))
        stream.code('\n'.join(log[-22:]), language='text')

    st.warning(
        '**Do not switch page while this runs.** Streamlit abandons a script '
        'that is replaced, which would leave a browser session billing until '
        'its timeout. Nothing else breaks — this project owns its policies and '
        'they are reinstalled idempotently on the next run.')
    with st.spinner('Running the matrix against live services…'):
        try:
            bundle = testcases.run_all(include_hosted=hosted, say=say)
            path = fm_trace.write(bundle, testcases.ARTIFACT_PREFIX)
        except Exception as exc:                        # noqa: BLE001
            st.error(f'{type(exc).__name__}: {exc}')
            return
    summary = bundle['summary']
    with st.spinner('Rendering the PDF reports…'):
        import fm_report
        built = fm_report.build_all(bundle, say=say)
    st.session_state['fm_pdfs'] = built
    st.success(f"{summary['passed']} passed, {summary['failed']} failed, "
               f"{summary['blocked']} blocked — written to "
               f"`{os.path.basename(path)}`, plus {len(built)} PDF report(s)")
    st.cache_data.clear()
    st.rerun()


def _exports(bundle: Dict[str, Any]) -> None:
    """Let the results leave the page: raw artifact, and a flat table."""
    rows = bundle.get('cases') or []
    tsv = ['\t'.join(['ID', 'Scenario', 'Mode', 'Result', 'Expected',
                      'Actual', 'Services', 'Errors'])]
    for record in rows:
        tsv.append('\t'.join([
            record['id'], record['scenario'], record['mode'],
            record['result'], record['expected'].replace('\t', ' '),
            str(record['actual']).replace('\t', ' ').replace('\n', ' '),
            '; '.join(record.get('services') or []),
            '; '.join(str(e)[:120] for e in record.get('errors') or [])]))
    lines = [f"# Test results — {bundle.get('generated_at')}", '',
             f"Prompt: {bundle.get('prompt')}", '',
             '| ID | Scenario | Mode | Result | Actual |',
             '|---|---|---|---|---|']
    for record in rows:
        actual = str(record['actual']).replace('|', '\\|').replace('\n', ' ')
        lines.append(f"| {record['id']} | {record['scenario']} | "
                     f"{record['mode']} | {record['result']} | "
                     f"{actual[:200]} |")
    columns = st.columns(4)
    with columns[3]:
        if st.button('Build visual PDFs',
                     help='Renders four PDFs into artifacts/: one combined '
                          'report plus three themed ones (gateway, web '
                          'search, browser). Each themed report recomputes '
                          'its own headline and includes the cases shared '
                          'across all three, so it stands alone.'):
            import fm_report
            with st.spinner('Rendering…'):
                try:
                    built = {'combined': fm_report.build(bundle)}
                    built.update(fm_report.build_split(bundle))
                except Exception as exc:                # noqa: BLE001
                    st.error(f'{type(exc).__name__}: {exc}')
                    built = {}
            if built:
                st.session_state['fm_pdfs'] = built
        for label, where in (st.session_state.get('fm_pdfs') or {}).items():
            if where and os.path.exists(where):
                with open(where, 'rb') as handle:
                    st.download_button(
                        f'PDF — {label}', handle.read(),
                        file_name=os.path.basename(where),
                        mime='application/pdf', key=f'pdf_{label}')
    columns[0].download_button(
        'Download full artifact (JSON)',
        json.dumps(bundle, indent=2, default=str),
        file_name=f"testcases_{bundle.get('generated_at', 'run')}.json",
        mime='application/json',
        help='Everything: every case, every span, both research runs, the '
             'security suite. This is the evidence file.')
    columns[1].download_button(
        'Download results table (TSV)', '\n'.join(tsv),
        file_name='test_results.tsv', mime='text/tab-separated-values',
        help='Paste straight into a spreadsheet.')
    columns[2].download_button(
        'Download results (Markdown)', '\n'.join(lines),
        file_name='test_results.md', mime='text/markdown',
        help='For a ticket or a write-up.')


def _flow(bundle: Dict[str, Any]) -> None:
    """The end-to-end flow of the run the cases were evaluated against.

    Shown before the per-case detail because the question "what did it
    actually do, in order" comes before "did each assertion hold".
    """
    runs = bundle.get('runs') or {}
    labels = {'with_gateway': 'With Gateway', 'without_gateway': 'Without Gateway',
              'hosted_with_gateway': 'With Gateway (in Runtime)',
              'hosted_without_gateway': 'Without Gateway (in Runtime)'}
    available = [(key, run) for key, run in runs.items() if run]
    if not available:
        return
    st.markdown('### The flow these cases were evaluated against')
    chosen = st.radio('Execution', [labels.get(k, k) for k, _ in available],
                      horizontal=True, key='flow_pick')
    run = dict(available)[next(k for k, _ in available
                               if labels.get(k, k) == chosen)]
    st.caption(f"services: " + ', '.join(f'`{s}`' for s in
                                         run.get('services_invoked') or []))
    spans = ((run.get('trace') or {}).get('spans')
             or run.get('steps') or [])
    if spans:
        st.dataframe(
            [{'#': i, 'service': s.get('service'), 'api': s.get('api'),
              'status': s.get('status'), 'ms': s.get('duration_ms'),
              'enforced at': s.get('enforcement_point', '—'),
              'deciding policy': s.get('deciding_policy') or '—'}
             for i, s in enumerate(spans, start=1)],
            width='stretch', hide_index=True)
    note = (run.get('trace') or {}).get('trace_note')
    if note:
        st.caption(note)


def page_testcases() -> None:
    total = _case_total()
    st.title(f'Test cases TC01–TC{total:02d}')
    st.caption('Executed against real services. Four cases are reported '
               'BLOCKED rather than passed, with the measurement that blocks '
               'them — a green row for something this account cannot do would '
               'defeat the purpose of the exercise.')

    with st.form('testcase_run', border=True):
        options = _testcase_options()
        pressed = st.form_submit_button(f'Run all {total} test cases',
                                        type='primary')
    if pressed:
        _run_testcases(options['hosted'])
        return

    bundle = _pick('testcases_', 'Recorded test-case run')
    if not bundle:
        st.info('No recorded run yet. Press the button above, or run '
                '`python run_fm.py testcases` from a terminal — either way the '
                'result lands in `artifacts/` and appears here.')
        return

    summary = bundle['summary']
    columns = st.columns(4)
    columns[0].metric('Passed', summary['passed'])
    columns[1].metric('Failed', summary['failed'])
    columns[2].metric('Blocked', summary['blocked'])
    columns[3].metric('Total', summary['total'])
    if summary['failed']:
        st.warning(f"{summary['failed']} case(s) failed — see the rows marked "
                   f"FAIL.")
    if summary.get('blocked_ids'):
        st.info('Blocked: ' + ', '.join(summary['blocked_ids'])
                + ' — each one expands below with the measurement that '
                  'blocks it.')
    _exports(bundle)
    _flow(bundle)
    st.markdown('### Every case')

    icons = {'PASS': '✅', 'FAIL': '🛑', 'BLOCKED': '⛔', 'SKIP': '⏭️'}
    st.dataframe(
        [{'': icons.get(c['result'], ''), 'ID': c['id'],
          'Scenario': c['scenario'], 'Mode': c['mode'],
          'Expected': c['expected'], 'Actual': str(c['actual'])[:160],
          'Services': ', '.join(c.get('services') or [])}
         for c in bundle['cases']], width='stretch', hide_index=True)

    for record in bundle['cases']:
        with st.expander(f"{icons.get(record['result'], '')} {record['id']} — "
                         f"{record['scenario']}"):
            st.caption(f"**Mode:** {record['mode']}  ·  **Prompt:** "
                       f"{record['prompt']}")
            st.markdown(f"**Expected.** {record['expected']}")
            st.markdown(f"**Actual.** {record['actual']}")
            if record.get('blocked_reason'):
                st.error(f"Blocked: {record['blocked_reason']}")
            if record.get('note'):
                st.info(record['note'])
            if record.get('strategy_caveat'):
                st.info(record['strategy_caveat'])
            if record.get('errors'):
                st.markdown('**Errors**')
                for error in record['errors']:
                    st.code(str(error)[:400], language='text')
            spans = (record.get('trace') or {}).get('spans') or []
            if spans:
                st.markdown('**Trace**')
                st.dataframe([{'service': s.get('service'),
                               'api': s.get('api'), 'status': s.get('status'),
                               'ms': s.get('duration_ms'),
                               'policy': s.get('deciding_policy') or '—'}
                              for s in spans],
                             width='stretch', hide_index=True)
            for key in ('evidence', 'correlated', 'stages', 'comparison'):
                if record.get(key):
                    st.markdown(f'**{key.title()}**')
                    st.json(record[key], expanded=False)


# --------------------------------------------------------- page: architecture

def page_architecture() -> None:
    st.title('Architecture')
    st.markdown('''
### What Gateway actually does

An AgentCore Gateway is a **front door with a policy engine attached**. It
authenticates the caller, resolves the request to an action, evaluates Cedar
policies, and only then forwards the call to the backend. Three consequences
that matter more than the plumbing:

* **Deny by default.** A tool no policy covers is not merely refused — it is
  not even listed to the agent.
* **The decision is about the request, not just the caller.** Cedar reads the
  arguments, so a policy can bound *how* a tool is called, not only whether.
* **A denial names the rule.** That is the difference between an audit answer
  and a support ticket.

It is not a proxy for everything. It fronts the targets you give it, and some
AgentCore services have no target type at all.
''')
    st.markdown('### Mode A — Without Gateway')
    st.graphviz_chart(fm_diagrams.mode_a(), width='stretch')
    st.caption('Nothing in this path can refuse a call. The red edge is '
               'measured: there is no AWS web search off-gateway, and the '
               'public no-JS endpoints are JavaScript-gated, so in Runtime '
               'this path falls back to seeded sources and says so.')

    st.markdown('### Mode B — With Gateway')
    st.graphviz_chart(fm_diagrams.mode_b(), width='stretch')
    st.caption('Two enforcement points, on search and on memory. The browser '
               'hop stays amber in both diagrams for the same measured '
               'reason.')

    st.markdown('### Which service can be invoked which way')
    st.graphviz_chart(fm_diagrams.capability_matrix(), width='stretch')

    st.markdown('### How authentication and policy work here')
    st.markdown('''
| Hop | Authenticated by | Authorised by |
|---|---|---|
| Streamlit → Runtime | SigV4, the caller's IAM identity | IAM (`bedrock-agentcore:InvokeAgentRuntime`) |
| Runtime → Gateway | SigV4, the runtime's own role via **IMDS** (`BedrockAgentCore-<uuid>`) | Cedar on the gateway |
| Gateway → connector | the gateway execution role | IAM on that role |
| Agent → Browser | the runtime role | IAM only — no Cedar action exists |
| Agent → Bedrock | the runtime role | IAM |
| Agent → Memory (direct) | the runtime role | IAM only |
| Agent → Memory (gateway) | the runtime role | Cedar on the request body |

The gateway here is **`AWS_IAM` inbound**. `CUSTOM_JWT` would put a corporate
IdP in front and make the caller's JWT claims available to policy — that is the
path to per-user rules, and it cannot be demonstrated in this account because
`cognito-idp` is explicitly denied, so no OIDC provider can be created.
''')

    st.markdown('### Where to find these in the AWS console')
    st.caption('Probed live — press the button so nothing here is asserted '
               'without a check.')
    if st.button('Resolve console locations'):
        resources = fm_resources.resources(refresh=True)
        rows = [
            {'Resource': 'AgentCore Runtime (this project)',
             'Identifier': '—', 'Console': 'Bedrock AgentCore → Agent '
                                           'Runtimes'},
            {'Resource': 'Gateway — web search (borrowed)',
             'Identifier': resources.get('search_gateway', {}).get('id') or 'missing',
             'Console': 'Bedrock AgentCore → Gateways → Targets'},
            {'Resource': 'Gateway — memory FGAC (borrowed)',
             'Identifier': resources.get('memory_gateway', {}).get('id') or 'missing',
             'Console': 'Bedrock AgentCore → Gateways → Targets'},
            {'Resource': 'Policy engine (borrowed)',
             'Identifier': resources.get('memory_gateway', {}).get('policy_engine')
                           or 'missing',
             'Console': 'Bedrock AgentCore → Policy engines → Policies'},
            {'Resource': 'Memory (borrowed)',
             'Identifier': resources.get('memory', {}).get('id') or 'missing',
             'Console': 'Bedrock AgentCore → Memory'},
            {'Resource': 'Browser', 'Identifier': resources.get('browser', {}).get('id'),
             'Console': 'Bedrock AgentCore → Browser (AWS managed)'},
        ]
        try:
            import deploy_runtime
            runtime = deploy_runtime.status()
            rows[0]['Identifier'] = runtime.get('runtime_id') or 'not deployed'
            rows.append({'Resource': 'Runtime logs',
                         'Identifier': runtime.get('log_group') or '—',
                         'Console': 'CloudWatch → Log groups (one stream per '
                                    'session)'})
        except Exception:                               # noqa: BLE001
            pass
        st.dataframe(rows, width='stretch', hide_index=True)
        st.info(
            '**Observability, stated precisely.** CloudWatch has the runtime\'s '
            'per-session log streams and the gateway\'s invocation metrics. '
            'There are **no X-Ray traces**: Transaction Search is not enabled '
            'in this account. Every span this app shows is a client-side or '
            'agent-self-reported measurement, labelled as such, with the '
            'service-issued identifiers listed separately so they can be '
            'looked up.')


# -------------------------------------------------------------------- shell

PAGES = {
    'Ask the agent': page_ask,
    'Compare modes': page_compare,
    'Security & FGAC': page_security,
    'Test cases': page_testcases,
    'Architecture': page_architecture,
}


def main() -> None:
    sidebar()
    page = st.sidebar.radio('Page', list(PAGES))
    PAGES[page]()


main()
